// -----------------------------------------------------------------------------
// rMate Chart H5 License Key 
//
// Product Name : rMate Chart for HTML5 v6.0
// License Type : Enterprise Trial License
// Product No : EB60-29A5-BF18-A17J
// Authenticated server Info : undefined
// Expiration date : 2022/12/31
//
var rMateChartH5License = "f011935378e389238d84c4526a37cd76fb15d4adb7690d2566ff242f97176660:3900610b3548443a4f4220504c20564a3a3732312e41302d2038503156463a42432d35352d4145394e322d2d36302e3630422d45453a564c41204c312033452f4c323a31742f203243323a303232303a32453220302a393a334830";
// -----------------------------------------------------------------------------

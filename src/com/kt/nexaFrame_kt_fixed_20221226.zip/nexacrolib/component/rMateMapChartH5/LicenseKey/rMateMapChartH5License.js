<!--
// -----------------------------------------------------------------------------
// rMate MapChart License Key 
//
// Product Name : rMate MapChart for HTML5 v5.5
// License Type : Enterprise Trial License
// Product No : 968A-71C4-1011-AA8V
// Authenticated server Info : undefined
// Expiration Date : 2023/01/31
//
var rMateMapChartH5License ="635c5545aa765a7ec4aa27ce98e77b78a41f8b8514572e7a9b5698e05974344c:3100630b343a484244504f2020564c3856413a41322d2e31303120305031562d3a344d4335312d37352d2e4135382d364539563a414c4c20203145334c2f3a317430202f43333a3232303032323a32453120302a323a3848";
// -----------------------------------------------------------------------------
// -->
/**
*  @Desction   Uitlity
*  @Creator    김용학
*  @CreateDate 2020.04.23
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2019.XX.XX			XXXXX					XXXXXXXXXXXXXXXXXXXXXXXXX
*******************************************************************************
*/

var pForm = nexacro.Form.prototype;

//------------- null 관련 함수
//
/**
* @class 값이 존재하는지 여부 체크 <br>
* @param {String} sValue	
* @return {Boolean} true/false
* @example
* var bNull = this.gfnIsNull("aaa");	// false
*/
pForm.gfnIsNull = function(sValue)
{
    if (sValue == undefined) {
		return true;
	}
    if (sValue == null) {
		return true;
	}
    var strValue = new String(sValue);
    if (strValue.length == 0) {
		return true;
	}
    return false;
};
/**
* @class argument로 넘어온 컬럼에 존재 하는지 검증
* @param {String} sValue	(문장 기술시 부정문장보다 긍정문장 기술로 script분석을 빠르게 하기 위함임)
*/
pForm.gfnIsExist = function(sValue)
{
	if (this.gfnIsNull(sValue))
		return false;
	else
		return true;
}

pForm.gfnIsNotNull = function(sValue)
{
	if (this.gfnIsNull(sValue))
		return false;
	else
		return true;
};


/**
* @class dataset 건수 조회
*/
pForm.gfnSetDataCnt = function(objStatic, obj)
{
	var cnt;
	if (obj instanceof nexacro.NormalDataset) {
		cnt = obj.getRowCount();
	} else {
		cnt = obj;
	}
	cnt = this.gfnAppendComma(cnt) + " 건";
		
	objStatic.set_text(cnt);
	this.resetScroll();
}

/**
* @class Dataset의 특정row의 모든 컬럼값을 json객체로 만들기 <br>
* @param {Object} objDs - 작업dataset
* @param {number} row   - 생성한row
* @return {Object} json object
* @example
*            //1. ds를 이용해서 json 생성
*            var obj = this.gfnCreateJsonWithDs(this.ds_nm, 1);
*            //2. json객체값 얻기  (obj.컬럼명)
*            trace(obj.empId);
*            trace(obj.empNm);
*/
pForm.gfnCreateJsonWithDs = function(objDs, row)
{
	var oData = {};
	var colCnt = objDs.colcount;
	for(var idx=0; idx<colCnt; idx++)
	{
		var val = objDs.getColumn(row, objDs.getColID(idx));
		val = this.gfnIsNull(val) ? "" : val.toString();  //BIGDECIMAL, DATE 형일 경우 때문에 toString()처리
		oData[objDs.getColID(idx)] = val;
	}
	return oData;
}

/**
* @gubn  json
* @class Dataset의 특정row의 모든 컬럼값을 json객체로 만들기 <br>
* @param {Object} objDs - 작업dataset
* @param {number} row   - 생성한row
* @return {Object} json object
* @example   
*            //1. ds를 이용해서 json 생성
*            var obj = this.gfnCreateJsonWithDs(this.ds_nm, 1);
*            //2. json객체값 얻기  (obj.컬럼명)
*            trace(obj.empId);
*            trace(obj.empNm);
*/
// pForm.gfnCreateJsonWithDs = function(objDs, row)
// {
// 	var oData = {};
// 	var colCnt = objDs.colcount;
// 	for(var idx=0; idx<colCnt; idx++)
// 	{
// 		oData[objDs.getColID(idx)] = objDs.getColumn(row, objDs.getColID(idx));
// 	}
// 	return oData;
// }

/**
* @gubn  json
* @class Dataset의 특정 from~to row의 모든 컬럼값을 json객체로 만들기 <br>
* @param {Object} objDs   - 작업dataset
* @param {number} fromRow - 시작row
* @param {number} toRow   - 종료row
* @return{Object} json object
* @example   
*            //1. ds를 이용해서 json 생성
*            var obj = this.gfnCreateJsonWithDsN(this.ds_nm, 0, 1);
*            //2. json객체를 trace하고 싶은 경우
*            //var obj_s = JSON.stringify(obj, null, "\t");
*            //trace(obj_s);
*            //3. json객체값 얻기  (obj["row"]["컬럼명"])
*            trace(obj["0"]["aa"]);
*            trace(obj["1"]["dd"]);
*/
pForm.gfnCreateJsonWithDsN = function(objDs, fromRow, toRow)
{
	var oData = {};
	var colCnt = objDs.colcount;
	var insRow=0;
	for(var row=fromRow; row<=toRow; row++)
	{
		var oOne = {};
		for(var idx=0; idx<colCnt; idx++)
		{
			oOne[objDs.getColID(idx)] = objDs.getColumn(row, objDs.getColID(idx));
		}
		oData[insRow] = oOne;
		insRow ++;
	}
	return oData;
}





/**
* @class 전화번호 형태의 문자열 return
* @param {string} str -없는 숫자
*/
pForm.gfnPhonNumStr = function(str)
{
	var RegNotNum  = /[^0-9]/g;
	var RegPhonNum = "";
	var DataForm   = "";

	// return blank    
	if( str == "" || str == null ) return "";

	// delete not number
	str = str.replace(RegNotNum,'');

	/* 4자리 이하일 경우 아무런 액션도 취하지 않음. */
	if( str.length < 4 ) return str;

	/* 지역번호 02일 경우 10자리 이상입력 못하도록 제어함. */
	if(str.substring(0,2)=="02" && str.length > 10){
		str = str.substring(0, 10);
	}

	if( str.length > 3 && str.length < 7 ) {
		if(str.substring(0,2)=="02"){
			DataForm = "$1-$2";
			RegPhonNum = /([0-9]{2})([0-9]+)/;
		} else {
			DataForm = "$1-$2";
			RegPhonNum = /([0-9]{3})([0-9]+)/;
		}
	} else if(str.length == 7 ) {
		if(str.substring(0,2)=="02"){
			DataForm = "$1-$2-$3";
			RegPhonNum = /([0-9]{2})([0-9]{3})([0-9]+)/;
		} else {
			DataForm = "$1-$2";
			RegPhonNum = /([0-9]{3})([0-9]{4})/;
		}
	} else if(str.length == 8 ) {
		if(str.substring(0,2)=="02"){
			DataForm = "$1-$2-$3";
			RegPhonNum = /([0-9]{2})([0-9]{3})([0-9]+)/;
		} else {
			DataForm = "$1-$2";
			RegPhonNum = /([0-9]{4})([0-9]{4})/;
		}
	} else if(str.length == 9 ) {
		if(str.substring(0,2)=="02"){
			DataForm = "$1-$2-$3";
			RegPhonNum = /([0-9]{2})([0-9]{3})([0-9]+)/;
		} else {
			DataForm = "$1-$2-$3";
			RegPhonNum = /([0-9]{3})([0-9]{3})([0-9]+)/;
		}
	} else if(str.length == 10){
		if(str.substring(0,2)=="02"){
			DataForm = "$1-$2-$3";
			RegPhonNum = /([0-9]{2})([0-9]{4})([0-9]+)/;
		}else{
			DataForm = "$1-$2-$3";
			RegPhonNum = /([0-9]{3})([0-9]{3})([0-9]+)/;
		}
	} else if(str.length > 10){
		if(str.substring(0,2)=="02"){
			DataForm = "$1-$2-$3";
			RegPhonNum = /([0-9]{2})([0-9]{4})([0-9]+)/;
		}else{
			DataForm = "$1-$2-$3";
			RegPhonNum = /([0-9]{3})([0-9]{4})([0-9]+)/;
		}
	} else { 
		if(str.substring(0,2)=="02"){
			DataForm = "$1-$2-$3";
			RegPhonNum = /([0-9]{2})([0-9]{3})([0-9]+)/;
		}else{
			DataForm = "$1-$2-$3";
			RegPhonNum = /([0-9]{3})([0-9]{3})([0-9]+)/;
		}
	}

	while( RegPhonNum.test(str) ) { 
		str = str.replace(RegPhonNum, DataForm); 
	}

	return str;
}






/**
* @class argument로 넘어온 컬럼에 존재 하는지 검증
* @param {String} sValue	(문장 기술시 부정문장보다 긍정문장 기술로 script분석을 빠르게 하기 위함임)
*/
pForm.gfnIsExist = function(sValue)
{
	if (this.gfnIsNull(sValue))
		return false;
	else
		return true;
}

/**
* @class argument로 넘어온 값이 true 또는 false인지 여부
* @param {boolean} b : boolean 값
*/
pForm.gfnIsTF = function(b)
{
	return ((b == true || b == false) ? true : false);
}

/**
* @class 값이 존재하는지 여부 체크 (trim 후 체크) <br>
* @param {String} sValue	
* @return {Boolean} true/false
* @example
* var bNull = this.gfnIsNull("aaa");	// false
*/
pForm.gfnIsTrimNull = function(sValue)
{
    if (sValue == undefined) {
		return true;
	}
    if (sValue == null) {
		return true;
	}    
    var strValue = new String(sValue);
    if (strValue.length == 0) {
		return true;
	}
	if (strValue.trim().length == 0) {
		return true;
	}
    return false;
};


/**
* @class 입력값을 체크하여 Null인경우 지정한 값을 리턴 <br>
* @param {String} chkVal   - 검색할 값
* @param {String} nullVal	- Null인경우 대치값
* @return {String} 입력값이 Null인경우 지정한값, Null이 아닌경우 입력값
*/
pForm.gfnNvl = function(chkVal, nullVal)
{
	return (this.gfnIsNull(chkVal) ? (this.gfnIsNull(nullVal) ? "" : nullVal) : chkVal);
};

/**
* @class	입력값이 Boolean 값인지 여부를 판별한다.
* @param 	{object}  판별대상 Object
* @return 	{boolean} boolean 이면 true 아니면 false 를 리턴한다.
*/
pForm.gfnIsBoolean = function(obj)
{
    var strvalue = obj + "";

    if (strvalue == "true" || strvalue == "false") {
        return true;
	} else {
        return false;
	}

};

/**
* @class   Grid에서 expression으로  표현할때 decode 문처럼 사용할 수 있는 기능
* @param  N/A 
* @return  {String} varRtnValue - 반환된 무자열
* @example
* this.gfnDecode();	
*/
pForm.gfnDecode = function(){

    var condVal = (arguments[0]==undefined)?null:arguments[0];

    for(var i = 1 ; i < arguments.length; i+=2 )
	{
		if(i + 1 == arguments.length) return arguments[i];

		if(condVal == arguments[i]) {
			return arguments[i+1];
		}
	}
	return arguments[i-2];
}

// pForm.gfnDecode = function ()
// {
// 	var varRtnValue = null;
// 
// 	var arrArgument = this.gfnDecode.arguments;
// 	var varValue = arrArgument[0];
// 	var bIsDefault = false;
// 	var nCount = 0;
// 
// 	if ((arrArgument.length % 2) == 0) {
// 		nCount = arrArgument.length - 1;
// 		bIsDefault = true;
// 	} else {
// 		nCount = arrArgument.length;
// 		bIsDefault = false;
// 	}
// 
// 	for (var i = 1; i < nCount; i += 2) {
// 		if (varValue == arrArgument[i]) {
// 			varRtnValue = arrArgument[i + 1];
// 			i = nCount;
// 		}
// 	}
// 
// 	if (varRtnValue == null && bIsDefault) {
// 		varRtnValue = arrArgument[arrArgument.length - 1];
// 	}
// 	
// 	return varRtnValue;
// };

/**
* @class arg0 번째값이 arg1~n 값중 하나인지 여부
* @param arg0   : 주메인비교값
*        arg1~n : 비교할 값들
* @rtn   true/false (동일한게 존재 하는지 여부)
* @exam  gfnIsEqual("dev", "local", "prod");   // 뒤쪽 2개의 arg값들중에 arg0 번째 값과 동일한게 있는지 여부
*        gfnIsEqual("dev", "local", "dev");
*/
pForm.gfnIsEqual = function()
{
    var mainVal = "," + arguments[0] + ",";
	var chkVal =  ",";
	for(var i=1; i<arguments.length; i++) {
		chkVal += arguments[i] + ",";
	}
	return (chkVal.indexOf(mainVal) >= 0 ? true : false);
}


//----------------------배열
/**
* @gubn  Array
* @class 배열에 해당 값이 존재하는지 확인한다. <br>
* @param {Array} arrVal
* @param {String} varVal - 값
* @return {Boolean} 배열에 존재여부
*/
pForm.gfnIsExistInArray = function(arrVal, varVal) 
{
	var retVal = false;
	var nCnt = arrVal.length;
	for (var i = 0; i < nCnt; i++) {
		if (arrVal[i] == varVal) {
			retVal = true;
			break;
		}
	}

	return retVal;
};

/**
* @gubn  Array
* @class  원하는 위치의 항목을 배열에서 삭제 처리한다.
* @param {Array} array remove 대상 Array.
* @param {Number} index remove하고자 하는 item index.
* @example
* var mon = ["Jan","Feb","Mar","Apr"];
* trace("mon==>" + mon);	// output : mon==>["Jan","Mar","Apr"]
*/
pForm.gfnRemoveAt = function(array, index) 
{
	array.splice(index, 1);
};


/**
* @gubn  Array
* @class 지정된 항목이 배열에 포함되어 있는지 확인한다.
* @param {Array} array 검색 대상 Array.
* @param {Object} item 찾고자 하는 Item.
* @param {Boolean} strict true: 형변환 없이 비교('==='), false: 형변환 후 비교('==') (default: false).
* @return {Boolean} 포함되어 있다면 true, 없다면 false를 리턴.
* @example
* var mon = ["Jan","Feb","Mar","Apr"];
* var contain = this.gfnContains(mon, "Mar");
* trace("contain==>" + contain);	// output : contain==>true
* var contain = this.gfnContains(mon, "May");
* trace("contain==>" + contain);	// output : contain==>false
*/
pForm.gfnContains = function(array, item, strict) 
{
	if (this.gfnIndexOf(array, item, null, strict) === -1) {
		return false;
	} else {
		return true;
	}
};


/**
* @gubn  Array
* @class 지정된 항목이 처음 나오는 배열 위치를 반환한다. 
* @param {Array} array 검색 대상 Array.
* @param {Object} item 찾고자 하는 Item.
* @param {Number} from 검색의 시작 위치 (default: 0).
* @param {Booleans} strict true: 형변환 없이 비교('==='), false: 형변환 후 비교('==') (default: false).
* @return {Number} 검색된 배열 위치. 없다면 -1 리턴.
* @example
* var mon = ["Jan","Feb","Mar","Apr"];
* var index = this.gfnIndexOf(mon, "Mar");
* trace("index==>" + index);	// output : index==>2
* var index = this.gfnIndexOf(mon, "May");
* trace("index==>" + index);	// output : index==>-1
*/
pForm.gfnIndexOf = function(array, item, from, strict) 
{
	var len = array.length;
	if (from == null) {
		from = 0;
	}
	strict == !!strict;
	from = (from < 0) ? Math.ceil(from) : Math.floor(from);
	if (from < 0) {
		from += len;
	}
	
	if (strict) {
		for (; from < len; from++) {
			if (array[from] === item) {
				return from;
			}
		}
	} else {
		for (; from < len; from++) {
			if (array[from] == item) {
				return from;
			}
		}
	}
	
	return -1;
};


//--------------------------기타
/**
* @class  alphabet character code.
* charvalue값 => [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, a, b, c, d, e, f]
*/
pForm._ALPHA_CHAR_CODES = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102]

/**
* @class  유일한 ID 를 반환
* @param {String} prefix id 앞에 붙일 문자열
* @param {String} separator id 생성시 구분용 문자(default: '-' ).
* @return {String} id
* @example
* trace(this.gfnGetUniqueId()); 
* // output : 3e52d1f6-f0d2-4970-a590-ba7656b07859
* 
* trace(this.gfnGetUniqueId("Button_")); 
* // output : Button_4e601da1-63f4-4cfa-849b-01b8a7f14d40
* 
* trace(this.gfnGetUniqueId("", "_")); 
* // output : 4e601da1_63f4_4cfa_849b_01b8a7f14d40
* 
* trace(this.gfnGetUniqueId("Button_", "_")); 
* // output : Button_4e601da1_63f4_4cfa_849b_01b8a7f14d40
*/
pForm.gfnGetUniqueId = function(prefix, separator)
{
	if (this.gfnIsNull(prefix)) {
		prefix = "";
	}
	if (this.gfnIsNull(separator)) {
		separator = 45;
	} else {
		separator = separator.charCodeAt(0);
	}
	
	var pThis = this,
		charcode = this._ALPHA_CHAR_CODES,
		math = Math;
	var seq = 0;
	var seq0;
	var tmpArray = new Array(36);
	var idx = -1;
	
	while (seq < 8) {
		tmpArray[++idx] = charcode[math.random() * 16 | 0];
		seq++;
	}
	seq = 0;
	while (seq < 3) {
		tmpArray[++idx] = separator;//45 => "-", 95=> "_"
		seq0 = 0;
		while (seq0 < 4) {
			tmpArray[++idx] = charcode[math.random() * 16  | 0];
			seq0++;
		}
		seq++;
	}
	tmpArray[++idx] = separator; //45 => "-", 95=> "_"
	
	var tmpStr = (new Date()).getTime();
	tmpStr = ("0000000" + tmpStr.toString(16)).substr(-8);
	seq = 0;
	while (seq < 8) {
		tmpArray[++idx] = tmpStr.charCodeAt(seq);
		seq++;
	}
	seq = 0;
	while (seq < 4) {
		tmpArray[++idx] = charcode[math.random() * 16 | 0];
		seq++;
	}
	return prefix + String.fromCharCode.apply(null, tmpArray);
};

/**
* @class 로그 출력 (local/dev만 출력)
* @param  msg 로그 출력 문자열, json객체등
*/
pForm.gfnLog = function(msg, sType)
{
	if (this.gfnIsEqual(this.gfnGetEnvVar("evSvrType"), "prod")) {
		return;
	}
	
	if(this.gfnIsNull(sType))	sType = "debug";
	
	if (system.navigatorname == "nexacro") {
		if (msg instanceof Object) {
			for(var x in msg) {
				trace(x + " : " + msg[x]);
			}
		} else {
			trace(msg);
		}
	} else {
		console.log(msg);
	}
}

/**
* @class 체크할 값이 "[]"포함하면 true/ 포함하지 않으면 false를 return한다. <br>
* @param {String} sValue	
* @return {Boolean} true/false
*/
pForm.gfnIsCode = function(sValue) {
	var isResult = false;
	
	if(this.gfnIsNotNull(sValue)) {	
		var sValue = this.gfnNvl(sValue, "");
		var nLength = sValue.length;
		var nCkCnt  = 0;
		var sFirstYn = "";
		
		for(var i = 0; i < nLength; i++) {
			var sChar = sValue.charAt(i);
			if((i == 0) && (sChar == "[")) {
				sFirstYn="Y";
			}
			if(sChar == "]") {
				nCkCnt += 1;
			}
		}
		
		// true 인경우 문자열 첫번째가 "["로 시작하고 "]" 문자열이 존재하는 경우
		if(sFirstYn == "Y" && nCkCnt > 0){
			isResult = true;
		}
	}
	return isResult;
}

/**
* @class  입력된 실수를 표현법으로 표현하는 함수
* @param {String} value 쌍따옴표를 붙일 문자열.
* @param {Boolean} multi ,를 기준으로 멀티로 Quote를 할지 여부 Default false
* @return {String} 쌍따옴표가 붙여진 문자열.
*/
pForm.gfnQuote = function(value, multi)
{
	value = this.gfnNvl(value, "");
	multi = this.gfnNvl(multi, false);
	if (this.gfnIsEmpty(value))
	{
		return nexacro.wrapQuote("");
	}
	value = value + "";
	if(multi)
	{
		var o = value.replace(/ /gim, "");
		o = o.split(",");
		for ( var i in o)
		{
			if (typeof (o[i]) == "string" && o[i] == "undefined")
			{
				o[i] = "";
			}
			o[i] = nexacro.wrapQuote(o[i]);
		}
		value = o.join(",");
	}
	else
	{
		value = nexacro.wrapQuote(value);
	}
	return value;
};

/**
* tabpage index 얻기
*/
pForm.gfnGetPageIndex = function(objTab, pageId)
{
	var cnt = objTab.getTabpageCount(); //또는 objTab.tabpages.length
	for(idx=0; idx<cnt; idx++)
	{
		if (objTab.tabpages[idx].id == pageId) return idx  //또는 objTab.tabpages[idx].name
	}
	return -1;
}

/**
* @class 첫 값의 True/False를 검사해 그 결과에 따라 두번째 또는 세번째 값을 Return 하는 함수
* @param {Variant} value 비교할 값. value의 값으로 True/False 여부를 확인합니다. value가 Integer인경우 0이면 False아니면 True인식합니다.
* @param {Variant} varTrue   value가 True 에 해당하는 값일 경우 Return 되는 값.
* @param {Variant} varFalse value가 False 에 해당하는 값일 경우 Return 되는 값.
* @return {Variant} value에 따라 Return 된 값.
*/
pForm.gfnIif = function(value, varTrue, varFalse)
{
   var argc = arguments.length;
   if (argc != 3)
   {
      return false;
   }
   return (value | false) ? varTrue : varFalse;
};

/**
* @class  문자열에 있는 모든 영어를 대문자로 바꾸는 함수
* @param {String} value 영문자를 모두 대문자로 바꿀 문자열.
* @return {String} 영어 대문자와 다른 문자로 구성된 문자열.
*/
pForm.gfnToUpper = function(value)
{
   if (this.gfnIsNull(value) == true || this.gfnIsEmpty(value) == true)
   {
      return value;
   }
   if (typeof (value) == "object")
   {
      value = value.valueOf();
   }
   return String(value).toUpperCase();
};

/**
* @class  문자열에 있는 모든 영어를 소문자로 바꾸는 함수
* @param {String} value 영문자를 모두 소문자로 바꿀 문자열.
* @return {String} 영어 소문자와 다른 문자로 구성된 문자열.
*/
pForm.gfnToLower = function(value)
{
   if (this.gfnIsNull(value) == true || this.gfnIsEmpty(value) == true)
   {
      return value;
   }
   if (typeof (value) == "object")
   {
      value = value.valueOf();
   }
   return String(value).toLowerCase();
};

/**
* @class  문자열에 있는 모든 영어를 소문자로 바꾸는 함수
* @param {String} value 영문자를 모두 소문자로 바꿀 문자열.
* @return {String} 영어 소문자와 다른 문자로 구성된 문자열.
*/
pForm.gfnToLower = function(value)
{
   if (this.gfnIsNull(value) == true || this.gfnIsEmpty(value) == true)
   {
      return value;
   }
   if (typeof (value) == "object")
   {
      value = value.valueOf();
   }
   return String(value).toLowerCase();
};

/**
* @class 한글만으로 되어 있는지 Check한다. <br>
* @param {String} strValue
* @return {Boolean}
*/
pForm.gfnIsKoreanChar = function(strValue)
{
	var retVal = true;

	for (i = 0; i < strValue.length; i++){
		if (!((strValue.charCodeAt(i) > 0x3130 && strValue.charCodeAt(i) < 0x318F) || (strValue.charCodeAt(i) >= 0xAC00 && strValue.charCodeAt(i) <= 0xD7A3))){
			retVal = false;
		}
	}

	return retVal;
};

/**
* @class 특수문자가 있는지 Check한다. <br>
* @param {String} strValue
* @return {Boolean}
*/
pForm.gfnIsSpecialChar = function(strValue)
{
	var retVal = false;
	if(strValue.search(/\W|\s/g) > -1) retVal = true;

	return retVal;
};

/**
* @class 주민등록번호 여부를 확인한다. <br>
* @param {String} sJuminNo - 입력문자열(주민번호 13자리)
* @return {Boolean}
*/
pForm.gfnIsSSN = function(sJuminNo)
{
	var birthYear = this.gfnGetBirthYear(sJuminNo);

	birthYear += sJuminNo.substr(0, 2);
	var birthMonth = sJuminNo.substr(2, 2)-1;
	var birthDate = sJuminNo.substr(4, 2);
	var birth = new Date(birthYear, birthMonth, birthDate);

	if ( birth.getYear() % 100 != sJuminNo.substr(0, 2) ||
		birth.getMonth() != birthMonth ||
		birth.getDate() != birthDate)
	{
		return false;
	}

	// Check Sum 코드의 유효성 검사
	buf = new Array(13);
	for (i = 0; i < 6; i++) buf[i] = parseInt(sJuminNo.charAt(i));
	for (i = 6; i < 13; i++) buf[i] = parseInt(sJuminNo.charAt(i));

	multipliers = [2,3,4,5,6,7,8,9,2,3,4,5];
	for (i = 0, sum = 0; i < 12; i++) sum += (buf[i] *= multipliers[i]);

	if ((11 - (sum % 11)) % 10 != buf[12]) {
		return false;
	}else{
		return true;
	}
};

/**
* @class 외국인 등록번호 여부를 확인한다. <br>
* @param {String} strNo - 입력문자열(등록번호13자리)
* @return {Boolean}
*/
pForm.gfnIsFrnrIdNo = function(strNo)
{
	if (strNo.length != 13 || !isNumber(strNo)) return false;

	var month = Number(strNo.substr(2, 2));
	var day	  = Number(strNo.substr(4, 2));

	if (month < 1 || month > 12) return false;
	if (day < 1 || day > 31) return false;

	var sum = 0;
	var odd = 0;
	var buf = array(13);
	var multipliers = [2,3,4,5,6,7,8,9,2,3,4,5];

	for (var i=0; i<13; i++) {
		buf[i] = Number(strNo.charAt(i));
	}

	if (buf[11] < 6) return false;

	odd = buf[7] * 10 + buf[8];
	if((odd%2) != 0) return false;

	for (var i=0; i<12; i++) {
		sum += (buf[i] * multipliers[i]);
	}

	sum = 11 - (sum % 11);

	if (sum >= 10) sum -= 10;
	sum += 2;
	if (sum >= 10) sum -= 10;

	if (buf[12] == sum) {
		return true;
	} else {
		return false;
	}
};

/**
* @class 사업자 등록번호 여부를 확인한다.
* @param {String} strCustNo - 입력문자열(등록번호10자리)
* @return {Boolean}
*/
pForm.gfnIsBzIdNo = function(strCustNo)
{
	if (strCustNo.length != 10) return false;
	else {

		var checkID = new Array(1, 3, 7, 1, 3, 7, 1, 3, 5, 1);
		var tmpcustNo, i, chkSum=0, c2, remander;

		for (i=0; i<=7; i++) chkSum += checkID[i] * strCustNo.charAt(i);

		c2 = "0" + (checkID[8] * strCustNo.charAt(8));
		c2 = c2.substring(c2.length - 2, c2.length);

		chkSum += Math.floor(c2.charAt(0)) + Math.floor(c2.charAt(1));

		remander = (10 - (chkSum % 10)) % 10 ;

		if (Math.floor(strCustNo.charAt(9)) == remander) return true; // OK!
		return false;
	}

	return true;
};

/**
* @class 법인 등록번호 여부를 확인한다. <br>
* @param {String} strNo - 입력문자열(법인번호13자리)
* @return {Boolean}
*/
pForm.gfnIsFirmIdNo = function(strNo)
{
	if (strNo.length != 13 || !isNumber(strNo)) return false;

	var sum = 0;
	var buf = new Array(13);
	var multipliers = [1,2,1,2,1,2,1,2,1,2,1,2];

	for (var i=0; i<13; i++) {
		buf[i] = Number(strNo.charAt(i));
	}

	for (var i=0; i<12; i++) {
		sum += (buf[i] * multipliers[i]);
	}

	sum = (10 - (sum % 10)) % 10;

	if (buf[12] == sum) {
		return true;
	} else {
		return false;
	}
};

/**
* @class 신용카드번호 여부를 확인한다. <br>
* @param {String} strNo - 카드번호16자리
* @return {Boolean}
*/
pForm.gfnIsCardNo = function(strNo)
{
	if (strNo.length < 13 || strNo.length > 19 || !nexacro.isNumeric(strNo)) return false;

	var sum = 0;
	var buf = new Array();

	for (var i=0; i<strNo.length; i++) {
		buf[i] = Number(strNo.charAt(i));
	}

	var temp;
	for (var i=buf.length-1, j=0; i>=0; i--, j++) {
		temp = buf[i] * ((j%2) + 1);
		if (temp >= 10) {
			temp = temp - 9;
		}
		sum += temp;
	}

	if ((sum % 10) == 0) {
		return true;
	} else {
		return false;
	}
};

/**
* @class 이메일 형식에 맞는지 Check한다.
* @param {String} strValue
* @return {Boolean}
*/
pForm.gfnIsEmail = function(strValue)
{
	var retVal = false;
	var sTmp = "";
	var sRegExp = "[a-z0-9]+[a-z0-9.,_]+@[a-z0-9]+[a-z0-9.,_]+\\.[a-z0-9]+";

	var regexp = new RegExp(sRegExp,"ig");
	sTmp = regexp.exec(strValue);

	if (sTmp == null) {
		retVal = false;
	}
	else {
		if (( sTmp.index == 0 ) && (sTmp[0].length == strValue.length )) {
			retVal = true;
		} else {
			retVal = false;
		}
	}
	return retVal;
};


/**
* @class 정규식 형식에 맞는지 Check한다.
* @param {String} strValue
* @param {String} strRegExp
* @param {String} strFlags
* @return {Boolean}
*/
pForm.gfnIsRegExp = function(strValue, sOption)
{
	var retVal = false;
	var sTmp = "";

	var sRegExp, sFlags;
	var arrOption = sOption.split(':');
	if (arrOption.length > 1) {
		sRegExp = arrOption[0];
		sFlags = arrOption[1];
	} else {
		sRegExp = sOption;
	}

	var regexp;
	if (sFlags) {
		regexp = new RegExp(sRegExp, sFlags);
	} else {
		regexp = new RegExp(sRegExp);
	}
	sTmp = regexp.exec(strValue);

	if (sTmp == null) {
		retVal = false;
	} else {
		retVal = true;
	}
	return retVal;
};


/**
* @class 실행되는 장비가 모바일 기기인지 판단. <br>
* @param 없음
* @return {Boolean} 모바일 기기 여부
*/
pForm.gfnIsMobile = function ()
{
	var UserAgent = navigator.userAgent;

	if (UserAgent.match(/iPhone|iPod|Android|Windows CE|BlackBerry|Symbian|Windows Phone|webOS|Opera Mini|Opera Mobi|POLARIS|IEMobile|lgtelecom|nokia|SonyEricsson/i) != null || UserAgent.match(/LG|SAMSUNG|Samsung/) != null)
	{
		return true;
	} else {
		return false;
	}
}
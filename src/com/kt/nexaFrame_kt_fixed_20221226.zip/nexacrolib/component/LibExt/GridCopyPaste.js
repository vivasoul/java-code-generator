﻿/**
*  @FileName 	GridCopyPaste.js 
*/
var pForm = nexacro.Form.prototype;

/**
*******************************************************************************
*  2019.11.06  tobenana   최초 생성
*  2020.05.21  농부지기  row, multirow 추가
*******************************************************************************
*/ 

pForm.colSeperator = "	"; //"	" : tab key (cell과 cell간에 구분자)

/**************************************************************************
 * 사용자 FUNCTION 영역
 **************************************************************************/
/**
* @desc  form onload : gfnSetGridCopyPaste --> set copy paste grid component
* @param objForm : form,
*   objConfig : {objGrid}
*/
pForm.gfnSetGridCopyPaste = function (objForm, objGrid)
{
	var objConfig = { objGrid : objGrid};
	objForm.config = objConfig;

	if (system.navigatorname == "nexacro" || system.navigatorname == "IE" && system.navigatorversion < 12) {
		//objForm.config.colSeperator = this.colSeperator;  
		objForm.config.targetGrid = null; 

		objForm.config.objGrid.addEventHandler("onkeydown", this._gfnGrdCopyPasteStateChk, objForm);
		objForm.config.objGrid.addEventHandler("onkeyup"  , this._gfnGrdCopyPaste        , objForm);  
	} else {
		//objForm.config.colSeperator = this.colSeperator;
		objForm.config.targetGrid  = undefined;
		objForm.config.targetEvent = undefined;
		
		objForm.addEventHandler("ontimer", this._gfnBlinkTimerHandler, objForm); 
		objForm.config.objGrid.addEventHandler("onkeydown", this._gfnGrdCopyPasteEtc, objForm);
	}
}

/**
* @desc  paste data : setPasteData --> set copy paste grid component
* @param clipText
*/
pForm.gfnSetPasteData =  function(objForm,clipText)
{
	//var pThis = objForm;
	var obj = objForm.config.targetGrid;
	var e = objForm.config.targetEvent;

	obj.set_enableevent(false);
	obj.set_enableredraw(false); 

	var ds = obj.getBindDataset();
	ds.set_enableevent(false); 

	var grdCellCount = obj.getCellCount("body");
	var rowCount = ds.getRowCount();

	var objRowCol = this.gfnGetGridSelRowCol(obj);
	var startrow = objRowCol.selectstartrow;
	var endrow   = objRowCol.selectendrow;
	var startcol = objRowCol.selectstartcol;
	var endcol   = objRowCol.selectendcol; 

	var currRow = startrow;
	var cellIndex = startcol;

	copyData = clipText;
	//var seperator = objForm.config.colSeperator;

	var rowData = copyData.split(/[\n\f\r]/); 
	var rowDataCount = rowData.length - 1;
	var checkIndex = {}; 

	for (var i = 0; i < rowDataCount; i++) {
		if(rowCount <= currRow) {
			ds.addRow();
		}

		var columnData = rowData[i].split(this.colSeperator);
		var columnLoopCount = cellIndex + columnData.length;

		if(columnLoopCount > grdCellCount) {
			columnLoopCount = grdCellCount;
		}

		var k = 0;
		for(var j = cellIndex; j < columnLoopCount; j++) {
			var colid = obj.getCellProperty("body", j, "text").substr(5);
			var tempValue = columnData[k];
			if(!this.gfnIsNull(tempValue)) {
				ds.setColumn(currRow, colid, tempValue);
			}
			k++;
		}
		currRow++;
	}  

	ds.rowposition = currRow; 

	endrow = endrow + rowDataCount - 1;
	endcol = columnLoopCount - 1;  

	obj.set_enableredraw(true);
	obj.set_enableevent(true);
	ds.set_enableevent(true); 

	obj.selectArea(startrow, startcol, endrow, endcol);

	objForm.config.targetEvent = undefined;   
}

/**
* @desc  create textarea : gfnCreateElementTextarea --> create document innerhtml : textarea
* @param clipText
*/
pForm.gfnCreateElementTextarea = function(innerText)
{
	var txtValue = document.createElement('textarea');
	txtValue.style.position = 'absolute';
	txtValue.style.left = '-1000px';
	txtValue.style.top = document.body.scrollTop + 'px';
	txtValue.value = innerText;
	document.body.appendChild(txtValue);
	txtValue.select();

	return txtValue;
}

/**
* @desc  init blink data : gfnInitBlinkData --> empty target grid 
* @param objFrom
*/
pForm.gfnInitBlinkData = function(objFrom)
{
	var grid = objFrom.config.targetGrid; 
	grid.targetGrid = null;
}

/**************************************************************************
* 각 COMPONENT 별 EVENT 영역
**************************************************************************/
/**
* @desc  grid onkeydown event --> ctrl and c or v key down check  ( for nexacro & less than ie 11 )
* @param obj - nexacro.Grid
* @param e   - nexacro.KeyEventInfo
*/
//pForm._gfnGrdCopyPasteStateChk = function(obj,e:nexacro.KeyEventInfo)
pForm._gfnGrdCopyPasteStateChk = function(obj,e)
{
	var keycode = e.keycode;

	//only ctrl key down
	if(e.ctrlkey && !e.shiftkey && !e.altkey) {
		//ctrl + c
		if(keycode == 67) {
			obj.bGridCopy = true;
		//ctrl + v
		} else if(keycode == 86) {
			obj.bGridPaste = true;
		}
	}
};

/**
* @desc  grid onkeyup event --> ctrl and c or v key down excute  ( for nexacro & less than ie 11 )
* @param obj - nexacro.Grid
* @param e   - nexacro.KeyEventInfo
*/
pForm._gfnGrdCopyPaste = function(obj,e)
{
	var objForm = obj.parent;
	var keycode = e.keycode;
	//ctrl + c
	if(obj.bGridCopy == true) {
		obj.bGridCopy = false;

		var objRowCol = this.gfnGetGridSelRowCol(obj);
		var startrow = objRowCol.selectstartrow;
		var endrow   = objRowCol.selectendrow;
		var startcol = objRowCol.selectstartcol;
		var endcol   = objRowCol.selectendcol;   

		var copyData = "";
		//var colSeperator = objForm.config.colSeperator;

		objForm.config.targetGrid = null;

		for (var i = startrow; i <= endrow; i++) {
			for (var j = startcol; j <= endcol; j++) {       
				var value = obj.getCellValue(i,j);

				if(!this.gfnIsNull(value)) {
					if (j < endcol) {
						copyData += obj.getCellValue(i,j) + this.colSeperator;
					} else {
						copyData += obj.getCellValue(i,j);
					}
				}
			}

			if (i < obj.selectendrow){
				copyData += "\r\n";
			}
		} //for

		copyData += "\r\n";

		//clipboard
		system.clearClipboard();
		system.setClipboard("CF_TEXT",copyData);

		objForm.config.targetGrid = obj;

	 //ctrl + v
	} else if(obj.bGridPaste == true) {
		obj.bGridPaste = false;
		//clipboard
		var copyData = system.getClipboard("CF_TEXT");
		copyData = new String(copyData);
		//var colSeperator = objForm.config.colSeperator;
		var rowData = copyData.split("\r\n");
		var rowDataCount = rowData.length - 1;
		if(rowDataCount < 1) {
			e.stopPropagation();
			return;
		}

		obj.set_enableevent(false);
		obj.set_enableredraw(false); 

		var ds = obj.getBindDataset();
		ds.set_enableevent(false); 

		var grdCellCount = obj.getCellCount("body");
		var rowCount = ds.getRowCount();

		var objRowCol = this.gfnGetGridSelRowCol(obj);
		var startrow = objRowCol.selectstartrow;
		var endrow   = objRowCol.selectendrow;
		var startcol = objRowCol.selectstartcol;
		var endcol   = 0; //objRowCol.selectendcol;

		var currRow = startrow;
		var cellIndex = startcol;
		var maxColumnCount = 0;

		//check current cell editType 
		for (var i = 0; i < rowDataCount; i++) {
			if(rowCount <= currRow) {
				ds.addRow();
			}

			var columnData = rowData[i].split(this.colSeperator);
			var columnLoopCount = cellIndex + columnData.length;

			if(columnLoopCount > grdCellCount) {
				columnLoopCount = grdCellCount;
			}

			if(maxColumnCount < columnLoopCount) {
				maxColumnCount = columnLoopCount;
			}

			var k = 0;
			for(var j = cellIndex; j < columnLoopCount; j++) {           
				var colid = obj.getCellProperty("body", j, "text").substr(5);      
				var tempValue = columnData[k];

				if(!this.gfnIsNull(tempValue)) {
					ds.setColumn(currRow, colid, tempValue);
				}

				k++;         
			} //for

			currRow++;
		} //for      

		ds.rowposition = currRow; 

		endrow = endrow + rowDataCount - 1;
		endcol = maxColumnCount - 1;

		//system.clearClipboard();

		obj.set_enableredraw(true);
		obj.set_enableevent(true);
		ds.set_enableevent(true); 

		obj.selectArea(startrow, startcol, endrow, endcol);    

		objForm.config.targetGrid = obj;

		//grid enableredraw가 false일 경우 
		//event 전파과정에서 error발생을 막기위한 처리.2015.02.25 버전.
		e.stopPropagation(); 

	} 
};

/**
* @desc  grid onkeydown event --> ctrl and c or v key down check  ( for edge : more than ie 12 & chrome, firefox .. )
* @param obj - nexacro.Grid
* @param e   - nexacro.KeyEventInfo
*/
//pForm._gfnGrdCopyPasteEtc = function(obj:nexacro.Grid,e:nexacro.KeyEventInfo)
pForm._gfnGrdCopyPasteEtc = function(obj,e)
{
	var objForm = obj.parent;
	var keycode = e.keycode;

	if(e.ctrlkey && !e.shiftkey && !e.altkey) {
		//ctrl + c
		if(keycode == 67)
		{
			var objRowCol = this.gfnGetGridSelRowCol(obj);
			var startrow = objRowCol.selectstartrow;
			var endrow   = objRowCol.selectendrow;
			var startcol = objRowCol.selectstartcol;
			var endcol   = objRowCol.selectendcol;

			objForm.config.targetGrid = undefined;

			var clipText = "";
			//var colSeperator = objForm.config.colSeperator;
			for (var i = startrow; i <= endrow; i++) {
				var copyData = [];
				var styleData = [];

				for (var j = startcol; j <= endcol; j++) {
					var value = obj.getCellValue(i,j);
					copyData.push(value);

					if (j < endcol) {
						clipText += value + this.colSeperator;
					} else {
						clipText += value;
					}
				}

				clipText += "\r\n";
			}

			objForm.config.targetGrid = obj;  

			var ta = this.gfnCreateElementTextarea(clipText);        
			objForm.config.targetGrid["ta"] = ta;  

			objForm.setTimer(777, 100);

			if(!this.gfnIsNull(clipText)) {
				objForm.setTimer(1000, 110);
			}

			e.stopPropagation();            
		//ctrl + v
		} else if(keycode == 86) {
			objForm.config.targetGrid = obj;
			objForm.config.targetEvent = e;

			var ta = this.gfnCreateElementTextarea('');
			objForm.config.targetGrid["ta"] = ta;  

			objForm.setTimer(888, 100);  

			e.stopPropagation();   
		}
	}
}

/**
* @desc  form ontimer event --> delay processing data time
* @param obj - nexacro.Form
* @param e   - nexacro.TimerEventInfo
*/
pForm._gfnBlinkTimerHandler = function(obj,e)
{
	var timerid = e.timerid;
	obj.killTimer(timerid);

	if(timerid >= 1000) {
		var remainder = timerid%1000;   
		if(remainder > 8) {
			this.gfnInitBlinkData(obj);
		}
	} else {
		//after copy   
		if(timerid == 777) { 
			var ta = obj.config.targetGrid["ta"];
			if(!ta) {
				return; 
			}

			document.body.removeChild(ta);
			obj.config.targetGrid["ta"] = undefined;    
		//after paste
		} else if(timerid == 888) { 
			var ta = obj.config.targetGrid["ta"];    
			if(!ta) {
				return; 
			}

			var clipText = ta.value;
			document.body.removeChild(ta);
			this.gfnSetPasteData(obj,clipText);
			obj.config.targetGrid["ta"] = undefined;
		}
	} 
}

/**************************************************************************
*  공통 함수 처리 영역
해당 함수의 경우 프로젝트 사용 시 프로젝트 공통함수로 전환을 권장 드립니다.
**************************************************************************/

/**
* @desc   copy 및 paste할 row, col 값 얻기
* @param  obj - nexacro.Grid
* @return json object(row, col)
*/
pForm.gfnGetGridSelRowCol = function(obj)
{
	var selecttype = obj.selecttype;
	var objRowCol  = {};
	if (selecttype == "row") {
		objRowCol.selectstartrow = nexacro.toNumber(obj.currentrow);
		objRowCol.selectendrow   = nexacro.toNumber(obj.currentrow);
		objRowCol.selectstartcol = 0;
		objRowCol.selectendcol   = nexacro.toNumber(obj.getCellCount("body")-1);
	} else if (selecttype == "multirow") {
		objRowCol.selectstartrow = nexacro.toNumber(obj.selectstartrow);
		objRowCol.selectendrow   = nexacro.toNumber(obj.selectendrow);
		objRowCol.selectstartcol = 0;
		objRowCol.selectendcol   = nexacro.toNumber(obj.getCellCount("body")-1);
	} else if (selecttype == "cell") {
		objRowCol.selectstartrow = nexacro.toNumber(obj.currentrow);
		objRowCol.selectendrow   = nexacro.toNumber(obj.currentrow);
		objRowCol.selectstartcol = nexacro.toNumber(obj.currentcol);
		objRowCol.selectendcol   = nexacro.toNumber(obj.currentcol);
	} else if (selecttype == "area") {
		objRowCol.selectstartrow = nexacro.toNumber(obj.selectstartrow);
		objRowCol.selectendrow   = nexacro.toNumber(obj.selectendrow);
		objRowCol.selectstartcol = nexacro.toNumber(obj.selectstartcol);
		objRowCol.selectendcol   = nexacro.toNumber(obj.selectendcol);
	} else if (selecttype == "multiarea") {
		alert("grid.selecttype=multiarea 기능에서는 copy & paste를 사용할 수 없습니다");
		objRowCol.selectstartrow = -1;
		objRowCol.selectendrow   = -1;
		objRowCol.selectstartcol = -1;
		objRowCol.selectendcol   = -1;
	}
	return objRowCol;
}

/**
* @desc   입력값이 null에 해당하는 경우 모두를 한번에 체크한다.
* @param  sValue - 체크할 문자열( 예 : null 또는 undefined 또는 "" 또는 "abc" )
* @return Boolean sValue이 undefined, null, NaN, "", Array.length = 0인 경우 true
*/
// pForm.gfnIsNull = function (sValue)
// {
// 	if (new String(sValue).valueOf() == "undefined") {
// 		return true;
// 	}
// 	if (sValue == null) {
// 		return true;
// 	}
// 
// 	var v_ChkStr = new String(sValue);
// 
// 	if (v_ChkStr == null) {
// 		return true;
// 	}
// 	if (v_ChkStr.toString().length == 0) 
// 	{
// 		return true;
// 	}
// 
// 	return false;
// };





//---------------------------------------------------------------------------------------------------
//  아래는 Grid copy & paste old version (2020.08.06 이전)
//---------------------------------------------------------------------------------------------------
/**
 * @class  그리드키다운 이벤트 [cellcopypaste]
 * @param {Object} objGrid - 대상그리드
 * @param {Evnet}  e	   - 키다운이벤트
 * @return  N/A
 * @example
 * objGrid.gfnGrid_onkeydown("onheadclick", 	 this.gfnGrid_onheadclick, 	 this);
 */
// pForm.gfnGrid_onkeydown =function(objGrid, e){
// 	var keycode = e.keycode;
// 	var sBrowser = system.navigatorname;
// 	if (e.ctrlkey) {
// 		if (keycode == 67) {
// 			//copy
// 			if (sBrowser == "nexacro" || sBrowser == "IE") {
// 				this.gfnGridCopyEventForRuntime(objGrid, e);
// 			} else {
// 				this.gfnGridCopyEventForChrome(objGrid, e);
// 			}
// 		} else if(keycode == 86) {
// 			//paste
// 			this.gfnGridPasteEvent(objGrid, e);
// 		}
// 	}
// };

/**
 * @class copy event(nexacro, ie)
 * @param {Object} obj- 대상그리드
 * @param {Event}  e - key down event
 * @return N/A
 * @example
 * this.gfnGridCopyEventForRuntime(obj, e);	
*/
// pForm.gfnGridCopyEventForRuntime = function (obj, e)
// {
// 	var startrow = nexacro.toNumber(obj.selectstartrow);
// 	if (startrow == -9) {
// 		return;
// 	}
// 
// 	var endrow = nexacro.toNumber(obj.selectendrow);
// 	if (endrow == -9) {
// 		return;
// 	}
// 	
// 	var startcol = 0;
// 	var endcol = 0;
// 	
// 	if (obj.selecttype == "row" || obj.selecttype == "multirow") {
// 		startcol = 0;
// 		endcol = obj.getCellCount("body") - 1;
// 	} else {
// 		startcol = nexacro.toNumber(obj.selectstartcol);
// 		endcol = nexacro.toNumber(obj.selectendcol);
// 	}
// 	var colSeperator = "\t";
// 	var copyData = "";
// 	var checkIndex = {};
// 	
// 	for (var i = startrow; i <= endrow; i++) {
// 		for (var j = startcol; j <= endcol; j++) {
// 			var value = obj.getCellValue(i, j);
// 			if (this.gfnIsNotNull(value)) {
// 				if (j < endcol) {
// 					copyData += obj.getCellValue(i, j) + colSeperator;
// 				} else {
// 					copyData += obj.getCellValue(i, j);
// 				}
// 			}
// 		}
// 		if (i < obj.selectendrow) {
// 			copyData += "\r\n";
// 		}
// 	}
// 
// 	copyData += "\r\n";
// 	system.clearClipboard();
// 	system.setClipboard("CF_TEXT", copyData);
// 	
// 	// var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
// };


// /**
//  * @class copy event(chrome)
//  * @param {Object} obj- 대상그리드
//  * @param {Event}  e - key down event
//  * @return N/A
//  * @example
//  * this.gfnGridCopyEventForChrome(obj, e);	
// */
// pForm.gfnGridCopyEventForChrome = function (obj, e)
// {
// 	var startrow = nexacro.toNumber(obj.selectstartrow);
// 	if (startrow == -9) {
// 		return;
// 	}
// 
// 	var endrow = nexacro.toNumber(obj.selectendrow);
// 	if (endrow == -9) {
// 		return;
// 	}
// 	
// 	var startcol = 0;
// 	var endcol = 0;
// 	
// 	if (obj.selecttype == "row" || obj.selecttype == "multirow") {
// 		startcol = 0;
// 		endcol = obj.getCellCount("body") - 1;
// 	} else {
// 		startcol = nexacro.toNumber(obj.selectstartcol);
// 		endcol = nexacro.toNumber(obj.selectendcol);
// 	}
// 
// 	var colSeperator = "\t";
// 	var copyData = "";
// 	
// 	for (var i = startrow; i <= endrow; i++) {
// 		for (var j = startcol; j <= endcol; j++) {
// 			var value = obj.getCellValue(i, j);
// 			if (this.gfnIsNotNull(value)) {
// 				if (j < endcol) {
// 					copyData += obj.getCellValue(i, j) + colSeperator;
// 				} else {
// 					copyData += obj.getCellValue(i, j);
// 				}
// 			}
// 		}
// 		if (i < obj.selectendrow) {
// 				copyData += "\r\n";
// 		}
// 	}
// 
// 	copyData += "\r\n";
// 	
// 	var ta = this.gfnCreateTextarea(copyData);
// 	this.tragetGrid = obj;
// 	this.tragetGrid["ta"] = ta;
// 	// var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
// 	e.stopPropagation();
// };


/**
 * @class cell copy and paste (크롬용 텍스트에어리어생성)
 * @param {String} innerText- value
 * @return{Object} 텍스트에어리어 오브젝트
 * @example
 * this.gfnCreateTextarea("꼬부기");	
*/
// pForm.gfnCreateTextarea = function(innerText)
// {
// 	var ta = document.createElement('textarea');
// 	ta.id = "textAreabyCopyAndPaste";
// 	ta.style.position = 'absolute';
// 	ta.style.left = '-1000px';
// 	ta.style.top = document.body.scrollTop + 'px';
// 	ta.value = innerText;
// 	
// 	document.body.appendChild(ta);
// 	ta.select();
// 
// 	return ta;
// };


/**
 * @class paste event
 * @param {Object} obj- 대상그리드
 * @param {Event}  e - key down event
 * @return N/A
 * @example
 * this.gfnGridPasteEvent(obj, e);	
*/
// pForm.gfnGridPasteEvent = function (obj, e)
// {
// 	var browser = system.navigatorname;
// 	var copyData = this.gfnGirdGetPasteData(browser);
// 	
// 	if (this.gfnIsNull(copyData)) {
// 		return;
// 	}
// 	
// 	var colSeperator = "\t";
// 	var rowData = "";
// 	if (browser == "nexacro" || browser =="IE") {
// 		rowData = copyData.split("\r\n");
// 		if (rowDataCount < 1) {
// 			e.stopPropagation();
// 			return;
// 		}
// 	} else {
// 		rowData = copyData.split(/[\n\f\r]/); 
// 	}
// 	var rowDataCount = rowData.length - 1;
// 
// 	obj.set_enableevent(false);
// 	obj.set_enableredraw(false); 
// 
// 	var datasetName = obj.binddataset;
// 	var ds = obj.getBindDataset();
// 
// 	ds.set_enableevent(false); 
// 
// 	var grdCellCount = obj.getCellCount("body");
// 	var rowCount = ds.getRowCount();
// 	
// 	var startrow = nexacro.toNumber(obj.selectstartrow);
// 	if (startrow == -9) {
// 		return;
// 	}
// 
// 	var endrow = nexacro.toNumber(obj.selectendrow);
// 	if (endrow == -9) {
// 		return;
// 	}
// 	
// 	var startcol = 0;
// 	var endcol = 0;
// 	
// 	if (obj.selecttype == "row" || obj.selecttype == "multirow") {
// 		startcol = 0;
// 		endcol = obj.getCellCount("body") - 1;
// 	} else {
// 		startcol = nexacro.toNumber(obj.selectstartcol);
// 		endcol = nexacro.toNumber(obj.selectendcol);
// 	}
// 
// 	var currRow = startrow;
// 	var cellIndex = startcol;
// 	var maxColumnCount = 0;
// 	var checkIndex = {};	
// 
// 	for (var i = 0; i < rowDataCount; i++) {
// 		if (rowCount <= currRow) {
// 			ds.addRow();
// 		}
// 
// 		var columnData = rowData[i].split(colSeperator);
// 		var columnLoopCount = cellIndex + columnData.length;
// 
// 		if (columnLoopCount > grdCellCount) {
// 			columnLoopCount = grdCellCount;
// 		}
// 
// 		if (maxColumnCount < columnLoopCount) {
// 			maxColumnCount = columnLoopCount;
// 		}
// 
// 		var k = 0;
// 		for (var j = cellIndex; j < columnLoopCount; j++) {
// 			var colTemp = obj.getCellProperty("body", j, "text");
// 			var colid;
// 			if (this.gfnIsNull(colTemp)) {
// 				colid = obj.getCellProperty("body", j, "text");
// 			} else {
// 				colid = obj.getCellProperty("body", j, "text").substr(5);
// 			}
// 			
// 			var tempValue = columnData[k];
// 			if (this.gfnIsNotNull(tempValue)) {
// 				ds.setColumn(currRow, colid, tempValue);
// 			}
// 			k++;
// 		}
// 		currRow++;
// 	}
// 
// 	ds.rowposition = currRow;	
// 
// 	endrow = endrow + rowDataCount - 1;
// 	endcol = maxColumnCount - 1;
// 	
// 	system.clearClipboard();
// 
// 	obj.set_enableredraw(true);
// 	obj.set_enableevent(true);
// 	ds.set_enableevent(true); 
// 
// 	obj.selectArea(startrow, startcol, endrow, endcol);
// 
// 	// var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
// 	e.stopPropagation();
// };


/**
 * @class paste데이터생성
 * @param {String} browser - 브라우저
 * @return paste데이터 
 * @example
 * this.gfnGirdGetPasteData("nexacro");	
*/
// pForm.gfnGirdGetPasteData = function (browser)
// {
// 	var copyData = "";
// 	if (browser == "nexacro" || browser == "IE") {
// 		copyData = system.getClipboard("CF_TEXT");
// 		copyData = new String(copyData);
// 	} else {
// 		var ta = this.tragetGrid["ta"];
// 
// 		if (!ta) {
// 			return;
// 		}
// 
// 		copyData = ta.value;
// 		document.body.removeChild(ta);
// 		
// 		this.tragetGrid["ta"] = undefined;
// 	}
// 	return copyData;
// 	
// };
// 

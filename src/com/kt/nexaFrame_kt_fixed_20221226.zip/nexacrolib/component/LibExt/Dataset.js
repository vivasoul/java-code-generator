﻿/**
*  @FileName 	Dataset.js
*/

var pForm = nexacro.Form.prototype;

//pForm.COM_CHECK_ID = "chk";  //grid check 공통 column  (GridOnload.js에 존재 해서 주석 처리)

/**
* 1. 검증관련 관련 함수
*   - gfnExistDupRow      : 중복 검사(다중 컬럼)
*   - gfnDsIsUpdated      : dataSet의 Row 중에서 변경된 내용이 있는지 여부
*   - gfnIsUpdatedRow     : dataSet의 Row가 변경되었는지 판단하는 함수
*   - gfnIsUpdateColumn   : dataSet의 Row 에서 특정 칼럼이 변경되었는지 판단하는 함수
*   - 
*   - 
* 2. 복사,삭제 추가 관련 함수
*   - gfnMoveDataSetRow      : org Dataset특정Row를 target Dataset으로 이동 처리 (n개 가능)
*   - gfnMoveDataSetRow      : org Dataset특정Row를 target Dataset으로 이동 처리 (1개 row)
*   - gfnCopyRow             : org Dataset 전체Row를 target Dataset으로 복사
*   - gfnDeleteChkRow        : 
*   - gfnAddRow              : 행추가
*   - gfnCopyContents        : Dataset 컬럼정보(ColumnInfo)정보만 copy하기
*   - gfnDsChangeDatasetRow  : Dataset 2개의 row를 서로 교체 한다.
*   - 
* 3. 컬럼 값 Get, Set 관련 함수
*   - gfnSetColumnAllRow     : Dataset 모든 Row에 특정값을 Setting하기
*   - gfnAddFirstRowCommCd   : 코드 Dataset 첫번째 Row 공백,전체,선택 값 넣기
*   - gfnChangeNullToSpace   : Dataset set 조회 후 모든컬럼을 검증하여 null값이면 space('')값으로 변경
*   - gfnGetColumnNull       : Dataset에서 값을 얻어올때 null이면 공백 또는 0 으로 return
*   - gfnGetColumnNull       : Dataset에 값을 Setting전 enableevent = false 처리 후 set
*   - gfnChangeNullToSpace   : Dataset set 조회 후 null값을 space('')값으로 변경
*   - gfnSetColumnFalse      : Dataset에 값을 set 할때 enableevent, updatecontol 을 false처리후 함
*   - 
* 8. rowtype 관련함수
*   - gfnMaintailNormalType  : grid에서 checkbox를 클릭 시 해당 dataset row에 대해서 normal상태 유지 시킴
*   - 
*   - gfnUpdateToDataset     : 컨트롤이 Dataset에 bind되어 있을 경우 즉시 value를 Dataset에 적용시킨다.
*   - gfnChkBoxSetNormal     : 데이터셋에서 check컬럼만 변경 시 normal 상태로 변경 
*   - gfnAddFirstRow         : code dataset의 첫번째 row에 '전체,선택'값 넣기
*   - gfnDistincDsFilter      : Dataset 중복컬럼적용 후 유일한 자료만 filter처리
*   - gfnChangeChkToRadio     : grid checkbox를 radio버튼 형식으로 변경
*   - gfnDefaultDataset      : dataset을 초기 상태로 원복
*   - gfnDsMakeJson          :  특정Row의 자료를 Json객체로 만들기 
*/


/************************************************************************************************
* 1. 검증관련 함수
************************************************************************************************/

/**
* @class 중복 검사(다중 컬럼) <br>
* @param {dataset} objDs    - 중복검사할 dataset
* @param {String} colList   - 컬럼목록(콤마로 구분)(empno,age)
* @param {String} chkType   - 검증할 ROW 설정 (U:수정된 ROW만 검증, A:전체 ROW검증)
* @param {Number} dupPosCnt - 중복가능한 갯수 (0,1,2,3...)
* @param {String} msgCd - 중복발생 시 보여줄 message code
* @param {String} msgArg - 중복발생 시 보여줄 message argument
* @return {Number} 중복검사 후 중복발생 row return
* @exam this.gfnExistDupRow(this.ds_emp, "EMP_NO,AGE", 0, "U", "I2234", ["사원번호","나이"]);
* @exam this.gfnExistDupRow(this.ds_emp, "EMP_NO,AGE", 2);
*/
pForm.gfnExistDupRow = function(objDs, colList, dupPosCnt, chkType, msgCd, msgArg)
{
	var arrCol = colList.split(",");
	var sFindCond = "";
	chkType   = this.gfnIsNull(chkType)   ? "A" : chkType;
	dupPosCnt = this.gfnIsNull(dupPosCnt) ? 0   : dupPosCnt;
	
	var nRowCnt = objDs.rowcount;
	
	for(var row=0; row<nRowCnt; row++){
		if (chkType == "U" && objDs.getRowType(row) == Dataset.ROWTYPE_NORMAL) continue;
		
		for(var idx=0; idx<arrCol.length; idx++){
			sFindCond += (this.gfnIsExist(sFindCond)) ? " && " : "";
			
			var colInfo = objDs.getColumnInfo(arrCol[idx]);
			var colVal  = this.gfnNvl(objDs.getColumn(row, arrCol[idx]), "");
			if (colInfo.type == "BIGDECIMAL" || colInfo.type == "INT"){
				sFindCond += arrCol[idx] + "==" + colVal;
			}else{
				sFindCond += arrCol[idx] + "=='" + nexacro.trim(colVal) + "'";
			}
		}
		
		var nFindRow = objDs.getCaseCount(sFindCond);
		if (nFindRow > dupPosCnt) {
			objDs.set_rowposition(row);
			if (this.gfnIsExist(msgCd))  this.gfnAlert(msgCd, msgArg);  //NX1325 : [{0}] 중복된 데이터가 존재합니다.
			return nFindRow;
		}
		sFindCond = "";
	}
	return -1;
}

/**
 * @class dataSet의 Row 중에서 변경된 내용이 있는지 여부 <br>
 * @param {Object}  objDs      - 확인 대상 Dataset
 *        {boolean} bSkipCheck - checkbox만 변경 되었을 경우 해당 row는 변경 되지 않았다고 판단할지 여부
 *                               true  : 각 row별 모든 컬럼이 변경되었는지 검증(checbox 컬럼(CHK)은 제외)
 *                               false : 각 row가 변경 되었는지 검증
 * @return {boolean}
 */   
pForm.gfnDsIsUpdated = function (objDs, bSkipCheck)
{
	if (this.gfnIsNull(bSkipCheck))		bSkipCheck = false;
	
	if (objDs.getDeletedRowCount() > 0) {
		return true;
	}
	
	if (bSkipCheck) {
		for (var i = 0 ; i < objDs.getRowCount() ; i++) {
			if (this.gfnIsUpdatedRow(objDs,i,bSkipCheck)) {
				return true;
			}
		}
	} else {
		for (var i = 0 ; i < objDs.getRowCount() ; i++) {
			if (objDs.getRowType(i) == 2 || objDs.getRowType(i) == 4 || objDs.getRowType(i) == 8) {
				return true;
			}
		}
	}
	return false;
};

/**
* @class 여러개 Dataset이 변경 되었는지 검증 <br>
* @param {string}  dsList     - 확인 대상 Dataset list
*        {boolean} bSkipCheck - checkbox만 변경 되었을 경우 해당 row는 변경 되지 않았다고 판단할지 여부
*                               true  : 각 row별 모든 컬럼이 변경되었는지 검증(checbox 컬럼(CHK)은 제외)
*                               false : 각 row가 변경 되었는지 검증
* @return {boolean}
* @exam {string} dsList - 
* @exam this.gfnDsIsUpdatedMulti("ds_emp,ds_salry");
*/ 
// 대용량dataset을 처리 하는 플젝일 경우에는 아래 script와 속도 검증 필요
pForm.gfnDsIsUpdatedMulti = function(dsList, notUpdateMsg, bSkipCheck)
{
	this.gfnUpdateToDataset(this);
	
	var aDs = dsList.split(",");
	for(var i=0; i<aDs.length; i++) {
		var objDs = this.all[aDs[i]];
		//if (objDs.getCaseCountNF("(dataset.getRowType(rowidx) == 2) || (dataset.getRowType(rowidx) == 4) || (dataset.getRowType(rowidx) == 8)")  > 0 || objDs.getDeletedRowCount() > 0  ) {
		if (   objDs.findRowExprNF("dataset.getRowType(rowidx) == 2") >= 0
		    || objDs.findRowExprNF("dataset.getRowType(rowidx) == 4") >= 0
			|| objDs.findRowExprNF("dataset.getRowType(rowidx) == 8") >= 0
			|| objDs.getDeletedRowCount() > 0 ) {
		
			return true;
		}
	}
	if (this.gfnIsExist(notUpdateMsg)) {
		this.gfnAlert(notUpdateMsg); // NX1004 : 변경된 내역이 없습니다.
	}
	return false;
}
// pForm.gfnDsIsUpdatedMulti = function(dsList, notUpdateMsg, bSkipCheck)
// {
// 	this.gfnUpdateToDataset(this);
// 	
// 	var aDs = dsList.split(",");
// 	for(var i=0; i<aDs.length; i++) {
// 		var objDs = this.all[aDs[i]]; //if (this.gfnDsIsUpdated(eval("this." + aDs[i]), bSkipCheck) == true) {
// 		if (this.gfnDsIsUpdated(objDs, bSkipCheck) == true) {
// 			return true;
// 		}
// 	}
// 	if (this.gfnIsExist(notUpdateMsg)) {
// 		this.gfnAlert(notUpdateMsg); // NX1004 : 변경된 내역이 없습니다.
// 	}
// 	return false;
// }

 /**
 * @class dataSet의 Row가 변경되었는지 판단하는 함수 <br>
 * @param {Object} ObjDs - 대상 dataset
 * @param {Number} nRow - row값
 * @return {boolean}
 */   
pForm.gfnIsUpdatedRow = function (objDs, nRow, bSkipCheck)
{
	if (this.gfnIsNull(bSkipCheck))		bSkipCheck = false;
	
	if (objDs.updatecontrol == true && bSkipCheck == false) {
		if (objDs.getRowType(nRow) == 2 || objDs.getRowType(nRow) == 4) {
			return true;
		}
		return false;
	} else {
		for (var i = 0, s = objDs.getColCount(); i < s; i++) {
			if (this.gfnIsUpdateColumn(objDs, nRow, objDs.getColID(i), bSkipCheck) == true) {
				return true;
			}
		}
	}
	return false;
};

/**
 * @class dataSet의 Row 에서 특정 칼럼이 변경되었는지 판단하는 함수
 * @param {Object} ObjDs - 대상 dataset
 * @param {Number} nRow - row값
 * @param {String || Number} Column - 칼럼명 or 칼럼index
 * @return {boolean}
 */   
pForm.gfnIsUpdateColumn = function (objDs, nRow, Column, bSkipCheck)
{
	if (this.gfnIsNull(bSkipCheck))		bSkipCheck = false;
	
	if (bSkipCheck == true && Column == this.COM_CHECK_ID) return false;		// 체크박스는 스킵
	
	if (objDs.getRowType(nRow) == 2) {
		if (this.gfnIsNull(objDs.getColumn(nRow, Column))) {
			return false;
		}
	} else {
		var currValue = objDs.getColumn(nRow, Column);
		var orgValue  = objDs.getOrgColumn(nRow, Column);
		currValue = this.gfnNvl(currValue, "");
		orgValue  = this.gfnNvl(orgValue, "");
		if (currValue == orgValue) {
			return false;
		}
	}
	
	return true;
};

 /**
 * @class dataSet의 Row가 변경되었는지 판단하는 함수
 * @param {Object} ObjDs - 대상 dataset
 * @param {Number} nRow - row값
 * @return {boolean}
 */   
pForm.gfnIsUpdatedRow = function (objDs, nRow, bSkipCheck)
{
	if (this.gfnIsNull(bSkipCheck))		bSkipCheck = false;
	
	if (objDs.updatecontrol == true && bSkipCheck == false) {
		if (objDs.getRowType(nRow) == 2 || objDs.getRowType(nRow) == 4) {
			return true;
		}
		return false;
	} else {
		for (var i = 0, s = objDs.getColCount(); i < s; i++) {
			if (this.gfnIsUpdateColumn(objDs, nRow, objDs.getColID(i), bSkipCheck) == true) {
				return true;
			}
		}
	}
	return false;
};

 /**
 * @class dataSet의 Row 에서 해당 칼럼이 변경되었는지 판단하는 함수
 * @param {Object} ObjDs - 대상 dataset
 * @param {Number} nRow - row값
 * @param {String || Number} Column - 칼럼명 or 칼럼index
 * @return {boolean}
 */   
pForm.gfnIsUpdateColumn = function (objDs, nRow, Column, bSkipCheck)
{
	if (this.gfnIsNull(bSkipCheck))		bSkipCheck = false;
	
	if (bSkipCheck == true && Column == this.COM_CHECK_ID)		return false;		// 체크박스는 스킵
	
	if (objDs.getRowType(nRow) == 2) {
		if (this.gfnIsNull(objDs.getColumn(nRow, Column))) {
			return false;
		}
	} else {
		if (objDs.getColumn(nRow, Column) == objDs.getOrgColumn(nRow, Column)) {
			return false;
		}
	}
	
	return true;
};



/************************************************************************************************
* 2. 복사,삭제 관련 함수
************************************************************************************************/
/**
 * @class org Dataset특정Row를 target Dataset으로 이동 처리 (n개 가능)
 * @param {Object} objDsOrg      - 복사할 자료가 있는 dataset
 * @param {String} orgRowList    - 복사할 row list
 * @param {Object} objDsTarget   - 복사된 dataset
 * @param {String} targetRowList - 복사될 row list
 * @exam  this.gfnMoveDataSetRow(this.ds_list1, "2,3,10,15", this.ds_list2, "5,2,1,10");
 * @참고  dataset.copyRow() : orgDs와 targetDs간에 동일한 컬럼만 복사
 * @return none
 */   
pForm.gfnMoveDataSetRowMulti = function(objDsOrg, orgRowList, objDsTarget, targetRowList)
{
	var orgRow    = orgRowList.split(",");
	var targetRow = (this.gfnIsExist(targetRowList)) ? targetRowList.split(",") : "";
	var orgCnt = orgRow.length;
	
	//1. 자료 복사
	for(var ii=0; ii<orgCnt; ii++)
	{
		var addRow;
		if (this.gfnIsNull(targetRowList)) {
			addRow = objDsTarget.addRow(0);
		}else{
			addRow = targetRow[ii];
		}
		
		objDsTarget.copyRow(addRow, objDsOrg, orgRow[ii]);
	}
	
	//2. 자료 삭제 (원본 ROW순서를 지키기 위해서 복사 후 DELETE 하는 순서로 개발)
	for(var ii=orgCnt-1; ii>=0; ii--)
	{
		objDsOrg.deleteRow(orgRow[ii]);
	}	
}
/**
 * @class org Dataset특정Row를 target Dataset으로 이동 처리 (1개 row)
 */
pForm.gfnMoveDataSetRow = function(objOrg, orgRow, objTarget, targetRow)
{
	if (this.gfnIsNull(targetRow))
	{
		targetRow = objTarget.addRow(0);
	}
	
	objTarget.copyRow(targetRow, objOrg, orgRow);
	objOrg.deleteRow(orgRow);
}


/**
 * @class org Dataset 전체Row를 target Dataset으로 복사
 * @param {Object} objDsOrg      - 복사할 자료가 있는 dataset
 * @param {Object} objDsTarget   - 복사된 dataset
 * @참고  dataset.copyRow() : orgDs와 targetDs간에 동일한 컬럼만 복사
 * @return none
 */ 
pForm.gfnCopyRow = function(objDsOrg, objDsTarget)
{
	var rowCnt = objDsOrg.rowcount;
	for(var ii=0; ii<rowCnt; ii++)
	{
		var row = objDsTarget.addRow(0);
		objDsTarget.copyRow(row, objDsOrg, ii);
	}
}

/**
* @class 선택된 row삭제
* @param {Object}  objDs - 삭제할 dataset
* @return none
*/
pForm.gfnDeleteSelRow = function(objDs, bConfirm) //, callback)
{
	var selRow = objDs.rowposition;
	if (selRow < 0){
		this.gfnAlert("MSG1002"); //선택된 ROW가 없습니다.
		return -1;
	}
	
	if (bConfirm == true) {
		this.gfnConfirm("MSG1212", "", objDs.id, "gfnDeleteSelRowCallback"); // 선택된 row를 삭제하시겠습니까?
	} else {
		this.gfnDeleteSelRowCallback(objDs.id, true);
	}
}

/**
* @class 선택된 row삭제 여부 callback
* @param {string}  popId - callback id (여기서는 삭제할 dataset)
* @return none
*/
pForm.gfnDeleteSelRowCallback = function(popId, popRtn)
{
	if (popRtn == false) return -1;
	
	var objDs = this.all[popId];
	objDs.set_enableevent(false);
	var selRow = objDs.rowposition;
	objDs.deleteRow(selRow);
	objDs.set_enableevent(true);
}

/**
* @class check된 ROW 삭제
* @param {Object}  objDs - 삭제할 dataset
* @param {String}  sNotSelectMsg - check된 row가 없을 경우 msg cd
* @exam  {boolean} bEvent - delete row시 event 미 발생 여부 (false:미발생, true:발생) (default:true)
* @return none
*/
pForm.gfnDeleteChkRow = function(objDs, sNotSelectMsg, chkColId, bEvent)
{
	if (this.gfnIsNull(chkColId)) chkColId = this.COM_CHECK_ID;
	if (bEvent == false) objDs.set_enableevent(false);
	objDs.set_updatecontrol(false);
	
	var nAllRow = objDs.getRowCount();
	var nDelCnt = 0;

	for(var row=nAllRow-1; row >= 0; row--) {
		var chk = objDs.getColumn(row, chkColId);
		if (chk == "1") {
			if (objDs.getRowType(row) == Dataset.ROWTYPE_INSERT) {
				objDs.deleteRow(row);
			} else {
				//화면에서 바로 삭제 안하고, 상태만 관맇하는 경우
				//objDs.setRowType(row, Dataset.ROWTYPE_DELETE);
				
				//화면에서 바로 삭제 하는 경우
				objDs.deleteRow(row);
			}
			nDelCnt++;
		}
	}
	
	if (nDelCnt == 0 && this.gfnIsExist(sNotSelectMsg)){
		this.gfnAlert(sNotSelectMsg); //"NX1002":선택된 ROW가 없습니다.
	}
	
	objDs.set_updatecontrol(true);
	if (bEvent == true) objDs.set_enableevent(true);
	return nDelCnt;
}

/**
 * @class 행추가
 * @param {Object} objGrd    : Grid
 * @param {String} posColId  : 추가한 행에 focus위한 컬럼명
 * @param {String} bEvent    : enable event true/false
 * @return {number} 삭제row count
 */
pForm.gfnAddRow = function(objGrd, posColId, inRow)
{
	var objDs = objGrd.getBindDataset();
	objDs.set_enableevent(false);
	var row;
	
	if (this.gfnIsNull(inRow)) {
		row = objDs.addRow();  //마지막 row에 추가
	} else {
		row = objDs.insertRow(inRow);
	}
	
	objDs.set_enableevent(true);
	
	if (this.gfnIsExist(posColId)) {
		var idx = objGrd.getBindCellIndex("body", posColId);
		objGrd.setCellPos(idx);
		objGrd.showEditor(true);
	}
	return row;
}

// pForm.gfnAddRow = function(objDs, posColId, chkColId)
// {
// 	objDs.set_enableevent(false);
// 	var row = objDs.addRow();  //마지막 row에 추가
// 	chkColId ? objDs.setColumn(row, chkColId, '0') : "";
// 	objDs.set_enableevent(true);
// 	return row;
// }

/**
 * @class Dataset 컬럼정보(ColumnInfo)정보만 copy하기
 * @param {Object} objTargetDs : Target Dataet
 * @param {Object} objSourceDs : Source Dataet
 */
this.gfnCopyContents = function(objTargetDs, objSourceDs)
{
	var strCont =  '<ColumnInfo>';
	for(var i=0; i < objSourceDs.getColCount();i++){
		strCont += '  <Column id="'+objSourceDs.getColumnInfo(i).id+'" type="'+objSourceDs.getColumnInfo(i).type
		+'" size="'+objSourceDs.getColumnInfo(i).size+'"/>';
	}    
	strCont += '</ColumnInfo>';
	objTargetDs.setContents(strCont);
}

/** type : Dataset
* @class Dataset 2개의 row를 서로 교체 한다.
* @param {Dataset} objDs : 작업할 Dataset
*        {int}     row0  : 교체할 row0
*        {int}     row1  : 교체할 row1
* @exec  this.gfnDsChangeDatasetRow(this.dsDivSeq, moveRow, switchRow);
*/
this.gfnDsChangeDatasetRow = function(objDs, row0, row1)
{
	if (row0 > row1) {
		var temp = row0;
		row0 = row1;
		row1 = temp;
	}
	
	objDs.insertRow(row0);
	objDs.copyRow(row0, objDs, row1+1);
	objDs.copyRow(row1+1, objDs, row0+1);
	objDs.deleteRow(row0+1)
}

/************************************************************************************************
* 3. 컬럼 값 Get, Set 관련 함수
************************************************************************************************/
/**
 * @class Dataset 모든 Row에 특정값을 Setting하기
 * @param {Object}  objDs   - 대상 dataset
 * @param {String}  colId   - 적용할 컬럼 id
 * @param {String}  colVal  - 적용할 값
 * @param {boolean} bFilter - filter를 해제하고 알지? 현재 적용된것만 할지 여부 (true:해제 후 set)
 * @return none
 */
pForm.gfnSetColumnAllRow = function(objDs, colId, colVal, bFilter)
{
	var filterStr = objDs.filterstr;
	
	//필터 해제
	if (bFilter == true) objDs.set_filterstr("");

	var rowCnt = objDs.rowcount;
	for(var i=0; i<rowCnt; i++)
	{
		objDs.setColumn(i, colId, colVal);
	}
	
	if (bFilter == true) objDs.set_filterstr(filterStr);
}

/**
 * @class 코드 Dataset 첫번째 Row 공백,전체,선택 값 넣기
 * @param {Object}  obj      - 대상 dataset
 * @param {String}  sFirstNm - 적용할 값   (공백, 선택, 전체)
 * @param {String}  sFirstCd - 적용할 코드 (주로 공백) 또는 (공백, 'A', 'S' 등)
 * @param {String}  cdId     - 컬럼 id
 * @param {String}  cdNm     - 컬럼 nm
 * 예) this.gfnAddFirstRowCommCd(this.ds_cdLarge , "선택");
 *     this.gfnAddFirstRowCommCd(this.ds_cdLarge , "선택", "cdId", "cdNm", "userYn");
 */
pForm.gfnAddFirstRowCommCd = function(obj, sFirstNm, sFirstCd, cdId, cdNm, sUserYnColId)
{
	cdId = (this.gfnIsNull(cdId)) ? "codeCd" : cdId;
	cdNm = (this.gfnIsNull(cdNm)) ? "codeNm" : cdNm;
	
	sFirstCd = (this.gfnIsNull(sFirstCd)) ? "" : sFirstCd;
	
	obj.insertRow(0);
	obj.setColumn(0, cdId, sFirstCd);
	obj.setColumn(0, cdNm, sFirstNm);
	if (this.gfnIsExist(sUserYnColId)) obj.setColumn(0, sUserYnColId, "Y");
}

/**
 * @class Dataset set 조회 후 모든컬럼을 검증하여 null값이면 space('')값으로 변경
 * @param {Object}  objDs  - 대상 dataset
 * @param {String}  objGrd - 화면 Grid (ds row가 많을 경우 값이 변경 시 enableredraw event 발생여부용)
 * @return none
 * @exam   this.gfnChangeNullToSpace(this.ds_list3, "", "EMP_NO,EMP_NAME");
 * @참고  dataset에 콤보가 있는데.. 컬럼값이 null이지만 .. 이 콤보 첫번째 ROW(주로:선택,전체)를 선택 하기 위해서 사용
 * @참고  null은 dataset의 row에 컬럼 tag가 없고, space('')는 컬럼 tag가 존재 함
 * @참고  현재 number type은 '' 으로 변환됨
 */
pForm.gfnChangeNullToSpace = function(objDs, objGrd, colList)
{
	if (this.gfnIsExist(objGrd)) objGrd.set_enableredraw(false);
	objDs.set_enableevent(false);
	
	var aColId    = this.gfnIsNull(colList) ? "" : colList.split(",");
	var colAllCnt = objDs.colcount;
	var rowCnt    = objDs.rowcount;
	for(var row=0; row<rowCnt; row++)
	{
		var bChanged = false;
		var rowType	 = objDs.getRowType(row);
		
		//1. 지정된 컬럼id가 존재 시
		if (aColId.length > 0)
		{
			for(var idx=0; idx<aColId.length; idx++)
			{
				var colValue = objDs.getColumn(row, aColId[idx]);
				if (this.gfnIsNull(colValue))
				{
					objDs.setColumn(row, aColId[idx], ""); 
					bChanged = true; 
				}
			}
		}
		else
		{
			for(var idx=0; idx<colAllCnt; idx++)
			{
				var colValue = objDs.getColumn(row, idx);
				if (this.gfnIsNull(colValue))
				{
					objDs.setColumn(row, idx, ""); 
					bChanged = true; 
				}
			}
		}
		
		//2. 값이 변경 된 경우.. 변경 전 rowType으로 set
		if (bChanged == true)
		{
			objDs.set_updatecontrol(false);
			objDs.setRowType(row, rowType);
			objDs.set_updatecontrol(true);
		}
	}
	
	objDs.set_enableevent(true);
	if (this.gfnIsExist(objGrd)) objGrd.set_enableredraw(true);
}

/**
 * @class Dataset에서 값을 얻어올때 null이면 공백 또는 0 으로 return
 * @param {Object}  objDs - 대상 dataset
 * @param {number}  row   - 대상 row
 * @param {string}  colId - 대상 컬럼 id
 * @return 컬럼값 (만약, null이면서 문자 type은 공백(''), 숫자 type은 0 으로 return)
 */
pForm.gfnGetColumnNull = function(objDs, row, colId)
{
	var colInfo = objDs.getColumnInfo(colId);
    var value   = objDs.getColumn(row, colId);

    if (this.gfnIsNull(value) && (colInfo.type == "BIGDECIMAL" || colInfo.type == "INT")) {
		return 0;
	} else if (this.gfnIsNull(value)) {
		return '';
	} else {
		return value;
	}
}

/**
 * @class Dataset에 값을 Setting전 enableevent = false 처리 후 set
 * @param {Object} obj - Dataset
 */ 
pForm.gfnSetCoumnNotEvent = function(obj, row, col, val)
{
	var bCurr = obj.enableevent;
	if (bCurr == true) obj.set_enableevent(false);
	obj.setColumn(row, col, val);
	if (bCurr == true) obj.set_enableevent(true);
}



/**
 * @class Dataset set 조회 후 null값을 space('')값으로 변경
 */
pForm.gfnChangeNullToSpace = function(objDs, objGrd)
{
	if (this.gfnIsExist(objGrd)) objGrd.set_enableredraw(false);
	objDs.set_enableevent(false);
	objDs.set_updatecontrol(false);
	var colCnt = objDs.colcount;
	var rowCnt = objDs.rowcount;
	for(var row=0; row<rowCnt; row++)
	{
		for(var idx=0; idx<colCnt; idx++)
		{
			var colValue = objDs.getColumn(row, idx);
			if (this.gfnIsNull(colValue)) objDs.setColumn(row, idx, "");
		}
		
		objDs.setRowType(row, Dataset.ROWTYPE_NORMAL);
		
	}
	objDs.set_updatecontrol(true);
	objDs.set_enableevent(true);
	if (this.gfnIsExist(objGrd)) objGrd.set_enableredraw(true);
}

/**
* @class Dataset에 값을 set 할때 enableevent, updatecontol 을 false처리후 함
*/
pForm.gfnSetColumnFalse = function(objDs, row, colId, val)
{
	objDs.set_enableevent(false);
	objDs.set_updatecontrol(false);
	objDs.setColumn(row, colId, val);
	objDs.set_updatecontrol(true); 
	objDs.set_enableevent(true);
};

/************************************************************************************************
* 8. rowtype 관련
************************************************************************************************/
/**
 * @class grid에서 checkbox를 클릭 시 해당 dataset row에 대해서 normal상태 유지 시킴
 *        checkbox컬럼이외의 컬럼들도 가능
 * @param {object} objDs          : 작업dataset
 * @param {string} normalChkColId : checkbox를 체크 해도 dataset row의 type을 normal type으로 유지하고 싶은 column id
 * @exam  this.gfnMaintailNormalType(this.dsNm, "chk")
 * @참고 event수행 순서 : 업무화면에서 설정된 cancolumnchange, oncolumnchanged event가 먼저수행되고 아래 event가 수행됨
 */
pForm.gfnMaintailNormalType = function(objDs, normalChkColId)
{
	objDs.normalChkColId = normalChkColId;
	objDs.addEventHandler("cancolumnchange", this._gfnMaintailNormalTypeCancolumnchange, this);
	objDs.addEventHandler("oncolumnchanged", this._gfnMaintailNormalTypeOncolumnchanged, this);
}
pForm._gfnMaintailNormalTypeCancolumnchange = function(obj,e)
{
	if (e.columnid == objDs.normalChkColId)
	{
		obj.preRowType = obj.getRowType(e.row);
	}
}
pForm._gfnMaintailNormalTypeOncolumnchanged = function(obj,e)
{
	if (e.columnid == objDs.normalChkColId)
	{
		if (obj.preRowType == Dataset.ROWTYPE_NORMAL)
		{	
			obj.set_updatecontrol(false);
			obj.setRowType(e.row, Dataset.ROWTYPE_NORMAL);
			obj.set_updatecontrol(true);
		}
	}
}

/************************************************************************************************
* 9. 기타 및 공통
************************************************************************************************/
/**
 * @class  현재 form에 존재 하는 dataset얻기 <br>
 * @return none
 * @참조   아래 함수는 참고용임
 */

pForm.gfnGetDatasetList = function()
{
	for(var i=0; i < this.all.length; i++){
		if (this.all[i] instanceof Dataset){
			trace( this.all[i].name );
		}
	}
}

/**
 * @class  div에 연결된  form안에 존재 하는 Dataset 찾기 <br>
 * @return none
 * @참조   미 검증
 */
pForm.gfnGetDivDatasetList = function(objDiv)
{
	for(var i=0; i < objDiv.all.length; i++){
		if (objDiv.all[i] instanceof Dataset){
			trace(objDiv.all[i].name);
		}
	}
}	

/**
 * @class 컨트롤이 Dataset에 bind되어 있을 경우 즉시 value를 Dataset에 적용시킨다.
 * @return N/A
 */   
pForm.gfnUpdateToDataset = function(objForm)
{
	if (objForm == null) {
		objForm = this;
	}
	
	var objComp = objForm.getFocus();
	
	if (objComp != null) {
		try {
			objComp.updateToDataset();
		} catch (e) {
		}
	}
};

/**
 * @class 데이터셋에서 check컬럼만 변경 시 normal 상태로 변경 <br>
 * @param {Object} objDs  - 대상 Dataset
 * @param {String} chkCol - checkbox column
 * @return none
 * @exam this.gfnChkBoxSetNormal(this.dsEmp, "chk");
 */
pForm.gfnChkBoxSetNormal = function(objDs, chkCol) 
{
	var rowCnt = objDs.rowcount;
	var colCnt = objDs.colcount;
	
	objDs.set_updatecontrol(false);
	for(var row=0; row<rowCnt; row++)
	{
		if (objDs.getRowType(row) == Dataset.ROWTYPE_NORMAL) continue;
		var modiColCnt = 0;
		for(var jj=0; jj<colCnt; jj++)
		{
			if (objDs.getColID(jj)     == chkCol) continue;
			if (this.gfnNvl(objDs.getColumn(row, jj), "") != this.gfnNvl(objDs.getOrgColumn(row, jj), "")) modiColCnt ++;
		}
		if (modiColCnt == 0) objDs.setRowType(row, Dataset.ROWTYPE_NORMAL);
	}
	objDs.set_updatecontrol(true);
};


/**
 * @class code dataset의 첫번째 row에 '전체,선택'값 넣기
 * @param {Object}  objDs   : dataset
 * @param {Boolean} bSelBtn : ok, cancel 클릭 한 버튼 (true/false)
 */
pForm.gfnAddFirstRow = function(objDs, firstNm, firstCd)
{
	firstNm = this.gfnNvl(firstNm);
	firstCd = this.gfnNvl(firstNm);
	var addRow = objDs.insertRow(0);
	
}

/**
 * @class Dataset 중복컬럼적용 후 유일한 자료만 filter처리
 * @param {object} objDs  : 작업 dataset
 * @param {string} sColID : 컬럼 목록
 * @exam  this.gfnDistincDsFilter(this.dsNm, "Column1,Column2") 
 */
pForm.gfnDistincDsFilter = function(objDs, sColID)
{
	var arrArgs = sColID.split(",");
	var sFilterExpr  = "";
	var sFindRowExpr = ""; 
	for (var i=0; i<arrArgs.length; i++)
	{
		if (objDs.getColumnInfo(arrArgs[i]) == null) continue;

		sFindRowExpr += (this.gfnIsNull(sFindRowExpr) == false) ? " && " : "";
		sFindRowExpr += "" + arrArgs[i] + "=='\" + " + arrArgs[i] + " + \"'";
	}

	if (this.gfnIsNull(sFindRowExpr) == false) {
		sFilterExpr = "rowidx==dataset.findRowExpr(\"" + sFindRowExpr + "\")";
	}
	objDs.filter(sFilterExpr);
}

/**
* @class grid checkbox를 radio버튼 형식으로 변경
* @param {object} objGrid : 작업grid
* @param {event}  e       : nexacro.GridClickEventInfo
*/
pForm.gfnChangeChkToRadio = function(objGrid,e)
{
	var objDs  = objGrid.getBindDataset();
	var rowCnt = objDs.rowcount;
	var colId  = this.gfnGetColidProperty(objGrid.getCellProperty("body", e.cell, "text"));
	
	var findRow = objDs.findRowExpr("currow!=" + e.row + " && " + colId + "=='1'");
	if(findRow >= 0)
	{
		objDs.setColumn(findRow,colId,"0"); 
	}
}

/**
* @class 현재form부터 상위form을 뒤져서 dataset찾기
* @param {object} objForm : this form
* @param {string} sDsId   : 찾고싶은 dataset string형id
*/
pForm.gfnGetParentDataset = function(objForm, sDsId)
{
	var oParent = objForm; //현재 form부터 찾기
	var objDs;
	for(var j=0; j<=9; j++)
	{
		if (oParent.id == "form")  //div, tab등은 제외 (oParent.objects[] 에서 오류 발생)
		{
			objDs = oParent.objects[sDsId];
			if ( (objDs instanceof nexacro.NormalDataset) )
			{
				return objDs;
			}
		}
		oParent = oParent.parent;
		objDs = "";
	}
	return null;
}


/**
* @class dataset을 초기 상태로 원복
* @param {object} objDs : 작업 dataset
*/
pForm.gfnDefaultDataset = function(objDs, sortStr, lastRow)
{
	if (this.gfnDsIsUpdated(objDs) == false) return;
	lastRow = (this.gfnIsNull(lastRow) ? 0 : lastRow);

 	objDs.set_updatecontrol(false);
 	objDs.set_enableevent(false);
// 	var rowCnt = objDs.getRowCount();
// 	var colCnt = objDs.getColCount();   
// 	
// 	for(var i=0; i< rowCnt; i++)
// 	{   
// 		var rowType = objDs.getRowType(i);
// 		// 1. 추가된 행일 경우 삭제   
// 		if(rowType == Dataset.ROWTYPE_INSERT)
// 		{         
// 			objDs.deleteRow(i);
// 			rowCnt--;
// 			i--;
// 		}
// 		// 2. 데이타셋 값이 변경된 경우, 원복
// 		else if(rowType == Dataset.ROWTYPE_UPDATE)
// 		{
// 			for(var j=0; j< colCnt; j++)
// 			{      
// 				objDs.setColumn(i, j, objDs.getOrgColumn(i,j));
// 			}
// 			objDs.setRowType(i, Dataset.ROWTYPE_NORMAL);
// 		}
// 	}
// 
// 	// 3. 삭제된 row 원복
// 	var delCnt = objDs.getDeletedRowCount();
// 	for(var i=0; i<delCnt; i++)
// 	{
// 		var addRow = objDs.addRow();
// 		for(var j=0; j< colCnt; j++)
// 		{      
// 			objDs.setColumn(addRow, j, objDs.getDeletedColumn(i,j));
// 		}
// 		objDs.setRowType(addRow, Dataset.ROWTYPE_NORMAL);
// 	}
// 	if (this.gfnIsExist(sortStr)) objDs.set_keystring(sortStr);
// 	objDs.applyChange();  //삭제된 row clear해줌
	
	objDs.set_enableevent(true);
	objDs.reset();
	objDs.set_rowposition(lastRow);
	objDs.set_updatecontrol(true);
//objDs.set_rowposition(-1);
//objDs.set_rowposition(0);
}


/** type : Dataset
* @class Dataset특정Row의 자료를 Json객체로 만들기 
* @param {Dataset} objDs : 작업대상 dataset
*        {int}     row   : json으로 만들 row
*/
pForm.gfnDsMakeJson = function(objDs, row) 
{
	var oJson = {};
	for(var idx=0; idx<objDs.getColCount(); idx++) {
		var colId = objDs.getColID(idx);
		var val   = objDs.getColumn(row, colId)
		oJson[colId] = val;
	}
	return oJson;
}

/** type : Dataset
* @class Dataset특정Row의 자료를 Json객체로 만들기 (여러줄)
* @param {Dataset} objDs : 작업대상 dataset
*        {int}     row   : json으로 만들 row
*/
pForm.gfnDsMakeJsonMultiRow = function(objDs, colList)
{
	var aColList = colList.split(",");
	var rowCnt = objDs.rowcount;
	var colCnt = aColList.length;
	
	var objRtn = [];
	for(var i=0; i<rowCnt; i++) {
		oneJson = {};
		for(var j=0; j<colCnt; j++) {
			//oneJson.add(aColList[j], objDs.getColumn(i, aColList[j]));
			oneJson[aColList[j]] = objDs.getColumn(i, aColList[j]);
		}
		objRtn[i] = oneJson;
	}
	return JSON.stringify(objRtn);
}
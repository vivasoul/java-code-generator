﻿/**
*  @FileName 	GridUtil.js 
*/
var pForm = nexacro.Form.prototype;

/**
 * 1. checkbox 관련 함수
 *   - gfnGrdcheckAllProgress    : 그리드 셀 전체 선택 시 progressbar 조회용
 *   - gfnGrdCheckAllCell        : 그리드 셀 전체 선택. 
 *   - 
 *   - 
 * 2. grid 생성, 삭제, 조작관련 함수
 *   - gfnCopyGrid               : 그리드 복사
 *   - 
 * 3. grid 열(컬럼) 관련 함수
 *   - gfnChangeGridCell         : Grid에서 특정cell 2개를 서로 교환.이동(change)하기
 *   - 
 * 4. grid head관련 함수
 *    - gfnGetHeadColIndex       : 그리드 head cell중 text명이 몇번째 col  index 얻기
 *    - gfnGetHeadCellIndex      : 그리드 head cell중 text명이 몇번째 cell index 얻기
 * 8. grid 속성값 관리 함수
 *   - gfnGetColId               : Grid에서 click한 cell의 컬럼ID 얻기
 *   - gfnGetColidProperty       : Grid Column id 가져오는 함수
 *   - 
 * 9. 기타
 *   - gfnGridCellSetFocus       : Grid cell focus 위치시키기
 *   - 
 */



/************************************************************************************************
* 1. checkbox 관련 함수
************************************************************************************************/

/**
 * @class  그리드 셀 전체 선택 시 progressbar 조회용
 * @param  obj   작업할 그리드
 * @param  nCell 선택된 해드셀 번호
 * @return boolean 체크 처리여부
 * @exam   gfnGrdcheckAllProgress(this.gridNm, 0)
 * @참고  progressbar(setWaitCursor)는 sync일때는 조회가 안됨. 반드시 asnyc만 가능함
 *         그래서 timer를 하나 생성 하면서 asnyc를 만들어서 progressbar를 보여주는 형태임
 */
pForm.objGrdChcekcAll;
pForm.gfnGrdcheckAllProgress = function(obj, nCell)
{
	if(this.gfnToUpper(this.gfnGetType(obj)) != "GRID") return;
	
	this.objGrdChcekcAll = obj;
	this.setWaitCursor(true); 
	this.addEventHandler("ontimer", this._Grd_checkAllTimer, this)
	this.setTimer(4551, 5);
}
pForm._Grd_checkAllTimer = function(obj,e)
{
	if (e.timerid == 4551)
	{
		this.killTimer(4551);
		this.gfnGrdCheckAllCell(this.objGrdChcekcAll, 0);
		this.setWaitCursor(false); 
	}
}

/**
 * 농부 : 다방면으로 테스트는 못해봤음
 * 그리드 셀 전체 선택. 
 * 그리드 head에 cell merge됐을 경우에도 전체 선택
 * <pre>
 * - 제약사항
 *     Cell의 Edit속성이 수식(Expr)을 사용한 경우는 해당 폼에서 직접 처리를 해야함.
 * - Grid.Edit속성에 Expr이 있는 경우는, 해당화면에서 처리하도록 변경
 * - Cell merge된 경우 로직 추가.
 * </pre>
 * @param obj   작업할 그리드
 * @param nCell 선택된 해드셀 번호
 * @return boolean 체크 처리여부
 */
pForm.gfnGrdCheckAllCell = function(obj, nCell)
{
	if(this.gfnToUpper(this.gfnGetType(obj)) == "GRID") {
		// 그리드 해더가 체크박스인 경우
		var nHeadColIdx  = parseInt(obj.getCellProperty("Head",nCell,"col"));
		var sDipType     = this.gfnToLower(obj.getCellProperty("Head",nCell,"displaytype"));
//trace('sDipType->' + sDipType);
		var nHeadSubCnt  = obj.getSubCellCount("Head", nCell);
		
		// head에 매칭되는 body의 nCell 찾기.
		var aBodyColIdx = new Array();
		var cnt = 0;
		for(var i=0; i<obj.getCellCount("Body"); i++)
		{
			var nBodyColIdx  = parseInt(obj.getCellProperty("Body",i,"col"));
			if(nHeadColIdx == nBodyColIdx)
			{
				aBodyColIdx[cnt++] = i;
			}
		}
		
		// head에 매칭되는 body의 nCell중 첫번째 체크박스인 nCell 찾기.
		var nBodyCell = -1;
		var sColId 	  = "";
//trace('this.gfnToLower(aBodyColIdx)->' + this.gfnToLower(aBodyColIdx));
		for(var i=0; i<this.gfnLength(aBodyColIdx); i++)
		{
			var sEdtType     = this.gfnToLower(obj.getCellProperty("Body",aBodyColIdx[i],"edittype"));
			var nBodySubCnt  = obj.getSubCellCount("Body", aBodyColIdx[i]);

			// subCellCount가 1인 경우가 존재하는데..SubCell은 Edit속성을 가지고 있지 않다.
			// 이 경우는 SubCell을 포함하는 Cell의 Edit속성을 확인하는게 맞는 방법일 것 같다..
			// subcellCount가 1인 경우는...[merge:아니오:subCell:Edit sub Cell Editor:merge] 두번 중복해서 merge하면 subCellCount가 1이 된다.
			// if(nBodySubCnt > 0) => if(nBodySubCnt > 1) 변경.
//trace('nBodySubCnt->' + nBodySubCnt);
//trace('sEdtType->' + sEdtType);

			if(nBodySubCnt > 1)	
			{
				for(var j=0; j<nBodySubCnt; j++)
				{
					var sSubEdtType = this.gfnToLower(obj.getSubCellProperty("Body", aBodyColIdx[i], j,"edittype"));
					if(sSubEdtType == "checkboxcontrol")
					{
						sColId 	  = obj.getSubCellProperty("Body", aBodyColIdx[i], j, "text");
						break;
					}
					if(this.gfnIsNull(sColId) == true)
						break;
				}
			}
			else if(sEdtType == "checkbox")
			{
				sColId 	  = this.gfnGetColidProperty(obj.getCellProperty("Body",aBodyColIdx[i],"text"));
				break;
			}
		}
//trace('sColId->' + sColId);
		// body중 checkbox인 컬럼이 해당 col에 없으면 종료.
		if(this.gfnIsNull(sColId) == true)
			return false;

		// merge된 서브셀이 존재하면 서브셀에 체킹을 한다.
//trace('nHeadSubCnt->' + nHeadSubCnt);
		if(nHeadSubCnt > 0)
		{
			for(var i=0; i<nHeadSubCnt; i++)
			{
				var sSubDipType = this.gfnToLower(obj.getSubCellProperty("Head", nCell, i,"displaytype"));
//trace('sSubDipType->' + sSubDipType);
				if( sSubDipType == "checkboxcontrol" )
				{
					var objDs = obj.getBindDataset();
					obj.set_enableredraw(false);
					objDs.set_enableevent(false);
					
					//선택 값 전환 ( true <-> false )
					var sText = this.gfnDecode(obj.getSubCellProperty("Head", nCell, i,"text"), "1", "0", "0", "1", "1");
					obj.setSubCellProperty("Head",nCell,i,"text",sText);
//trace(objDs.id + " :: " + objDs.rowcount);
					for(var i = 0; i < objDs.getRowCount(); i++) {
//trace(i + " :: " + sColId + " :: " + sText);
						objDs.setColumn(i, sColId, sText);
					}
					objDs.set_enableevent(true);
					obj.set_enableredraw(true);
					return true;
				}
			}
		}
		else if( sDipType == "checkboxcontrol" ) 
		{
			var objDs = obj.getBindDataset();
			obj.set_enableredraw(false);
			objDs.set_enableevent(false);
			
			//선택 값 전환 ( true <-> false )
			var sText = this.gfnDecode(obj.getCellProperty("Head",nCell,"text"), "1", "0", "0", "1", "1");
			obj.setCellProperty("Head",nCell,"text",sText);
			for(var i = 0; i < objDs.getRowCount(); i++) {
//trace(i + " :: " + sColId + " :: " + sText);
				objDs.setColumn(i, sColId, sText);
			}
			objDs.set_enableevent(true);
			obj.set_enableredraw(true);
			return true;
		}
	}
	return false;
};

/************************************************************************************************
* 2. grid 생성, 삭제, 조작관련 함수
************************************************************************************************/
/**
 * @class  그리드 복사
 * @param  {object}  objGrid      : 작업할 그리드
 * @param  {boolean} bSizeZero    : cell Size가 0인 경우 복사여부    (true 또는 null : 복사, false: 제외)
 * @param  {string}  strNewGridId : 그리드 copy후 신규생성된 grid id
 * @param  {object}  oPos         : {left:0, top:0, width:100, height:200} 형식의 json object
 * @return {string}  grid contents string
 *         또는
 *         {object}  grid object
 * @exam   var oPos = {left:0, top:0, width:300, height:200};
 * @exam   gfnCopyGrid(this.gridNm, true, "gridNmExcel", oPos)
 * @exam   gfnCopyGrid(this.gridNm)
 */
this.gfnCopyGrid = function(objGrid, bSizeZero, strNewGridId, oPos)
{
	var srcFormats = objGrid.formats;
	var bindDs     = objGrid.binddataset;
	var strGridId  = (this.gfnIsNull(strNewGridId) ? "_copyTempGrid" : strNewGridId);
	
	//0. grid size 
	if (this.gfnIsNull(oPos))
	{
		oPos = {left:0, top:0, width:0, height:0};
	}
	
	//1. grid 생성
	var objNewGrid = this.components[strGridId];
	if (this.gfnIsNull(objNewGrid))
	{
		objNewGrid = new Grid(strGridId, oPos.left, oPos.top, oPos.width, oPos.height); //, null, null);
		this.addChild(strGridId, objNewGrid); 
		objNewGrid.show();
	}
	
	objNewGrid.set_formats(srcFormats);
	objNewGrid.set_binddataset(bindDs);
	
	//2. size 0 인 cell 삭제
	if (bSizeZero == false)
	{
		var cellCnt = objNewGrid.getCellCount("body");
		for(var idx=cellCnt-1; idx>=0; idx--)
		{
			var size = objNewGrid.getFormatColProperty(idx, "size");
			if (size == 0) objNewGrid.deleteContentsCol(idx);
		}
	}
	
	//3. strNewGridId 값이 
	//   - null이면 : 임시 grid 삭제 
	//                 format string return
	//   - 존재 시  : 화면에 보여주는 grid 또는 excel down시 임시로 생성한 Grid임
	//                 grid object return
	if (this.gfnIsNull(strNewGridId))
	{
		var newFormats = objNewGrid.formats;
		this.removeChild(strGridId); 
		objNewGrid.destroy(); 
		objNewGrid = null;
		return newFormats;
	}
	else
	{
		return objNewGrid;
	}
}

/************************************************************************************************
* 3. grid 열(컬럼) 관련 함수
************************************************************************************************/
/**
 * @class Grid에서 특정cell 2개를 서로 교환.이동(change)하기
 * @param {Object} objGrid - 대상그리드
 * @param {number} firstCell  - 첫번째 cell
 * @param {number} secondCell - 두번째 cell
 * @return N/A
 * @example this.gfnChangeGridCell(this.grdNm, 2, 5);  //(2번째 cell과 5번째 cell간에 이동하기)
*/
pForm.gfnChangeGridCell = function(objGrid, firstCell, secondCell)
{
	//1. 초기정보 얻기
	var firstSize  = objGrid.getFormatColProperty(firstCell, "size");
	var secondSize = objGrid.getFormatColProperty(secondCell, "size");
	var contents = objGrid.formats;

	//2. cell이동
	contents = nexacro.replaceAll(contents, '<Cell col="' + firstCell + '"', '<Cell col="first"');
	contents = nexacro.replaceAll(contents, '<Cell col="' + secondCell + '"', '<Cell col="' + firstCell + '"');
	contents = nexacro.replaceAll(contents, '<Cell col="first"', '<Cell col="' + secondCell + '"');
	objGrid.set_enableredraw(false);
	objGrid.set_formats(contents);
	objGrid.setFormatColProperty(firstCell , "size", secondSize);
	objGrid.setFormatColProperty(secondCell, "size", firstSize);
	objGrid.set_enableredraw(true);
}

/************************************************************************************************
* 4. grid head관련 함수
************************************************************************************************/
/**
* @class  그리드 head cell중 text명이 몇번째 cell index 얻기 
* @param  {Grid}   objGrid : 대상 Grid
*         {string} val     : 찾을 head text값
*         {int}    nextIdx : head text에 동일명칭이 존재 시 해당 순서
* @exam   this.gfnGetHeadCellIndex(this.grdNm, "거래처코드")
*         this.gfnGetHeadCellIndex(this.grdNm, "거래처코드", 2)
* @return grid cell index
*/
pForm.gfnGetHeadCellIndex = function(objGrd, val, nextIdx)
{
	var cnt = objGrd.getCellCount("head");
	nextIdx = this.gfnIsNull(nextIdx) ? 1 : nextIdx;
	var seqIdx = 0;     //nextIdx와 동일한 idx인지 비교
	var searchIdx;  
	for(var cell=0; cell<cnt; cell++) {
		var text = objGrd.getCellProperty("head", cell, "text");
		if (text == val) {
			seqIdx ++;
			if (seqIdx == nextIdx) {
				return cell;
			}
		}
	}
	
	if (seqIdx > 0) {
		return cnt-1;
	} else {
		return null;
	}
}

/**
* @class  그리드 head cell중 text명이 몇번째 col index 얻기 
* @param  {Grid}   objGrid : 대상 Grid
*         {string} val     : 찾을 head text값
*         {int}    nextIdx : head text에 동일명칭이 존재 시 해당 순서
* @exam   this.gfnGetHeadColIndex(this.grdNm, "거래처코드")
*         this.gfnGetHeadColIndex(this.grdNm, "거래처코드", 2)
* @return grid col index
*/
pForm.gfnGetHeadColIndex = function(objGrd, val, nextIdx)
{
	var cnt = objGrd.getCellCount("head");
	nextIdx = this.gfnIsNull(nextIdx) ? 1 : nextIdx;
	var seqIdx = 0;     //nextIdx와 동일한 idx인지 비교
	var searchIdx;  
	for(var cell=0; cell<cnt; cell++) {
		var text = objGrd.getCellProperty("head", cell, "text");
		if (text == val) {
			seqIdx ++;
			if (seqIdx == nextIdx) {
				return objGrd.getCellProperty("head", cell, "col");
			}
		}
	}
	
	if (seqIdx > 0) {
		return objGrd.getCellProperty("head", cnt-1, "col");
	} else {
		return null;
	}
}

/************************************************************************************************
* 8. grid 속성값 관리 함수
************************************************************************************************/
/**
 * @class Grid에서 click한 cell의 컬럼ID 얻기
 * @param {Object} obj:nexacro.Grid
 * @param {Object} e:nexacro.GridClickEventInfo
 */
pForm.gfnGetColId = function(obj, e)
{
	if (e.row < 0) return "";
	
	var sColId = obj.getCellProperty("body", e.cell, "text");
	var sColId = nexacro.replaceAll(sColId, "bind:", "");
	return sColId;
};

/**
* @class  Grid Column id 가져오는 함수
* @param  {string} 가져올 id 값
* @return {string} 가져온 값
* @exam   this.gfnGetColidProperty("bind:colId");
*/
pForm.gfnGetColidProperty = function(strText)
{
	if(this.gfnIsNull(strText)) return "";
	arrText = strText.split(":");
	if(arrText.length == 2) return arrText[1];
	return strText;
}




/************************************************************************************************
* 9. 기타
************************************************************************************************/

/**
 * @class Grid cell focus 위치시키기
 * @param {Object} Grid Object
 * @param {String} Column ID
*/
// pForm.gfnGridCellSetFocus = function(objGrid, sColId)
// {
// 	objGrid.setCellPos(objGrid.getBindCellIndex('Body', sColId));
// 	objGrid.showEditor(true);
// 	objGrid.setFocus();
// };
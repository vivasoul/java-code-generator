﻿/**
*  @Desction   메시지 관리
*  @Creator 	김용학
*  @CreateDate 	2020.04.23
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2019.XX.XX			XXXXX					XXXXXXXXXXXXXXXXXXXXXXXXX
*******************************************************************************
*/

var pForm = nexacro.Form.prototype;


/**
* @class 메세지팝업오픈
* @param {String} sMsgId      - 메세지ID	
* @param {Array}  arrArg      - 메세지에 치환될 부분은 "{0~N}"이 되고 치환값은 배열로 넘김 
* @param {String} sPopId      - 팝업ID(하나의 callback함수에서 중복된 메시지 처리를 할 경우 PopId구분을 위해 unique한 ID 반드시 사용)
* @param {String} sCallback   - 팝업콜백 (confirm성 메시지를 사용시 반드시 필요)
* @param {String} sType       - 메시지 타입(A:Alert, C:Confirm)
* @param {String} sAlign      - 메시지 문구 정렬 (C:Center, L:Left)
*                             - 현재 argument로 하고 있는데.. db에서 관리하는게 좋을 듯
* @return N/A
* @example
* this.gfnAlert(this, "A", ["확인하세요"]);	
*/
pForm.gfnAlert = function (sMsgId, arrArg, sPopId, sCallback, sType, sAlign)
{
//trace(sMsgId + " :: " + arrArg.toString());
	if (this.gfnIsNull(sMsgId))    { return; }
	//if (this.gfnIsNull(sCallback)) { sCallback = "fn_msgCallback";	}
	if (this.gfnIsNull(sAlign))    { sAlign = 'C'; }
	
	var aRet;
	var sMsgNm;
	var sMsgType;
	var sMsgUrl = "";
	
    aRet = this.gfnGetMessage(sMsgId,arrArg,true);
	if (aRet == false)		return;
	
	sMsgNm 	 = aRet[0];
	sMsgType = aRet[1];
	
	sMsgType = (this.gfnIsNotNull(sType) ? sType : sMsgType) ;
	switch (sMsgType) {
		case "C":
			sMsgUrl = "Comm::CommConfirm.xfdl";
			//alert("개발오류. 해당 Message id는 confirm형 입니다. gfnConfirm api를 사용하세요");
			//return;
			break;
		default:
			sMsgUrl = "Comm::CommAlert.xfdl";
			break;
	}
	
	//팝업 ID 없을 시 default 설정
	if(this.gfnIsNull(sPopId)) sPopId = sMsgId;

	// messagePopup
	var objArg = {paramContents: sMsgNm, paramMsgType:sMsgType, paramAlign: sAlign};
	var oOption = {titlebar: "false"};
	
	this.gfnAddPopup(sPopId, sMsgUrl, objArg, sCallback, oOption);
};

/**
* @class confirm창 호출시
* @param {String} sMsgId      - 메세지ID	
* @param {Array}  arrArg      - 메세지에 치환될 부분은 "{0~N}"이 되고 치환값은 배열로 넘김 
* @param {String} sPopId      - 팝업ID(하나의 callback함수에서 중복된 메시지 처리를 할 경우 PopId구분을 위해 unique한 ID 반드시 사용)
* @param {String} sCallback   - 팝업콜백 (confirm성 메시지를 사용시 반드시 필요)
* @param {String} sAlign      - 메시지 문구 정렬 (C:Center, L:Left)
*                             - 현재 argument로 하고 있는데.. db에서 관리하는게 좋을 듯
* @return N/A
* @example
* this.gfnAlert(this, "A", ["확인하세요"]);	
*/
pForm.gfnConfirm = function (sMsgId, arrArg, sPopId, sCallback, sAlign)
{
	this.gfnAlert(sMsgId, arrArg, sPopId, sCallback, "C", sAlign);
};

/**
* @class 메시지코드 없이 . 메시지만 존재 시 alert
* @param {String} msg       - 메세지
* @param {Array}  arrArg    - 메세지에 치환될 부분은 "{0~N}"이 되고 치환값은 배열로 넘김 
* @param {String} sPopId]   - 팝업ID(하나의 callback함수에서 중복된 메시지 처리를 할 경우 PopId구분을 위해 unique한 ID 반드시 사용)
* @param {String} sCallback - 팝업콜백 (confirm성 메시지를 사용시 반드시 필요)
* @return N/A
* @example
* this.gfnAlertMsg("메시지내용");
*/
pForm.gfnAlertMsg = function (msg, arrArg, sPopId, sCallback)
{
	var sMsgUrl = "Comm::CommAlert.xfdl";
	var oArg = {paramContents:msg};
	var oOption = {titlebar: "false"};
	this.gfnAddPopup("alertMsg",sMsgUrl,oArg,sCallback,oOption);
};

/**
* @class 메세지 치환
* @param {String} msg    - 메세지	
* @param {Array}  values - 메세지에 치환될 부분은 "{0~N}"이 되고 치환값은 배열로 넘김 
* @return {String}
*/
pForm.gfnConvertMessage = function(msg, arrArg) 
{
    if (this.gfnIsExist(arrArg) && (typeof arrArg) == "string") {
		arrArg = new Array(arrArg);
	}
	
	return msg.replace(/\{(\d+)\}/g, function() {
        return arrArg[arguments[1]];
    });
};

// pForm.gfnConvertMessage = function(msg, values) 
// {
//     return msg.replace(/\{(\d+)\}/g, function() {
//         return values[arguments[1]];
//     });
// };


/**
* @class 메세지 치환 후 완성된 메시지 리턴
* @param {String} sMsgId - 메세지ID	
* @param {Array}  arrArg - 메세지에 치환될 부분은 "{0~N}"이 되고 치환값은 배열로 넘김 
* @param {Boolean}  bArrRet - 메시지 반환값을 array로 넘길지 여부. (true - [메시지,메시지타입], false(디폴트) - 메시지)
* @return {String}
*/
pForm.gfnGetMessage = function(sMsgId, arrArg, bArrRet) 
{
	var sMsgType, sMsg, sRet;
	
    var objApp = pForm.gfnGetApplication();
	var objMsgDs    = this.gfnGetGdsMsg(); //objApp.gds_msg;
	var objMsgDsSys = this.gfnGetGdsMsgSys(); //objApp.gds_msg;
	
	//업무용 msg 먼저 검색
	var nRow = objMsgDs.findRow("msgId", sMsgId);
	if( nRow >= 0) {
		sMsg     = objMsgDs.getColumn(nRow, "msgNm");
		sMsgType = objMsgDs.getColumn(nRow, "msgType");
	} else {
		//system용 msg 검색
		var nRow = objMsgDsSys.findRow("msgId", sMsgId);
		if( nRow >= 0) {
			sMsg     = objMsgDsSys.getColumn(nRow, "msgNm");
			sMsgType = objMsgDsSys.getColumn(nRow, "msgType");
		} else {
			trace("메시지ID (" + sMsgId + ")가 존재하지 않습니다.");
			return false;
		}
	}

	if (pForm.gfnIsNull(sMsg)) {
		sMsg = "";
	}
	
	// 줄바꿈 변경
	sMsg = sMsg.replace(/\\n/g, String.fromCharCode(10));
	if (pForm.gfnIsExist(arrArg)) sMsg = pForm.gfnConvertMessage(sMsg, arrArg);	
	
	if (bArrRet == true) {
		sRet = new Array();
		sRet[0] = sMsg;
		sRet[1] = sMsgType;
	} else {
		sRet = sMsg;
	}
	
	return sRet;
};

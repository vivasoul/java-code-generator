﻿/**
*  @FileName 	GridOnload.js 
*/
var pForm = nexacro.Form.prototype;

/**
 * 1. grid 설정
 *   - gfnSetGrid                      : Grid에 기능 추가
 *   - gfnGridAddProp                  : Grid에 기능 추가(addCol..)
 *   - gfnGridCheckboxNoStatusAdd      : Grid에 기능 추가(addCol..)
 *   - gfnGridGetFixedCell             : grid에 고정된 fixed cell index얻기
 *   - _gfnGrid_onheadclick             : 그리드헤드클릭 이벤트 [Sort, Checkbox]
 *   - gfnGrid_onkeydown               : 그리드키다운 이벤트 [cellcopypaste]
 *   - gfnGridUserHeaderFlg            : 유저헤더사용여부반환
 *   - gfnGridUserHeaderExcuteSort     : 유저헤더를 이용한 정렬
 *   - gfnGridSetSortStatus            : 정렬가능여부리턴
 *   - gfnGridGetBodyCellIndex         : head cell에 match되는 body cell을 얻어온다
 *   - gfnGridGetBindColumnNameByIndex : body cell index로 binding 된 컬럼명을 얻어온다.
 *   - gfnGridExecuteSort              : 소트를 실행한다
 *   - gfnGridGetGridCellObject        : Cell object 를 반환 (Grid 내부 속성이므로 get 용도로만 사용)
 *   - gfnClearSortMark                : 그리드의 Sort Mark 제거
 *   - _gfnGrid_onrbuttondown          : 마우스우클릭이벤트
 *   - _gfnPopupmenu_onmenuclick       : 내부함수로 팝업메뉴 클릭 시 발생하는 이벤트
 *   - gfnGridSetCssclass              : 행고정/해제시 css설정
 *   - gfnInitGrid                     : 그리드 초기화(체크박스 초기화)
 *   - gfnHeadCheckSelectAll           : 그리드헤드클릭이벤트 내부함수 (헤드클릭시 체크 ALL/None)
 *   - gfnMakeGridPopupMenu            : 마우스우클릭시 표현될 팝업메뉴생성
 *   - gfnGetGridUserProperty          : 그리드 설정 내부함수
 *   - _gfnDataset_rowtype_cancolumnchange : grid에서 공통 checkbox를 check시 이전 rowtype을 유지시켜줌
 *   - _gfnDataset_rowtype_oncolumnchanged : grid에서 공통 checkbox를 check시 이전 rowtype을 유지시켜줌
 *   - 
 * 2. grid popupmenu
 *   - gfnGridcellFix           : 셀고정(colfix)
 *   - gfnGridCellFree          : 셀고정해제(colfree)
 *   - gfnGridFilter            : 셀필터(cellFilter)
 *   - gfnGridCellFilterFree    : 셀필터해제(cellfilterfree)
 *   - gfnGridCellFind          : 찾기/바꾸기
 *   - gfnGridColHideShow       : 컬럼 숨기기/보이기
 *   - gfnGridExcelExport       : 엑셀익스포트
 *   - gfnGridExcelImport       : 엑셀임포트
 *   - gfnGridPersonalize       : 그리드 개인화
 *   - gfnGetUniqueId              : 그리드 개인화내용 저장을 위해 유니크한 아이디를 구성한다.
 *   - gfnClearHeadMark
 *   - gfnGridPersonalizeExcute : 그리드 개인화실행.
 *   - 
 *   - 
 * 3. popupmenu callback
 *   - gfnGridFormatChangeMsgCallback : 그리드 개인화 메세지콜백
 *   - gfnFindCallback                : 그리드 찾기/바꾸기 팝업 콜백
 *   - gfnGridFilterCallback          : 그리드 필터 팝업 콜백
 *   - gfnColumnHidCallback           : 그리드 컬럼숨기기/보이기
 *   - 
 * 4. popupmenu funciton
 *   - gfnFindGridText           : 주어진 문자열을 그리드에서 찾는다.
 *   - gfnReplaceGridText        : 주어진 문자열을 그리드에서 찾아서 바꿀 문자열로 변경한다.
 *   - gfnReplaceGridCellText    : 바꾸기에 의해 찾아진 행, 셀 인덱스에 해당하는 데이터를 실제 변경한다.
 *   - gfnReplaceIgnoreCase      : 문자열을 대소문자 구별없이 주어진 변경문자열(문자) 치환한다.
 *   - gfnReplaceDateMaskValue   : 날짜형으로 마스크 처리된 문자열에서 실제 값을 얻어온다.
 *   - gfnParseDateMask          : 날짜형 마스크 구문을 분석합니다.
 *   - gfnReplaceNumberMaskValue : 숫자형으로 마스크 처리된 문자열에서 실제 값을 얻어온다.
 *   - gfnCompareFindText        : 주어진 행, 셀 인덱스에 해당하는 그리드 데이터와 문자열을 비교하여 찾아진 결과를 반환
 *   - gfnGetBindColumnType      : 데이터의 타입반환
 *   - 
 * 5. 
 *   - 
 * 9. 기타
 *   - gfnGridDropDownOneClick             : Grid combo, date(calendar) 팝업창을 한번클릭으로 팝업창이 열리도록 처리
 *   - 
 */

/*
grid propertiy
	filedown      : 파일다운로드  (업무화면의.. fn_fileDownload(objGrd) 함수 호출)
	filepreview   : 파일미리보기  (업무화면의.. fn_filePreview(objGrd) 함수 호출)
	colfix        : 틀고정 (열)
	rowfix        : 틀고정 (행)
	sort          : 정렬
	filter        : 그리드 필터
	initial       : 초기상태로
	find          : 찾기/바꾸기
	colhide       : 컬럼숨기기/보이기
	export        : 엑셀내보내기
	import        : 엑셀가져오기
	personal      : 현재포맷저장
	cellcopypaste : 클립보드 복사
	checkbox      : (체크박스 생성)         head 클릭 시 전체체크
	chk           : (체크박스 생성은 안함) head 클릭 시 전체체크
	no            : 순번
	status        : 상태
	cellmove	  : 컬럼이동
	cellsize 	  : 컬럼사이즈조정
	autoenter	  : autoenter
*/

//pForm.defaultmenulist = "sort,export"; //,export"; //,colfix,rowfix,filter,initial"; //colfix,rowfix,filter,find,colhide,export,initial,personal,cellmove,cellsize,autoenter";   //default 모두 제거 (플젝별로 필요한 항목 추가)
pForm.defaultmenulist = "colfix,rowfix,filter,find,colhide,export,initial";   //default 모두 제거 (플젝별로 필요한 항목 추가)
pForm.selectmenulist  = "checkbox,chk,no,status,find,colhide,export,import,personal,userheader,cellcopypaste,cellmove,cellsize,autoenter";
pForm.popupmenulist   = "filedown,filepreview,colfix,rowfix,filter,initial,find,colhide,export,import,personal,userheader";                  //grid popupmenu가능 속성 목록

/*
  Grid Comm Option
	uCommSetCallback  : grid user property속성에 대한 함수 수행 후 callback 함수
	                    (2020.04.20일 기준 : checkbox, sort만 됨)
    uCommChkColId     : 해당속성값이 정의된 컬럼들은 rowtype을 변경하지 않음
    uCommNotSortColId : grid sort시 sort예외 컬럼 목록(예, col1,col2,col3,...)
	uCommAutoChkColId : grid head checkbox에서 자동체크 처리 컬럼id
*/

// sort
// 헤더 클릭시 정렬 false= 오름/내림 true= 오름/내림/없음
pForm.SORT_TOGGLE_CANCEL = true;
pForm.MARKER_TYPE = "image"; // 정렬 표시자 구분 (text or image)
// Grid Head 에 정렬 상태를 표시할 텍스트 또는 이미지 경로 지정 
//pForm.MARKER = ["▲", "▼"];// [오름차순표시, 내림차순표시]
pForm.MARKER = ["btn_WF_SortUp", "btn_WF_SortDown"];
//cell copy and paste 시 chorme용 textarea 저장 object
pForm.tragetGrid = "";

pForm.COM_CHECK_ID = "chk";
pForm.COM_GRID_NO_NM = "번호";
pForm.COM_GRID_STATUS_NM = "상태";

/************************************************************************************************
* 1. grid 설정
************************************************************************************************/
/**
* @class Grid에 기능 추가
* @param {Object} obj	- 대상그리드
* @return N/A
* @example
* this.gfnSetGrid(this.grdMain);	
*/
pForm.gfnSetGrid = function(objForm, objGrid)
{
	//1. 기본속성 지정
	this.gfnSetGridBaseProperty(objGrid);

	//기본 Event추가
	objGrid.addEventHandler("oncellclick", this._gfnGrid_oncellclick, this);

	// uCommSet이 false인 경우 제외
	if (objGrid.uCommSet == "false") return;
	
	//Grid의 binddataset설정
	var objDs = objGrid.getBindDataset();

	// grid에 바인드된 Dataset이 없는 경우 return;
	if (this.gfnIsNull(objDs)) {
		this.gfnLog(objGrid.name + "에 데이터셋이 설정되지 않아 공통기능이 적용되지 않습니다.","info");
		return;
	}
	// Validation에서 foucus 처리시 사용
	else {
		objDs.bindgrid = objGrid;
	}
	
	// Grid의 UserProperty설정
	var arrProp = this.gfnGetGridUserProperty(objGrid);
	if (this.gfnIsNull(arrProp)) { return; } // 설정할 속성 없음
	//this.gfnLog("arrProp : " + arrProp);
	
	objGrid.set_enableevent(false);
	objGrid.set_enableredraw(false);	
	objDs.set_enableevent(false);
	
	// Grid의 UserProperty 관련 항목 추가
	objGrid.arrprop = arrProp;
	this.gfnGridAddProp(objGrid);
//if (objGrid.id == "Grid01_00") trace('4 arrProp -> ' + arrProp.toString());
	
//	objGrid.orgcurformat = objGrid.getCurFormatString();
	
	// 기존에 저장된 포멧 설정
// 	var objApp = pForm.gfnGetApplication();
// 	var objGds = objApp.gds_gridPersonal;
// 	
// 	var sFormatId = this.gfnGetUniqueId(objGrid);
// 	var sFormat, sOrgFormats;
// 	var nFindRow = objGds.findRow("GRID_FORMAT_ID", sFormatId);
// 	if (nFindRow > -1) {
// 		sOrgFormats = objGds.getColumn(nFindRow, "ORG_FORMAT_XML");
// 		if (sOrgFormats == objGrid.getFormatString()) {		// 저장시점의 포멧과 현재화면 포멧이 변경되지 않았을 경우만 적용
// 			objGrid.orgformats = sOrgFormats;
// 			sFormat = "<Formats>" + objGds.getColumn(nFindRow, "FORMAT_XML") + "</Formats>";
// 			objGrid.set_formats(sFormat);
// 		} else {		// 포멧이 달라진 경우 기존 저장된 포멧은 삭제
// 			objGds.deleteRow(nFindRow);
// 		}
// 	} else {
// 		objGrid.orgformats = objGrid.getFormatString();
// 	}
	
	this.gfnMakeGridPopupMenu(objGrid,arrProp);//popupmenu 생성
	
	/*********************************************** 이벤트추가 START ***********************************************/
	objGrid.addEventHandler("onheadclick", this._gfnGrid_onheadclick, this); 	//헤드클릭이벤트추가
	
	var arr = this.popupmenulist.split(",");
	for (var n = 0, t = arr.length; n < t; n++) {
		if (arrProp.indexOf(arr[n]) >= 0) {
			//우클릭 이벤트 중 하나라도 있어야 팝업 이벤트 사용 가능 (우클릭이벤트추가)
			objGrid.addEventHandler("onrbuttondown", this._gfnGrid_onrbuttondown, this);	    
			break;
		}
	}
	if (arrProp.indexOf("cellcopypaste") >= 0) {
		//objGrid.addEventHandler("onkeydown", this.gfnGrid_onkeydown, this);
		this.gfnSetGridCopyPaste(objForm, objGrid);
	}
	
	
// 	for (var k = 0, s = arrProp.length; k < s; k++) {
// 		var arr = this.popupmenulist.split(",");
// 		for (var n = 0, t = arr.length; n < t; n++) {
// 			if (arrProp[k] == arr[n]) {
// 				//우클릭 이벤트 중 하나라도 있어야 팝업 이벤트 사용 가능
// 				//우클릭이벤트추가
// 				objGrid.addEventHandler("onrbuttondown", this._gfnGrid_onrbuttondown, this);	    
// 				break;
// 			}
// 		}
// 		if (arrProp[k] == "cellcopypaste") {
// 			objGrid.addEventHandler("onkeydown", this.gfnGrid_onkeydown, this);
// 		}
// 	}
	/*********************************************** 이벤트추가 END *************************************************/
	
	objGrid.set_enableevent(true);
	objGrid.set_enableredraw(true);	
	objDs.set_enableevent(true);
};	

/**
* @class Grid에 개발자 option없이도 default로 적용할 기능
* @param {Object} obj - 대상그리드
* @return N/A
* @example
* this.gfnSetGrid(this.grdMain);	
*/
pForm.gfnSetGridBaseProperty = function(objGrid)
{
	objGrid.set_autoenter("select");
	objGrid.set_autoupdatetype("itemselect");
	objGrid.set_cellsizingtype("col");
	//objGrid.set_nodatatext(this.gfnGetMessage("MSG1003")); // 조회된 데이터가 없습니다.
}

/**
 * @class Grid에 기능 추가(addCol..)
 * @param {Object} objGrid	- 대상그리드
 * @return N/A
 * @example
 * this.gfnGridAddProp(this.grdMain);	
 */
pForm.gfnGridAddProp = function (objGrid)
{
	var arrProp = objGrid.arrprop;
		
	// 설정한 순서대로 표시하기 위해 역순으로 추가
	var objDs = objGrid.getBindDataset();
	for (var i = arrProp.length -1, s = 0; i >= s; i--) {
		switch (arrProp[i]) {
			case "status":
				this.gfnGridCheckboxNoStatusAdd(objGrid, objDs, "status");
				break;
			case "checkbox":
				this.gfnGridCheckboxNoStatusAdd(objGrid, objDs, "checkbox");
				break;
			case "no":
				this.gfnGridCheckboxNoStatusAdd(objGrid, objDs, "no");
				break;
			case "sort":
				objGrid.sort = "true";
				break;
			case "cellmove":
				objGrid.set_cellmovingtype("col");
				break;
			case "cellsize":
				objGrid.set_cellsizingtype("col");
				objGrid.set_cellsizebandtype("allband");
				break;
			case "autoenter":
				objGrid.set_autoenter("select");
				break;
			default: break;
		}
	}
};

/**
 * @class Grid에 기능 추가 - checkbox, no, status 상태 추가
 * @param {Object} objGrid	- 대상그리드  
 * @param {Object} objDs	- 대상데이터셋
 * @param {Array} addProp	- 기능
 * @return N/A
 * @example
 * this.gfnGridCheckboxNoStatusAdd(this.grdMain, this.dsList, [checkbox,no,status]);	
*/
pForm.gfnGridCheckboxNoStatusAdd = function(objGrid, objDs, addProp)
{	
	var nHeadColIndex;
	if (this.gfnIsNull(objDs.insertheadcell)) {
		nHeadColIndex = 0;
	} else {
		nHeadColIndex = objDs.insertheadcell;
	}

	var nBodyColIndex;
	if (this.gfnIsNull(objDs.insertbodycell)) {
		nBodyColIndex = 0;
	} else {
		nBodyColIndex = objDs.insertbodycell;
	}
	
	var nFixedCell      = this.gfnGridGetFixedCell(objGrid);  //화면.grid에 이미 fixed cell 이 있는지 확인.
	var nFormatRowCount = objGrid.getFormatRowCount();
	var nHeadCount = -1;
	var nBodyCount = -1;
	for (var i = 0; i < nFormatRowCount; i++) {
		if (objGrid.getFormatRowProperty(i, "band") == "head") {
			nHeadCount++;
		}
		if (objGrid.getFormatRowProperty(i, "band") == "body") {
			nBodyCount++;
		}
	}

	var sNo = this.COM_GRID_NO_NM;			// 순번
	var sStatus = this.COM_GRID_STATUS_NM;	// 상태
	var sCheckYn = this.gfnNvl(objGrid.checkboxyn, "");

	//체크박스
	if (addProp == "checkbox") {
		objDs.set_enableevent(false); 
		var idx = -1;
		for (var j = 0, s = objDs.getColCount(); j < s; j++) {
			var tmpcol = objDs.getColID(j);
			if (tmpcol == this.COM_CHECK_ID) {
				idx = j;
			}
		}
		if (idx < 0) {
			objDs.addColumn(this.COM_CHECK_ID, "STRING", 1);
		}
		
		for (var i = 0, s = objGrid.getCellCount("head"); i < s; i++) {
			//헤드텍스트
			var tmp = objGrid.getCellProperty("head", i, "text");
			if (tmp == "0") {
				// head cell index 에 해당하는 body cell index
				var bodyCellIndex = this.gfnGridGetBodyCellIndex(objGrid, i);
				// body cell index 에 해당하는 바인드 컬럼명
				var columnName = this.gfnGridGetBindColumnNameByIndex(objGrid, bodyCellIndex);
				if (columnName == this.COM_CHECK_ID) {
					//return;
					objGrid.deleteContentsCol("left", i);
				}
			}
		}
		
		if (nFixedCell > 0) this.gfnGridCellFree(objGrid);
		objGrid.insertContentsCol("left", nBodyColIndex);			
		objGrid.setFormatColProperty(nBodyColIndex, "size", "30");	
		
		objGrid.setCellProperty("head", nHeadColIndex, "displaytype", "checkboxcontrol");
		objGrid.setCellProperty("head", nHeadColIndex, "edittype", "checkbox");
		objGrid.setCellProperty("head", nHeadColIndex, "text", "0");
		
		if (this.gfnIsNull(sCheckYn)) {
			objGrid.setCellProperty("body", nBodyColIndex, "displaytype", "checkboxcontrol");
			objGrid.setCellProperty("body", nBodyColIndex, "edittype", "checkbox");
		} else {
			objGrid.setCellProperty("body", nBodyColIndex, "displaytype", "expr:CHK_YN=='Y'?'checkboxcontrol':'none'");
			objGrid.setCellProperty("body", nBodyColIndex, "edittype", "expr:CHK_YN=='Y'?'checkbox':'none'");
		}
		objGrid.setCellProperty("body", nBodyColIndex, "text", "bind:" + this.COM_CHECK_ID);
		
		objGrid.mergeContentsCell("head", 0, nBodyColIndex, nHeadCount, nBodyColIndex, nHeadColIndex, false);	
		objGrid.mergeContentsCell("body", 0, nBodyColIndex, nBodyCount, nBodyColIndex, nBodyColIndex, false);		
		if (nFixedCell > 0) this.gfnGridcellFix(objGrid, nFixedCell+1, -1);
		
		nHeadColIndex++;
 		nBodyColIndex++;
		
		//기본 checkbox를 클릭해도 .. rowtype을 변경하지 않게 처리
		var uCommChkColId = objGrid.uCommChkColId;
		if (this.gfnIsExist(uCommChkColId)) {
			objDs.uCommChkColId = uCommChkColId;
			objDs.addEventHandler("cancolumnchange", this._gfnDataset_rowtype_cancolumnchange, this);
			objDs.addEventHandler("oncolumnchanged", this._gfnDataset_rowtype_oncolumnchanged, this);
		}
		
	}
	//번호
	if (addProp == "no") {
		for (var i = 0, s = objGrid.getCellCount("head"); i < s; i++) {
			var tmp = objGrid.getCellProperty("head", i, "text");
			if (tmp == "NO" || tmp == this.COM_GRID_NO_NM) {
				//return;
				objGrid.deleteContentsCol("left", i);
			}
		}
		if (nFixedCell > 0) this.gfnGridCellFree(objGrid);
		objGrid.insertContentsCol("left", nBodyColIndex);	
		objGrid.setFormatColProperty(nBodyColIndex, "size", "40");	
 		objGrid.setCellProperty("head", nHeadColIndex, "text", sNo);	
		objGrid.setCellProperty("head", nHeadColIndex, "textAlign", "center");
		objGrid.setCellProperty("body", nBodyColIndex, "text", "expr:currow+1");
		objGrid.setCellProperty("body", nBodyColIndex, "textAlign", "center");
		objGrid.mergeContentsCell("head", 0, nBodyColIndex, nHeadCount, nBodyColIndex, nHeadColIndex, false);	
		objGrid.mergeContentsCell("body", 0, nBodyColIndex, nBodyCount, nBodyColIndex, nBodyColIndex, false);			
		if (nFixedCell > 0) this.gfnGridcellFix(objGrid, nFixedCell+1, -1);
		
		nHeadColIndex++;
 		nBodyColIndex++;
	}
	//상태
	if (addProp == "status") {
		for (var i = 0, s = objGrid.getCellCount("head"); i < s; i++) {
			var tmp = objGrid.getCellProperty("head", i, "text");
			if (tmp == this.COM_GRID_STATUS_NM || tmp == "Status") {
				//return;
				objGrid.deleteContentsCol("left", i);
			}
		}
		
		var nSize = 15;
		if (nFixedCell > 0) this.gfnGridCellFree(objGrid);
		objGrid.insertContentsCol("left", nBodyColIndex);	
		objGrid.setFormatColProperty(nBodyColIndex, "size", nSize);	
		objGrid.setCellProperty("head", nHeadColIndex, "text", sStatus);
		objGrid.setCellProperty("head", nHeadColIndex, "displaytype", "none");
		//==============================================================================
		// 입력, 수정, 삭제 표시를 이미지로 표현할때
		//==============================================================================
		//var sExpr = "expr:dataset.getRowType(currow)==1?'':(dataset.getRowType(currow)==2?'cell_WF_IconN':(dataset.getRowType(currow)==4?'cell_WF_IconM':(dataset.getRowType(currow)==8?'cell_WF_IconD':'')))";
		
		var expr = "( dataset.getRowType(currow) == 2 ? 'cell_WF_Add' : ( dataset.getRowType(currow) == 4 ? 'cell_WF_Mod' : '' ))";
		objGrid.setCellProperty("body", nBodyColIndex, "cssclass", "expr:" + expr);
		objGrid.mergeContentsCell("head", 0, nBodyColIndex, nHeadCount, nBodyColIndex, nHeadColIndex, false);	
		objGrid.mergeContentsCell("body", 0, nBodyColIndex, nBodyCount, nBodyColIndex, nBodyColIndex, false);			
		if (nFixedCell > 0) this.gfnGridcellFix(objGrid, nFixedCell+1, -1);
		
		nHeadColIndex++;
 		nBodyColIndex++;
	}
};

/**
 * @class grid에 고정된 fixed cell index얻기
 * @param {Object} objGrid	- 대상그리드
 * @return fixed cell index
 * @example
 */
pForm.gfnGridGetFixedCell = function(objGrid)
{
	var cellCnt  = objGrid.getCellCount("head");
	var nFixCell = -1;
	for(var nCell=0; nCell<cellCnt; nCell++)
	{
		var bandProp = objGrid.getFormatColProperty(nCell, "band");
		if (this.gfnIsNull(bandProp) || bandProp != "left") return nFixCell;
		 nFixCell = nCell;
	}
	return nFixCell;
}

/**
* @class  그리드헤드클릭 이벤트 [Sort, Checkbox]
* @param {Object} objGrid - 대상그리드
* @param {Evnet}  e	   - 헤드클릭이벤트
* @return  N/A
* @example
* objGrid.addEventHandler("onheadclick", this._gfnGrid_onheadclick, this);
*/
pForm._gfnGrid_onheadclick = function(objGrid, e)
{
	var sType = objGrid.getCellProperty("head", e.cell, "displaytype");
	if (sType == "checkboxcontrol") {
		//head display type이 checkbox일 경우 all/none check기능추가
		this.gfnHeadCheckSelectAll(objGrid, e);
	} else {
		//sort
		if (this.gfnIsNull(objGrid.sort) || objGrid.sort == "false") {
			return;
		} else if (objGrid.sort == "true") {
			var arr = objGrid.arrprop;
			var bUserHeader = this.gfnGridUserHeaderFlg(objGrid);
			var multiple = false;
			if (e.ctrlkey) {
				multiple = true;// Ctrl 키
			}
			if (!bUserHeader) {
				// 정렬 상태 변경이 성공하면 정렬을 실행한다.
				var rtn = this.gfnGridSetSortStatus(objGrid, e.cell, multiple);
				if (rtn) {
					this.gfnGridExecuteSort(objGrid);
				}
			} else {
				this.gfnGridUserHeaderExcuteSort(objGrid, e.cell, multiple);
			}
		}
	}
};



/**
 * @class 유저헤더사용여부반환
 * @param {Object} objGrid - 대상그리드
 * @return 유저헤더사용여부 true/false
 * @example
 * this.gfnGridUserHeaderFlg(this.grdMain);
 */
pForm.gfnGridUserHeaderFlg = function (objGrid)
{
	var arr = objGrid.arrprop;
	var bUserHeader = false;
	for (var i = 0, s = arr.length; i < s; i++) {
		if (arr[i] == "userheader") {
			bUserHeader = true;
		}
	}
	return bUserHeader;
};

/**
 * @class 유저헤더를 이용한 정렬
 * @param {Object} grid - 대상그리드
 * @return N/A
 * @example
 * this.gfnGridUserHeaderExcuteSort(objGrid);
 */
pForm.gfnGridUserHeaderExcuteSort = function (objGrid, headCellIndex, multiple)
{
	var bindCol = objGrid.getCellProperty("head", headCellIndex, "calendarweekformat");
	if (this.gfnIsNull(bindCol)) {
		return false; //헤더에 바인드없음
	}

	var bodyCellIdx = 0;
	var nbodyCnt = objGrid.getCellCount("body");
	for (var i = 0; i < nbodyCnt; i++) {
		var tmp =  objGrid.getCellProperty("body", i, "text");
		if (tmp == bindCol) {
			bodyCellIdx = i;
			break;
		}
	}
	var rtn = this.gfnGridSetSortStatus(objGrid, headCellIndex, multiple, "", bodyCellIdx);
	if (rtn) {
		this.gfnGridExecuteSort(objGrid);
	}
};

/**
 * @class 정렬가능여부리턴
 * @param {Object} grid - 대상그리드
 * @param {Number} headCellIndex - 대상셀INDEX
 * @param {Boolean}multiple - 멀티소트여부 
 * @param {Number} sortStatus - 소트상태  
 * @return{Boolean} sort 가능/불가능 여부
 * @example
 * this.gfnGridSetSortStatus(obj, e.cell, multiple);	
 */
pForm.gfnGridSetSortStatus = function(grid, headCellIndex, isMultiple, sortStatus, bodyCellIndex)
{
	// head cell index 에 해당하는 body cell index
	if (this.gfnIsNull(bodyCellIndex)) {
		bodyCellIndex = this.gfnGridGetBodyCellIndex(grid, headCellIndex);
	}
	if (bodyCellIndex < 0) {
		return false;
	}
	
	// body cell index 에 해당하는 바인드 컬럼명 (expr 적용한 cell은 sort안함)
	var columnName = this.gfnGridGetBindColumnNameByIndex(grid, bodyCellIndex);
	if (this.gfnIsNull(columnName)) {
		return false;
	}
	
	//정렬제외 컬럼 (uCommNotSortColId user property에 컬럼정의하면 sort 제외됨)
	var uCommNotSortColId = grid.uCommNotSortColId;
	if (this.gfnIsExist(uCommNotSortColId)) {
		if (("," + uCommNotSortColId + ",").indexOf("," + columnName + ",") >= 0) return false;
	}	
	
	if (this.gfnIsNull(isMultiple)) {
		isMultiple = false;
	}
	if (this.gfnIsNull(sortStatus)) {
		sortStatus = -1;
	}
	
	// 대상 grid 에 정렬정보를 가지는 사용자 속성 확인/추가
	if (this.gfnIsNull(grid.sortInfos)) {
		grid.sortInfos = {};
	}
	
	// 정렬대상컬럼 (순서중요)
	if (this.gfnIsNull(grid.sortItems)) {
		grid.sortItems = [];
	}
	
	var sortInfos = grid.sortInfos,
		sortItems = grid.sortItems,
		sortInfo = sortInfos[columnName],
		sortItem,
		status;
	
	if (this.gfnIsNull(sortInfo)) {
		var headText = grid.getCellText(-1, headCellIndex);
		
		// executeSort에서 정렬 표시를 위해 cell index 가 필요한데
		// cell moving 될 경우 index는 변하므로 cell object 를 참조하여 값을 얻어온다. 		
		var refCell = this.gfnGridGetGridCellObject(grid, "head", headCellIndex);
		sortInfo = sortInfos[columnName] = {
			status: 0
		  , text: headText
		  , refCell: refCell
		};
	}
	// set sort status
	if (isMultiple) {
		status = sortInfo.status;
		if (sortStatus == -1) {
			if (status == 0) {
				sortInfo.status = 1;
			} else if (status == 1) {
				sortInfo.status = 2;
			} else if (status == 2) {
				sortInfo.status = (this.SORT_TOGGLE_CANCEL ? 0 : 1);
			}
		} else {
			sortInfo.status = sortStatus;
		}
	} else {
		for (var p in sortInfos) {
			if (sortInfos.hasOwnProperty(p)) {
				sortInfo = sortInfos[p];
				if (p == columnName) {
					status = sortInfo.status;
					if (sortStatus == -1) {
						if (status == 0) {
							sortInfo.status = 1;
						} else if ( status == 1 ) {
							sortInfo.status = 2;
						} else if ( status == 2) {
							sortInfo.status = (this.SORT_TOGGLE_CANCEL ? 0 : 1);
						}
					} else {
						sortInfo.status = sortStatus;
					}
				} else {
					sortInfo.status = 0;
				}
				if (sortInfo.status == 0) {
					for (var j = 0, len2 = sortItems.length; j < len2; j++) {
						if (sortItems[j] !== columnName) {
							sortItems.splice(j, 1);
							break;
						}
					}
				}
			}
		}
	}
	
	// 컬럼정보 등록
	var hasItem = false;
	for (var i = 0, len = sortItems.length; i < len; i++) {
		if (sortItems[i] == columnName) {
			hasItem = true;
			break;
		}
	}	
	if (!hasItem) {
		sortItems.push(columnName);
	}
	return true;
}; 

/**
 * @class head cell에 match되는 body cell을 얻어온다
 * @param {Object}  grid 대상 Grid Component
 * @param {Number} eadCellIndex head cell index
 * @return{Number}  body cell index
 * @example
 * this.gfnGridSetSortStatus(obj, e.cell, multiple);	
 */ 
pForm.gfnGridGetBodyCellIndex = function(grid, headCellIndex, useColspan) 
{	//, useColspan) 
	if( this.gfnIsNull(useColspan)) useColspan=false;
	// Max Head Row Index
	var maxHeadRow = 0;
	for (var i = 0, len = grid.getCellCount("head"); i < len; i++) {
		var row = grid.getCellProperty("head", i, "row");
		if (maxHeadRow < row) {
			maxHeadRow = row;
		}
	}
	// Max Body Row Index
	var maxBodyRow = 0;
	for (var i = 0, len = grid.getCellCount("body"); i < len; i++) {
		var row = grid.getCellProperty("body", i, "row");
		if (maxBodyRow < row) {
			maxBodyRow = row;
		}
	}
	
	if (maxHeadRow == 0 && maxBodyRow == 0) {
// 		var headcolspan = grid.getCellProperty("head", headCellIndex, "colspan");
// 		var bodycolspan = grid.getCellProperty("body", headCellIndex, "colspan");
// 		
// 		if( headcolspan == bodycolspan ){
// 			return headCellIndex;
// 		}
		useColspan = true;
	}
	
	// Body Row 가 1개 이상일 경우
	// Head의 row 가 Body의 row 보다 클 경우 차이 row 를 뺀 것을 대상으로 찾고
	// Body의 row 가 Head의 row 보다 크거나 같을 경우 row index가 같은 대상을 찾는다.			
	var cellIndex = -1;
	var sRow = -1;
	var nRow = parseInt(grid.getCellProperty("head", headCellIndex, "row"));
	var nCol = parseInt(grid.getCellProperty("head", headCellIndex, "col"));
	var nColspan = parseInt(grid.getCellProperty("head", headCellIndex, "colspan"));				
	
	if (maxHeadRow > maxBodyRow) {
		sRow = nRow - (maxHeadRow - maxBodyRow);
		sRow = (sRow < 0 ? 0 : sRow);
	} else {
		sRow = nRow;
	}
	var cRow, cCol, cColspan, cRowspan;
	for (var i = 0, len = grid.getCellCount("body"); i < len; i++) {
		cRow = parseInt(grid.getCellProperty("body", i, "row"));
		cCol = parseInt(grid.getCellProperty("body", i, "col"));	
		cColspan = parseInt(grid.getCellProperty("body", i, "colspan"));					
		cRowspan = parseInt(grid.getCellProperty("body", i, "rowspan"));
		if (cRowspan > 1) {
			if (useColspan) {
				if (sRow >= cRow && nCol <= cCol && cCol < (nCol + nColspan)) {		
					cellIndex = i;
					break;
				}
			} else {
				if (sRow >= cRow && nCol == cCol && nColspan == cColspan) {		
					cellIndex = i;
					break;
				}
			}
		} else {	
			if (useColspan) {
				if (sRow == cRow && nCol <= cCol && cCol < (nCol + nColspan)) {		
					cellIndex = i;
					break;
				}		
			} else {
				if (sRow == cRow && nCol == cCol && nColspan == cColspan) {		
					cellIndex = i;
					break;
				}
			}
		}
	}
	return cellIndex;
};

/**
 * @class body cell index로 binding 된 컬럼명을 얻어온다.
 * @param {Object}  grid 대상 Grid Component
 * @param {Number} eadCellIndex head cell index
 * @return{String} column id
 * @example
 * this.gfnGridGetBindColumnNameByIndex(obj, e.cell);	
 */  
pForm.gfnGridGetBindColumnNameByIndex = function(grid, index) 
{
	var text = "";
	var columnid = "";
	var subCell = grid.getCellProperty("body", index, "subcell");
	if (subCell > 0) {
		text = grid.getSubCellProperty("body", index, 0, "text");
	} else {
		text = grid.getCellProperty("body", index, "text");
	}
	
	if (this.gfnIsNotNull(text)) {
		if (text.search(/^BIND\(/) > -1) {	
			columnid = text.replace(/^BIND\(/, "");
			columnid = columnid.substr(0, columnid.length - 1);
		} else if ( text.search(/^bind:/) > -1) {
			columnid = text.replace(/^bind:/, "");
		}
	}
	return columnid;
};

/**
 * @class 소트를 실행한다
 * @param {Object}  grid 대상 Grid Component
 * @return{String}  N/A
 * @example
 * this.gfnGridExecuteSort(obj);	
 */  
pForm.gfnGridExecuteSort = function(grid) 
{
	var sortInfo, 
		sortItem,
		sortInfos = grid.sortInfos,
		sortItems = grid.sortItems,
		columnName,
		status,
		cell,
		sortString = "";
		
	if (this.gfnIsNull(sortInfos) || this.gfnIsNull(sortItems)) {
		return;
	}

	// keystring 조합
	for (var i = 0, s = sortItems.length; i < s; i++) {
		columnName = sortItems[i];
		sortInfo = sortInfos[columnName];
		status = sortInfo.status;
		cell = sortInfo.refCell;
		
		// 컬럼삭제 등으로 제거될 수 있으므로 실제 column 이 존재하는지
		// 확인하여 없으면 제거해 준다.
		if (this.gfnIsNull(cell) || grid.getBindCellIndex("body", columnName) < 0) {
			// 컬럼정보제거
			sortItems.splice(i, 1);
			sortInfos[columnName] = null;
			delete sortInfos[columnName];
			
			i--;
		} else if (status > 0) {
			sortString += (status == 1 ? "+" : "-") + columnName;
		}
	}
	
	var ds = grid.getBindDataset();
	// keystring 확인
	var curKeyString = ds.keystring;
	var groupKeyString = "";
	
	//sort 적용전 초기값 보존
	var orgDsKeyString = grid._orgDsKeystring;
	if (this.gfnIsNull(orgDsKeyString) && this.gfnIsExist(curKeyString)) {
		grid._orgDsKeystring = curKeyString;
	} else if (this.gfnIsNull(orgDsKeyString) && this.gfnIsNull(curKeyString)) {
		grid._orgDsKeystring = "none";
	}
	
	if (curKeyString.length > 0 && curKeyString.indexOf(",") < 0) {
		var sIndex = curKeyString.indexOf("S:");
		var gIndex = curKeyString.indexOf("G:");

		if (sIndex > -1) {
			groupKeyString = "";
		} else {
			if (gIndex < 0) {
				groupKeyString = "G:" + curKeyString;
			} else {
				groupKeyString = curKeyString;
			}
		}
	} else {
		var temps = curKeyString.split(",");
		var temp;
		for (var i = 0, len = temps.length; i < len; i++) {
			temp = temps[i];
			if (temp.length > 0 && temp.indexOf("S:") < 0) {
				if (temp.indexOf("G:") < 0) {
					groupKeyString = "G:" + temp;
				} else {
					groupKeyString = temp;
				}
			}
		}
	}
	
	if (sortString.length > 0) {
		var sortKeyString = "S:" + sortString;
		
		if (groupKeyString.length > 0) {
			ds.set_keystring(groupKeyString  + "," + sortKeyString);
		} else {
			ds.set_keystring(sortKeyString);
		}
		
		grid.sortKeyString = sortKeyString;
	} else {		
		ds.set_keystring(groupKeyString);
		grid.sortKeyString = "";
	}

	// 정렬표시
	var type = this.MARKER_TYPE;
	var index, marker, orgtype;
	for (var p in sortInfos) {
		if (sortInfos.hasOwnProperty(p)) {
			sortInfo = sortInfos[p];			
			cell = sortInfo.refCell;
			if (cell) {
				index = cell._cellidx;
				marker = this.gfnDecode(sortInfo.status, 1, this.MARKER[0], 2, this.MARKER[1], "");
				//grid.setCellProperty("head", index, "text", sortInfo.text + marker);
				if (marker == "") {
					orgtype = grid.getCellProperty("head", index, "calendardisplaynulltext");
					if(this.gfnIsNotNull(orgtype)) {
						grid.setCellProperty("head", index, "displaytype", grid.getCellProperty("head", index, "calendardisplaynulltext"));
						grid.setCellProperty("head", index, "cssclass", "");
					}
				} else {
					if (grid.getCellProperty("head", index, "displaytype") != "buttoncontrol") {
						grid.setCellProperty("head", index, "calendardisplaynulltext", grid.getCellProperty("head", index, "displaytype"));
					}
					//grid.setCellProperty("head", index, "displaytype", "buttoncontrol");
					grid.setCellProperty("head", index, "cssclass", marker);
					
				}
			}
		}
	}
	// Sort 시 Scroll 항상 맨위로 처리
	//   - dataset의 첫번째 row로는 이동하지 않았음.  첫번째 row로 이동해야 앞뒤지 맞지 않을까?  (farmer생각)
	var gridHScroll = grid.getHScrollPos();
	if (gridHScroll < 0) {
		gridHScroll = 0;
	}
	grid.scrollTo(gridHScroll, 0);
	
	//grid heade sort 후 callback함수 호출
	var callback = grid.uCommSetCallback;
	if (this.gfnIsExist(callback)) {	
		try {
			this.lookupFunc(callback).call("sort", grid); 
		} catch(e) {
			this.gfnLog(callback + "() 함수 실행시 오류가 발생했습니다. \n" + e.message);
		}
	}
};

/**
 * Cell object 를 반환 (Grid 내부 속성이므로 get 용도로만 사용)
 * @param {Grid} grid 대상 Grid Component
 * @param {string} band 얻고자 하는 cell 의 band (head/body/summ);
 * @param {number} index 얻고자 하는 cell 의 index
 * @return {object} cell object
 */
pForm.gfnGridGetGridCellObject = function(grid, band, index)
{
	// 내부속성을 통해 얻어온다.
	var refCell;
	var format = grid._curFormat;
	if (format) {
		if (band == "head") {
			refCell = format._headcells[index];
		} else if (band == "body") {
			refCell = format._bodycells[index];
		} else if (band == "summ" || band == "summary") {
			refCell = format._summcells[index];
		}
	}
	return refCell;
};

/**
* @class 그리드의 Sort Mark 제거
* @param {Object} Grid 대상그리드
* @return N/A
*/  
pForm.gfnClearSortMark = function(obj)
{
	var sortInfos = obj.sortInfos;
	var sortItems = obj.sortItems;
	
	if (this.gfnIsNull(sortInfos) || this.gfnIsNull(sortItems)) {
		return;
	}
	
	// 정렬상태 초기화.
	for (var j = 0, s = sortItems.length; j < s; j++) {
		var col = sortItems[j];
		var sortInfo = sortInfos[col];
		sortInfo.status = 0;
	}
	
	// 정렬실행
	this.gfnGridExecuteSort(obj);
	
	// 정보 초기화
	obj.sortInfos = {};
	obj.sortItems = [];
};

/**
* @class  마우스우클릭이벤트
* @param  {Object} objGrid	- 대상그리드
* @param  {Event}  e		- 우클릭이벤트 
* @return  N/A
* @example
* this._gfnGrid_onrbuttondown(this.grdMain, this.dsMain);	
* pForm._gfnGrid_onrbuttondown = function (objGrid:nexacro.Grid,e:nexacro.GridMouseEventInfo)
*/
pForm._gfnGrid_onrbuttondown = function (objGrid,e)
{
	var objApp = pForm.gfnGetApplication();
	
	// 대상 그리드와 셀 정보를 추가
	objGrid.popupMenu.grid      = objGrid;
	objGrid.popupMenu.cellindex = e.cell;
	objGrid.popupMenu.rowindex  = e.row;

	// trackPopupByComponent 이용
	var x = nexacro.toNumber(system.getCursorX()) - nexacro.toNumber(system.clientToScreenX(objGrid, 0));
	var y = nexacro.toNumber(system.getCursorY()) - nexacro.toNumber(system.clientToScreenY(objGrid, 0));
	
	// 스튜디오 사용시 팝업메뉴 위치 조정
	//var sRunMode = nexacro.getEnvironmentVariable("ev_quikView");
	//if (sRunMode == "Y") y += 83;

	objGrid.popupMenu.trackPopupByComponent(objGrid, x, y);
};

/**
 * @class  gfnCreatePopupMenu 내부함수로 팝업메뉴 클릭 시 발생하는 이벤트
 * @param {Object} objGrid	- 대상그리드
 * @param {Evnet}  e 		- 팝업메뉴클릭이벤트
 * @return N/A
 * @example
 * this._gfnPopupmenu_onmenuclick(this.grdMain, nexacro.MenuClickEventInfo);	
 */
pForm._gfnPopupmenu_onmenuclick = function (objMenu, e)
{
	var selectId   = e.id;
	var grid 	   = objMenu.grid;
	var nCellIndex = objMenu.cellindex;	
	var nRowIndex  = objMenu.rowindex;

	switch(selectId) {
		case "filedown": //파일다운로드
			var objDs = grid.getBindDataset();
			objDs.set_rowposition(grid.popupMenu.rowindex);
			this.fn_fileDownload(grid);
			break;
		case "filepreview": //파일미리보기
			var objDs = grid.getBindDataset();
			objDs.set_rowposition(grid.popupMenu.rowindex);
			this.fn_filePreview(grid);
			break;
		case "colfix": //틀고정 열
			this.fv_CellIndex = nCellIndex;
			this.gfnGridcellFix(grid, this.fv_CellIndex, nRowIndex);
			break;
		case "colfixfree": //틀고정 열 해제
			this.gfnGridCellFree(grid);
			break;
		case "rowfix": //틀고정 행
			if(nRowIndex<0) return;
			grid.fixedRow = nRowIndex;
			this.gfnGridSetCssclass(grid);
			break;
		case "rowfixfree": //틀고정 행 해제
			grid.fixedRow = -1;
			this.gfnGridSetCssclass(grid);
			break;
		case "filter": //필터
			this.gfnGridFilter(grid);
			break;
		case "filterfree": //필터해제
			this.gfnGridCellFilterFree(grid);
			break;
		case "find": //찾기
			this.gfnGridCellFind(grid, nCellIndex, nRowIndex);
			break;
		case "colhide": //컬럼숨기기
			this.gfnGridColHideShow(grid, nRowIndex);
			break;	
		case "export": //엑셀내보내기
			this.gfnGridExcelExport(grid, nRowIndex);
			break;	
		case "import": //엑셀가져오기
			this.gfnGridExcelImport(grid, nRowIndex);
			break;	
		case "personal": //개인화
			this.gfnGridPersonalize(grid);
			break;
		case "initial": //초기화
			grid.set_formats("<Formats>" + grid.orgcurformat + "</Formats>");
			//this.gfnGridCellFree(grid);
			this.gfnClearSortMark(grid);
			//this.gfnGridAddProp(grid);
			break;
		default: break;
	}
};

/**
 * @class 행고정/해제시 css설정
 * @param {Object} objGrid	- 대상그리드
 * @return N/A
 * @example
 * this.gfnGridSetCssclass(this.grdMain);	
 */
pForm.gfnGridSetCssclass = function (objGrid)
{
	var clname = "grd_WF_cell_fixed";
	clname = nexacro.wrapQuote(clname);
			
	objGrid.set_enableredraw(false);

	for (var k = 0, s = objGrid.getFormatColCount(); k < s; k++) {
		var expr = "";
		if (objGrid.fixedRow >= 0) {
			expr = "expr:comp.fixedRow==currow?" + clname + ":''";
		}
		objGrid.setCellProperty("body", k, "cssclass", expr);
	}
	objGrid.set_enableredraw(true);
	objGrid.setFixedRow(objGrid.fixedRow);
};

/**
 * @class 그리드 초기화(체크박스 초기화)
 * @param {Object} objGrid	- 대상그리드
 * @return N/A
 * @example
 * this.gfnInitGrid(this.grdMain);	
 */
pForm.gfnInitGrid = function (objGrid)
{
	// 체크박스 클리어
	var nChkIdx = objGrid.getBindCellIndex( "body", this.COM_CHECK_ID);
	if (nChkIdx >= 0) {
		 objGrid.setCellProperty("head", nChkIdx, "text", "0");
	}
};

/**
 * @class  그리드헤드클릭이벤트 내부함수 (헤드클릭시 체크 ALL/None)
 * @param {Object} objGrid - 대상그리드
 * @param {Evnet}  e	   - 헤드클릭이벤트
 * @return  N/A
 * @example
 * this.gfnHeadCheckSelectAll(objGrid, e); //ALL CHECK
 */
pForm.gfnHeadCheckSelectAll = function (objGrid, e)
{
	if (objGrid.readonly == true || objGrid.enable == false) return;
	var oDsObj = objGrid.getBindDataset();
	if (oDsObj.getRowCount() < 1) return;
	
	var sType;
	var sChk;
	var sVal;
	var sChkColId;
	var nHeadCell = e.cell;
	var nBodyCell;
	var uCommAutoChkColId    = objGrid.uCommAutoChkColId;
	var uCommChkColId = objGrid.uCommChkColId;
	var nSubCnt             = objGrid.getSubCellCount("head", nHeadCell);
	if (this.gfnIsNull(uCommAutoChkColId)) return;
	uCommAutoChkColId    = "," + uCommAutoChkColId    + ",";
	uCommChkColId = "," + uCommChkColId + ",";
	
	//var sCheckYn            = this.gfnNvl(objGrid.checkboxyn);
	
	// 1. chek처리할 컬럼 얻기
	if (objGrid.getCellCount("body") != objGrid.getCellCount("head")) {
		nBodyCell = parseInt(objGrid.getCellProperty("head", nHeadCell, "col"));
	} else {
		nBodyCell = e.cell;
	}
	sChkColId = objGrid.getCellProperty("body", nBodyCell, "text");
	sChkColId = sChkColId.toString().replace("bind:", "");
	if (uCommAutoChkColId.indexOf("," + sChkColId + ",") < 0) return;
		
	// 2. Merge한 셀이 없는 경우
	sType = objGrid.getCellProperty("head", nHeadCell, "displaytype");
	if (sType != "checkboxcontrol") return;

	// 3. Head셋팅
	sVal = objGrid.getCellProperty("head", nHeadCell, "text");

	if (sVal == "0") {
		objGrid.setCellProperty("head", nHeadCell, "text", "1");
		sChk = 1;
	} else {
		objGrid.setCellProperty("head", nHeadCell, "text", "0");
		//var bodyCellIndex = this.gfnGridGetBodyCellIndex(objGrid, nHeadCell);
		// body cell index 에 해당하는 바인드 컬럼명
		//var columnName = this.gfnGridGetBindColumnNameByIndex(objGrid, bodyCellIndex);
		sChk = 0;
	}
		
	// 4. Body셋팅 (all check 0/1 처리)
	oDsObj.set_enableevent(false);
	
	// a. rowtype을 변경하지 않음
	if (uCommChkColId.indexOf("," + sChkColId + ",") >= 0) {
		oDsObj.set_updatecontrol(false);
		for (var i = 0, s = oDsObj.rowcount; i < s; i++) {
			var rowType = oDsObj.getRowType(i);
			oDsObj.setColumn(i, sChkColId, sChk);
			if (rowType == Dataset.ROWTYPE_NORMAL) {
				oDsObj.setRowType(i, Dataset.ROWTYPE_NORMAL);
			}
		}
		oDsObj.set_updatecontrol(true);
	} else {
		for (var i = 0, s = oDsObj.rowcount; i < s; i++) {
			oDsObj.setColumn(i, sChkColId, sChk);
		}
	}
	oDsObj.set_enableevent(true);
	
	//grid heade check box callback함수 호출
	var callback = objGrid.uCommSetCallback;
	if (this.gfnIsNotNull(callback)) {	
		try {
			this.lookupFunc(callback).call("checkbox", objGrid, e, sChkColId, sChk); 
		} catch(e) {
			this.gfnLog(callback + "() 함수 실행시 오류가 발생했습니다. \n" + e.message);
		}
	}
};

/**
 * @class  마우스우클릭시 표현될 팝업메뉴생성
 * @param  {Object} objGrid	- 대상그리드
 * @return  N/A
 * @example
 * this._gfnGetHeadBodyIndex(this.grdMain, this.dsMain);	
 */
pForm.gfnMakeGridPopupMenu = function (objGrid, arrProp)
{
	//  아래 script는 gsretail 버전
	var objApp 		 = this.gfnGetApplication();
	var objMenuDs 	 = this.gfnGetGdsGridPopupMenu();
	var objParentForm= objGrid.parent;

	var sPopMenu = "popMenu_" + objGrid.name + "_" + this.name;
	var sPopupDsMenu = "dsPopupMenu_" + objGrid.name + "_" + this.name;
	if (this.gfnIsExist(objParentForm[sPopMenu]) && this.gfnIsExist(objParentForm[sPopupDsMenu]))
	{
		return;
	}
	
	var objPopMenu = new PopupMenu(sPopMenu, 0, 0, 100, 100);
	objParentForm.addChild(objPopMenu.name, objPopMenu);
	
	var objPopupDs 	 = new Dataset(sPopupDsMenu);
	objParentForm.addChild(sPopupDsMenu, objPopupDs);
	objPopupDs.copyData(this.gfnGetGdsGridPopupMenu());
//trace(objPopupDs.saveXML()); 

	for (var i=0; i<arrProp.length; i++) {
		for (var j=0; j<objPopupDs.rowcount; j++) {
			var sMenu = objPopupDs.getColumn(j,"id");
			if (this.gfnIsNull(sMenu)) continue;

			if (sMenu.indexOf(arrProp[i]) > -1) {
				objPopupDs.setColumn(j, "enable", "true");
				if (objPopupDs.getColumn(j, "level") == 1) {
					var sUpMenu = objPopupDs.getColumn(j, "upmenu");
					var nUpRow = objPopupDs.findRow("id", sUpMenu);
					if (nUpRow > -1) objPopupDs.setColumn(nUpRow, "enable", "true");
				}
			}
		}
	}
//if (objGrid.id == "Grid01_00") trace("objPopupDs-> " + objPopupDs.rowcount);
	objPopupDs.set_filterstr("enable=='true'");  //popup menu를 띄울때  적용된 속성들만 목록에 조회
	objPopMenu.set_innerdataset(sPopupDsMenu);
//if (objGrid.id == "Grid01_00") trace(objPopupDs.saveXML());

	objPopMenu.set_captioncolumn("caption");
	objPopMenu.set_enablecolumn("enable");
	objPopMenu.set_idcolumn("id");
	objPopMenu.set_levelcolumn("level");
 	objPopMenu.addEventHandler("onmenuclick", this._gfnPopupmenu_onmenuclick, objParentForm);
	objPopMenu.show();

	// itemheight이 30보다 작을 경우 폰트가 깨져보임
	objPopMenu.set_itemheight(30);
	
	objPopMenu.grid = objGrid;
	objGrid.popupMenu = objPopMenu;


//  아래 script는 초기 버전 (위 script는 gsretail 버전)
// 	var objApp = pForm.gfnGetApplication();
// 	var objMenuDs = this.gfnGetGdsGridPopupMenu();
// 	var objParentForm = objGrid.parent;
// 	
// 	var sPopupDsMenu = "dsPopupMenu_" + objGrid.name + "_" + this.name;
// 	var objPopupDs = new Dataset(sPopupDsMenu);
// 	objParentForm.addChild(sPopupDsMenu, objPopupDs); 
// 	objPopupDs.copyData(this.gfnGetGdsGridPopupMenu());
// 	
// 	for (var i = 0, s = arrProp.length; i < s; i++) {
// 		for (var j = 0, t = objPopupDs.rowcount; j < t; j++) {
// 			var sMenu = objPopupDs.getColumn(j, "ID");
// 			if (this.gfnIsNull(sMenu)) {
// 				continue;
// 			}
// 			
// 			if (sMenu.indexOf(arrProp[i]) > -1) {
// 				//if (arrProp[i] == "export" && objGrid.authExcel == "N")		continue;		// 엑셀 권한처리
// 				
// 				objPopupDs.setColumn(j, "ENABLE", "true");
// 				if (objPopupDs.getColumn(j, "LEVEL") == 1) {
// 					var sUpMenu = objPopupDs.getColumn(j, "UPMENU");
// 					var nUpRow = objPopupDs.findRow("ID", sUpMenu);
// 					if (nUpRow > -1) {
// 						objPopupDs.setColumn(nUpRow, "ENABLE", "true");
// 					}
// 				}
// 			}
// 		}
// 	}
// 	objPopupDs.set_filterstr("ENABLE=='true'");  //popup menu를 띄울때  적용된 속성들만 목록에 조회
// 	
// 	// 엑셀 Export 권한
// 	//export
// 	
// 	var sPopMenu = "popMenu_" + objGrid.name + "_" + this.name;
// 	var objPopMenu = new PopupMenu(sPopMenu, 0, 0, 100, 100);
// 	
// 	objParentForm.addChild(objPopMenu.name, objPopMenu);
// 	
// 	objPopMenu.set_innerdataset(sPopupDsMenu);
// 	objPopMenu.set_captioncolumn("CAPTION");
// 	objPopMenu.set_enablecolumn("ENABLE");
// 	objPopMenu.set_idcolumn("ID");
// 	objPopMenu.set_levelcolumn("LEVEL");
//  	objPopMenu.addEventHandler("onmenuclick", this._gfnPopupmenu_onmenuclick, objParentForm);
// 	objPopMenu.show();
// 	
// 	//objPopMenu.set_itemheight(28);
// 	
// 	objPopMenu.grid   = objGrid;
// 	objGrid.popupMenu = objPopMenu;
};

/**
 * @class  그리드 설정 내부함수<br>
		   그리드에 유저프로퍼티를 Array형태로 반환한다.
 * @param  {Object}objGrid	- 대상그리드
 * @return {Array} user property
 * @example
 * this.gfnGetGridUserProperty(this.grdMain);	 //old nm : _getGridUserProperty
 */
pForm.gfnGetGridUserProperty = function (objGrid)
{
	var sProp = objGrid.uCommSet;
	
	var arrdefault = this.defaultmenulist.split(",");
//if (objGrid.id == "Grid01_00") trace('1 arrdefault -> ' + arrdefault);
	var arrprop = [];
	
	if (this.gfnIsNotNull(sProp)) {
		arrprop = sProp.split(",");
		for (var i = 0, s = arrprop.length; i < s; i++) {
			if (arrprop[i].indexOf("!") == 0) {
				for (var j = 0, t = arrdefault.length; j < t; j++) {
					if (arrdefault[j] == arrprop[i].substr(1)) {
						arrdefault[j] = "";
					}
				}
				arrprop[i] = "";
			}
		}
	}
//if (objGrid.id == "Grid01_00") trace('2 arrprop -> ' + arrprop.toString());
	
	var arrmyprop = [];
	for (var i = 0, s = arrdefault.length; i < s; i++) {
		if (this.gfnIsNotNull(arrdefault[i])) {
			arrmyprop.push(arrdefault[i]);
		}
	}
	
	for (var i = 0, s = arrprop.length; i < s; i++) {
		if (this.gfnIsNotNull(arrprop[i])) {
			arrmyprop.push(arrprop[i]);
		}
	}
//if (objGrid.id == "Grid01_00") trace('3 arrmyprop -> ' + arrmyprop.toString());
	
	return arrmyprop;
};

/**
 * @class grid에서 공통 checkbox를 check시 이전 rowtype을 유지시켜줌
 * pForm._gfnDataset_rowtype_cancolumnchange = function(obj:nexacro.NormalDataset,e:nexacro.DSColChangeEventInfo)
 */
pForm._gfnDataset_rowtype_cancolumnchange = function(obj, e)
{
	var uCommChkColId = "," + obj.uCommChkColId + ",";
	if (uCommChkColId.indexOf(e.columnid) >= 0) {
		obj.preRowType = obj.getRowType(e.row);
	}
};
//pForm._gfnDataset_rowtype_oncolumnchanged = function(obj:nexacro.NormalDataset,e:nexacro.DSColChangeEventInfo)
pForm._gfnDataset_rowtype_oncolumnchanged = function(obj, e)
{
	var uCommChkColId = "," + obj.uCommChkColId + ",";
	if (uCommChkColId.indexOf(e.columnid) >= 0) {
		if (obj.preRowType == Dataset.ROWTYPE_NORMAL) {	
 			obj.set_updatecontrol(false);
 			obj.setRowType(e.row, Dataset.ROWTYPE_NORMAL);
 			obj.set_updatecontrol(true);
		}
	}
};

/************************************************************************************************
* 2. grid popupmenu
************************************************************************************************/
/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
		  셀고정(colfix)
 * @param {Object} objGrid  - 대상그리드
 * @param {Number} nCellIdx - 셀고정 셀인덱스
 * @param {Number} nRowIdx  - 셀고정 로우 인덱스
 * @return N/A
 * @example
 * this.gfnGridcellFix(this.grdMain, 1, 2);	
 */
pForm.gfnGridcellFix = function (objGrid, nCellIdx, nRowIdx)
{
	var sBandType, nCellCount, nTargetCol, bRtn;

	var nColStart, nColSpan, nColEnd;

	var arrBandType = ["Head", "Body", "Summary"];

	objGrid.set_enableredraw(false);
	objGrid.setFormatColProperty(0, "band", "body");

	if(nRowIdx == -1)      sBandType = "Head";
	else if(nRowIdx == -2) sBandType = "Summary";
	else sBandType = "Body";

	//현재 선택된 Cell의 Col Index
	nTargetCol = nexacro.toNumber(objGrid.getCellProperty(sBandType, nCellIdx, "col"));

	//Head, Body, Summary의 Cell중 Col Index를 포함하여 병합된 Cell이 있을 경우
	//병합된 Cell의 마지막 Col 값을 찾는다.
	for(var i=0;i<3;i++) {
		sBandType = arrBandType[i];
		nCellCount = objGrid.getCellCount(sBandType);
		for(var j=0;j<nCellCount;j++) {
		  //현재 Cell의 시작 Col Index
		  nColStart = nexacro.toNumber(objGrid.getCellProperty(sBandType, j, "col"));
		  
		  nColSpan = nexacro.toNumber(objGrid.getCellProperty(sBandType, j, "colspan"));
		  
		  //현재 Cell의 마지막 Col Index
		  nColEnd = nColStart + nColSpan -1;
		  
		  //현재 Cell이 선택된 Cell의 Col Index를 포함하고 있을 경우
		  //현재 Cell의 마지막 Col Index를 변수에 담는다.
		  if(nColStart<=nTargetCol && nColEnd >= nTargetCol)nTargetCol = nColEnd;
		}
	}

	//Cell고정 실행
	bRtn = objGrid.setFormatColProperty(nTargetCol, "band", "left");  

	//Cell고정 성공시 border 변경
	if(bRtn == true) {
		for(var i=0;i<3;i++) {
			sBandType = arrBandType[i];
			nCellCount = objGrid.getCellCount(sBandType);
			for(var j=0;j<nCellCount;j++) {
				nColStart = nexacro.toNumber(objGrid.getCellProperty(sBandType, j, "col"));
				nColSpan = nexacro.toNumber(objGrid.getCellProperty(sBandType, j, "colspan"));
				nColEnd = nColStart + nColSpan -1;

				if(nTargetCol==nColEnd) {
					if(sBandType=="Head") {
						objGrid.setCellProperty(sBandType, j, "border", "1px solid #cacaca,1px solid #000000,1px solid #cacaca,1px solid #cacaca");
					} else if(sBandType=="Body") {
						objGrid.setCellProperty(sBandType, j, "border", "1px solid #dbdee2,1px solid #000000,1px solid #dbdee2,1px solid #dbdee2");
					} else if(sBandType=="Summary") {
						objGrid.setCellProperty(sBandType, j, "border", "1px solid #c8c1c2,1px solid #000000,1px solid #c8c1c2,1px solid #c8c1c2");
					}
				} else {
					objGrid.setCellProperty(sBandType, j, "border", "");
				}
			}
		}
	}

	objGrid.set_enableredraw(true);

//  2020.08.06 이전 version. cell merge된 경우 cellFix 오류가 있음
// 	var sBandType;
// 	if (nRowIdx == -1) {
// 		sBandType = "Head";
// 	} else if (nRowIdx == -2) {
// 		sBandType = "Summary";
// 	} else {
// 		sBandType = "Body";
// 	}
// 	
// 	var nCol = nexacro.toNumber(objGrid.getCellProperty(sBandType, nCellIdx, "col"));
// 	var nColSpan = nexacro.toNumber(objGrid.getCellProperty(sBandType, nCellIdx, "colspan"));
// 	var nRowSpan = nexacro.toNumber(objGrid.getCellProperty(sBandType, nCellIdx, "rowspan"));
// 	var nVal = objGrid.getCellpos
// 	var nMaxCol = 0;
// 	var i;
// 	var nRealCol;
// 	var nRealColSpan;
// 	var nRealCol_end;
// 	
// 	objGrid.set_enableredraw(false);
// 	
// 	objGrid.setFormatColProperty(0, "band", "body");	
// 	
// 	for (var i = 0, s = objGrid.getCellCount("Head"); i < s; i++) {
// 		nRealCol = nexacro.toNumber(objGrid.getCellProperty("Head", i, "col"));
// 		nRealColSpan = nexacro.toNumber(objGrid.getCellProperty("Head", i, "colspan"));
// 		nRealCol_end = nRealCol + nRealColSpan - 1;
// 		if (nRealCol == nCol || nRealCol_end == nCol) {
// 			if (nRealColSpan > 1) {
// 				//objGrid.setCellProperty("Head", i, "line", "1 solid #dcdbdaff,2 solid #919191ff");
// 				nCol = nRealCol_end;
// 			} else {
// 				//objGrid.setCellProperty("Head", i, "line", "1 solid #dcdbdaff,2 solid #919191ff");
// 				nCol = nRealCol_end;
// 			}
// 		} else {
// 			objGrid.setCellProperty("Head", i, "line", "");
// 		}
// 	}
// 	
// 	for (var i = 0, s = objGrid.getCellCount("Body"); i < s; i++) {
// 		if (objGrid.getCellProperty("Body", i, "col") == nCol) {
// 			//objGrid.setCellProperty("Body", i, "line", "1 solid #dcdbdaff,2 solid #919191ff");
// 			objGrid.setCellProperty("Body", i, "border", "1px solid #dbdee2 , 2px solid aqua , 1px solid #dbdee2 , 1px solid #dbdee2");
// 		} else {
// 			//objGrid.setCellProperty("Body", i, "line", "");
// 			objGrid.setCellProperty("Body", i, "border", "");
// 		}
// 	}	
// 	
// 	objGrid.setFormatColProperty(nCol, "band", "left");	
// 	objGrid.set_enableredraw(true);
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
		  셀고정해제(colfree)
 * @param {Object} objGrid - 대상그리드
 * @return N/A
 * @example
 * this.gfnGridCellFree(this.grdMain);	
 */
pForm.gfnGridCellFree = function(objGrid)
{
	for (var i = 0, s = objGrid.getFormatColCount(); i < s; i++) {		
		objGrid.setFormatColProperty(i, "band", "body");	
	}
		
	for (var i = 0, s = objGrid.getCellCount("Body"); i < s; i++) {
		objGrid.setCellProperty("Body", i, "border", "");
	}
	
	this.gv_CellIndex = -1;
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          셀필터(cellFilter)
 * @param {Object} objGrid - 대상그리드	
 * @param {Number} nCell - 셀필터 셀 인덱스
 * @return N/A
 * @example
 * this.gfnGridFilter(this.grdMain);	
 */
pForm.gfnGridFilter = function(objGrid)
{
	var oArg = {pvGrid: objGrid};
	var oOption		= {title:"데이터 필터 설정", width:"470", height:"299", popuptype:"modeless", topmost : true};
	var sPopupCallBack = "gfnGridFilterCallback";
	this.gfnOpenPopup("CommGridFilter", "Comm::CommGridFilter.xfdl", oArg, sPopupCallBack, oOption);	
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          셀필터해제(cellfilterfree)
 * @param {Object} objGrid - 대상그리드	
 * @param {Number} nCell - 셀필터 셀 인덱스
 * @return N/A
 * @example
 * this.gfnGridCellFilterFree(this.grdMain);	
 */
pForm.gfnGridCellFilterFree = function(objGrid)
{
	var objDs = objGrid.getBindDataset();
	objDs.set_filterstr("");
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          찾기/바꾸기
 * @param {Object} objGrid - 대상그리드	
 * @param {Number} nCell - 셀필터 셀 인덱스
 * @return N/A
 * @example
 * this.gfnGridCellFind(this.grdMain);	
 */
pForm.gfnGridCellFind = function(objGrid,nCellIndex,nRowIndex)
{
	var sTitle = "데이터 찾기";
	var orgselecttype = objGrid.selecttype;

	var oArg = {
		pvGrid: objGrid
	  , pvStrartRow: nRowIndex
	  , pvSelectCell: nCellIndex
	  , pvSelectType: orgselecttype
	};
	var oOption		= {title:"데이터 찾기", width:"300", height:"230", popuptype:"modeless", topmost : true};
	var sPopupCallBack = "gfnFindCallback";
	this.gfnOpenPopup("CommGridFind", "Comm::CommGridFind.xfdl", oArg, sPopupCallBack, oOption);	
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          컬럼 숨기기/보이기
 * @param {Object} objGrid - 대상그리드	
 * @param {Number} nCell - 셀필터 셀 인덱스
 * @return N/A
 * @example
 * this.gfnGridColHideShow(this.grdMain);	
 */
pForm.gfnGridColHideShow = function(objGrid)
{
	var oArg = {pvGrid: objGrid};
	var oOption		= {title:"컬럼 보이기/숨기기", width:"300", height:"400", popuptype:"modeless", topmost : true};
	var sPopupCallBack = "gfnColumnHidCallback";
	this.gfnOpenPopup("Comm_ColumnHide", "Comm::Comm_ColumnHide.xfdl", oArg, sPopupCallBack, oOption);	
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          엑셀익스포트
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this.gfnGridExcelExport(this.grdMain);	
 */
pForm.gfnGridExcelExport = function(objGrid)
{
	var excelDownFunc = objGrid.uExcelDownFunc;
	if (this.gfnIsExist(excelDownFunc))
	{
		this.lookupFunc(excelDownFunc).call(objGrid); 
	}
	else
	{
		this.gfnExcelExport(objGrid, "*?*?*?*?*?*?*?","");
	}
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          엑셀임포트
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this.gfnGridExcelImport(this.grdMain);	
 */
pForm.gfnGridExcelImport = function(objGrid)
{
	var sDataset = objGrid.binddataset;
	this.gfnExcelImport(sDataset, "sheet1", "A2", "fnImportCallback", objGrid.name + sDataset , this);
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 개인화
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this.gfnGridPersonalize(this.grdMain);	
 */
pForm.gfnGridPersonalize = function(objGrid)
{
	var sOrgFormat = objGrid.orgformats;
	var sCurFormat = objGrid.getCurFormatString();
	this.gfnGridPersonalizeExcute(objGrid);
//	//변경된 사항 확인 할 경우 아래 스크립트 사용
// 	if( sOrgFormat == sCurFormat ){
// 		this.gfnAlert("msg.save.nochange","","NoChangeFormat");
// 	}else{
// 		var sId = "ChangeFormat|" + objGrid.name;
// 		this.gfnAlert("confirm.before.save","", sId, "gfnGridFormatChangeMsgCallback");
// 	}
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 개인화내용 저장을 위해 유니크한 아이디를 구성한다.
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this.gfnGetUniqueId(this.grdMain);	//oldnm: get_uniqueId
 */
pForm.gfnGetUniqueId = function (objGrid)
{
	var sFormId;
	var oForm = objGrid.parent; //대상FORM조회
	while (true) {
		if (oForm instanceof nexacro.ChildFrame) {
			break;
		} else {
			oForm = oForm.parent;
		}
	}
	sFormId = oForm.name;
	if (sFormId.indexOf("FRAME_WORK_") > -1) {
		//팝업과 workform구분
		sFormId = oForm.form.div_work.form.name;
	}
	
	var otf = objGrid.parent.parent;
	if (otf instanceof nexacro.Tabpage) {
		//탭안에 그리드가 있을경우
		sFormId += "_" + otf.parent.name +"_"+ otf.name;
	} else if (otf instanceof nexacro.Div && otf.name != "div_work") {
		//div안에 그리드가 있을경우
		sFormId += "_" + otf.name;
	}
	sFormId += "_" + objGrid.name;
	return sFormId;
};

pForm.gfnClearHeadMark = function(obj)
{
	var sDisplaytype, sCalendardisplaynulltext;
	
	for (var i = 0, s = obj.getCellCount("head"); i < s; i++) {
		sDisplaytype = obj.getCellProperty("head", i, "displaytype");
		sCalendardisplaynulltext = obj.getCellProperty("head", i, "calendardisplaynulltext");
		
		if (sDisplaytype == "buttoncontrol" && this.gfnIsNotNull(sCalendardisplaynulltext) ) {
			obj.setCellProperty("head", i, "displaytype",sCalendardisplaynulltext);
			obj.setCellProperty("head", i, "cssclass", "");
			obj.setCellProperty("head", i, "calendardisplaynulltext", "");
		}
	}
};
/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 개인화실행.
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this.gfnGridPersonalize(this.grdMain);	
 */
pForm.gfnGridPersonalizeExcute = function (objGrid)
{
	var sFormatId = this.gfnGetUniqueId(objGrid);
	var sFormat = objGrid.getCurFormatString(false);
	var sOrgFormats = objGrid.getFormatString();
	var oBindDs		= objGrid.getBindDataset();
	
	// 포멧 저장용 그리드 생성
	var name = "_temp_" + this.gfnGetUniqueId(objGrid);
	var objTempGrid = new Grid(name, "absolute", 0, 0, 0, 0);
	this.addChild(name, objTempGrid);
	objTempGrid.set_visible(false);
	objTempGrid.show();
	
	var strFormatContents = objGrid.getCurFormatString();
	objTempGrid.set_formats("<Formats>" + strFormatContents + "</Formats>");
	
	this.gfnClearHeadMark(objTempGrid);
	
	sFormat = objTempGrid.getCurFormatString(false);
	
	this.removeChild(name); 
	objTempGrid.destroy(); 
	objTempGrid = null;
	
	// 포멧저장
	var objApp = pForm.gfnGetApplication();
	var objGds = objApp.gdsGridPersonal;
	
	var nFindRow = objGds.findRow("GRID_FORMAT_ID", sFormatId);
	if (nFindRow == -1) {
		var nRow = objGds.addRow();
		objGds.setColumn(nRow, "GRID_FORMAT_ID", sFormatId);
		objGds.setColumn(nRow, "FORMAT_XML", sFormat);
		objGds.setColumn(nRow, "ORG_FORMAT_XML", sOrgFormats);
	} else {
		objGds.setColumn(nFindRow, "FORMAT_XML", sFormat);
		objGds.setColumn(nFindRow, "ORG_FORMAT_XML", sOrgFormats);
	}
	var sXML = objGds.saveXML();
	nexacro.setPrivateProfile(this.gfnGetUserInfo("USER_ID") + "/" + "gdsGridPersonal", sXML);	
	this.gfnAlert("MSG1001", "", "saveSuccess", "gfnGridFormatChangeMsgCallback");  //저장 되었습니다.
};

/************************************************************************************************
* 3. popupmenu callback
************************************************************************************************/
/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 개인화 메세지콜백
 * @param {String} sid - popupid	
 * @param {String} rtn - return value	 
 * @return N/A
 * @example
 * this.gfnGridFormatChangeFormatCallback("TEST", "");	
 */
pForm.gfnGridFormatChangeMsgCallback = function (sid, rtn)
{
	//TODO.
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 찾기/바꾸기 팝업 콜백
 * @param {String} sid - popupid	
 * @param {String} rtn - return value	 
 * @return N/A
 * @example
 * this.gfnReplaceCallback("TEST", "");	
 */
pForm.gfnFindCallback = function (sid, rtn)
{
	//TODO
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 필터 팝업 콜백
 * @param {String} sid - popupid	
 * @param {String} rtn - return value	 
 * @return N/A
 * @example
 * this.gfnGridFilterCallback("TEST", "");	
 */
pForm.gfnGridFilterCallback = function (sid, rtn)
{
	//TODO
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 컬럼숨기기/보이기
 * @param {String} sid - popupid	
 * @param {String} rtn - return value	 
 * @return N/A
 * @example
 * this.gfnColumnHidCallback("TEST", "");	
 */
pForm.gfnColumnHidCallback = function (sid, rtn)
{
	//TODO
};

/************************************************************************************************
* 4. popupmenu funciton
************************************************************************************************/
/**
 * @class   주어진 문자열을 그리드에서 찾는다.
 * @param {Object} grid - 대상그리드	
 * @param {String} findText - 찾을 문자열	
 * @param {Object} option - 찾기옵션	
 * @return {Object} 찾은 열과행
 * @example
 * this.gfnFindGridText(this.fv_grid, txt, option);
 */
pForm.gfnFindGridText = function (grid, findText, option)
{
	grid.lastFindText = findText;
	grid.lastFindOption = option;

	// 찾을 옵션
	var direction = option.direction;
	var position = option.position;
	var scope = option.scope;
	var condition = option.condition;
	var strict = option.strict;

	var dataset = grid.getBindDataset();
	var startCell = (position == "current" ? grid.currentcell : grid.lastFindCell);
	var startRow = (position == "current" ? grid.currentrow : grid.lastFindRow);
	
	// 바꾸기에서 호출시 (option.cell 은 바꾸기에서만 지정)
	if (scope == "col" && this.gfnIsNotNull(option.cell)) {
		startCell = option.cell;
	}
	
	var findRow = findCell = -1;
	var rowCnt = dataset.rowcount;
	var bodyCellCnt = grid.getCellCount("body");
			
	// 대소문자 구분
	if (!strict) {
		findText = findText.toUpperCase();			
	}
		
	if (direction == "prev") {
		startRow -= 1;	
		if (startRow < 0) {
			startRow = rowCnt-1;
		}
	} else {
		startRow += 1;
		if (startRow >= rowCnt) {
			startRow = 0;
		}
	}
	
	var loopCnt = rowCnt;
	while (loopCnt > 0) {
		// 문자열 비교
		if (this.gfnCompareFindText(grid, startRow, startCell, findText, condition, strict)) {
			findRow = startRow;
			findCell = startCell;
			break;
		}
		
		// 방향 (이전, 다음)
		if (direction == "prev") {
			startRow -= 1;
			if (startRow < 0) {
				startRow = rowCnt-1;
			}				
		} else {
			startRow += 1;
			if (startRow > (rowCnt-1)) {
				startRow = 0;
			}
		}
		
		loopCnt--;
	}
	// 마지막 찾은 위치 지정
	// 팝업에서 찾을 방향을 "처음부터" 로 변경 시 초기화
	if (findRow > -1 && findCell > -1) {
		grid.lastFindRow = findRow;
		grid.lastFindCell = findCell;
	}
	
	return [findRow, findCell];
};

/**
 * @class   주어진 문자열을 그리드에서 찾아서 바꿀 문자열로 변경한다.
 * @param {Object} grid - 대상 Grid Component
 * @param {String} findText - 찾을 문자열
 * @param {String} replaceText - 바꿀 문자열
 * @param {Object} option - 찾을 옵션
 * @param {Boolean} all - 모두 바꾸기 여부
 * @return {Number} 변경 항목 개수.
 * @example
 *this.gfnReplaceGridText(grid, findText, replaceText, option, bAllChg);
 */
pForm.gfnReplaceGridText = function(grid, findText, replaceText, option, all)
{
	// F3 발생 시 마지막 찾은 문자열 계속 찾기 위해 값 지정
	grid.lastFindText = findText;
	grid.lastFindOption = option;
	
	if (this.gfnIsNull(all)) {
		all = false;
	}
	
	// 찾을 옵션 ( 바꾸기의 범위는 특정 칼럼만 지원) 
	var direction = option.direction;
	var position = option.position;
	var condition = option.condition;
	var strict = option.strict;
	var cell = option.cell;
	
	var dataset = grid.getBindDataset();//this.gfnLookup(grid.parent, grid.binddataset);
	
	// 바꾸기의 범위는 특정 칼럼만 지원
	var startCell = option.cell;
	var startRow;
	
	if (position == "current") {
		startRow = grid.currentrow;
	} else {
		var lastReplaceRow = grid.lastReplaceRow;
		if (this.gfnIsNull(lastReplaceRow)) {
			startRow = 0;
		} else {
			startRow = lastReplaceRow;
		}
	}
	
	var results = [];
	var findRow = findCell = -1;		
	var rowCnt = dataset.rowcount;
	var bodyCellCnt = grid.getCellCount("body");
	
	// 바꿀 문자열 목록에 등록
	//this.appendFindReplaceCache("replace", replaceText);
	
	// 대소문자 구분
	if (!strict) {
		findText = findText.toUpperCase();	
	}
	
	// 열 범위 바꾸기
	var result;
	var loopCnt = rowCnt;
	while (loopCnt > 0) {
		// 문자열 비교
		if (this.gfnCompareFindText(grid, startRow, startCell, findText, condition, strict)) {
			findRow = startRow;
			findCell = startCell;
			result = this.gfnReplaceGridCellText(grid, findRow, findCell, findText, replaceText, strict);
			results.push(result);
			if (!all) {
				break;
			}
		}
		
		// 방향 (이전, 다음)
		if (direction == "prev") {
			startRow -= 1;
			if (startRow < 0) {
				startRow = rowCnt-1;
			}				
		} else {
			startRow += 1;
			if (startRow > (rowCnt-1)) {
				startRow = 0;
			}
		}
		
		loopCnt--;
	}
		
	// 마지막 바꾸기 위치 지정
	grid.lastReplaceRow = findRow;
	return results;
};

 /**
 * @class   바꾸기에 의해 찾아진 행, 셀 인덱스에 해당하는 데이터를 실제 변경한다.
 * @param {Object} grid 대상 Grid Component
 * @param {Number} findRow 찾아진 행 인덱스
 * @param {Number} findCell 찾아진 셀 인덱스
 * @param {String} findText 찾을 문자열
 * @param {String} replaceText 바꿀 문자열
 * @param {Boolean} strict 대소문자 구분
 * @return {Object} result - 결과
 * @example
 * this.gfnReplaceGridCellText(grid, findText, replaceText, option, bAllChg);
 */
pForm.gfnReplaceGridCellText = function(grid, findRow, findCell, findText, replaceText, strict)
{
	var result = {
		'replace': true
	  , 'message': '처리되었습니다.'
	  , 'row': findRow
	  , 'cell': findCell
	};
	
	// expr 등에 의해 셀이 실제 입력 가능한지 테스트 후 처리
	var dataset = grid.getBindDataset();//this.gfnLookup(grid.parent, grid.binddataset);
	dataset.set_rowposition(findRow);
	grid.setCellPos(findCell);
// 	trace(grid + " :::: " + grid.name);
// 	trace("111111111111111111 findRow :: " + findRow + " findCell :: " + findCell)
// 	trace("111111111111111111 dataset :: " + dataset.name);
//	var editable = grid.showEditor(true);
// 	trace("111111111111111111 editable :: " + editable);
// 	if ( editable )
// 	{
// 		grid.showEditor(false);
// 	}
// 	else
// 	{
// 		 return;
// 	}
	var displayType = grid.getCellProperty("body", findCell, "displaytype");
	var editType 	= grid.getCellProperty("body", findCell, "edittype");
	var text 		= grid.getCellProperty("body", findCell, "text");
	var bindColid 	= text.replace("bind:", "");
	
	// displayType 이 normal일 경우
	// dataType 을 체크하여 displayType 을 변경
	var dataType = this.gfnGetBindColumnType(grid, findCell);
	if (this.gfnIsNull(displayType) || displayType == "normal") {
		switch (dataType) {
			case 'INT':
			case 'FLOAT':
			case 'BIGDECIMAL':
				displayType = "number";
				break;
			case 'DATE':
			case 'DATETIME':
			case 'TIME':
				displayType = "date";
				break;
			default:
				displayType = "text";
		}
	}
	
	var replace;
	var replaceVal;
	var columnValue = dataset.getColumn(findRow, bindColid);
	var displayValue = grid.getCellText(findRow, findCell);
	if (displayType == "number" || displayType == "currency") {
		// currency 의 경우 원(￦) 표시와 역슬레시(\) 다르므로 제거 후 변경
		if (displayType == "currency") {
			var code = findText.charCodeAt(0);
			if (code == 65510 || code == 92) {
				findText = findText.substr(1);
			}
			
			code = replaceText.charCodeAt(0);
			if (code == 65510 || code == 92) {
				replaceText = replaceText.substr(1);
			}
			
			code = displayValue.charCodeAt(0);
			if (code == 65510 || code == 92) {
				displayValue = displayValue.substr(1);
			}			
		}
		
		// 셀에 보여지는 값에서 찾는 문자열 값을 변경
		
		// 대소문자 구분
		if (strict) {
			displayValue = displayValue.replace(findText, replaceText);
		} else {
			displayValue = this.gfnReplaceIgnoreCase(displayValue, findText, replaceText);
		}
		
		// 숫자형 이외 제거
		replaceVal = this.gfnReplaceNumberMaskValue(displayValue);
	} else if (displayType == "date"|| displayType == "calendarcontrol") {
		if (columnValue == null) {
			// 값이 없을때 보이는 "0000-01-01" 과 같이 
			// 텍스트에서 찾아 질 경우가 있다.
			result.replace = false;
			result.message = "유효한 날짜가 아닙니다.";
		} else {							
			var mask = grid.getCellProperty("body", findCell, "calendardateformat");
			var ret = this.gfnReplaceDateMaskValue(columnValue, displayValue, findText, replaceText, mask, strict);			
			replaceVal = ret[1];
			
			if (ret[0] == false) {
				result.replace = false;
				result.message = ret[2];
			}
		}
	} else {
		// 대소문자 구분
		if (strict) {
			replaceVal = columnValue.replace(findText, replaceText);
		} else {
			replaceVal = this.gfnReplaceIgnoreCase(columnValue, findText, replaceText);
		}					
	}
		
	if (result.replace) {
		dataset.setColumn(findRow, bindColid, replaceVal);
	}
	
	return result;
};

 /**
 * @class   문자열을 대소문자 구별없이 주어진 변경문자열(문자) 치환한다.
 * @param {String} sOrg - 원래 문자열( 예 : "aaBBbbcc" )
 * @param {String} sRepFrom - 찾고자 하는 문자열( 예 : "bb" )
 * @param {String} sRepTo - 치환될 문자열 ( 예 : "xx" )
 * @return {String} 치환된 문자열 ( 예 : "aaxxxxccxx" ).
 * @example
 * this.gfnReplaceIgnoreCase(str, findStr, "x");
 */
pForm.gfnReplaceIgnoreCase = function(sOrg, sRepFrom, sRepTo)	
{
	var pos, nStart = 0, sRet = "";
	
	while(1) {
		pos = sOrg.toLowerCase().indexOf(sRepFrom.toLowerCase(), nStart)
		
		if (pos < 0) {
			sRet += sOrg.substr(nStart);
			break;
		} else {
			sRet += sOrg.substr(nStart, pos - nStart);
			sRet += sRepTo;
			nStart = pos+sRepFrom.length;
		}
	}
	
	return sRet;
};

 /**
 * @class  날짜형으로 마스크 처리된 문자열에서 실제 값을 얻어온다.
 * @param {*} columnValue - 변경전 데이터셋의 실제 값
 * @param {String} displayValue - 보여지는 문자열
 * @param {String} findText - 찾을 문자열
 * @param {String} replaceText - 바꿀 문자열
 * @param {String} mask - 마스크 속성값
 * @param {Boolean} strict - 대소문자 구분 여부
 * @return {Object} 변환정보 (날짜여부, 변경된 문자열, 에러메시지)
 * @example
 * this.gfnReplaceDateMaskValue(str, findStr, "x");
 */
pForm.gfnReplaceDateMaskValue = function(columnValue, displayValue, findText, replaceText, mask, strict)
{		
	if (this.gfnIsNull(replaceText)) {
		// 바꿀 문자열이 빈값이 되지 않도록 패딩
		replaceText = replaceText.padRight(findText.length, " ");
	}
	
	// 1. 현재 보이는 값에서 문자열을 찾아 바꿀 문자열로 변경
	var replaceDisplayValue;
	
	// 대소문자 구분
	if (strict) {
		replaceDisplayValue = displayValue.replace(findText, replaceText);
	} else {
		replaceDisplayValue = this.gfnReplaceIgnoreCase(displayValue, findText, replaceText);
	}
	
	// 바꿀 값이 없다면 값을 제거한다.
	if (this.gfnIsNull(replaceDisplayValue.trim())) {
		return [true, null];
	}
	
	// 2. mask 문자 분리
	var arrMask = this.gfnParseDateMask(mask);
	
	// 3. 변경한 값과 마스크 값을 비교하면서 실제 값을 추출하고 유효날짜 판단
	var tmpStr = "";
	var isDate = true;
	var errorMsg = "";
	var valueIndex = 0;
	var displayIndex = 0;
	var dateValue = [];
	var errorValue = [];
	var checkMask;
	var checkDayIndex = -1;
	var checkYearValue = "";
	var checkMonthValue = "";
	
	for (var i = 0, len = arrMask.length; i < len ; i++) {
		checkMask = arrMask[i];
		if (!this.gfnIsDigit(checkMask)) {
			switch (checkMask) {
				case 'yyyy':
					tmpStr = replaceDisplayValue.substr(displayIndex, 4);
					
					if (tmpStr.length != 4 || !nexacro.isNumeric(tmpStr)) {
						isDate = false;	
						errorMsg = "연도가 올바르지 않습니다.";
					}
					
					// 일자체크를 위해
					checkYearValue = tmpStr;
					
					dateValue[dateValue.length] = tmpStr.trim(" ");
					errorValue[errorValue.length] = tmpStr.trim(" ");
					displayIndex += 4;					
					valueIndex += 4;
					break;
				case 'yy':
				case 'MM':
				case 'dd':
				case 'hh':
				case 'HH':
				case 'mm':
				case 'ss':
					tmpStr = replaceDisplayValue.substr(displayIndex, 2);
										
					if (tmpStr.length == 2 && nexacro.isNumeric(tmpStr)) {
						if (checkMask == "yy") {
							// 앞 두자리를 원본 데이터로 채운다.
							tmpStr = columnValue.substr(valueIndex, 2) + tmpStr;
							
							// 일자체크를 위해
							checkYearValue = tmpStr;
						} else if (checkMask == "MM") {
							if (parseInt(tmpStr) < 1 || parseInt(tmpStr) > 12) {
								isDate = false;
								errorMsg = "월이 올바르지 않습니다.";
							}
							
							// 일자체크를 위해
							checkMonthValue = tmpStr;
						} else if (checkMask == "dd") {
							// 윤년을 적용하기 위해서는 연도가 필요한데 
							// 무조건 연도(yyyy, yy)가 일(dd) 보다 앞에 온다는
							// 보장이 없으므로 루프가 끝난 후 체크한다.
							checkDayIndex = dateValue.length;
						} else if (checkMask == "hh" || checkMask == "HH") {
							if (parseInt(tmpStr) < 0 || parseInt(tmpStr) > 23) {
								isDate = false;
								errorMsg = "시간이 올바르지 않습니다.";
							}
						} else if (checkMask == "mm" || checkMask == "ss") {
							if (parseInt(tmpStr) < 0 || parseInt(tmpStr) > 59) {
								isDate = false;
								errorMsg = "분이 올바르지 않습니다.";
							}
						}
					} else {
						isDate = false;
						errorMsg = "날짜 형식이 올바르지 않습니다.";
					}
					
					dateValue[dateValue.length] = tmpStr.trim(" ");	
					errorValue[errorValue.length] = tmpStr.trim(" ");	
					displayIndex += 2;
					valueIndex += 2;
					break;
			} // end switch
		} else {
			// dateValue 는 실제 적용할 값이므로 skip 하자
			
			// 마스크 문자가 아닌 경우 표시문자 이므로 원래 값의 것을 사용
			errorValue[errorValue.length] = displayValue.charAt(checkMask);
			displayIndex += 1;
		}
	}
	
	// 일자 유효 체크
	if (this.gfnIsNotNull(checkYearValue) && this.gfnIsNotNull(checkMonthValue) && checkDayIndex > -1) {
		var dt = checkYearValue + checkMonthValue + "01";
		var inputDay = parseInt(dateValue[checkDayIndex]);
		var lastDay = this.gfnGetMonthLastDay(dt);
	}
	
	if (isDate) {
		return [isDate, dateValue.join("")];
	} else {
		return [isDate, errorValue.join(""), errorMsg];
	}
};

/**
 * @class  날짜형 마스크 구문을 분석합니다.
 * @param {String} mask - mask 마스크 속성값
 * @return {Object} 구문값
 * @example
 * this.gfnParseDateMask("yyyy-MM-dd");
 */
pForm.gfnParseDateMask = function(mask)
{
	arrMask = [];
	var dateMaskCache;
	var maskArr = mask.split("");	
	var tmpStr = "";
	var tokenStr = "";
	var seq = 0;

	for (var i = 0, len = mask.length; i < len;) {
		tmpStr = mask.substr(i, 4);
		if (tmpStr == "yyyy") {
			arrMask[seq] = tmpStr;
			i += 4;
			seq++;
			continue;
		}
		
		// ddd => 요일은 입력할 수 없다.		
		tmpStr = mask.substr(i, 3);
		if (tmpStr == "ddd") {
			//arrMask[seq] = tmpStr;
			i += 3;
			//seq++;
			continue;
		}						
		
		// hh의 경우 (Calendar는 HH이며 그리드는 둘다 동작함)
		tmpStr = mask.substr(i, 2);
		if (tmpStr == "yy" || tmpStr == "MM" || tmpStr == "dd" || tmpStr == "HH" || tmpStr == "hh" || tmpStr == "mm" || tmpStr == "ss") {
			arrMask[seq] = tmpStr;
			i += 2;
			seq++;
			continue;
		}
		
		tokenStr = maskArr[i];
		
		// 입력되지 않으므로 skip.
		if (tokenStr == "H" || tokenStr == "M" || tokenStr == "d" || tokenStr == "m" || tokenStr == "s") {
			//arrMask[seq] = tokenStr;
			//seq++;
		} else {
			arrMask[seq] = i;
			seq++;					
		}
		i++;
	}
	
	//dateMaskCache[mask] = arrMask;
	
	return arrMask;
};

 /**
 * @class  숫자형으로 마스크 처리된 문자열에서 실제 값을 얻어온다.
 * @param {String} mask - 숫자형 문자열
 * @return {String} 변환값 문자열
 * @example
 * this.gfnReplaceNumberMaskValue("20170808");
 */
pForm.gfnReplaceNumberMaskValue = function(numString)
{
	numString = numString.trim();
	
	var numReg = /[0-9]/;
	var bPoint = false; // 소숫점은 1개만 인정.
	var bInside = false; // 부호는 숫자가 나오기 전에만 인정.
	var c, buf = [];
	
	for (var i = 0, len = numString.length; i < len; i++)  {
		c = numString.charAt(i);
		if ((c == '+' || c == '-') && (bInside === false)) {
			// 부호는 숫자가 나오기 전에만 인정.
			buf.push(c);
			bInside = true;
		} else if (numReg.test(c)) {
			// 숫자인경우 인정.
			buf.push(c);
			bInside = true;
		} else if (c == "." && bPoint === false) {
			// 소숫점은 1회만 인정.
			buf.push(c);
			bPoint = true;
			bInside = true;
		} else if (c != ",") {
			return "";
		}
	}
	return buf.join("");
};

 /**
 * @class 주어진 행, 셀 인덱스에 해당하는 그리드 데이터와 문자열을 비교하여 찾아진 결과를 반환
 * @param {Object} grid - 대상 Grid Component
 * @param {Number} row - 찾을 행 인덱스
 * @param {Number} cell - 찾을 셀 인덱스
 * @param {String} findText - 찾을 문자열
 * @param {String} condition - 찾을 조건(equal/inclusion)
 * @param {Boolean} strict - 대소문자 구분 (true/false)
 * @return {Boolean} - 찾기 성공.
 * @example
 * this.gfnCompareFindText(grid, startRow, startCell, findText, condition, strict) 
 */
pForm.gfnCompareFindText = function(grid, row, cell, findText, condition, strict)
{
	var cellText = grid.getCellText(row, cell);
	if (this.gfnIsNull(cellText)) {
		return;
	}
	var displayType = grid.getCellProperty("body", cell, "displaytype");
		
	// displayType 이 normal일 경우
	// dataType 을 체크하여 displayType 을 변경
	if (this.gfnIsNull(displayType) || displayType == "normal") {
		var dataType = this.gfnGetBindColumnType(grid, cell);
		switch (dataType) {
			case 'INT':
			case 'FLOAT':
			case 'BIGDECIMAL':
				displayType = "number";
				break;
			case 'DATE':
			case 'DATETIME':
			case 'TIME':
				displayType = "date";
				break;
			default:
				displayType = "strign";
		}
	}
	
	// currency 의 경우 원(￦) 표시와 역슬레시(\) 다르므로 제거 후 비교
	if (displayType == "currency") {
		var code = cellText.charCodeAt(0);
		if (code == 65510 || code == 92) {
			cellText = cellText.substr(1);
		}
		
		code = findText.charCodeAt(0);
		if (code == 65510 || code == 92) {
			findText = findText.substr(1);
		}
	}

	// 대소문자 구분
	if (!strict) {
		cellText = cellText.toUpperCase();
	}
	// 일치/포함
	if (condition == "equal") {
		if (findText == cellText) {
			return true;
		}
	} else {
		if (cellText.indexOf(findText) > -1) {			
			return true;
		}
	}

	return false;
};

 /**
 * @class   데이터의 타입반환
 * @param {Object} grid - 대상 Grid Component
 * @param {Number} cell - 찾을 셀 
 * @return {Object} - 찾기 성공.
 * @example
 *  this.gfnGetBindColumnType(grid, cell);
 */
pForm.gfnGetBindColumnType = function(grid, cell)
{
	var dataType = null;
	var dataset = this.gfnLookup(grid.parent, grid.binddataset);
	var bindColid = grid.getCellProperty("body", cell, "text");
		bindColid = bindColid.replace("bind:", "");
	
	if (this.gfnIsNotNull(bindColid)) {
		var colInfo = dataset.getColumnInfo(bindColid);
		if (this.gfnIsNotNull(colInfo)) {
			dataType = colInfo.type;
		}
	}
	
	return dataType;
};

/************************************************************************************************
* 
************************************************************************************************/


/************************************************************************************************
* 9. 기타
************************************************************************************************/
/**
* @class Grid combo, date(calendar) 팝업창을 한번클릭으로 팝업창이 열리도록 처리
* @param {Object} objGrid        - 대상그리드
* @param {Event}  e        - nexacro.GridClickEventInfo
*/
pForm._gfnGrid_oncellclick = function(obj,e)
{
	if (obj.getCurEditType() == "combo") {
		obj.dropdownCombo();
	} else if (obj.getCurEditType() == "date") {
		obj.dropdownCalendar();
	}
}

/**
* @class Grid combo, date(calendar) 팝업창을 한번클릭으로 팝업창이 열리도록 처리
* @param {Object} objGrid        - 대상그리드
* @param {Event}  e        - nexacro.GridClickEventInfo
*/
pForm.gfnGridDropDownOneClick = function(objGrid,e)
{
	var edittype = objGrid.getCellPropertyValue(e.row, e.cell, "edittype");
	if      (edittype == "combo") objGrid.dropdownCombo();
	else if (edittype == "date")  objGrid.dropdownCalendar();
}



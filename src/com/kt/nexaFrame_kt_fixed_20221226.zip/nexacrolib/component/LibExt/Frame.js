/*
* Frame.js : Frame Util
*/
var pForm  = nexacro.Form.prototype;

pForm.titlebarheight = 24;			 // 타이틀바 사이즈
pForm.FRAME_IS_AUTOKILLFOCUS = true; // static, div등을 클릭 시 이전컴포넌트에 killfocus를 강제로 발생시킬지 여부

/**
 * 1. Environment, Frame, Global Dataset 관련
 * 2. FrameTop   관련
 * 3. FrameWork  관련
 * 4. formOnload 관련
 * 9. 기타 
 */

/************************************************************************************************
* 1. Environment, Frame, Global Dataset 관련
************************************************************************************************/
/**
* @class  시스템에서 관리는 모든 url 정보 얻기
* @param  id : 얻고 싶은 url id
* @return {string} 서버 URL
* @exec   this.gfnGetUrl("svcUrl")
*/
//TO.DO : server url 변경
pForm.gfnGetUrl = function(id)
{
	switch(id) {
		case "svcUrl":  //
			return this.gfnGetEnvServices("svcUrl", "url");
			break;
		case "excel":
			return this.gfnGetUrl("svcUrl") + "/XExportImport.cb";
			break;
		case "file":
			return this.gfnGetUrl("svcUrl") + "/uploadFiles.cb";
			break;
	}
};

/**
* @class frame separatesize 조절
* @param  none
* @return {Object}
*/
pForm.gfnSetFrameSeparate = function(type)
{
trace('this.gfnGetEnvVar("evFrame")-->' + this.gfnGetEnvVar("evFrame"));
	if (this.gfnGetEnvVar("evFrame") == "FrameTopMegaMenu") {
		this.gfnSetFrameSeparateMegaMenu(type);
	} else if (this.gfnGetEnvVar("evFrame") == "FrameLeftMenu") {
		this.gfnSetFrameSeparateLeftMenu(type);
	}
}

/**
* @class frame separatesize 조절
* @param  none
* @return {Object}
*/
pForm.gfnSetFrameSeparateMegaMenu = function(type)
{
	var objApp = nexacro.getApplication();
	if (type == "loginCallback") {
		var pjtWidth  = nexacro.getEnvironmentVariable("evPjtWidth");
		var pjtHeight = nexacro.getEnvironmentVariable("evPjtHeight");
		objApp.avMainframe.set_width(pjtWidth);
		objApp.avMainframe.set_height(pjtHeight);
		
		objApp.avFrameTop.set_formurl("FrameMega::FrameTop.xfdl");
		objApp.avFrameMain.set_formurl("FrameMega::FrameMain.xfdl");
		objApp.avFrameTab.set_formurl("Frame::FrameTab.xfdl");
		//objApp.avFrameTab.set_formurl("Sample::menu_temp3.xfdl");
		
		objApp.avFrameLogin.set_formurl("");
		
		objApp.avVFrameSet.set_separatesize("0,86,*"); //Login,Top,WorkFrame
		objApp.avVFrameSet1.set_separatesize("*,0,38");   //Main,Work,Tab
	} else if (type == "menuClick" || type == "FrameWork") {
		objApp.avVFrameSet1.set_separatesize("0,*,38");  //Main,Work,Tab
	} else if (type == "FrameMain") {
		objApp.avVFrameSet1.set_separatesize("*,0,38");  //Main,Work,Tab
	}
}

/**
* @class frame separatesize 조절
* @param  none
* @return {Object}
*/
pForm.gfnSetFrameSeparateLeftMenu = function(type)
{
	var objApp = nexacro.getApplication();
	if (type == "loginCallback") {
		var pjtWidth  = nexacro.getEnvironmentVariable("evPjtWidth");
		var pjtHeight = nexacro.getEnvironmentVariable("evPjtHeight");
		objApp.avMainframe.set_width(pjtWidth);
		objApp.avMainframe.set_height(pjtHeight);

		objApp.avFrameTop.set_formurl("FrameLeft::FrameTop.xfdl");
		objApp.avFrameLeft.set_formurl("FrameLeft::FrameLeft.xfdl");
		objApp.avFrameMain.set_formurl("FrameLeft::FrameMain.xfdl");
		objApp.avFrameTab.set_formurl("Frame::FrameTab.xfdl");
		
		objApp.avFrameLogin.set_formurl("");
		
		objApp.avVFrameSet1.set_separatesize("0,86,*");   //Login,Top,WorkFrame
		objApp.avHFrameSet.set_separatesize("240,*");     //Left,WorkFrame
		objApp.avVFrameSet2.set_separatesize("38,*,0");   //Tab,Main,FrameWork
	} else if (type == "menuClick" || type == "FrameWork") {
		objApp.avVFrameSet2.set_separatesize("38,0,*");   //Tab,Main,FrameWork
	} else if (type == "FrameMain") {
		objApp.avVFrameSet2.set_separatesize("38,*,0");   //Tab,Main,FrameWork
	}
}

/**
 * @class  Application 오브젝트를 반환하는 메소드
 *
 * @param  none
 * @return {Object}
 */
pForm.gfnGetApplication = function()
{
	var objApp = nexacro.getApplication();
	return objApp;
}

/**
 * @class Environment 오브젝트를 반환하는 메소드
 * @class EnvironmentVariable 값 반환
 * @return {Object} objEnv
 * @return {String} variable값
 */
pForm.gfnGetEnv         = function()               { return nexacro.getEnvironment(); }
pForm.gfnGetEnvServices = function(prefixId, type) { return this.gfnGetEnv().services[prefixId][type]; }
pForm.gfnGetEnvVar      = function(v)              { return nexacro.getEnvironmentVariable(v); }
pForm.gfnSetEnvVar      = function(id,val)         { return nexacro.setEnvironmentVariable(id,val); }

/**
* @class 각 Frame 객체 얻기
*/
pForm.gfnGetMainframe    = function() { return nexacro.getApplication().avMainframe;  }
pForm.gfnGetVFrameSet    = function() { return nexacro.getApplication().avVFrameSet;  }
pForm.gfnGetFrameTop     = function() { return nexacro.getApplication().avFrameTop;   }
pForm.gfnGetVFrameSet1   = function() { return nexacro.getApplication().avVFrameSet1  }
pForm.gfnGetFrameTab     = function() { return nexacro.getApplication().avFrameTab;   }
pForm.gfnGetFrameMain    = function() { return nexacro.getApplication().avFrameMain;  }
pForm.gfnGetFrameWork    = function() { return nexacro.getApplication().avFrameWork;  }

/**
* @class global dataset 얻기
*/
pForm.gfnGetGdsCode          = function() { return nexacro.getApplication().gdsCode; }
pForm.gfnGetGdsFavorite      = function() { return nexacro.getApplication().gdsFavorite; }
pForm.gfnGetGdsGridPopupMenu = function() { return nexacro.getApplication().gdsGridPopupMenu; } 
pForm.gfnGetGdsMenu          = function() { return nexacro.getApplication().gdsMenu; } 
pForm.gfnGetGdsMenuSample    = function() { return nexacro.getApplication().gdsMenuSample; } 
pForm.gfnGetGdsMsg           = function() { return nexacro.getApplication().gdsMsg; }
pForm.gfnGetGdsMsgSys        =  function() { return nexacro.getApplication().gdsMsgSys; }
pForm.gfnGetGdsOpenMenu      = function() { return nexacro.getApplication().gdsOpenMenu; } 
pForm.gfnGetGdsUser          = function() { return nexacro.getApplication().gdsUser; } 
pForm.gfnGetGdsVisit         = function() { return nexacro.getApplication().gdsVisit; }

/**
* @class 사용자정보 얻기
*/
pForm.gfnGetUserInfo = function(colId) { return this.gfnNvl(this.gfnGetGdsUser().getColumn(0,colId), ""); } 


/************************************************************************************************
* 2. FrameTop 관련
************************************************************************************************/
/**
* @class  메뉴(화면) 열기 메인
* @param  : menuId : 메뉴 id
* @param  : oParam	: 화면에 넘길 파라미터 Object
* @param  : bReload	: 화면을 리로드 할지 여부(디폴트 : false)
* @return : N/A
*/
pForm.gfnOpenMenu = function(menuId, oParam, bReload) 
{
	// Null Check
	if (this.gfnIsNull(menuId)){
		this.gfnLog("[gfnOpenMenu] MENU ID가 없습니다","info");
		return false;
	}
	
	var objMenuDs = this.gfnGetGdsMenu();
	var nFindrow = objMenuDs.findRow("menuId", menuId);
	if( nFindrow < 0 ) return false;
	var pgmUrl = objMenuDs.getColumn(nFindrow, "pgmUrl");
	if (this.gfnIsNull(pgmUrl) || pgmUrl.indexOf(".xfdl") < 0) return;	
	
	//1. FrameWork에 화면 추가
	var bRtn = this.gfnCreateMenuForm(objMenuDs, nFindrow, oParam, bReload);
	if (bRtn == false) return;
	
	//2. MDI Tab 추가
	var objFrameTab = this.gfnGetFrameTab();
	objFrameTab.form.fnOpenTabMenu(menuId, objMenuDs.getColumn(nFindrow, "menuNm"));
	
	//var objApp = nexacro.getApplication();
	//objApp.avFrameTab.form.fnOpenTabMenu(menuId, objMenuDs.getColumn(nFindrow, "menuNm"));
	
	
	//objApp.avFrameTab.form.fnAddTab(sFormId, menuNm);
	//objApp.avFrameTab.form.fnAddTab(menuId, menuNm);
	
	// 열린메뉴 추가
	//this.gfnAddOpenMenuDs(sFormId, menuId, menuNm, pgmUrl); //, sPgmId);
	//this.gfnAddOpenMenuDs(menuId, menuNm, pgmUrl); //, sPgmId);


	// MARU : 사용자 화면 이력 저장	
	
	return true;
};

/**
 * @class gdsMenu의 해당 Row의 정보를 기준으로 신규 윈도우 화면을 생성하고 open 시킴 <br>
 * @param {String} menuId - menuId
 * @param {Number} row   - gdsMenu의rowpostion
 * @param {json}   oParam - 업무화면에서 버튼 클릭 시 특정화면을 workFrame에 mdi로 띄우는 경우가 존재 한다.
 *                          이때 버튼 클릭시 argument를 넘기고 싶을 경우 이 oParam(json)값을 이용한다.
 *                          띄우을 당하는 화면에서는 gfnGetParam("변수값"); 함수를 이용해서 json값을 얻을 수 있다.
 * @param {Boolean} bReload	- 화면을 리로드 할지 여부(디폴트 : false)
 * @return N/A
 */
//pForm.gfnAddMenu = function(objDs, row, oParam, bReload)
pForm.gfnCreateMenuForm = function(objDs, row, oParam, bReload)
{
	var objApp		= pForm.gfnGetApplication();
    var menuId		= objDs.getColumn(row, "menuId");
	var pgmUrl		= objDs.getColumn(row, "pgmUrl");
	var menuNm		= objDs.getColumn(row, "menuNm");
	var sMenuPath	= objDs.getColumn(row, "menuPath");

	if (this.gfnIsNull(bReload)){
		bReload = false;
	}

	if (this.gfnIsNull(menuId) || this.gfnIsNull(pgmUrl)) {
		return false;
	}

	var objOpenMenu  = this.gfnGetGdsOpenMenu(); //objApp.gdsOpenMenu; 
	var objFrameWork = objApp.avFrameWork;
	
	var objChildForm = objFrameWork[menuId];

	// 기존에 오픈된 화면이 있는 경우 처리
	if (objChildForm != null) {
		objChildForm.setFocus();
		//objChildForm.set_showtitlebar(false);
		//objChildForm.set_border("0px none #808080");
		objChildForm.set_openstatus("maximize");	
		//objChildForm.form.divWork.set_left(6);//arrange에서 left를 20으로 설정한것 원상복귀	
		return false;
	}
	
// 	if (objChildForm != null) {
// 		if (bReload == true) {		// 리로드(화면에서 오픈)
// 			// 변경된 데이터가 있는 경우 confirm, 그외는 그냥 reload
// 			if (objChildForm.form.fnWorkFrameClose() == false) {
// 				// 변경된 데이터가 있습니다. 화면을 다시 여시겠습니까?
// 				this.gfnConfirm("MSG1207",[menuNm],"NX1207" + "^" + menuId,function(strId, strVal){
// 					if (strVal) {
// 						objChildForm.arguments["argParam"] 	= oParam;
// 						objApp.avFrameTab.form.fnActiveTab(menuId);
// 						objChildForm.form.fvDivWork.form.reload();
// 						return;
// 					}
// 				});
// 
// 			} else {
// 				objChildForm.arguments["argParam"] 	= oParam;
// 				objApp.avFrameTab.form.fnActiveTab(menuId);
// 				objChildForm.form.fvDivWork.form.reload();
// 			}
// 		} else {						// 리로드 안함(left메뉴쪽에서 클릭)
// 			objApp.avFrameTab.form.fnActiveTab(menuId);
// 		}
// 		return;
// 	}

	if (objApp.avMaxTabCnt <= objOpenMenu.getRowCount()) {
		alert(objApp.avMaxTabCnt + "개 초과하여 화면을 열수 없습니다.");
		return false;
	}

	var sBtn = "";

	// 업무영역 Size, application.avFrameWork
	var nWidth  = objApp.avFrameWork.getOffsetWidth();
	var nHeight = objApp.avFrameWork.getOffsetHeight();

	var objNewFrame = new ChildFrame();
//trace("create workframe id -->" + menuId);
	objNewFrame.init(menuId, 0, 0, nWidth, nHeight);
	objNewFrame.set_titletext(menuNm);
	objNewFrame.set_resizable(true);
	objNewFrame.set_dragmovetype("all");
	objNewFrame.set_openstatus("maximize");
	objNewFrame.set_showtitlebar(false);
	objNewFrame.set_titlebarheight(this.titlebarheight);
	objNewFrame.set_showcascadetitletext(false);
	objFrameWork.addChild(menuId, objNewFrame);

	objNewFrame.arguments = {};
	//objNewFrame.arguments["formId"] 	= sFormId;
	objNewFrame.arguments["menuId"] 	= menuId;
	objNewFrame.arguments["menuNm"] 	= menuNm;
	objNewFrame.arguments["menuPath"] 	= sMenuPath;
	//objNewFrame.arguments["pgmId"] 		= sPgmId;
	objNewFrame.arguments["pgmUrl"] 	= pgmUrl;
	objNewFrame.arguments["argParam"] 	= oParam;
//	objNewFrame.arguments["auth"] 		= objAuth;			// 메뉴권한 객체
	//objNewFrame.arguments["favoYn"] 	= sFavoYn;			// 즐겨찾기

//trace("Frame ->menuId =>" + menuId);
	objNewFrame.set_formurl("Frame::FrameWork.xfdl");
	objNewFrame.show();
	
	//화면 history저장
	//this.gfnInsertHistoryTransaction(menuId, menuNm);
	
	//ChildFrame onsyscommand event
	//objNewFrame.addEventHandler("onsyscommand", this._gfnChildframe_onsyscommand, this);
	return true;
};

/**
* @class 화면 OPEN시 방력이력 정보 저장
*/
pForm.gfnInsertHistoryTransaction = function(menuId, menuNm)
{
	//TODO : gdsMenuSample dataset을 삭제 했을 경우에는 아래 한줄 삭제
	if (menuId.indexOf("S") == 0) return;
	
	var objGdsVisit = this.gfnGetGdsVisit();
	
	//1. 방문이력이 이미 존재 하면  삭제 (차후 맨 마지막row에 추가)
	var findRow = objGdsVisit.findRow("menuId", menuId);
	var delRow  = -1;
	if (findRow >= 0)
	{
		delRow = findRow;
	}
	else
	{
		var rowCnt = objGdsVisit.rowcount;
		if (rowCnt >= 10)
		{
			delRow = 0;
		}
	}
	if (delRow >= 0)
	{
		objGdsVisit.set_enableevent(false);
		objGdsVisit.set_updatecontrol(false);
		objGdsVisit.deleteRow(delRow);
		objGdsVisit.set_enableevent(true);
		objGdsVisit.set_updatecontrol(true);
	}
	
	//2. 현재 open화면 방문이력에 추가
	var addRow = objGdsVisit.addRow();
	objGdsVisit.setColumn(addRow, "menuId", menuId);
	objGdsVisit.setColumn(addRow, "menuNm", menuNm);
	
	var svcId	= "fnSaveFavirotyTransaction";
	var service	= "/cmm/cmmUtil/insertMenuVisit.cb";
	var inDs	= "ds_visit=gdsVisit:U";
	var outDs	= "";
	this.gfnTransaction(svcId, service, inDs, outDs);
}

/**
* @class ChildFrame onsyscommand event
*/
//this._gfnChildframe_onsyscommand = function(obj:nexacro.FrameSet,e:nexacro.SysCommandEventInfo)
// pForm._gfnChildframe_onsyscommand = function(obj,e)
// {
// 	if (e.systemcommand == "maximize")
// 	{
// 		this.gfnGetFrameTab().form.fnMaximize();
// 	}
// }


/**
* @class 업무 화면에서 [종료]버튼 클릭 시 화면 닫기용
*/
pForm.gfnCloseForm = function()
{
	var menuId = this.menuId;
	//this.gfnCloseMenu(menuId);
	this.gfnGetFrameTab().form.fnCloseMenuMain("one", menuId);
}

// /**
// * @class 해당 메뉴를 닫아준다.
// *        - MDI 버튼 [x] 클릭 시 호출
// *        - FrameWork.onclose event에서도 호출함.  (농부 : 할필요 없을듯 한데..?)
// * @param {string} menuId : 닫으려는 화면 MENU_ID
// * @호출위치  . 
// *             . 
// *             . 
// */
// pForm.gfnCloseMenu = function(menuId)
// {	
// 	//열린 업무화면 arr 로 얻기
// 	var objFrameWork = this.gfnGetFrameWork();
// 	
// 	//gfnCloseMenu가 중복 호출 되었을 때 return
// 	if(!objFrameWork[menuId]) return;
// 
// 	//화면(WorkFrame)을 삭제한다.
// 	var objChild = objFrameWork.removeChild(menuId);
// 	objChild.destroy();
// 	objChild = null;
// 	
// 	//활성화 된 화면이 닫혔을 경우 다른 화면에 focus를 준다.
// 	if(this.gfnIsNull(objFrameWork.frames[menuId]))
// 	{
// 		if( objFrameWork.frames.length > 0 )
// 		{
// 			//objFrameWork.frames[0].setFocus();
// 			//objFrameWork.getActiveFrame().set_openstatus("maximize");	//포커스 한번 잃으면서 깜빡임
// 		}
// 	}
// 
// 	/*탭(TabFrame) 버튼 위치 재정렬*/
// 	this.gfnGetFrameTab().form.fnDeleteTab(menuId);
// 	this.gfnGetFrameTab().form.fnRearrange();
// 	
// 	//모든 화면이 닫힌경우에 메인 화면으로 이동한다.
// 	if( objFrameWork.frames.length == 0 )
// 	{
// 		this.gfnSetFrameSeparate("FrameMain");
// 	}
// 
// 
// // 	var objApp = nexacro.getApplication();
// // 	var gWorkFrameSet = objApp.mainframe.VFrameSet.HFrameSet.VFrameSet00.Work;//열린 업무화면 arr
// // 	
// // 	//gfnCloseMenu가 중복 호출 되었을 때 return
// // 	if(!gWorkFrameSet[menuId]) return;
// // 
// // 	//화면(WorkFrame)을 삭제한다.
// // 	var objChild = gWorkFrameSet.removeChild(menuId);
// // 	objChild.destroy();
// // 	objChild = null;
// // 	
// // 	//활성화 된 화면이 닫혔을 경우 다른 화면에 focus를 준다.
// // 	if(this.gfnIsNull(gWorkFrameSet.frames[menuId]))
// // 	{
// // 		if( gWorkFrameSet.frames.length > 0 )
// // 		{
// // 			//gWorkFrameSet.frames[0].setFocus();
// // 			
// // 			//gWorkFrameSet.getActiveFrame().set_openstatus("maximize");	//포커스 한번 잃으면서 깜빡임
// // 		}
// // 	}
// // 
// // 	/*탭(TabFrame) 버튼 위치 재정렬*/
// // 	var btnNm = "div" + menuId;//버튼 삭제하기 div + menuId
// // 	objApp.mainframe.VFrameSet.HFrameSet.VFrameSet00.Tab.form.divButtonList.form.removeChild(btnNm);
// // 	objApp.mainframe.VFrameSet.HFrameSet.VFrameSet00.Tab.form.fnRearrange();
// // 	
// // 	//모든 화면이 닫힌경우에 메인 화면으로 이동한다.
// // 	if( gWorkFrameSet.length == 0 )
// // 	{
// // 		//objApp.mainframe.VFrameSet.set_separatesize("*, 0, 0");//메인, 탑, 업무
// // 	}
// }


/************************************************************************************************
* 3. FrameWork 관련
************************************************************************************************/
/**
* @class  FrameWork관련 정보들 얻기
*         . gfnGetWorkFormCnt    : FrameWork에 존재하는 form갯수 얻기
*         . gfnGetFrameWorkWidth : 현재 FrameWork width얻기
*         . gfnGetWorkFormWidth  : Framework에 내부에 존재하는 form의 width position 얻기
*         . gfnGetWorkFormLeft   : Framework에 내부에 존재하는 form의 left  position 얻기

*         . gfnGetArrangeType : arrage type 얻기 (maximize, cascade,horizontal,vertical)
*/
pForm.gfnGetWorkFormCnt    = function()    { return this.gfnGetFrameWork().frames.length;     };
pForm.gfnGetFrameWorkWidth = function()    { return this.gfnGetFrameWork().width;             };
pForm.gfnGetWorkFormWidth  = function(idx) { return this.gfnGetFrameWork().frames[idx].width; };
pForm.gfnGetWorkFormLeft   = function(idx) { return this.gfnGetFrameWork().frames[idx].left;  };
/**
* @class  현재 arrange type 얻기
*/
// pForm.gfnGetArrangeType = function()
// {
// 	var workFrame =  this.gfnGetFrameWork();
// 	trace(workFrame.arrange());
// }

/************************************************************************************************
* 4. formOnload 관련
************************************************************************************************/
/**
* @class frame open <br>
* @param {Object}  obj - 화면
* this.gfnFormOnload(this);
* 
* @TODO 고려사항 - 아래 객체.속성에 대해서 필수로 처리 할지에 대한 고민 필요 (TODO)
*   1. grid.속성.autoenter       = select
*                .autoupdatetype = itemselect
*   2. tab.속성.selectchangetype = up           (mouse over와 transaction이 중복되면서 css 이상현상 발생)
*   3. editing가능한 object.autoselect = true   (edit, textarea, maskedit 등.. focus가 위치할 경우 기존값을 자동선택해주는 기능)
*/
pForm.gfnFormOnload = function(objForm) //, objCommBtn)
{
	if (objForm.parent.name == "divWork") {
		// 키다운 이벤트 추가
		objForm.addEventHandler("onkeydown", this.gfnOnkeydown, this);
		
		//killfocus자동 추가 여부
		if (this.FRAME_IS_AUTOKILLFOCUS == true) this.gfnSetAutoKillfocus(objForm);
	}

	// 팝업 일때 처리
	if (objForm.opener) {
		if (objForm.parent instanceof nexacro.ChildFrame) {
			// 키다운 이베트 추가
			objForm.addEventHandler("onkeydown", this.gfnOnkeydown, this);
		}
		
		//killfocus자동 추가 여부
		if (this.FRAME_IS_AUTOKILLFOCUS == true) this.gfnSetAutoKillfocus(objForm);
		
	}

	// QuikView 일때 처리
// 	if (nexacro.getEnvironmentVariable("ev_quikView") == "Y") {
// 		if (this.gfnIsNull(objForm.opener) && objForm.parent instanceof nexacro.ChildFrame) {
// 			// 키다운 이베트 추가
// 			objForm.addEventHandler("onkeydown", this.gfnOnkeydown, this);
// 		}
// 	}

	// 업무화면의 height가 줄어 들면서 scroll bar가 발생할때 divWork의 width를 조절처리해줌
	//this.gfnFormResizeScrollBar(objForm);
	
	// menu정보를 화면.user property에 setting
	this.gfnSetMenuInfo(objForm);
	
	//Grid 개인화정보 초기화
	//this.gfnPersonOnload(this);
	
	//다국어처리
	this.gfnInitLang(this);	
	
	//컴포넌트 초기 작업
	this.gfnInitComp(objForm);
	
};

/**
* @class 업무화면이면 menu정보를 form.user property에 setting
*/
pForm.gfnSetMenuInfo = function(objForm)
{
	var objMenu = this.gfnGetMenuInfo();
	if (this.gfnIsNull(objMenu)) return;
	
	this.menuId = objMenu.menuId;
	this.pgmUrl = objMenu.pgmUrl;
}

/**
* @class form open 시 Component 초기화 처리 <br>
* @param {Object} obj - 화면
* @return N/A
* @example
* this.gfnInitComp(this);
*/
pForm.gfnInitComp = function(objForm)
{
	var arrComp = objForm.components;
	var nLength = arrComp.length;

	for (var i=0; i<nLength; i++) {
		if (arrComp[i] instanceof nexacro.Div) {
			//1. 버튼권한제어는 각 form(xfdl)에서 처리
			if (this.gfnIsNull(arrComp[i].url)) {
				this.gfnInitComp(arrComp[i].form);
			}
			//2. 조회조건에서 enter key클릭 시 '조회' 버튼 클릭
			if ( (arrComp[i].id).indexOf("div_search") >= 0) {
				arrComp[i].addEventHandler("onkeydown", this._gfnDiv_search_onkeydown, this);
			}
		} else if (arrComp[i] instanceof nexacro.Tab) {
			var nPages = arrComp[i].tabpages.length;

			for (var j=0; j<nPages;j++) {
				// URL로 링크된 경우에는 존재하는 경우에는 해당 링크된 Form Onload에서 처리하도록 한다.
				if (this.gfnIsNull(arrComp[i].tabpages[j].url)) {
					this.gfnInitComp(arrComp[i].tabpages[j].form);
				}
			}
		} else if (arrComp[i] instanceof nexacro.Grid) {
			// 피봇 그리드 제외
			//if (arrComp[i].name == "grdPivot" || arrComp[i].name == "popGrdItemFilterGrid")	{ continue; }
				
			this.gfnSetGrid(objForm, arrComp[i]);
		}
	}
};

/**
 * @class div_search에서 enter key를 누르면 [조회]버튼 event후행
*/
//this._gfnDiv_search_onkeydown = function(obj:nexacro.Div,e:nexacro.KeyEventInfo)
pForm._gfnDiv_search_onkeydown = function(obj, e)
{
	if (e.keycode == 13)
	{
		try{
			var searchFunc = obj.searchFunc;
			if (this.gfnIsNull(searchFunc))
			{
				searchFunc = "fnSearch";
			}
			this.gfnUpdateToDataset(this); 
			this.lookupFunc(searchFunc).call();
		} catch(e){}		
	}
}

/**
* @class html5처럼 div,static에 클릭시에도 입력컴포넌트에 killfocus를 발생하기 위하여 최상위 form,div의 onlbuttonup이벤트를 생성하여 처리함
*/
pForm.gfnSetAutoKillfocus = function(objForm)
{
	objForm.addEventHandler("onlbuttonup", function(objForm, e) {
		//1. click전에 focus가 없는 컴포넌트에 위치 되어 있으면 return
		var objFocusComp = objForm.getFocus();
		var objClickComp = e.fromreferenceobject;
		if (this.gfnIsNull(objFocusComp)) return;
		if (objFocusComp == objClickComp) return;  //e.fromreferenceobject:클릭한 component
		
		//2. click한 component가 focus를 이동할 수 있는 컴포넌트는 제외 
		if (   String(objClickComp) != "[object Static]"
			&& String(objClickComp) != "[object Div]"
			&& String(objClickComp) != "[object Tab]"
			&& String(objClickComp) != "[object Form]" )  {
			return;
		}
		
		//3. 가상의 컴포넌트를 생성 후 focus를 줌
		var nLeft = e.canvasx;
		var nTop  = e.canvasy;
		
		var sKillFocusComp = "sImgKillFocus";
		var objNextComp = objForm[sKillFocusComp];
		if (this.gfnIsNull(objNextComp)) {
			var objImageViewer = new Button(sKillFocusComp, "absolute", nLeft, nTop, 0, 0, null, null);
			objForm.addChild(sKillFocusComp, objImageViewer);
			objImageViewer.show();
			objImageViewer.set_tabstop(false);
			objImageViewer.set_taborder(parseInt(objClickComp.taborder) + 1);
			objNextComp = objImageViewer;
		}	
		objNextComp.move(nLeft, nTop);
		objNextComp.setFocus(true);

	}, objForm);
}

/**
 * @class 각 화면에서 단축키 지정
*/
pForm.gfnOnkeydown = function(obj, e)
{
	// 디버그 창 : Ctrl + Q
	if (e.ctrlkey && e.keycode == 81) {
		// 운영환경에서는 실행 방지
		//if (nexacro.getEnvironmentVariable("evRunMode") == "2") return;

		var oArg = {};
		var oOption = {
			popuptype: "modeless"
		  , title: "디버그"
		  , width: 800
		  , height:700
		};
		var sPopupCallBack = "";
		this.gfnOpenPopup("debugging", "Comm::CommDebug.xfdl", oArg, sPopupCallBack, oOption);

		return true;
	}
};

/**
* 조회 Div에 있는 컴포넌트에서 엔터시 조회 메소드 호출
* @param  {object} objDiv - 조회 Div
* @param  {object} sSearchFnNm - 조회함수명. 미설정시 fnSearch() 실행
* @return N/A
* @example this.gfnSetDivSearch(this.div_search);
*/
pForm.gfnSetDivSearch = function(objDiv, sSearchFnNm)
{
	var arrComp = objDiv.form.components;
	var nLength = arrComp.length;

	objDiv.searchFnNm = sSearchFnNm;

	for( var i=0; i<nLength; i++) {
		if( arrComp[i] instanceof nexacro.Edit) {
			if (arrComp[i].excludeSrchYn != 'Y') {
				arrComp[i].addEventHandler("onkeydown", this._fnOnkeydown_edit, this);

				if (sSearchFnNm ==  null) {
					arrComp[i]._searchFnNm = "fnSearch";
				} else {
					arrComp[i]._searchFnNm = sSearchFnNm;
				}
			}
		}
	}
};
pForm._fnOnkeydown_edit = function(obj,e)
{
	// 엔터시 조회
	if(e.keycode == 13) {
		this.gfnUpdateToDataset(this);

		var sFunction = obj._searchFnNm;

		if(this.gfnIsExist(sFunction)) {
			this.lookupFunc(sFunction).call();
		}
	}
};

/************************************************************************************************
* 9. 기타 
************************************************************************************************/
/**
* @class 화면권한 얻기
* @param {string} flag - s/i/d/u/b/x
* @return 0/1 (권한여부)
*/
pForm.gfnGetAuth = function (flag)
{
// 	var objParent = this.parent;
// 	var menuId  = objParent.menuId;
// 	
// 	//div내부의 url일 경우 menuId얻기
// 	if (this.gfnIsNull(menuId))
// 	{
// 		for(var i=0; i<10; i++)
// 		{
// 			objParent = objParent.parent;
// 			if (this.gfnIsNull(objParent))
// 			{
// 				return "0";
// 			}
// 			menuId = objParent.menuId;
// 			if (this.gfnIsExist(menuId)) break;
// 		}
// 	}

	var menuId = this.gfnGetMenuId();

	if (this.gfnIsNull(menuId))
	{
		return "0";
	}
	
	var objDsMenu = this.gfnGetGdsMenu();
	var authCol = (flag.indexOf("Fg") >= 0 ? flag : flag + "Fg");
	var auth = objDsMenu.lookup("menuId", menuId, authCol);
	auth = (this.gfnIsNull(auth) ? "0" : auth);
	return auth;
}
pForm.gfnGetAuth2 = function (flag, menuId)
{
	var objDsMenu = this.gfnGetGdsMenu();
	var authCol = (flag.indexOf("Fg") >= 0 ? flag : flag + "Fg");
	var auth = objDsMenu.lookup("menuId", menuId, authCol);
	auth = (this.gfnIsNull(auth) ? "0" : auth);
	return auth;
}

/**
* @class 현재 화면의 menuId얻기 (팝업창 화면에서는 얻을 수 없음)
* @param {Object}  obj - 화면
* @return 0/1 (권한여부)
*/
pForm.gfnGetMenuId = function()
{
	var objParent = this.parent;
	var menuId    = objParent.menuId;
	
	//div내부의 url일 경우 menuId얻기
	if (this.gfnIsNull(menuId))
	{
		for(var i=0; i<10; i++)
		{
			objParent = objParent.parent;
			if (this.gfnIsNull(objParent))
			{
				return "";
			}
			menuId = objParent.menuId;
			if (this.gfnIsExist(menuId)) break;
		}
	}
	return menuId;
}

/**
* @class 현재 화면의 menuId, pgmUrl 얻기 (팝업창 화면에서는 얻을 수 없음)
* @param {Object}  obj - 화면
* @return 0/1 (권한여부)
*/
pForm.gfnGetMenuInfo = function()
{
	var objParent = this.parent;
	var menuId    = objParent.menuId;
	var pgmUrl    = objParent.pgmUrl;
	
	//div내부의 url일 경우 menuId얻기
	if (this.gfnIsNull(menuId))
	{
		for(var i=0; i<10; i++)
		{
			objParent = objParent.parent;
			if (this.gfnIsNull(objParent))
			{
				return "";
			}
			menuId = objParent.menuId;
			pgmUrl = objParent.pgmUrl;
			if (this.gfnIsExist(menuId)) break;
		}
	}
	var objMenu = {menuId:menuId, pgmUrl:pgmUrl}
	return objMenu;
}

/**
* @class 팝업창에서 argument 얻기
* @param {string}  sName - argument name
* @return 0/1 (권한여부)
*/
pForm.gfnGetArgument = function(sName)
{
	return this.getOwnerFrame().arguments[sName];
	
	//var jsonParam = this.getOwnerFrame().arguments["argParam"];
	//return jsonParam[sName];
};

/**
* @class 화면 파라미터 반환
* @param  {string} sParamNm - 파라미터명
* @return 파라미터값
* @example this.gfnGetParam("paramNo");
*/
pForm.gfnGetParam = function(sParamNm)
{
	try {
		return this.getOwnerFrame().arguments[sParamNm];
		
		/*
		var jsonParam = this.getOwnerFrame().arguments["argParam"];
		ret = jsonParam[sParamNm];
		*/
	
		// 아래가 초기 버전. 팝업open방식이 변경되어 위 방식으로 처리
		//  		var oParam = this.gfnGetArgument("argParam");
		//  		if (this.gfnIsNull(sParamNm)) {
		//  			ret = oParam;
		//  		} else if (oParam) {
		// 			var argument = oParam["arguments"]
		// 			//ret = argument[sParamNm];
		// 			//return ret;
		//  			ret = oParam[sParamNm];
		//  		}

		//  		var oParam = this.gfnGetArgument("arguments");
		//  		if (this.gfnIsNull(sParamNm)) {
		//  			ret = oParam;
		//  		} else if (oParam) {
		// 			//var argument = oParam["argParam"]
		// 			//ret = argument[sParamNm];
		// 			//return ret;
		//  			ret = oParam[sParamNm];
		//  		}

	} catch(e){
		this.gfnLog(sParamNm + " 파라미터 객체가 선언되지 않았습니다.","info");
		return "";
	}
};

/**
 * @class URL 이동
 * @param {String} sUrl
 * @return
 */
pForm.gfnGoUrl = function(sUrl) {
	if (system.navigatorname == 'nexacro') {
		system.execBrowser(sUrl);
	} else {
		location.href = sUrl;
	}
}

/**
 * @class 새창 URL 이동
 * @param {String} sUrl
 * @return
 */
pForm.gfnOpenUrl = function(sUrl) {
	if (system.navigatorname == 'nexacro') {
		system.execBrowser(sUrl);
	} else {
		window.open(sUrl);
	}
}

/**
 * @class 부모폼을 반환
 * @param {Object} Child Form
 * @return {Object} Parent Form
 */
pForm.gfnGetOwnerForm = function(obj)
{
	if (obj.getOwnerFrame().form.name == "frameWork") {
		return obj.getOwnerFrame().form.divWork.form;
	} else {
		return obj.getOwnerFrame().form;
	}
}

/**
* @class  업무화면의 height가 줄어 들면서 scroll bar가 발생할때 divWork의 width를 조절처리해줌
* @param  {Object} form
*/
pForm.gfnFormResizeScrollBar = function(objForm)
{
	if (objForm.parent.id == "divWork") {
		this._gfnResizeScrollBar_form_onsize(); //화면 onload시 초기 scroll때문에 바로 호출 필요
		objForm.addEventHandler("onsize", this._gfnResizeScrollBar_form_onsize, objForm);
	}
}

/**
* @class  업무화면의 height가 줄어 들면서 scroll bar가 발생할때 divWork의 width를 조절처리해줌
* @param  {Object} form
*/
pForm._gfnResizeScrollBar_form_onsize = function()
{
	if (this.vscrollbar.max == 0) {
		var scrollbarsize = 15; //nexacro.getEnvironmentVariable("scrollbarsize");
		this.parent.parent.divWork.set_right(scrollbarsize);
	} else {
		this.parent.parent.divWork.set_right(2);
	}
}


/************************************************************************************************
* 1. 다국어 Start
************************************************************************************************/
/**
 * @class  해당 form의 하위 콤포넌트 모두 찾아 다국어 처리
 * @param  {Form} objForm - 대상 form
 * @return N/A
 */
pForm.gfnInitLang = function (objForm)
{
	//var sNowLang    = nexacro.getEnvironmentVariable("evLanguage");			// 현재 언어
	//var sChangeLang = nexacro.getEnvironmentVariable("evLanguageChange");	// 바꿀 언어
	
	// Language 변경 전/후 값 확인
	/*if (sNowLang == "KO" && sNowLang == sChangeLang) return;*/

	var arrComp = objForm.components;
	var nLength = arrComp.length;

	for (var i=0; i<nLength; i++) {
		if (arrComp[i] instanceof nexacro.Div) {
			// URL로 링크된 경우에는 존재하는 경우에는 해당 링크된 Form Onload에서 처리하도록 한다.
			if (this.gfnIsNull(arrComp[i].url)) this.gfnInitLang(arrComp[i].form); //재귀함수			
		} else if (arrComp[i] instanceof nexacro.Tab) {
			var nPages = arrComp[i].tabpages.length;

			for (var j=0; j<nPages;j++) {
				// URL로 링크된 경우에는 존재하는 경우에는 해당 링크된 Form Onload에서 처리하도록 한다.
				if (this.gfnIsNull(arrComp[i].tabpages[j].url)) {
					this.gfnChangeLang(arrComp[i].tabpages[j]);
					this.gfnInitLang(arrComp[i].tabpages[j].form); //재귀함수
				}
			}
		} else {
			this.gfnChangeLang(arrComp[i]); //다국어설정
		}
	}
	
	// text 사이즈 변경으로 인한 화면 갱신 필요
	objForm.resetScroll();
};


/**
 * @class  해당 Component에 대해 다국어 처리
 * @param  {Object} objComp - 대상 Object
 * @return N/A
 */
pForm.gfnChangeLang = function (objComp)
{
	var termId = "";		// 용어 code
	var termNm = "";		// 치환될 값
	
	// Button, Static, CheckBox, Tabpage
	if (objComp instanceof nexacro.Button || objComp instanceof nexacro.Static || objComp instanceof nexacro.CheckBox || objComp instanceof nexacro.Tabpage) {
		termId   = objComp.uWord;
		var text = objComp.text;
		if(this.gfnIsNull(text)) return;
		if (this.gfnIsNull(termId)) {
			objComp.set_text("X_" + text);
			return;
		}
	
		termNm = this.gfnGetWord(termId, text);
		objComp.set_text(termNm.toString());
	}
	// ImageViewer 는 해당 프로젝트의 디자인 파일의 Naming Rule에 맞게 수정 필요
	else if (objComp instanceof nexacro.ImageViewer) {		
// 		termId = objComp.uWord; 		// image의 경우 용어 code에 true 설정
// 		if (this.gfnIsNull(termId) || termId != "true") return;
// 
// 		var sImage   = objComp.image;	// image
// 		// 이미지 확장자
// 		var buff     = sImage.split(".");
// 		var fileExt  = buff[buff.length-1].replace("\")", "");
// 			
// 		var sNowLang    = nexacro.getEnvironmentVariable("evLanguage");			// 현재 언어
// 		var sChangeLang = nexacro.getEnvironmentVariable("evLanguageChange");	// 바꿀 언어
// 		if (sNowLang != "KO" && sChangeLang == "KO")
// 		{
// 			sImage = sImage.replace("_"+sNowLang+"."+fileExt,"."+fileExt);
// 		}
// 		else {		
// 			var nPos = this.gfnPosReverse(sImage,"."+fileExt);
// 			sImage = sImage.substr(0, nPos) + "_" + nexacro.getEnvironmentVariable("evLanguageChange")+"."+fileExt+"\")";
// 		}
// 		objComp.set_image(sImage);		
	}
	// Grid
	else if (objComp instanceof nexacro.Grid) {
		objComp.set_enableevent(false);
		var nCol = objComp.getCellCount("head");

		for (var j=0; j<nCol; j++) {
			var text = objComp.getCellProperty("Head", j, "text");
			
			// Grid의 경우 용어 code를 Header의 expandchar Property에 기술
			termId = objComp.getCellProperty("Head", j, "uWord");	// 용어 code
			if (this.gfnIsNull(termId)) {
				if(this.gfnIsNull(text)) continue;
				
				objComp.setCellProperty("Head", j, "text", "X_" + text);
			} else {
				termNm = this.gfnGetWord(termId, text);
				objComp.setCellProperty("Head", j, "text", termNm.toString());
			}
		}
		
		nCol = objComp.getCellCount("summary");
		for (var j=0; j<nCol; j++) {
			var text = objComp.getCellProperty("Summary", j, "text");
			
			// Grid의 경우 용어 code를 Header의 expandchar Property에 기술
			termId = objComp.getCellProperty("Summary", j, "uWord");	// 용어 code
			if (this.gfnIsNull(termId)) {
				if(this.gfnIsNull(text)) continue;
				if(text.toString().indexOf("expr:") >= 0) continue; // expr 적용된 경우, 패스!!
				
				objComp.setCellProperty("Summary", j, "text", "X_" + text);
			} else {
				termNm = this.gfnGetWord(termId, text);
				objComp.setCellProperty("Summary", j, "text", termNm.toString());
			}
		}
		objComp.set_enableevent(true);
	}	
};

/**
 * @class  다국어 처리를 위한 용어 검색
 * @param  {String} sTargetVal - 검색할 용어
 *         {String} text       - component에 대한 text값
 * @return {String} 변경할 용어
 */
pForm.gfnGetWord = function (termId, text)
{
	if (termId == "_false") return text;

	//TO.DO : 플젝에 적용시 아래 주석문장 살리고, form에 존재 하는 gdsMultiLang는 삭제
	//var objApp 	  = this.gfnGetApplication();
	//var objLangDs = objApp.gdsTerm;
	var objLangDs = this.gdsMultiLang;
	
	var termNm = termId;
	var row = objLangDs.findRow("termId", termId);
	if (row != -1) {
		termNm = objLangDs.getColumn(row, "termNm");
		if(!this.gfnIsNull(termNm)) termNm = termNm.toString().replace(/\\n/g, "\n");
	} else {
		termNm = "X_" + text;
	}
	return termNm;
};

/************************************************************************************************
* 1. 다국어 End
************************************************************************************************/






/**
* gfnOpenMenu (frame open)
* @param  : menuId : 화면ID
* @param  : oParam	: 화면에 넘길 파라미터 Object
* @param  : bReload	: 화면을 리로드 할지 여부
* @return : N/A
* @example :  this.gfnOpenMenu(strMenuId, oParam);
*/
// pForm.gfnOpenMenu  = function(menuId, oParam, bReload)
// {
// 	var ret = false;
// 
// 	// 팝업에서 부모쪽 제어할때 IE에서 느려지는 제약사항이 있어서 함수 호출 분리함.
// 	if (this.gfnIsNull(this.getOwnerFrame().form.opener)) {
// 		ret = this._gfnOpenMenu(menuId, oParam, bReload);
// 	} else {
// 		ret = nexacro.getApplication().avFrameLeft.form._gfnOpenMenu(menuId, oParam, bReload);
// 	}
// 
// 	return ret;
// };

/**
* gfnOpenPgm (frame open)
* @param  : sPgmId : 프로그램ID
* @param  : oParam	: 화면에 넘길 파라미터 Object
* @param  : bReload	: 화면을 리로드 할지 여부(디폴트 : true)
* @return : N/A
* @example :  this.gfnOpenPgm(sPgmId, oParam);
*/
// pForm.gfnOpenPgm  = function(sPgmId, oParam, bReload)
// {
// 	if (this.gfnIsNull(bReload)){
// 		bReload = true;
// 	}
// 	var objMenuDs = nexacro.getApplication().gdsMenu; 		// 글로벌데이터셋 메뉴
// 	var nFRow	= objMenuDs.findRow("pgmId",sPgmId);
// 	var menuId	= objMenuDs.getColumn(nFRow, "menuId");
// 
// 	this.gfnOpenMenu(menuId,oParam, bReload);
// };


// /**
//  * @class 화면 닫기
// */
// pForm.gfnCloseMenu = function(menuId, bCloseCheck)
// {
// 	if (this.gfnIsNull(bCloseCheck)) bCloseCheck = true;
// 
// 	//var sFormId;
// 
// // 	if (this.gfnIsNull(menuId)) {
// // 		sFormId = this.getOwnerFrame().name;
// // 	} else {
// // 		var objApp = pForm.gfnGetApplication();
// // 		var row = objOpenMenu.findRow("menuId",menuId);
// // 
// // 		if (row == -1)		return;
// // 
// // 		sFormId = objOpenMenu.getColumn(row, "formId");
// // 	}
// 
// 	nexacro.getApplication().avFrameTab.form.fnCloseMenu(menuId);
// };


/**
 * @class 열린메뉴 데이터셋에 추가 <br>
 * @param {String} sFormId
 * @param {String} menuId
 * @param {String} strTitle
 * @param {String} spageUrl
 * @param {String} sPgmId
 * @return N/A
 */
// pForm.gfnAddOpenMenuDs = function(sFormId, menuId, menuNm, pgmUrl) //, sPgmId)
// {
// 	var objApp = pForm.gfnGetApplication();
// 	var row = objOpenMenu.addRow();
// 	objOpenMenu.setColumn(row, "formId", sFormId);
// 	objOpenMenu.setColumn(row, "menuId", menuId);
// 	objOpenMenu.setColumn(row, "menuNm", menuNm);
// 	objOpenMenu.setColumn(row, "pgmUrl", pgmUrl);
// 	//objOpenMenu.setColumn(row, "pgmId", sPgmId);
// };

/**
 * @class 열린메뉴 데이터셋에 삭제 <br>
 * @param {String} sFormId
 * @return N/A
 */
// pForm.gfnRemoveOpenMenuDs = function(sFormId, menuId, menuNm, pgmUrl)
// {
// 	var objApp = pForm.gfnGetApplication();
// 	var row = objOpenMenu.findRow("formId", sFormId);
// 	objOpenMenu.deleteRow(row);
// };



// pForm.gfnGetArgumentMain = function(sName)
// {
// 	return this.getOwnerFrame().arguments[sName];
// };

/**
 * Nexacro browser 여부 확인
 *
 * @return {Boolean} Nexacro browser 여부
 */
// pForm.gfnIsNexaBrowser = function()
// {
// 	return (system.navigatorname == "nexacro");
// }

/**
* @class Left, Top, work 모든frame조회
*/
// pForm.gfnSetMainFrame = function()
// {
// 	var objApp = nexacro.getApplication();
// 
// 	objApp.av_closecheck 	= true;
// 
// 	//URL 연결
// 	objApp.avFrameTop.set_formurl("Frame::FrameTop.xfdl");
// 	objApp.avFrameLeft.set_formurl("Frame::FrameLeft.xfdl");
// 	objApp.avFrameTab.set_formurl("Frame::FrameTab.xfdl");
// 	objApp.avFrameLogin.set_formurl("");
// 	//application.gvLeftFrame.form.getMenu();
// 
// 	// grid 개인화 조회
// 	var sXML = nexacro.getPrivateProfile(this.gfnGetUserInfo("USER_ID") + "/" + "gds_gridPersonal");
// 	objApp.gds_gridPersonal.loadXML(sXML);
// 
// 	// 메인화면셋팅
// 	pForm.gfnSetFrameMain(true);			
// };

/**
	메인화면으로 이동
*/
// pForm.gfnSetFrameMain = function(bInit)
// {
// 	if (this.gfnIsNull(bInit))			bInit = false;
// 
// 	var objApp = nexacro.getApplication();
// 
// 	objApp.av_framestat	= "main";
// 
// 	// Layout
// 	objApp.avVFrameSet.set_separatesize("0,54,*");
// 	objApp.avVFrameSet1.set_separatesize("34,*,0");
// 
// 	if (bInit == false) {
// 		objApp.avFrameTab.form.fnSetEnableArrange(false);		// 메인일때 정렬 사용못함
// 		objApp.avFrameLeft.form.fnSetMenuStyle(objApp.av_framestat);
// 	}
// 	
// 	var formurl = "Frame::FrameMain.xfdl"; //"Frame::FrameMain.xfdl"; 
// 
// 	objApp.avFrameMain.set_formurl('');
// 	objApp.avFrameMain.set_formurl(formurl);
// };

/**
* @class 서브화면으로 이동
*/
// pForm.gfnSetSub = function()
// {
// 	var objApp = nexacro.getApplication();
// 	objApp.av_framestat	= "sub";
// 	objApp.avVFrameSet1.set_separatesize("34,0,*");
// 	objApp.avFrameTab.form.fnSetEnableArrange(true);		// 서브일때 정렬 사용
// 	objApp.avFrameLeft.form.fnSetMenuStyle(objApp.av_framestat);
// 	objApp.avFrameMain.set_formurl("");
// };


// /**
// * @class Login화면으로 이동(로그아웃처리)
// */
// pForm.gfnGoLogin = function()
// {
// 	var objApp = nexacro.getApplication();
// 
// 	objApp.av_framestat	= "login";
// 
// 	// 닫을때 체크안함.
//  	objApp.av_closecheck = false;
// 
// 	try {
// 		// 폼닫기
// 		objApp.avFrameTab.form.fnCloseAll(false);
// 	} catch(e){ }
// 
// 	objOpenMenu.clearData();
// 
// 	// URL 초기화
// 	objApp.avFrameTop.set_formurl("");
// 	objApp.avFrameLeft.set_formurl("");
// 	objApp.avFrameTab.set_formurl("");
// 	objApp.avFrameMain.set_formurl("");
// 	objApp.avFrameLogin.set_formurl("Frame::FrameLogin.xfdl");
// 
// 	objApp.avVFrameSet.set_separatesize("*,0,0");
// 	objApp.avHFrameSet.set_separatesize("240,*");
// 	//objApp.avFrameLogin.form.reload();
// };


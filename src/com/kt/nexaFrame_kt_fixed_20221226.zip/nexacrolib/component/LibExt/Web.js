//web 관련 script

var pForm = nexacro.Form.prototype;

/**
 * @class cookie값 얻기
 *        html5 일 경우
 * @param {string} name : cookie name
 * @exam  this.gfnGetCookie("ehCook")
 * @참고 cookie 값을 얻을때 nexacro.getCookieVariable() api를 사용하면 좋지만 단점이 있다.
 *       단점은, trasnaction을 호출하지 않고는cookie값을 얻어 올수 없다.
 *       즉, 브라우져에서 tab page를 하나 추가 후 cookie값을 얻어 올려면 못가져온다.
 *       그래서 document.cookie script를 사용해서 값을 얻어온다.
 */
pForm.gfnGetCookie = function(name) {
  var arg = name + "=";
  var alen = arg.length;
  var clen = document.cookie.length;
  var i = 0;

 while (i < clen) {
   var j = i + alen;
       if (document.cookie.substring(i, j) == arg)
          return this.gfnGetCookieval (j);
       i = document.cookie.indexOf(" ", i) + 1;
       if (i == 0) break; 
  }
  return null;
}
pForm.gfnGetCookieval = function(offset) {
    var endstr = document.cookie.indexOf (";", offset);
    if (endstr == -1)
       endstr = document.cookie.length;
    return unescape(document.cookie.substring(offset, endstr));
}
/**
*  @FileName 	Popup.js 
*/

var pForm = nexacro.Form.prototype;

/**
* 1. 팝업 호출 및 닫기 공통
*   - gfnOpenPopup            : 공통팝업 오픈
*   - gfnAddPopup             : 공통팝업 오픈(실재 오픈)
*   - gfnClosePopup           : 팝업화면에서 창 닫기 (팝업창에서 수정여부 확인 및 return값 처리)
*   - gfnPopupChangedCallback : 팝업창자료가 변경 시 confirm callback
*   - _gfnClosePopup          : 팝업창에서 argument를 업무창에 넘기거나, 업무창 callback함수를 호출 후 팝업창 닫기
*   - gfnCloseAllPopup        : 열려져 있는 전체 팝업 닫기 
*   - 
* 5. 달력 Grid용 - PopupDiv 관련 함수
*   - gfnOpenCalYmGrid        : Grid에 클릭한 cell위치에 년월일 From~to달력 팝업창 띄워주기 <br>
*   - gfnOpenCalYmDualGrid    : Grid에 클릭한 cell위치에 년월일 From~to달력 팝업창 띄워주기 <br>
*   - gfnOpenCalYmdDualGrid   : Grid에 클릭한 cell위치에 년월일 From~to달력 팝업창 띄워주기 <br>
*   - gfnOpenCalDualGrid      : Grid에 클릭한 cell위치에 년월일 From~to달력 팝업창 띄워주기 <br>
*   - gfnOpenPopupDivGridCell : Grid에서 클릭 한 cell 밑으로  PopupDiv를 띄위기
*   - 
* 6. 달력 Calendar 용 - PopupDiv 관련 함수
*   - gfnOpenCalYmdDualComponent : 검색조건 날짜 from~to, 또는 master형에 날짜 from~to일 경우 날짜 팝업
*   - gfnOpenPopupDivCal          :  Grid에서 클릭 한 cell 밑으로  PopupDiv를 띄위기
*   - 
* 7. 공통코드 찾기 팝업 호출
* 9. 기타  start
*   - gfnSetPopupProp            : 팝업창 기본속성정의(팝업창 onload event에서 호출)
*   - _gfnPopup_onkeydown        : popup창 onkeydown event
*   - gfnPopupGridLinePivot      : grid 한줄을 팝업창에서 row 방식으로 조회
*   - 
*/

/************************************************************************************************
* 1. 팝업 호출 및 닫기 공통 start
************************************************************************************************/
/**
* @class  공통팝업 오픈
*/
pForm.gfnOpenPopup = function(sPopupId, sUrl, oParam, sPopupCallback, oOption)
{
	if (this.gfnIsNull(sPopupId)) {
		this.gfnLog("[gfnOpenPopup] Popup ID가 없습니다","info");
		return false;
	}
	if (this.gfnIsNull(sUrl)) {
		this.gfnLog("[gfnOpenPopup] Url이 없습니다","info");
		return false;
	}
	if (this.gfnIsNull(oOption["title"])) {
		this.gfnLog("[gfnOpenPopup] Title이 없습니다","info");
		return false;
	}
// 	if (this.gfnIsNull(oOption["width"])){
// 		this.gfnLog("[gfnOpenPopup] Width가 없습니다","info");
// 		return false;
// 	}
// 	if (this.gfnIsNull(oOption["height"])){
// 		this.gfnLog("[gfnOpenPopup] Height가 없습니다","info");
// 		return false;
// 	} 
	
	var oArg = {};
	oArg["popupTitle"]  = oOption["title"];
	oArg["popupUrl"]	= sUrl;
	//oParam["auth"] 		= this.gfnGetAuth();			// 메뉴권한 객체(팝업은 부모권한 가져감)
	
	if (this.gfnIsNull(oOption))			oOption = {};
	oOption["showtitlebar"] = true;
	oOption["width"]	    = (this.gfnIsNull(oOption["width"])  ? -1 : parseInt(oOption["width"]) );// + 40 + 4);
	oOption["height"]	    = (this.gfnIsNull(oOption["height"]) ? -1 : parseInt(oOption["height"]) + 33);  //33 : title height  // + 180 + 4);
	oParam["popupTitle"]    = oOption["title"];
	oParam["popupId"]       = sPopupId;
	oParam["callbackFunc"]  = (this.gfnIsNull(sPopupCallback) ? "" : sPopupCallback);
	oParam["pgmUrl"]        = sUrl;
	
	//this.gfnAddPopup(sPopupId,"Comm::Comm_Popup.xfdl",oParam,sPopupCallback,oOption,oArg);	
	this.gfnAddPopup(sPopupId, sUrl, oParam, sPopupCallback, oOption, oArg);	
};

/**
* @class  공통팝업 오픈
* @참고   Message.js에서 gfnAddPopup()을 바로 호출함. 
*          autosize=true  : 개발자가 부여한 width, height가 적용이 안되고 개발한 form의 width, heigth그대로 팝업창이 뜸
*                           resizable = true로 해도 팝업창을 마우스로 resize할 수 없음
*          resizable=true : 팝업창의 size를 마우스로 resize할 수 있음
*/
pForm.gfnAddPopup = function(sPopupId, sUrl, oParam, sPopupCallback, oOption)
{
    var objApp = pForm.gfnGetApplication();
	var bShowStatus = false;	
	
	//default value
	var nLeft         = (this.gfnIsExist(oOption.left)         ? oOption.left         : -1);
	var nTop          = (this.gfnIsExist(oOption.top)          ? oOption.top          : -1);
	var nWidth        = (this.gfnIsExist(oOption.width)        ? oOption.width        : -1);
	var nHeight       = (this.gfnIsExist(oOption.height)       ? oOption.height       : -1);
	var bTopmost      = (this.gfnIsExist(oOption.topmost)      ? oOption.topmost      : false);   
	var sPopupType    = (this.gfnIsExist(oOption.popuptype)    ? oOption.popuptype    : "modal");
	var bLayered      = (this.gfnIsExist(oOption.layered)      ? oOption.layered      : false);
	var nOpacity      = (this.gfnIsExist(oOption.opacity)      ? oOption.opacity      : 100);
	var bAutoSize     = (this.gfnIsExist(oOption.autosize)     ? oOption.autosize     : false);
	var bShowtitlebar = (this.gfnIsExist(oOption.showtitlebar) ? oOption.showtitlebar : false);
    var sTitleText    = (this.gfnIsExist(oOption.title)        ? oOption.title        : ""   );
    var bResizable    = (this.gfnIsExist(oOption.resizable)    ? oOption.resizable    : false);
	
	var titlebarheight        = (this.gfnIsExist(oOption.titlebarheight)       ? oOption.titlebarheight       : 40);
	var titlebarbuttonsize    = (this.gfnIsExist(oOption.titlebarbuttonsize)   ? oOption.titlebarbuttonsize   : 40);

	//modaless 전용 option start
	var bShowstatusbar        = (this.gfnIsExist(oOption.showstatusbar)        ? oOption.showstatusbar        : false);
	var bShowontaskbar        = (this.gfnIsExist(oOption.showontaskbar)        ? oOption.showontaskbar        : true);
	var bShowcascadetitletext = (this.gfnIsExist(oOption.showcascadetitletext) ? oOption.showcascadetitletext : false);
	//modaless 전용 option end

	var sOpenalign = "";
	if (nLeft == -1 && nTop == -1) {
		sOpenalign = "center middle";
		
		//sOpenalign = "center middle" 인 경우에는 left, top 좌표를 구할필요가 없음
		//left, top좌표값이 있어도 자동으로 center, middle로 정렬되서 중앙에 popup창이 보여짐
		// if (system.navigatorname == "nexacro") {
		// 	var curX = objApp.mainframe.left;
		// 	var curY = objApp.mainframe.top;
		// }
		// else{
		// 	var curX = window.screenLeft;
		// 	var curY = window.screenTop;
		// }
		// nLeft =  curX + (objApp.mainframe.width / 2) - Math.round(nWidth / 2);
		// nTop  = curY + (objApp.mainframe.height / 2) - Math.round(nHeight / 2) ;
		
		/*
        nLeft = (objApp.mainframe.width  / 2) - Math.round(nWidth / 2);
        nTop = (objApp.mainframe.height / 2) - Math.round(nHeight / 2) ;		
		if (sPopupType == "modeless") 
		{ 
			nLeft = system.clientToScreenX(this, nLeft);
			nTop = system.clientToScreenY(this, nTop);
		} else {
			nLeft = this.getOffsetLeft() + nLeft;
			nTop  = this.getOffsetTop() + nTop;
		}
		*/
	} else {
		nLeft = this.getOffsetLeft() + nLeft;
		nTop  = this.getOffsetTop() + nTop;
	}

	if (nWidth == -1 || nHeight == -1) {
	    bAutoSize = true;
	}
	
	// modeless를 위해 팝업 Type 및 callBack함수 지정
	if (this.gfnIsNull(oParam))		oParam = {};
	
	oParam.popupType = sPopupType;
	oParam.popupId   = sPopupId;
	oParam.callback  = sPopupCallback;
	oParam.popupType = sPopupType;
	
	// 높이 체크
	var nMaxHeight;
	if (sPopupType == "modeless") {		// 모니터 해상도로 체크
		nMaxHeight = system.getScreenHeight();
	} else {							// 어플리케이션 크기로 체크
		nMaxHeight = objApp.mainframe.height;
	}
	
	nMaxHeight = parseInt(nMaxHeight) - 100;
	// 최대해상도보다 큰 경우
	if (nHeight > nMaxHeight) {
		nTop = 0;
		nHeight = nMaxHeight;
		bAutoSize = false;
		sOpenalign = "center top";
	}
	var objParentFrame = this.getOwnerFrame();

	//추가 옵션 예제
	// 1. 듀얼모니터 사용시 index2화면에 팝업창 띄우기
	//   - getScreenRect() 를 이용하여 모니터의 좌표값을 가져와서 open 시에 left 값을 설정을 하여 처리를 해주시기 바랍니다. 
	//   - ex) var objRct = system.getScreenRect(2); 
	//   - nexacro.open( strID, strFormURL, objParentFrame, {objArguList}, strOpenStyle, objRct.left, nTop ) 
// trace(sPopupType + '--bAutoSize->' + bAutoSize);	
// trace('bShowTitle->' + bShowTitle);	

    if (sPopupType == "modal") 
	{
		newChild = new nexacro.ChildFrame;
		newChild.init(sPopupId, nLeft, nTop, nWidth, nHeight, null, null, sUrl);
		newChild.set_dragmovetype("all");
		newChild.set_showcascadetitletext(false);
		newChild.set_showtitlebar(bShowtitlebar);    //titlebar는 안보임
		if (bShowtitlebar == true)
		{
			newChild.set_titlebarheight(titlebarheight);
			newChild.set_titlebarbuttonsize(titlebarbuttonsize);
		}

		newChild.set_autosize(bAutoSize);	
		newChild.set_resizable(bResizable);    //resizable 안됨

		if (this.gfnIsExist(sTitleText)) {
            newChild.set_titletext(sTitleText);
        }
		newChild.set_showstatusbar(bShowStatus);    //statusbar는 안보임
		newChild.set_openalign(sOpenalign);  //"center middle" : 로 값이 setting시 'newChild.init()에서 left, top 에 값이 존재 해도 무시됨'
		newChild.set_layered(bLayered);
		newChild.set_topmost(bTopmost);
		newChild.set_overlaycolor("RGBA(0, 0, 0, 0.2)");
		
		newChild.showModal(sPopupId, objParentFrame, {"arguments" : oParam}, this, sPopupCallback);
	} else if (sPopupType == "modeless") {
		var sOpenStyle = "showtitlebar="          + bShowtitlebar;
		sOpenStyle    += " showstatusbar="        + bShowstatusbar;
		sOpenStyle    += " showontaskbar="        + bShowontaskbar
		sOpenStyle    += " showcascadetitletext=" + bShowcascadetitletext;
		sOpenStyle    += " resizable="            + bResizable;
		sOpenStyle    += " autosize="             + bAutoSize;
		sOpenStyle    += " topmost="              + bTopmost;
		sOpenStyle    += " titlebarheight="       + titlebarheight;
		sOpenStyle    += " titlebarbuttonsize="   + titlebarbuttonsize;
		sOpenStyle    += " titletext="            + sTitleText;	

		var arrPopFrame = nexacro.getPopupFrames(objParentFrame);
		if (arrPopFrame[sPopupId]) {
			if (system.navigatorname == "nexacro") {
				arrPopFrame[sPopupId].setFocus();
			} else {
				try {
					arrPopFrame[sPopupId]._getWindowHandle().focus();
				} catch (e) { }
			}
		} else {
			nexacro.open(sPopupId, sUrl, objParentFrame, {"arguments" : oParam}, sOpenStyle, nLeft, nTop, nWidth, nHeight, this);
		}
    }
};

/**
* @class 팝업화면에서 창 닫기 (팝업창에서 수정여부 확인 및 return값 처리)
* @param {object} objRtn : json형태의 string형 return값
* @param {var}    arg1   : return하고 싶은 arg1
* @param {var}    arg2   : return하고 싶은 arg2
* @param {var}    arg3   : return하고 싶은 arg3
*/
pForm._popReturn;
pForm._popArg1;
pForm._popArg2;
pForm._popArg3;
pForm.gfnClosePopup = function(objRtn, arg1, arg2, arg3)
{
	var objChild = this.getOwnerFrame().form;
	
	if (objChild == null) {
		return;
	}
	
	//var objWorkForm = objChild.fv_divWork;  //팝업창을 div하나 만들어서 업무팝업창을 연결(url)했을 경우의 script
	var objWorkForm = objChild;
	
	// 화면 닫기체크
	if (objWorkForm != null)
	{
		// 마지막 컴포넌트 데이터셋  업데이트
		this.gfnUpdateToDataset(objWorkForm.form);
		
		//팝업창 data 변경여부 검증
		if (this.gfnIsExist(objChild.lookup("fn_isClose")))  
		{
			var rtn = objChild.fn_isClose();
			if (rtn == false) {
				this._popReturn = objRtn;
				this._popArg1 = arg1;
				this._popArg2 = arg2;
				this._popArg3 = arg3;
				this.gfnAlert("MSG1205", null, "popupChanged", "gfnPopupChangedCallback");  //변경된 데이터가 있습니다. 현재 화면을 닫겠습니까?
				return;
			}
		}
	}
	this._gfnClosePopup(objRtn, arg1, arg2, arg3);
};

/**
* @class 팝업창자료가 변경 시 confirm callback
*/
pForm.gfnPopupChangedCallback = function (strId, strVal)
{
	// 변경된 데이터가 있습니다. 현재 화면을 닫겠습니까? -> true
	if (strId == "popupChanged")	
	{	
		if(strVal == true)
		{
			this._gfnClosePopup(this._popReturn, this._popArg1, this._popArg2, this._popArg3);
		}
		//else시 팝업창을 닫지 않는다.
	}
};

// pForm.gfnMsgCallback = function (strId, strVal)
// {
// 	if (strId == "gfnBeforclosepopup")	{	// 변경된 데이터가 있습니다. 현재 화면을 닫겠습니까?
// 		if(strVal == true)
// 		{
// 			this._gfnClosePopup(this._popReturn);
// 		}
// 	}
// };

/**
* @class 팝업창에서 argument를 업무창에 넘기거나, 업무창 callback함수를 호출 후 팝업창 닫기
*/
pForm._gfnClosePopup = function(objRtn, arg1, arg2, arg3)
{
	var objChild = this.getOwnerFrame().form;
	
	if (objChild == null) return;
	
	// modeless 팝업일때 부모창의 callBack 함수 실행
	if (objChild.opener) 
	{		
		var sPopupType = this.gfnGetArgument("popupType");
		
		// 팝업이 modeless 일때
		if (sPopupType == "modeless")
		{
			var sPopupId  = this.gfnGetArgument("popupId");
			var sCallBack = this.gfnGetArgument("callback");

			// callBack 함수가 있을 때
			if (this.gfnIsNull(sCallBack) == false) 
			{
				if (typeof(sCallBack) == "function") 
				{
					sCallBack.call(this.opener, sPopupId, objRtn); 
				} 
				else 
				{
					objChild.opener.lookupFunc(sCallBack).call(sPopupId, objRtn, arg1, arg2, arg3);
				}
				objChild.close();
				return;
			}
		}
	}
	
	// 팝업이 modal 일때
	objChild.close(objRtn);
}

/**
* @class 열려져 있는 전체 팝업 닫기 
*/
pForm.gfnCloseAllPopup = function(objFrame) {
	if (!objFrame) {
		objFrame = this.getOwnerFrame();
	}
	var arrPopFrame = nexacro.getPopupFrames(objFrame);
	var popFrame;
	// var openPopCnt = 0;
	for (var i = arrPopFrame.length - 1; i >= 0; i--) {
		popFrame = arrPopFrame[i];
		if (popFrame) {
			if (popFrame.form) {
				popFrame.form.close();
			} else {
				// openPopCnt++;
			}
		}
	}
	/*
	if (openPopCnt) {
		setTimeout(function() {
			pForm.gfnCloseAllPopup();
		}, 100);
	}
	*/
}

/************************************************************************************************
* 1. 팝업 호출 및 닫기 공통 end
************************************************************************************************/





/************************************************************************************************
* 7. 공통코드 찾기 팝업 호출 - start
************************************************************************************************/

/** type : CommonCode
 * @class 공통코드 팝업 호출
 *        1. 조회조건일 경우 : 돋볻기버튼에.uPopupProp  userproperty추가  (값은 NULL)
 *        2. grid일 경우      : grid에     .uPopupProp  userproperty추가  (값은 NULL)
 *        3. dataset에         : uPopupProp userproperty추가               (값은 NULL)
 * @param workType - component : 조회조건등과 같은 컴포넌트 기본 코드 찾기
 *                 - grid      : grid cell에서 '찾기버튼' (expand버튼) 클릭시  코드 찾기
 */
pForm.gfnCoPopupCommon = function(workType, objDs, oPopProp, objGrid) 
{
	//1. dataset oncolumnchanged event추가
	objDs.uCoPopProp = oPopProp;
	objDs.addEventHandler("oncolumnchanged", this._gfnCoPopupCommon_dataset_oncolumnchanged, this);
	
	//2. button onclick시  코드찾기 팝업창 띄워주는 event 생성
	if (workType == "component") {
		for(var popType in oPopProp) {
			var subProp    = oPopProp[popType];
			var oBtnSearch = subProp["oBtnSearch"];
			if (this.gfnIsExist(oBtnSearch)) {
				oBtnSearch.addEventHandler("onclick", this._gfnCoPopupCommon_button_onclick, this);
				oBtnSearch.uCoPopType  = popType;
				oBtnSearch.uCoPopProp  = oPopProp;
				oBtnSearch.uCoPopObjDs = objDs;
			}
		}
		
	//3. grid onexpandup시  코드찾기 팝업창 띄워주는 event 생성
	} else {
		objGrid.uCoPopProp = oPopProp;
		objGrid.addEventHandler("onexpandup", this._gfnCoPopupCommon_grid_onexpandup, this);
	}
}

/** type : CommonCode
* @class dataset oncolumnchanged event (팝업 호출)
* this._gfnCoPopupCommon_dataset_oncolumnchanged = function(obj:nexacro.NormalDataset,e:nexacro.DSColChangeEventInfo)
*/
pForm._gfnCoPopupCommon_dataset_oncolumnchanged = function(obj, e)
{
	//1. Popup속성값 얻기
	var oPopProp = obj.uCoPopProp;
	if (this.gfnIsNull(oPopProp)) return;
	
	//2. 사용자가 변경한 컬럼명 확인 (코드, 코드명 컬럼)
	var changedColId = "," + e.columnid + ",";
	
	//3 변경한 컬럼명을 기준으로 popType 찾기
	//  - popType 이란 : EMP, DEPT 와 같은 코드종류(팝업종류)
	var popType;
	var oMapColList;
	for(var type in oPopProp) {
		var subProp     = oPopProp[type];
		var editColList = subProp["editColList"];
		editColList     = "," + editColList + ",";
		if (editColList.indexOf(changedColId) >= 0) {
			popType     = type;
			oMapColList = subProp["oMapColList"];
			break;
		}
	}
	
	//4. 변경된 컬럼명이 코드찾기컬럼명이 아니면 return
	if (this.gfnIsNull(popType)) return;
	
	//5. 사용자가 입력한 값이외의 컬럼들 clear
	for(var colId in oMapColList) {
		if (colId != e.columnid) {
			obj.setColumn(e.row, colId, "");
		}
	}
	
	//6. 팝업창 호출
	if (this.gfnIsExist(e.newvalue)) {
		this.gfnCoPopupMain(popType, oPopProp, e.newvalue, obj);
	}
}
 
/** type : CommonCode
* @class button onclick event (팝업 호출)
* pForm._gfnCoPopupCommon_button_onclick = function(obj:nexacro.NormalDataset,e:nexacro.DSColChangeEventInfo)
*/
pForm._gfnCoPopupCommon_button_onclick = function(obj ,e)
{
	var popType  = obj.uCoPopType;
	var oPopProp = obj.uCoPopProp;
	var newvalue = "";
	var objDs    = obj.uCoPopObjDs;
	this.gfnCoPopupMain(popType, oPopProp, newvalue, objDs);
}

/** type : CommonCode
*   @class grid onexpandup event
*   this._gfnCoPopupCommon_grid_onexpandup = function(obj:nexacro.Grid,e:nexacro.GridMouseEventInfo)
*/
pForm._gfnCoPopupCommon_grid_onexpandup = function(obj ,e)
{
	//1. 객체정보 얻기
	var objDs    = obj.getBindDataset();
	var oPopProp = obj.uCoPopProp;
	if (this.gfnIsNull(oPopProp)) return;
	
	//var subProp  = oPopProp[popType];
	
	//bind:empNm
	//2. expand버튼 클릭에 대한 컬럼명을 기준으로 popType 찾기
	//  - popType 이란 : EMP, DEPT 와 같은 코드종류(팝업종류)
	var popType;
	var oMapColList;
	var bindColId = nexacro.replaceAll(obj.getCellProperty("body", e.col, "text"), "bind:", "");
	for(var type in oPopProp) {
		var subProp     = oPopProp[type];
		var editColList = subProp["editColList"];
		editColList     = "," + editColList + ",";
		if (editColList.indexOf(bindColId) >= 0) {
			popType  = type;
			oMapColList = subProp["oMapColList"];
			break;
		}
	}	
	
	//3. 공통 코드찾기 버튼이 아니면 return
	if (this.gfnIsNull(popType)) return;
	
	//4. 팝업창 호출
	var newvalue = "";
	this.gfnCoPopupMain(popType, oPopProp, newvalue, objDs);
}

/** type : CommonCode
 * @class 팝업 main
 * @param popType         - EMP, DEPT 와 같은 코드종류(팝업종류)
 *        uPopupProp      - 개발자가 정의한 popup용 Property전체
 *        newvalue        - 사용자가 검색을 위해서 입력한 값
 *        objDs           - 사용되는 DATASET
 *        oMapColList     - 팝업창에서 값을 받아 setting할 컬럼 목록
 *        busiCallback    - 팝업창이 닫힌 후 호출할 callback function
 */
//var pForm = nexacro.Form.prototype;
//pForm.ivCpPopType;  과 같이 변경해야 됨
//this.gfnCoPopupCallback()함수에서 사용하기 위해서 instance variable 추가
this.ivCoPopUpType;
this.ivCoPopUpProp;
this.ivCoPopUpObjDs;
pForm.gfnCoPopupMain = function(popType, uPopupProp, newvalue, objDs) {
	this.ivCoPopUpType  = popType;
//trace('gfnCoPopupMain :: uPopupProp->'  + JSON.stringify(uPopupProp));
	this.ivCoPopUpProp  = uPopupProp;
	this.ivCoPopUpObjDs = objDs;

	//팝업창 까지는 현sample에서 만들지 않았음.. 그래서 이곳에서 바로 callback함수를 호출함
	if (popType == "EMP")  this.gfnCoPopupEmp(newvalue);

//아래 script3줄은 테스트용
// 	if (popType == "EMP") {
// 		var oRtnVal = {"comEmpNo":"A001", "comEmpNm":"강감찬", "comAddr":"경기도 광명시", "comAge":30};
// 		this.gfnCoPopupCallback("SearchEmpPopup", oRtnVal);
// 	}
	
	//else if (popType == "DEPT") this.gfnCoPopupDept(newvalue);
	//else if (popType == "MAT")  this.gfnCoPopupMat(newvalue);
	//else if (popType == "STND") this.gfnCoPopupMatStnd(newvalue);
}

/** type : CommonCode
 * @class 사원번호 팝업
 */
pForm.gfnCoPopupEmp = function(empNm)
{
	var sTitle  = "사원번호 검색";
	var oArg    = {pStr_empNo:"", pStr_empNm:empNm};
	var oOption = {title:sTitle,resize:true};	//top, left를 지정하지 않으면 가운데정렬
	this.gfnOpenPopup( "SearchEmpPopup","Sample::Sample_EmpSearchPopup.xfdl", oArg, "gfnCoPopupCallback", oOption);
};


/** type : CommonCode
 * @class 팝업 callback
 */
pForm.gfnCoPopupCallback = function(popId, popVal)
{
	var subProp          = this.ivCoPopUpProp[this.ivCoPopUpType];
	var codeColId        = subProp["codeColId"];
	var oMapColList      = subProp["oMapColList"];
	var busiCallback     = subProp["busiCallback"];
	var bAutoSetFlag     = subProp["bAutoSetFlag"];
	var bEnableeventFlag = subProp["bEnableeventFlag"];
	bAutoSetFlag     = (this.gfnIsNull(bAutoSetFlag)     ? true  : bAutoSetFlag);
	bEnableeventFlag = (this.gfnIsNull(bEnableeventFlag) ? false : bEnableeventFlag);
	
	var row             = this.ivCoPopUpObjDs.rowposition;
	
	if (this.gfnIsNull(bAutoSetFlag) || bAutoSetFlag == true) {
		if (bEnableeventFlag == false) this.ivCoPopUpObjDs.set_enableevent(false);
		
		//1. 팝업 Return값으로 setting
		if(this.gfnIsExist(popVal)) {
			var oPopVal = JSON.parse(popVal);
			for(var colId in oMapColList) {
				this.ivCoPopUpObjDs.setColumn(row, colId, oPopVal[oMapColList[colId]]);
			}
		
		//2. 팝업 Return값이 없을 경우 .. 관련된 값들 clear
		} else {
			var codeVal = this.ivCoPopUpObjDs.getColumn(row, codeColId);
			if (this.gfnIsNull(codeVal)) {
				for(var colId in oMapColList) {
					this.ivCoPopUpObjDs.setColumn(row, oMapColList[oMapColList[colId]], "");
				}
			}
		}
		if (bEnableeventFlag == false) this.ivCoPopUpObjDs.set_enableevent(true);
	}
	
	if (this.gfnIsExist(busiCallback)) this.lookupFunc(busiCallback).call(popId, popVal, this.ivCoPopUpType, this.ivCoPopUpProp);
};

/************************************************************************************************
* 7. 공통코드 찾기 팝업 호출 - end
************************************************************************************************/


/************************************************************************************************
* 9. 기타  start
************************************************************************************************/
/**
* @class  팝업창 기본속성정의(팝업창 onload event에서 호출)
*/
pForm.gfnSetPopupProp = function()
{
	this.set_border("0px solid #999999, 1px solid #000000, 1px solid #000000, 1px solid #000000");
 	this.objParentFrame = this.getOwnerFrame(); 
	//this.objParentFrame.titlebar.set_border("2px solid #000000, 2px solid #000000, 2px solid #000000, 2px solid #000000");
	this.objParentFrame.titlebar.set_border("2px solid #404b57, 2px solid #404b57, 2px solid #404b57, 2px solid #404b57");
	
	this.menuId = this.gfnGetParam("menuId");
	this.pgmUrl = this.gfnGetParam("pgmUrl");
	
	//esc key event
	this.addEventHandler("onkeydown", this._gfnPopup_onkeydown, this);
}

/**
* @class popup창 onkeydown event
*/
pForm._gfnPopup_onkeydown = function(obj, e)
{
	if (e.keycode == 27)
	{
		this.fn_close();
	}
}


/**
* @class grid 한줄을 팝업창에서 row 방식으로 조회
* @param {String} title      : 팝업창 title명
* @param {Object} objGrd     : nexacro.Grid
* @param {Object} oProp      : 작업속성 json (예:{dataType:"viewGrid", row:e.row, exceptCell:"0,1", datasetCell:"5,8", popUpWidth:600, headCellWidth:200};);
* @exam  //arg : (필수항목) row
		 //      (선택항목) exceptCell, datasetCell, width, headCellWidth
		
		 //항목 설명 : exceptCell  - 팝업창에 제외할 cell
		 //             datasetCell - 팝업창에 보여줄값은 기본이 grid에 보여지는 값임
		 //                           만약, dataset의 컬럼값을 보여주고 싶은 경우에 기술(이때 expr은 불가)
		 //             popUpWidth  - 팝업창 width (default : 600)
		 //             headCellWidth  - 팝업창에서 보여줄 head  cell width
		
		 //필수주석문장
		 // - exceptCell  : 0 - 순번
		 //                 1 - 선택
		 // - datasetCell : 5 - busiNo
		 //                 8 - inDate
		 //var oProp = {row:e.row, exceptCell:"0,1", datasetCell:"5,8", popUpWidth:600, headCellWidth:200};
		 var title = "팝업창 타이틀명";
		 var oProp = {row:e.row, exceptCell:"0,1,2", datasetCell:"5,8", popUpWidth:600, headCellWidth:200};
		 this.gfnPopupGridLinePivot(title, obj, oProp);
*/
pForm.gfnPopupGridLinePivot = function(title, objGrd, oProp)
{
	//1. width
	if (this.gfnIsNull(oProp.popUpWidth)) oProp.popUpWidth = 600;
	
	//2. height
	var cellCnt       = objGrd.getCellCount("body");
	var exceptCellCnt = (this.gfnIsNull(oProp.exceptCell) ? 0 : (oProp.exceptCell.split(",").length));
	var viewCellCnt   = cellCnt - exceptCellCnt;
	//29:grid row height, 32:grid head height,  83:grid와 상단, 하단 여유분, 2:Grid 알수 없는 추가 height, 8:여러가지 border
	var height        = viewCellCnt * 29 + 32 + 83 + 2 + 8;  
	
	oProp.cellCnt       = cellCnt;
	oProp.exceptCellCnt = exceptCellCnt;
	oProp.viewCellCnt   = viewCellCnt;
	oProp.height        = height;
	
	var frameWorkHeight = this.gfnGetFrameWork().getOffsetHeight();
	oProp.height = (frameWorkHeight > oProp.height ? frameWorkHeight  : oProp.height);
	
	var popId    = "GridLinePivot";
    var url      = "MAIN::GridLinePivotP.xfdl";
	var menuId   = this.gfnGetMenuId();
	var oParam   = {pMenuId:menuId, pObjGrd:objGrd, pProp:oProp};
	var callback = "fn_popupCallback";
	var oOption  = {title: title, resizable:true, width: oProp.popUpWidth, height: height};
	//var oOption  = {title: title, width: oProp.popUpWidth, height: height};
	
	this.gfnOpenPopup(popId, url, oParam, callback, oOption);
}

/**
* @class 파일미리보기
* @param {String} title     : 팝업창 title명
* @param {Object} oFileInfo : 파일미리보기 옵션
* @param {Object} oProp     : 팝업창 옵션
*/
pForm.gfnPopupFilePreview = function(title, oFileInfo, oProp)
{
	var popId    = "filePreview";
    var url      = "MAIN::FilePreviewP.xfdl";
	var menuId   = this.gfnGetMenuId();
	var oParam   = {pMenuId:menuId, pFileInfo:oFileInfo};
	var callback = "";
	var oOption  = {title:title, resizable:true, width:oProp.width, height:oProp.height};
	//var oOption  = {title: title, width: oProp.popUpWidth, height: height};
	
	this.gfnOpenPopup(popId, url, oParam, callback, oOption);
}


/************************************************************************************************
* 9. 기타  end
************************************************************************************************/

/*
Component.js : dynamic component
             , combo, edit, maskedit, TextArea, Static, Radio, CheckBox, 
             , ListBox, Spin, GroupBox,  ImageViewer, ProgressBar
			 , Plugin, ListView, NxPivot, binditem
*/


var pForm = nexacro.Form.prototype;

/**
 * @class enter key를 tab key로 변환
 * @param {object}  obj : form
 * @param {object}  e    : nexacro.KeyEventInfo
 * @example form_onkeydown event에서 수행
this.form_onkeydown = function(obj:nexacro.Form,e:nexacro.KeyEventInfo)
{
	this.gfnFormEnterFocus(obj, e);
};
 * @주의 component.enable = false인 경우  setFocus()가 되지 않아.. gfnChangeNextEnabledComponent()함수를 만들었음
 *        component.autoskip 속성을  true 로 설정시 오류 발생. 반드시 false로 해야 됨
 *        div.url 내부에 연결된 form은 onkeydown event가 존재 하면 안됨 (tab이 두번 발생)
 */
pForm.gfnFormEnterFocus = function(obj, e)
{
	if(e.keycode != 13) return;

	var currObj   = obj.getFocus();
	
	//grid인 경우에는 cell 이동으로 skip
	if (currObj instanceof nexacro.Grid) return;
	
	var parentObj = currObj.parent.parent;
	
	var nextObj = parentObj.form.getNextComponent(currObj, true); 
	if ( nextObj.enable == false )
	{
		//enable=false 속성일 경우 setfocus가 안됨.
		//그래서 enable=true속성을 찾는 함수를 recursive 방식으로 호출
		this.gfnChangeNextEnabledComponent(parentObj, nextObj);
		return;
	}	
	nextObj.setFocus();
}
//enable=true속성을 찾는 함수를 recursive 방식으로 호출
pForm.gfnChangeNextEnabledComponent = function(parentObj, currObj)
{
	var parentObj = currObj.parent.parent;
	var nextObj = parentObj.form.getNextComponent(currObj, true); 
	
	if ( nextObj.enable == false )
	{
		this.gfnChangeNextEnabledComponent(parentObj, nextObj);
		nextObj.setFocus();
		return;
	}
	nextObj.setFocus();
}

/**
 * @class 해당 콤포넌트의 form으로 부터의 경로(path)를 구하는 함수
 * @param {Object} obj - 콤포넌트
 * @return {String} 해당 콤포넌트의 form으로 부터의 경로
 */
pForm.gfnGetCompId = function (obj)
{
	var sCompId = obj.name;
	var objParent = obj.parent;
	
	while (true) {
		//trace("" + objParent + " / " + objParent.name);
		if (objParent instanceof nexacro.ChildFrame ) {
			break;
		} else {
			sCompId = objParent.name + "." + sCompId;
		}
		objParent = objParent.parent;		
	}
	return sCompId;
};

/**
 * @class 컴포넌트에 ReadOnly 스타일을 적용하는 함수
 * @param {Object} oComp - 콤포넌트
 * @param {Boolean} bReadOnly - 콤포넌트
 */
pForm.gfnSetViewMode = function (oComp, bViewMode)
{
	var objComp, sClass;
	var nBtnWidth = -1;
	var arrComp = new Array();
	
	if (this.gfnIsNexaComponent(oComp)) {
		if (oComp instanceof nexacro.Div) {
			if (this.gfnIsNull(oComp.url)) {
				arrComp = oComp.form.components;
			}
		} else {
			arrComp.push(oComp);
		}
	} else {
		arrComp = oComp;
	}
	
	for(var i=0; i< arrComp.length; i++) {
		objComp = arrComp[i];
		
		if (objComp instanceof nexacro.Calendar
			|| objComp instanceof nexacro.Edit
			|| objComp instanceof nexacro.MaskEdit
			|| objComp instanceof nexacro.TextArea
			|| objComp instanceof nexacro.Combo) {
			
			objComp.set_readonly(bViewMode);
		
			if (bViewMode) {
				objComp.set_cssclass("com_WF_View");
				
				if (objComp instanceof nexacro.Calendar
				|| objComp instanceof nexacro.Combo) {
					objComp.set_buttonsize("0 0");
				}
			} else {
				objComp.set_cssclass("");
				
				if (objComp instanceof nexacro.Calendar
				|| objComp instanceof nexacro.Combo) {
					objComp.set_buttonsize("");
				}
			}
		}
	}
};


/**
* @class 주어진 nexacro 개체의 type 을 반환 <br>
* @param {*} obj Object, Component, Frame, .. 등 nexacro 모든 개체
* @return {String} 개체의 type
* @example
* trace(this.gfnTypeOf(Button00));	// output : Button
* trace(this.gfnTypeOf(Tab00));	// output : Tab
* trace(this.gfnTypeOf(Tab00.tabpage1));	// output : Tabpage
* trace(this.gfnTypeOf(Dataset00));	// output : Dataset
*/
pForm.gfnTypeOf = function(obj)
{
	var type;
	if (obj && (typeof obj == "object")) {
		var s = obj.toString();
		if(s == "[object Object]") {
			return type;
		}
		
		type = s.substr(8, s.length - 9);
	} else {
		type = typeof(obj)
	}
	return type;
};


/**
 * @class nexacro Component 여부 Check <br>
 * @param {Object} value - 체크할 Object	
 * @return {boolean}
 */
pForm.gfnIsNexaComponent = function(value) 
{
	if (value === null || value === undefined) {
		return false;
	}
	
	return value instanceof nexacro.Component;
};

 /**
 * @class object의 내용을 trace로 출력
 * @param {Object} objArg - 대상 Object
 * @param {String} [sName]  - key 값
 * @return N/A
 */
pForm.gfnObjView = function (objArg, sName)
{
	for (var name in objArg) {
		if (this.gfnIsNull(sName) == false) {
			if (name == sName) {
				trace("name : " + name + " / value : " + objArg[name]);
			}
		} else {
			trace("name : " + name + " / value : " + objArg[name]);		
		}
	}
};

/**
 * @class   대상에서 오브젝트 반환
 * @param 	{Object} p - 오브젝트를 찾을 대상
 * @param 	{String} name - 오브젝트네임
 * @return  {Object} 오브젝트
 * @example
 * this.gfnLookup(this, "dsList");	
 */
pForm.gfnLookup = function(p, name)
{
	var o;
	while (p) {		
		o = p.components;
		if (o && o[name]) {
			return o[name];
		}
		
		o = p.objects; 
		if (o && o[name]) {
			return o[name];
		}
		
		p = p.parent;
	}
	return null;
};

/**
* @class 문자열로 object찾기
* @param {Object} objForm - 화면
*        {String} name    - 객체명
* @return N/A
* @example
* this.gfnLookupComp(this);
*/
pForm.gfnLookupComp = function(objForm, name)
{
	if (this.gfnIsNull(name)) return;
	
	var arrComp = objForm.components;
	var nLength = arrComp.length;

	for (var i=0; i<nLength; i++)
	{
		if (arrComp[i].id == name) return arrComp[i];
	
		if (arrComp[i] instanceof nexacro.Div)
		{
			//1. 버튼권한제어는 각 form(xfdl)에서 처리
			if (this.gfnIsNull(arrComp[i].url))
			{
				var objRtn = this.gfnLookupComp(arrComp[i].form, name);
				if (this.gfnIsExist(objRtn)) return objRtn;
			}
		}
		else if (arrComp[i] instanceof nexacro.Tab)
		{
			var nPages = arrComp[i].tabpages.length;

			for (var j=0; j<nPages;j++)
			{
				// URL로 링크된 경우에는 존재하는 경우에는 해당 링크된 Form Onload에서 처리하도록 한다.
				if (this.gfnIsNull(arrComp[i].tabpages[j].url))
				{
					var objRtn = this.gfnLookupComp(arrComp[i].tabpages[j].form, name);
					if (this.gfnIsExist(objRtn)) return objRtn;
				}
			}
		} 
	}
};

/**
 * @class  지정된 속성의 값이 처음으로 일치하는 객체의 배열 위치를 뒤에서부터 찾아 반환한다.<br>
 * 배열의 각 항목은 하나 이상의 속성을 가진 객체이다.<br> 
 * @param {Array} array 대상 Array.
 * @param {String} prop 기준 속성.
 * @param {String} item 기준 값.
 * @param {Number} from 검색 시작 위치(default: 0).
 * @param {Boolean} strict true: 형변환 없이 비교('==='), false: 형변환 후 비교('==') (default: false).
 * @return {Number} 검색된 배열 위치. 없다면 -1 리턴.
 * @example
 * var users = [];
 * users[0] = {id:"milk", name:"park", age:33};
 * users[1] = {id:"apple", name:"kim"};
 * users[2] = {id:"oops", name:"joo", age:44};
 * users[3] = {id:"beans", name:"lee", age:50};
 * users[4] = {id:"zoo", age:65};
 * users[5] = {id:"milk", name:"", age:33};
 * users[6] = {id:"milk", name:"lee", age:33};
 * var index = this.gfnLastIndexOfProp(users, "name", "lee");
 * trace("index==>" + index);	// output : index==>6
 * var index = this.gfnLastIndexOfProp(users, "name", "lee", 5);
 * trace("index==>" + index);	// output : index==>3
*/
pForm.gfnLastIndexOfProp = function(array, prop, item, from, strict)
{
	var i, obj, propValue;
	
	if (from == null) {
		from = array.length - 1;
	} else if (from < 0) {
		from = Math.max(0, array.length + from);
	}
	
	var strict = strict || false;
	
	if (strict) {
		for (i = from; i >= 0; i--) {
			if (i in array && array[i]) {
				obj = array[i],
				propValue = obj[prop];
				
				if (propValue === item) {
					return i;
				}
			}
		}
	} else {
		for (i = from; i >= 0; i--) {
			if (i in array && array[i]) {
				obj = array[i],
				propValue = obj[prop];
				
				if (propValue == item) {
					return i;
				}
			}
		}
	}
	
	return -1;
};


/**
 * @class Component 기준의 XY좌표를 XCompA 기준의 XY좌표로 변환.
 * @param {Object} Component.
 * @param {Array} xy XCompB기준의 XY좌표.
 * @param {Object} XCompB XComponent.
 * @return {Array} XCompA기준의 좌표. [ x좌표, y좌표]
 * @example
 * Form에 아래와 같이 Button00이 존재 할 경우
 *
 * |---------------------------------------------------------|  ^
 * |  Form                                                   |  |
 * |                                                         |  |
 * |                                                         | 300
 * |                                                         |  |
 * |                                     //(0,0)             |  v
 * |                                       *-----------      | 
 * |                                       | Button00 |      | 
 * |                                       ------------      | 
 * |                                                         | 
 * |---------------------------------------------------------| 
 * <--------------- 900 ------------------>	
 *		 
 * trace(this.gfnConvertXY(this,[0,0], Button00)); //output: [900,300]
 * //Button00을 기준으로 한 0,0 좌표는
 * //form 기준으로 했을 때 900, 300이 된다.
*/				
pForm.gfnConvertXY = function(XCompA, xy, XCompB)
{
	var tempX, tempY;
	var x, y;
	if (XCompB) {
		tempX = system.clientToScreenX(XCompB, xy[0]);
		tempY = system.clientToScreenY(XCompB, xy[1]);
		x = system.screenToClientX(XCompA, tempX) + this.gfnGetScrollLeft(XCompA);
		y = system.screenToClientY(XCompA, tempY) + this.gfnGetScrollTop(XCompA);				
	} else {
		x = xy[0];
		y = xy[1];
	}
	
	return [x, y];
};

/**
 * @class  수평스크롤바의 trackbar 위치를 반환한다.
 * @param  {Object} Component.
 * @return {Number} 수평스크롤바의 trackbar 위치(수평스크롤바가 없을때는 0).
 * @example
 * trace(this.gfnGetScrollLeft(Div01)); //output: 10
 * trace(this.gfnGetScrollLeft(Div01)); //output: 0
*/
pForm.gfnGetScrollLeft = function(XComp)
{
	if (XComp instanceof nexacro.Div) {
		XComp = XComp.form;
	}
	return (XComp.hscrollbar && XComp.hscrollbar.visible ? XComp.hscrollbar.pos : 0);
};

/**
 * @class  수직스크롤바의 trackbar 위치를 반환한다.
 * @param  {Object} Component.
 * @return {Number} 수직스크롤바의 trackbar 위치(수직스크롤바가 없을때는 0).
 * @example
 * trace(this.gfnGetScrollTop(Div01)); //output: 20
 * trace(this.gfnGetScrollTop(Div01)); //output: 0
 */
pForm.gfnGetScrollTop = function(XComp)
{
	if (XComp instanceof nexacro.Div) {
		XComp = XComp.form;
	}
	return (XComp.vscrollbar && XComp.vscrollbar.visible ? XComp.vscrollbar.pos : 0);
};


/**
 * @class object에 argument로 주어진 object의 모든 속성값을 복사한다.<br>
 * object, function, date, array Type은 reference가 복사된다.
 * @param {Object} tarobject target 객체.
 * @param {Object} srcobject source 객체.
 * @example
 * var target = {};
 * this.gfnCopyProperties(target, {a: 1, b: "2", c: {"A": "3", "B": 4}});
 * for(var p in target)
 * {
 * 	trace(p + ":" + target[p]);
 *	// output : a:1
 *	// output : b:2
 *	// output : c:[object Object]
 * }
*/
pForm.gfnCopyProperties = function(tarobject, srcobject)
{
	if (tarobject && srcobject) {
		var p, value;
		
		for (p in srcobject) {
			if (srcobject.hasOwnProperty(p)) {
				value = srcobject[p];
				tarobject[p] = value;
			}
		}
	}
};	


/**
 * @class  Form 내에서 지정된 접두문자열에 순번이 붙여진 ID 를 반환
 * @param {Object} prefix 순번 앞에 붙일 문자열
 * @param {String} prefix 순번 앞에 붙일 문자열
 * @return {String} id
 * @example
 * // this = Form
 * trace(this.gfnGetSequenceId(this, "Button")); // output : Button0
 * trace(this.gfnGetSequenceId(this, "Button")); // output : Button1
 * // this = Form
 * trace(this.gfnGetSequenceId(this, "chk_")); // output : chk_0
 * trace(this.gfnGetSequenceId(this, "chk_")); // output : chk_1
*/		
pForm.gfnGetSequenceId = function(form, prefix)
{
	if (this.gfnIsNull(form)) {
		trace("getSequenceId :: 1st argument doesn't exist !!");
		return null;
	}
	
	if (this.gfnIsNull(prefix)) {
		trace("getSequenceId :: 2nd argument doesn't exist !!");
		return null;
	}
	
	if (!(form instanceof Form)) {				
		trace("getSequenceId :: 1st argument must be a Form !!");
		return null;
	}
	
	var cache = form._sequenceIdCache;
	if (this.gfnIsNull(cache)) {
		cache = form._sequenceIdCache = {};
	}
	
	var sequence = cache[prefix];
	if (this.gfnIsNull(sequence)) {
		sequence = -1;
	}
	sequence++;
	
	cache[prefix] = sequence;
	
	return prefix + sequence;
};

/**
 * @class object 속성값들을 주어진 함수로 처리한다.<br>
 * 주어진 함수에서 return false를 하면 반복이 멈춘다.
 * @param {Object} object 대상 object.
 * @param {Function} func callback 함수. 
 * @param {String} func.prop object property name.
 * @param {Object} func.val object property value.
 * @param {Object} func.object object 그 자체.
 * @param {Object} scope callback 함수에 대한 수행 scope.
 * @example
 * var datas = {code: "001", userId: "", name: "pete"};
 * this.gfnEach(datas, function(prop, val, object) {
 * 	var result = "";
 * 	if ( !val )
 * 	{
 * 		result = prop + " must have not a non-empty value!"
 * 		st_result03.text += result;
 * 		trace(result);	// output : userId must have not a non-empty value!
 * 		return false;
 * 	}
 * 	result = prop + ":" + val;
 * 	st_result03.text += result + "  ";
 * 	trace(result);	// output : code:001
 * }, this);
*/
pForm.gfnEach = function(object, func, scope)
{
	var p,
		scope = scope || object;
	for (p in object) {
		if (object.hasOwnProperty(p)) {
			if (func.call(scope, p, object[p], object) === false) {
				return;
			}
		}
	}
};

/**
 * @class 주어진 Form 을 포함하는 최상위 Form을 찾는다.
 * @param  {Object} curForm 검색 시작 Form.
 * @return {Object} 최상위 Form.
 * @example
 * trace(this.gfnGetTopLevelForm(this));	// output : [object Form]
*/		
pForm.gfnGetTopLevelForm = function(curForm)
{
	var p = curForm;
	while (p && !(p instanceof ChildFrame)) {
		p = p.parent;
	}
	return p.form;
};


/**
 * @class 검색어를 코드명, 코드 우선순위로 정제한다. [코드] 코드명
 * @param {String} sValue	
 * @return {Boolean} true/false
 */
pForm.gfnRefineSrchVal = function(sSrchVal) {
	if (!this.gfnIsNull(sSrchVal)) {
		var arrSrchVal = sSrchVal.split("]");
		var nIdx = sSrchVal.indexOf("[");
		if (arrSrchVal.length == 2) {
			var sSrchVal1 = nexacro.trim(arrSrchVal[1]);
			if (!this.gfnIsNull(sSrchVal1)) {
				sSrchVal = sSrchVal1;
			} else {
				var sSrchVal0 = nexacro.trim(arrSrchVal[0]);
				if (nIdx > -1) {
					sSrchVal = sSrchVal0.substr(nIdx + 1);
				} else {
					sSrchVal = sSrchVal0;
				}
			}
		} else if (nIdx > -1) {
			sSrchVal = sSrchVal.substr(nIdx + 1);
		}
	}
	return sSrchVal;
}

/**
 * @class Div하위에 있는 Component들에 대해 Enable,ReadOnly=true/false
 * @param {boolean} bTF        : Component들에 대해 Enable,ReadOnly=true/false
 * @param {boolean} bCompTFprop : true  - Component.userData.compTFprop = ENABLE 또는 READONLY 존재 하는 경우만 처리
 *                                false - 모든 Component대상
 * @param {boolean} bComTFexcept : true  - Component.userData.comTFexcept = true : 인 경우에는 안함 true/false할 때 제외(안함)
 *                                 false - 모든 Component대상
 */ 
pForm.gfnEnableComponent = function(objDiv, bTF, bCompTFprop, bComTFexcept)
{
	var arrComp = objDiv.form.components;
	var nLength = arrComp.length;
	
	for(var i=0; i<nLength; i++)
	{
		var sProp   = arrComp[i].compTFprop;  //속성이 존재 하는 컬럼들만 처리
		var sExcept = arrComp[i].comTFexcept;
		
		if (arrComp[i] instanceof nexacro.Div){
			if (bComTFexcept == true && sExcept == "true") continue;
			var divUrl = arrComp[i].url;
			if (this.gfnIsNotNull(divUrl))
			{
				arrComp[i].set_enable(bTF);
				continue; //url이 존재 시 하위 form은 안함
			}
			
			this.gfnEnableComponent(arrComp[i], bTF, bCompTFprop, bComTFexcept)
			continue;
		}
		
		if (bCompTFprop == true)
		{
			if (this.gfnIsNull(sProp)) continue;
			if (bComTFexcept == true && sExcept == "true") continue;

			sProp = sProp.toUpperCase()
			if      (sProp == "ENABLE")   arrComp[i].set_enable(bTF);
			else if (sProp == "READONLY") arrComp[i].set_readonly(!bTF);
		}
		else
		{
			if (bComTFexcept == true)
			{
				var sExcept = arrComp[i].comTFexcept;  //속성이 존재 하는 컬럼들만 처리
				if (sExcept == "true") continue;
			}
			
 			if      (arrComp[i] instanceof nexacro.Edit)     arrComp[i].set_readonly(!bTF);
 			else if (arrComp[i] instanceof nexacro.TextArea) arrComp[i].set_readonly(!bTF);
			else if (arrComp[i] instanceof nexacro.MaskEdit) arrComp[i].set_readonly(!bTF);
 			else if (arrComp[i] instanceof nexacro.CheckBox) arrComp[i].set_readonly(!bTF);
 			else if (arrComp[i] instanceof nexacro.Combo)    arrComp[i].set_readonly(!bTF);
			else if (arrComp[i] instanceof nexacro.Radio)    arrComp[i].set_readonly(!bTF);
			else if (arrComp[i] instanceof nexacro.Calendar) arrComp[i].set_readonly(!bTF);
			else if (arrComp[i] instanceof nexacro.Button)   arrComp[i].set_enable(bTF);
            else if (arrComp[i] instanceof nexacro.Grid)     arrComp[i].set_readonly(!bTF);
		}
	}
};

/**
 * @class Div하위에 있는 Component들에 대해 작업가능여부 Setting
 *              작업가능할 때만 Component.userData.compTFprop = READONLY 또는 ENABLE 값을 넣음.
 *              enable=false 또는 readonly=true인 component 들은 Component.userData.compTFprop = '' 임 (즉 Setting안함)
 *                (이유, 차후 enable=true, readonly=false를 안해야 되기 때문)
 * @개발이유 화면에서 특정시점에 각 컴포넌트들에 대해서 작업가능한상태의 컴포넌트인지의 상태를 보존 후
 *            this.gfnEnableComponent() 함수를 호출하여 component들을 false처리 하고
 *            다시 위에서 보존하고 있던 상태대로 원복 하기 위해서임
 * @param {Object} objDiv - 작업할 div
 * @호출예 this.gfnSetCompTFprop (this.div_middle);   //컴포넌트 속성 보존
 *          this.gfnEnableComponent(this.div_middle, false, true); //컴포넌트 속성 작업불가 처리
 *          this.gfnEnableComponent(this.div_middle, true, true);  //컴포넌트 속성 보존된 기준으로 원복
 */ 
pForm.gfnSetCompTFprop = function(objDiv)
{
    var arrComp = objDiv.form.components;
    var nLength = arrComp.length;
    
    for(var i=0; i<nLength; i++)
    {
		 //div는 recursive
         if (arrComp[i] instanceof nexacro.Div){
             this.gfnSetCompTFprop(arrComp[i]);
			 continue;
         }
	
         var enable   = arrComp[i].enable;
         var readonly = arrComp[i].readonly;

        //작업가능
         if      (enable == true && readonly == false){
            if      (arrComp[i] instanceof nexacro.Edit)     arrComp[i].compTFprop = "READONLY";
            else if (arrComp[i] instanceof nexacro.TextArea) arrComp[i].compTFprop = "READONLY";
            else if (arrComp[i] instanceof nexacro.MaskEdit) arrComp[i].compTFprop = "READONLY";
            else if (arrComp[i] instanceof nexacro.CheckBox) arrComp[i].compTFprop = "READONLY";
            else if (arrComp[i] instanceof nexacro.Combo)    arrComp[i].compTFprop = "READONLY";
            else if (arrComp[i] instanceof nexacro.Radio)    arrComp[i].compTFprop = "READONLY";
            else if (arrComp[i] instanceof nexacro.Calendar) arrComp[i].compTFprop = "READONLY";
			else if (arrComp[i] instanceof nexacro.Grid)     arrComp[i].compTFprop = "READONLY";

        //readnonly
        }else if (enable == true && readonly == true){
            //arrComp[i].compTFprop = "READONLY";
            
        //enable
        }else if (enable == false){
            //arrComp[i].compTFprop = "ENABLE";
			
        }else if (enable == true && this.gfnIsNull(readonly)){
            if (arrComp[i] instanceof nexacro.Button)   arrComp[i].compTFprop = "ENABLE";
        }else{
            //skip : 이 컴포넌트들은 거의 line, static등임
        }
    }
}



/**
 * @class  넥사크로 Component 관련 대체함수
 * @param  {object} 변환할 object 
 * @return
 * @exam
 */
pForm.gfnGetType = function(XobjTypeID)
{
	if(!this.gfnIsNull(XobjTypeID))
	{
		return XobjTypeID.toString().replace("object", "").replace("[", "").replace("]", "").trim();
	}
	return "";
}

/** bind, binditem object
* @class  컴포넌트에 연결된 dataset object 얻기
* @param  {object} objComp - 작업 component
* @return 컴포넌트에 연결된 dataset
* @exam
*/
pForm.gfnGetBindDataset = function(objComp)
{
	var objBindList = this.binds;

	for(var i=0; i<objBindList.length;i++)
	{
		if (objComp.id == objBindList[i].compid)
		{
			var objDs  = this.objects[objBindList[i].datasetid];

			if ( !(objDs instanceof nexacro.NormalDataset) )
			{
				var objDs = this.gfnGetParentDataset(this, objBindList[i].datasetid);
				return objDs;
 			}
			return null;
		}
	}
	return null;
}


/** edit component
* @class edit component에서 maxlength size만큼만 문자열 입력가능
*        edit.oninput event에서만 호출 가능
*        dataset.oncolumnchanged event가 발생하지 않을 수있음
* @param {object} obj : nexacro.Edit
* @param {object} e   : nexacro.InputEventInfo
* @exam  this._fn_edt_codeCd_oninput = function(obj:nexacro.Edit,e:nexacro.InputEventInfo)
		 {	this.gfnSetMaxlengthEdit(obj, e); }
*/
pForm.gfnSetMaxlengthEdit = function(obj, e)
{
	var maxLength = obj.maxlength;
	var val = obj.value;
	if (e.eventid != "oninput")                       return val;
	if (maxLength == 0 || this.gfnIsNull(maxLength)) return val;
	if (this.gfnIsNull(val))                         return "";
	
	var objDs = this.gfnGetBindDataset(obj);
	var byteLength = 0;
	var str = "";
	var newVal = this.gfnSubstrByte(val, maxLength);
	if (val != newVal)
	{
		if (objDs instanceof nexacro.NormalDataset)	objDs.set_enableevent(false);
		obj.set_value(newVal);
		//objDs.setColumn(0, "cd", newVal);  //dataset에 직접넣는 방식은 .. 한글일때 적용이 안됨
		if (objDs instanceof nexacro.NormalDataset)	objDs.set_enableevent(true);
	}
};

/**
* @class 글자에 대한 Static기준 size(width)얻기
* @param {string}  val  - 문자열
* @param {font}    font - 문자열에 적용될(된) font (예, 'normal 700 15pt/normal "Gulim"')
* @param {string}  type - width, height, both (둘다)
* @exam  var oStaSize = this.gfnTextSize(this.sta00.text, 'normal 12px/normal "Malgun Gothic"', "both", "STATIC");
*/
/**
* @class 글자에 대한 Static기준 size(width)얻기
* @param {string}  val  - 문자열
* @param {font}    font - 문자열에 적용될(된) font (예, 'normal 700 15pt/normal "Gulim"')
* @param {string}  type - width, height, both (둘다)
* @exam  var oStaSize = this.gfnTextSize(this.sta00.text, 'normal 12px/normal "Malgun Gothic"', "both", "STATIC");
*/
pForm.gfnTextSize = function(val, font, type, compKind)
{
	var width;
	var height;
	
// 	if (this.gfnIsExist(font)) {
// 		width  = nexacro.getTextSize(val, font).nx;
// 		height = nexacro.getTextSize(val, font).ny;
// 	} else {
		var objNew;
		if (compKind.toUpperCase() == "BUTTON") {
			objNew = new nexacro.Button();
		} else if (compKind.toUpperCase() == "EDIT") {
			objNew = new nexacro.Edit();
		} else {
			objNew = new nexacro.Static();
		}
		objNew.init( "objNew", 0, 0, 0, 0);
		this.addChild("objNew", objNew); 
		objNew.set_text(val);
		objNew.set_font(font);
		objNew.set_fittocontents("both");
		objNew.set_visible(false);
		objNew.show(); 
		
		var width = 0, height = 0;
		
		width = objNew.getOffsetWidth();
		height = objNew.getPixelHeight();
		
		this.removeChild("objNew"); 
		objNew.destroy(); 
	//}
	if (this.gfnIsNull(type) || type == "width") {
		return width;
	} else if (type == "height") {
		return height;
	} else if (type == "both") {
		return {'width':width, 'height':height}
	}
}


/**
*  @FileName 	Transaction.xfdl
*/

var pForm = nexacro.Form.prototype;

// 세션 만료 체크 제외 (FrameTop의 timer로 설정된 service)
//pForm.SESS_TIMEOUT_EXCLUDES = ['SYHM0010Service.appLoad', 'SYHM0090Service.alarmInfo', 'CMMD0040Service.emgcNotiList', 'CMMD0040Service.sessCheck'];  // 세션 Timeout exclude service

/******************************************************************************************************
* @class 서비스 호출 공통함수 <br>
* Dataset의 값을 갱신하기 위한 서비스를 호출하고, 트랜젝션이 완료되면 콜백함수을 수행하는 함수
* @param {String} sSvcId - 서비스 ID
* @param {String} sService - 서비스 호출 Service (Bean) 명 
* @param {String} sMethod - 서비스 호출 Method 명
* @param {String} [sInDs]	- input Dataset list("입력ID=DataSet ID" 형식으로 설정하며 빈칸으로 구분)
* @param {String} [sOutDs] - output Dataset list("DataSet ID=출력ID" 형식으로 설정하며 빈칸으로 구분)
* @param {String} [sArgs]	- 서비스 호출시 Agrgument
* @param {String} [sCallback] - Callback 함수명  (none으로 넘길 경우 callback 함수 수행안해도 됨)
* @param {Boolean} [bAsync] - 비동기통신 여부 (true : (default) 비동기, false : 동기)
* @param {Boolean} [bErrMute] - Error 오류 처리 무시 (true : 처리 무시, false : (default) 처리)
* @param {Boolean} [bLoadingImg] - 로딩 이미지 여부 (true : (default) 보임, false : 숨김)
* @return N/A
* @example
* var strSvcUrl = "transactionSaveTest.do";
* var inData    = "dsList=dsList:U";
* var outData   = "dsList=dsList";
* var arg       = "";
* this.gfnTransaction("save", strSvcUrl, inData, outData, arg, "fn_callback", true);
*****************************************************************************************************/ 
//pForm.gfnTransaction = function(sSvcId, sService, sMethod, sInDs, sOutDs, sArgs, sCallback, bAsync, bErrMute, bLoadingImg)
pForm.gfnTransaction = function(sSvcId, sService, sInDs, sOutDs, sArgs, sCallback, bAsync, bErrMute, bLoadingImg)
{
	//1. default값 설정 (callback, Async, bErrMute, bLoadingImg)
	sCallback   = this.gfnIsNull(sCallback)   ? "fnCallback" : (sCallback == "none" ? "" : sCallback);
	bAsync      = this.gfnIsTF(bAsync)        ? bAsync        : true;
	bErrMute    = this.gfnIsTF(bErrMute)      ? bErrMute      : false;
	bLoadingImg = this.gfnIsNull(bLoadingImg) ? true          : bLoadingImg;
	
	//2. transaction 처리 시간 trace용
	var dStartDate = new Date();
	var sStartTime = dStartDate.getTime();
	
	//3. callback에서 처리할 서비스 정보 저장
	var objSvcId = { 
		svcId      : sSvcId
	  , svcUrl     : sService
	  , callback   : sCallback
	  , startTime  : sStartTime
	  , errMute    : bErrMute
	  , loadingImg : bLoadingImg
	};
	
	//trace("menuId ->" + this.menuId);
	//trace("pgmUrl ->" + this.pgmUrl);

	// 2. strServiceUrl
	var sSvcUrl = "svcUrl::" + sService;

	// 4. dataset 통신 방식
	var nDataType;
	if (this.gfnIsEqual(pForm.gfnGetEnvVar("evSvcType"), "dev", "prod")) {
		nDataType = 2;  //2:xml   //nexacro.setHTTPHeaderVariable("FNC-Content-Type", "PlatformSsv");
	} else {
		nDataType = 0;  //0:ssv   // nexacro.setHTTPHeaderVariable("FNC-Content-Type", "PlatformXml");
	}
	
	// Loading 이미지 여부
	if (bLoadingImg == false) {
		nexacro.getEnvironment().set_usewaitcursor(false);
	} else {
		nexacro.getEnvironment().set_usewaitcursor(true);  //2022.09.28 일에 추가.  TO.DO 차후 잘 되는지 확인 필요
	}
	
	// 화면 xfdl id를 서버에 넘기기
	sArgs = (this.gfnIsNull(sArgs) ? "" : sArgs) + " pgmId=" + nexacro.wrapQuote(this.name);
	// 세션 Timeout 설정
	//if (pForm.SESS_TIMEOUT_EXCLUDES.indexOf(sService + '.' + sMethod) < 0) {
	//	nexacro.getApplication().gv_sessTime = 0;
	//}
	
	//this.lookupFunc(sCallback).call(sSvcId, 0, null);
	
	//타이머 연장 (frame이 구성되기 전에 호출 될수도 있어서 try~catch 문장 필요)
	try{
		this.gfnGetFrameTop().form.fnSetExtentionTimer();
	}catch(e){};
	
// sSvcUrl = "http://localhost:8080/cim/select_emp.jsp";
 //trace('transaction->' + sSvcUrl);
	this.transaction(JSON.stringify(objSvcId) //1.svcId
					, sSvcUrl             	  //2.strSvcUrl
					, sInDs                   //3.inDataSet
					, sOutDs                  //4.outDataSet
					, sArgs             	  //5.arguments
					, "gfnCallback"		      //6.sCallback
					, bAsync                  //7.bAsync
					, nDataType               //8.nDataType : 0(XML 타입), 1((Binary 타입),  2(SSV 타입) --> HTML5에서는 Binary 타입은 지원안함
					, false);                 //9.bCompress ( default : false ) 
};

/**
* @class 공통 Callback 함수 <br>
*        이 함수가 먼저 수행되고 사용자지정Callback함수가 수행된다.
* @param {String} svcID - 서비스 ID
* @param {Number} errorCode - 에러코드(정상 0, 에러 음수값)
* @param {String} [errorMsg] - 에러메시지
* @return N/A
*/
pForm.gfnCallback = function(svcId, errCd, errMsg)
{
	var objSvcId = JSON.parse(svcId);
	
	// loadingImg 처리
	if (objSvcId.loadingImg == false) {
		nexacro.getEnvironment().set_usewaitcursor(true);
	}
	
	// 서비스 실행결과 출력
	var dEndDate = new Date();
	var nElapseTime = (dEndDate.getTime() - objSvcId.startTime) / 1000;
	this.gfnLog("[gfnCallback] SvcId >> " + objSvcId.svcId + ", ElapseTime >> " + nElapseTime + ", ErrCd >> " + errCd + ", ErrMsg >> " + errMsg);

	// server validation error
	//-101 정합성체크 오류(VALIDATION)
	//-102 권한오류(CRUD,엑셀,배치)
	//-103 db오류(Duplicate, SqlException 등)
	//-999 그외 오류(NULL Pointer Exception, IOException 등)
	if (errCd == -101 || errCd == -102 || errCd == -103 || errCd == -999) {
		this.gfnErrorServer(errCd, errMsg, objSvcId.errMute, objSvcId);
		return;
	}
	// 에러 공통 처리
	else if (errCd != 0) {
		this.gfnAlertMsg(errMsg);
		//var ret = this.gfnCommSetError(errCd, errMsg, objSvcId.errMute, objSvcId);
		//if (ret== false) return;
		return;
	}
	
	// (errCd == 0) form에 callback 함수가 있을때
	if (this[objSvcId.callback]) {
        this.lookupFunc(objSvcId.callback).call(objSvcId.svcId, errCd, errMsg);
    }
};

/**
* @class server validation error
* @param {String}  errCd    - 서버 error code
* @param {String}  errMsg   - 서버 message
* @param {bollean} errMute  - error mute
* @param {object}  objSvcId - transaction호출 시 기본정보
* errMsg : NX1322|userName|0|20|false|Han|사용자명   (NX1322:{0}은(는) 유효하지 않은 형식입니다.)
*/ 
pForm.gfnErrorServer = function(errCd, errMsg, errMute, objSvcId) 
{
// 	NX1322|userName|0|20|false|Han|사용자명
// 	NX1322|사용자명
// 	NX1322|사용자명|asdf
// 	NX1322|사용자명|asdf|sdf
	
	var aErrMsg  = errMsg.split("|");
	var aArg = [];
	
	for(var i=1; i<aErrMsg.length; i++)
	{
		aArg[i-1] = aErrMsg[i];
	//trace(i-0 + " == " + aArg[i-0] + " === " + aErrMsg[i]);
	}
//trace("== last === " + aArg.length + " :: " + aArg.toString());
//return;	
	
// 	if (errCd == -101) {
// 		aArg[0] = aErrMsg[6];
// 	} else {
// 		aArg[0] = aErrMsg[1];
// 	} 
	this.gfnAlert(aErrMsg[0], aArg);
	
	

	//var objDsMsg = this.gfnGetGdsMsgSys();
	//var row      = objDsMsg.findRow("msgId", aErrMsg[0]);
	//var msgNm    = objDsMsg.getColumn(row, "msgNm");
	//message명칭에서 arg 갯수 구하기
	//var argCnt1 = ( (msgNm.match(/{/g)).length);  //{ 갯수
	//var argCnt2 = ( (msgNm.match(/}/g)).length);  //} 갯수
	//var argCnt  = (argCnt1 <= argCnt2 ? argCnt1 : argCnt2);
	//switch(argCnt) {
	//	case 0:
	//		aArg = "";
	//		break;
	//	case 1: aArg[0] = aErrMsg[6]; break;
	//	default:
	//		alert("메시지 확인 필요. nexa 공통담당자에게 문의-argCnt=" + argCnt);
	//		return;
	//		break;
	//}
	//this.gfnAlert(aErrMsg[0], aArg);
}


/**
* @class server callback error 발생시 처리
* @param {String}  errCd    - 서버 error code
* @param {String}  errMsg   - 서버 message
* @param {bollean} errMute  - error mute
* @param {object}  objSvcId - transaction호출 시 기본정보
* @return N/A
*/
pForm.gfnCommSetError = function(errCd, errMsg, errMute, objSvcId, bFile)
{
	if (errCd == 0 || errCd == "0")		return true;
	if (this.gfnIsNull(errCd))			return true;
	if (this.gfnIsNull(errMute))		errMute = false;
	if (this.gfnIsNull(bFile))			bFile = false;
	
	var bCallback = true;
	
	//서버 validation error
	if (errCd == -1)
	{
		this.gfnCommBizError(errCd, errMsg, sBizCallback)
	}	
	
	var arrErr = errMsg.split("|");
	var bizErrCd = arrErr[0];
	var bizErrMsg;
	if (arrErr.length < 2) {
		bizErrMsg = errMsg;
	} else {
		bizErrMsg = arrErr[1];
	}
	

	
	
	//파일쪽 에러처리 추가
	if (bFile) {
		if (errCd == "9901") { 
			errCd = -2;
		} else { 
			errCd = -1;
		}
	}
	
	if (bizErrCd == "CM401") {			// 세션인증 오류
		// goLogin
		this.gfnAlert("MSG1000", [bizErrMsg], "goLogin", "gfnCommonMsgCallback");  //{0}
		bCallback = false;
	} else if (bizErrCd == "CM403") {	// 세션인가 오류
		this.gfnAlert("MSG1000", [bizErrMsg], "logout", "gfnCommonMsgCallback");  //{0}
		bCallback = false;
	} else {
		this.gfnAlertMsg(errMsg);
	}
	return bCallback;
};

/**
 * @함수설명  				공통코드 조회
 * @param {Number} errCd - 에러코드(정상 0, 에러 음수값)
 * @param {String} [errMsg] - 에러메시지
 * @param {String} [sBizCallback] - 업무오류callback
 * @return None
 */ 
pForm.gfnCommBizError = function(errCd, errMsg, sBizCallback) {
	var arrErr = errMsg.split("|");
	var bizErrCd = arrErr[0];
	var bizErrMsg;
	if (arrErr.length < 2) {
		bizErrMsg = errMsg;
	} else {
		bizErrMsg = arrErr[1];
	}

	if (errCd == -1) {					// 시스템오류
		this.gfnAlert("MSG1027");  //시스템 오류가 발생하였습니다.
	} else if (errCd == -2) {
		if (this.gfnIsNotNull(sBizCallback)) {	
			try {
				this.lookupFunc(sBizCallback).call(bizErrCd, bizErrMsg); 
			} catch(e) {
				this.gfnLog(sBizCallback + "() 함수 실행시 오류가 발생했습니다. \n" + errMsg);
			}
		} else {
			this.gfnAlert("MSG1000", [bizErrMsg]);
		}
	} else {
		this.gfnAlert("MSG1000", [bizErrMsg]);
	}
}

pForm._commCodeArg = null;
/**
* @class 공통코드 조회 (Grobal Dataset에서 filter용)
* @param arrComCodeArg 	조회할 공통코드 정보
* @return None
*/ 
pForm.gfnGetComCode = function(arrComCodeArg) 
{
	for(var i=0; i<arrComCodeArg.length; i++) {
		var objDs;
		var objCbo;
		if (arrComCodeArg[i]['obj'] instanceof nexacro.Dataset) {
			objDs = arrComCodeArg[i]['obj'];
		} else if (arrComCodeArg[i]['obj'] instanceof nexacro.Combo) {
			objDs = (arrComCodeArg[i]['obj']).getInnerDataset();
			objCbo = (arrComCodeArg[i]['obj']);
		} else {
			trace("개발오류, 공통코드는 Dataset or Combo 만 연동 가능합니다.-" + arrComCodeArg[i]['obj']);
			return;
		}
		
		objDs.clearData();
		var filter = "groupCd=='" + arrComCodeArg[i]['groupCd'] + "'";
		if (this.gfnIsExist(arrComCodeArg[i]['filter'])) {
			filter = "(" + filter + ") && (" + arrComCodeArg[i]['filter'] + ")";
		}
		
		this.gfnGetGdsCode().set_filterstr(filter);
		for(var jj=0; jj<this.gfnGetGdsCode().rowcount; jj++) {
			objDs.addRow();
			objDs.copyRow(jj, this.gfnGetGdsCode(), jj);
		}
		
		if (this.gfnIsExist(arrComCodeArg[i]['firstcd']) || this.gfnIsExist(arrComCodeArg[i]['firstnm'])) {
			objDs.insertRow(0);
			objDs.setColumn(0, "codeCd", arrComCodeArg[i]['firstcd']);
			objDs.setColumn(0, "codeNm", arrComCodeArg[i]['firstnm']);
		}
		
		//콤보값을 넘긴 경우 0번째 인덱스 설정
		if(this.gfnIsExist(objCbo) && this.gfnIsExist(arrComCodeArg[i]['firstnm'])) {
			objCbo.set_index(0);
		}		
	}
	this.gfnGetGdsCode().set_filterstr("1==1");
}

/**
* @class 공통코드 조회 (Transaction호출용)
* @param arrComCodeArg 	조회할 공통코드 정보
* @param isAsync		싱크여부(디폴트 : ansync)
* @return None
*/ 
pForm.gfnSearchCommonCode = function(arrComCodeArg, callBackNm, callId, isAsync) 
{
	var arrGroupCd = new Array();
	this._commCodeArg = null;
	
	var objApp = pForm.gfnGetApplication();
	var objDs = objApp.gdsTemp;
	
	// 파라미터값 조회
	this._commCodeArg = arrComCodeArg;
	
	for(var i=0; i<arrComCodeArg.length; i++) {
		arrGroupCd.push(arrComCodeArg[i].groupCd);
	}
	objDs.clear();
	objDs.addColumn("groupCd");
	objDs.addRow();
	objDs.setColumn(0, "groupCd", arrGroupCd.toString());
	
	// 파라미터값 조회
	this._commCodeArg = arrComCodeArg;
	
	//===========================================================================
	
	var svcId    = "gfnSearchCommonCode";
	var service  = "/sys/cmmCode/selectCmmCodeAllList.cb";
	var inDs     = "dsSearch=gdsTemp";
	var outDs    = "gdsTemp=dsCode";
	var callBack = "gfnCommonCallback";

	if(this.gfnIsExist(callBackNm)) svcId = svcId + "^" + callBackNm + "^" + callId;
	
	this.gfnTransaction(svcId, service, inDs, outDs, "", callBack);
}

pForm.gfnCommonCallback = function(svcID,errorCode,errorMsg) 
{
	if (errorCode < 0) {
		var ret = pForm.gfnCommSetError(errorCode, errorMsg);
		if (ret == false) {
			return;
		}
	}
	
	var arrSvc =  svcID.split("^");
	if (arrSvc[0] == "gfnSearchCommonCode") {
		var callBackNm = arrSvc[1];
		var callId     = arrSvc[2];
		
		for(var i=0; i<this._commCodeArg.length; i++) {
			pForm.gfnGetCommonCode(pForm.gfnGetApplication().gdsTemp,this._commCodeArg[i]);
		}
		
		this._commCodeArg = null;
		
		// form에 callback 함수가 있을때
		if (this[callBackNm]) {
			this.lookupFunc(callBackNm).call(callId, errorCode, errorMsg);
		}
	}
};

pForm.gfnGetCommonCode = function(objDsComm, oCommArg) 
{
	var objDs;		// 대상 데이터셋
	var objCbo;		// 대상 콤보
	
	var obj = oCommArg.obj
	
	if( obj instanceof nexacro.Combo ){		//obj 가 콤보일경우
		objDs = obj.getInnerDataset();
		objCbo = obj;
	} else if( obj instanceof Dataset){		//obj 가 데이터셋일경우
		objDs = obj;
		objCbo = null;
	}
	
	if( objDs == null ) {	
		this.gfnLog("gfnGetCommonCode :  [Dataset]이 Null 입니다. ","error");
		return;
	}
	
	objDsComm.set_enableevent(false);
	objDs.set_enableevent(false);
   	var strFilter = "groupCd==" + nexacro.wrapQuote(oCommArg.groupCd);

   	//FIlter조건 추가
    if(this.gfnIsExist(oCommArg.filter)) {
     	strFilter = strFilter + " && " + oCommArg.filter;
    }
	
	objDsComm.filter(strFilter);
	objDs.copyData(objDsComm, true);

	// first set 세팅
	if(this.gfnIsExist(oCommArg.firstnm)) {
		var setFirstCd = (this.gfnIsNull(oCommArg.firstcd) ? "" : oCommArg.firstcd);
		var setFirstnm = (oCommArg.firstnm == "A" ? "전체" : (oCommArg.firstnm == "S" ? "선택" : ""));
		objDs.insertRow(0);
		objDs.setColumn(0, "codeCd", setFirstCd);
		objDs.setColumn(0, "codeNm", setFirstnm);
		
		//try{
		//	objDs.setColumn(0, "useYn", "Y");
		//} catch (e) {}
	}
	
	objDsComm.filter("");
	objDs.set_enableevent(true);
	objDsComm.set_enableevent(true);
	
	//콤보값을 넘긴 경우 0번째 인덱스 설정
	if(this.gfnIsExist(objCbo) && this.gfnIsExist(oCommArg.firstnm)) {
		objCbo.set_index(0);
		//objCbo.set_value("");
	}
};

/**
 * 오늘날짜 구하는 함수.
 * @return date
 */
pForm.gfnTranToday = function(objDs)
{
	//TODO : system 일자 조회 필요
// 	if(this.gfnIsNull(objDs))	objDs = this.gfnGetApplication().gdsTemp;
// 	
// 	objDs.clear();
// 	
// 	// 오늘날짜 조회
// 	var svcId	= "gfnTranToday";
// 	var service	= "CMMD0020Service";
// 	var method	= "serverTime";
// 	var inDs 	= "";
// 	var outDs 	= objDs.name + "=gds_serverTime";
// 	var args 	= "";
// 	var callBackFnc = "gfnCommonCallback";
// 	
// 	this.gfnTransaction(svcId, service, method, inDs, outDs, args, callBackFnc, false);
}



/**
 * 마이메뉴 저장
 */
pForm.gfnTranMyMenu = function(sPgmId,sFavoYn,sCallBackNm)
{
	var svcId	= "gfnTranMyMenu" + "^" + sPgmId + "^" + sFavoYn;
	var service	= "SYHM0060Service";
	var method	= "modifyFavPgm";
	var inDs 	= "";
	var outDs 	= "";
	var args 	= "pgmId=" 		+ nexacro.wrapQuote(this.gfnNvl(sPgmId,""));
		args 	+= " favoYn=" 	+ nexacro.wrapQuote(this.gfnNvl(sFavoYn,""));
	var callBackFnc = "gfnCommonCallback";
	
	if(!pForm.gfnIsNull(sCallBackNm))		svcId = svcId + "^" + sCallBackNm;
	
	this.gfnTransaction(svcId, service, method, inDs, outDs, args, callBackFnc, false);
};


pForm.gfnCommonMsgCallback = function(strId, strVal) {
	if (strId == "goLogin") {
		this.gfnGoLogin();
	} else if(strId == "logout") {
		this.gfnGetApplication().av_FrameTop.form.fn_logout();
	}
}

/**
 * 이미지 Base64 조회
 */
pForm.gfnGetImgBase64 = function(sFileUid, callbackNm) {
	if (!sFileUid) {
		return;
	}
	if (!callbackNm) {
		callbackNm = 'fn_callback';
	}

	if (!this.objects['gds_imgBase64']) {
		var gdsImgBase64 = new Dataset;
		gdsImgBase64.set_name('gds_imgBase64');
		gdsImgBase64.addColumn('SRC', 'BLOB');
		this.addChild("gds_imgBase64", gdsImgBase64); 
	}

	var svcId	= "gfnImgBase64^" + callbackNm;
	var service	= "CMMD0030Service";
	var method	= "imgBase64";
	var inDs	= "";
	var outDs	= "gds_imgBase64=ds_imgInfo";
	var args 	= "fileUid=" + nexacro.wrapQuote(sFileUid);
	
	this.gfnTransaction(svcId, service, method, inDs, outDs, args, 'gfnCommonCallback');
}

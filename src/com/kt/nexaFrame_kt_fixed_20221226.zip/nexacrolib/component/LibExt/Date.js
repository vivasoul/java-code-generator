/*
* Date.js : Date,Calendar Util
*/
var pForm = nexacro.Form.prototype;

/** 
* 1월, 당월 얻기
*/
pForm.gfnGetJanYm = function()  { return this.gfnGetYear() + "01"; }; 
pForm.gfnGetCurrYm = function() { return this.gfnGetToday().substr(0, 6); }; 

/**
*  당해 년도 얻기
*/
pForm.gfnGetYear = function()
{
	var ret = this.gfnGetDate(); //this.gfnGetServerTime();
	ret = ret.substr(0,4);
	return ret;
}

/**
*  @class millisend로 현재 시각 얻기
*/
pForm.gfnGetMilliSecond = function()
{
 	var dStartDate = new Date();
	return dStartDate.getTime();
}

/**
* @class 날짜 여부를 확인한다.(년월 or 년월일) <br>
* @param {String} strDate - 입력스트링(YYYYMM or YYYYMMDD)
* @return {Boolean}
*/
pForm.gfnIsYY = function(yy)
{
	if (this.gfnIsNull(yy) || yy.length != 4) return false;
	
	return this.gfnIsYY(yy + "0101");
}

/**
 * @class 날짜 여부를 확인한다.(년월 or 년월일) <br>
 * @param {String} strDate - 입력스트링(YYYYMM or YYYYMMDD)
 * @return {Boolean}
 */
pForm.gfnIsDate = function(strDate)
{
	if (this.gfnIsNull(strDate)) {
		return false;
	}
	
	var retVal;
	switch (strDate.length) {
		case 6: //년월
			retVal = this.gfnIsYM(strDate);
			break;
		case 8: //년월일
			retVal = this.gfnIsYMD(strDate);
			break;
		default:
			retVal = false; 
			break;
	}

	return retVal;
};

/**
 * @class 날짜 여부를 확인한다. <br>
 * @param {String} strDate - 8자리의 숫자로 된 날짜(YYYYMMDD)
 * @return {Boolean}
 */
pForm.gfnIsYMD = function(strDate)
{
	var retVal = this.gfnGetDigit(strDate);
	
	if (retVal.length != 8) {
		return false;
	}

	var strYM = strDate.substr(0, 6); // 년월
	if (!this.gfnIsYM(strYM)) {
		return false;
	}
	var nDay = Number(strDate.substr(6, 2)); // 일자
	var nLastDay = Number(this.gfnGetLastDate(strYM).substr(6, 2)); //gfnGetLastDay에서 전체 20170331값이 넘어와서 .substr(6,2)추가 20170313
	if (nDay < 1 || nDay > nLastDay) {
		return false;
	}
	return true;
};

/**
 * @class 날짜 시:분 여부를 확인한다. <br>
 * @param {String} strDateHm - 12자리의 숫자로 된 날짜(YYYYMMDDhhmm)
 * @return {Boolean}
 */
pForm.gfnIsYmdHm = function(strDateHm)
{
	if (this.gfnIsDigit(strDateHm) == false) return false;
	strDateHm = strDateHm.toString()
	if (strDateHm.length < 12)  	         return false;
	
	var ymd = strDateHm.substr(0,8);	//ymd
	if (this.gfnIsYMD(ymd) == false) return false;
	
	var hh = strDateHm.substr(9,2);	    //시간
	var mm = strDateHm.substr(11,2);	//분
	
	if((hh < 0 || hh > 23) || (mm < 0 || mm > 59)) {
		return false;
	} else {
		return true;
	}
};

/**
 * @class 날짜 여부를 확인한다. <br>
 * @param {String} strDate - 6자리의 숫자로 된 날짜(YYYYMM)
 * @return {Boolean}
 */
pForm.gfnIsYM = function(strDate)
{
	var valid = false;
	try {
		var regex = /^(\d{4})(\d{1,2})$/;
		var parts = regex.exec(strDate);
		if (parts) {
			var date = new Date(+parts[1], (+parts[2] - 1));
			if (date.getFullYear() == parts[1] && date.getMonth() == (+parts[2] - 1)) {
				valid = true;
			}
		}
	} catch (e) {
		trace('gfnIsYM error : ', e);
	}
	return valid;
};

/**
 * @class 시간 형식에 맞는지 Check 한다. <br>
 * @param {String} strTime - 6자리의 숫자로 된 내부시간형식(HHMMSS)
 * @return {Boolean}
 */
pForm.gfnIsTime = function(strTime)
{
	if (strTime.length != 6 || !isNumber(strTime)) {
		return false;
	}
	
	var t01 = Number(strTime.slice(0, 2));
	var t02 = Number(strTime.slice(2, 2));
	var t03 = Number(strTime.slice(4, 2));

	if ((t01 < 0 || t01 > 23) || (t02 < 0 || t02 > 59) || (t03 < 0 || t03 > 59)) {
		return false;
	} else {
		return true;
	}
};

/**
 * @class 현재일자를 구한다. <br>
 * @param {String} [sGubn] - date/null : 일자, time : 일자+시간, milli : Milliseconds
 * @return {String} 8자리 날짜(YYYYMMMDD)문자열
 */
pForm.gfnGetDate = function(sGubn) 
{
	if (this.gfnIsNull(sGubn)) {
		sGubn = "date";
	}
	var d = new Date();
	
	var s;
	
	if (sGubn == "date") {
		s = d.getFullYear()
			  + ((d.getMonth() + 1) + "").padLeft(2, "0")
			  + (d.getDate() + "").padLeft(2, "0");
	} else if (sGubn == "time") {
		s = d.getFullYear()
	      + ((d.getMonth() + 1) + "").padLeft(2, "0")
	      + (d.getDate() + "").padLeft(2, "0")
	      + (d.getHours() + "").padLeft(2, "0")
	      + (d.getMinutes() + "").padLeft(2, "0")
	      + (d.getSeconds() + "").padLeft(2, "0");
	} else if (sGubn == "milli") {
		s = d.getFullYear()
	      + ((d.getMonth() + 1) + "").padLeft(2, "0")
	      + (d.getDate() + "").padLeft(2, "0")
	      + (d.getHours() + "").padLeft(2, "0")
	      + (d.getMinutes() + "").padLeft(2, "0")
	      + (d.getSeconds() + "").padLeft(2, "0")
		  + (d.getMilliseconds() + "").padLeft(3, "0");
	}
	return (s);
};

/**
 * 오늘날짜 구하는 함수.
 * @return date
 */
pForm.gfnGetToday = function()
{
	//TODO : system 일자 조회 필요
	//var ret = this.gfnGetServerTime();
	var ret = this.gfnGetDate();
	
	ret = ret.substr(0,8);
	
	return ret;
}

/**
 * 현재시간 구하는 함수.
 * @return date
 */
pForm.gfnGetServerTime = function()
{
	var ret = "";
	var objDs = this.gfnGetApplication().gdsTemp;
	
	this.gfnTranToday(objDs);
					   
	if (objDs.rowcount > 0)
	{
		ret = objDs.getColumn(0,"SERVER_TIME");
	}
	else
	{
		this.gfnLog("날짜 조회에 실패했습니다.","error");
	}
	return ret;
}

/**
 * @class 년월을 입력받아 마지막 일를 반환한다(년월) <br>
 * @param {String} strDate - 6 / 8 자리의 숫자로 된 날짜(YYYYMM)
 * @return {String} 해당월의 마지막날 8자리
 */
pForm.gfnGetLastDate = function(strDate)
{
	var s = "";
    if (strDate == null) {
	    var date = (new Date()).addMonth(1);
    } else {
	    var date = new Date(parseInt(strDate.substr(0, 4)),parseInt(strDate.substr(4, 2)), 1);
    }

	date = (new Date(date)).addDate((new Date(date)).getDate() * -1);

	s = (new Date(date)).getFullYear()
	  + (((new Date(date)).getMonth() + 1) + "").padLeft(2, "0")
	  + ((new Date(date)).getDate() + "").padLeft(2, "0");

	return (s);
};

/**
 * @class 현재월 1일 만들기. <br>
 * @param {String} strDate - Date Format YYYYMM / YYYYMMDD
 * @return {String} date
 */
pForm.gfnGetFirstDate = function(strDate)
{
    var s = "";

    if (strDate == null) {
	    s = getToday().substr(0, 6) + "01";
    } else {
	    var date = new Date(parseInt(strDate.substr(0, 4)),parseInt(strDate.substr(4, 2)) - 1, 1);
	    s = (new Date(date)).getFullYear()
	      + (((new Date(date)).getMonth() + 1) + "").padLeft(2, "0")
	      + ((new Date(date)).getDate() + "").padLeft(2, "0");

    }
    
	return (s);
};

/**
 * @class 입력된 날자로부터 요일을 구함 <br>
 * @param {String} strDate - 'yyyyMMdd' 형태로 표현된 날짜.
 * @return {Number} 0 = 일요일 ~ 6 = 토요일. 오류가 발생할 경우 -1 Return.
 */
pForm.gfnGetDay = function(strDate)
{
    var date = new Date();

    var iYear = parseInt(strDate.substr(0, 4));
    var iMonth = parseInt(strDate.substr(4, 2) - 1);
    var iDate = parseInt(strDate.substr(6, 2));
    
	date.setFullYear(iYear, iMonth, iDate);
    return date.getDay();
};


/**
 * @class String 일시를 date로 변환 <br>
 * @param {String} strDate - 'yyyyMMddHHmmss' 형태로 표현된 날짜.
 */
pForm.gfnParseDate = function(strDate)
{
    var timeLen = strDate.length;
    var year = parseInt(strDate.substr(0, 4));
    var month = parseInt(strDate.substr(4, 2) - 1);
    var day = parseInt(strDate.substr(6, 2));
	var hour = 0;
	var minutes = 0;
	var seconds = 0;
	if (timeLen >= 10) {
		hour = parseInt(strDate.substr(8, 2));
	}
	if (timeLen >= 12) {
		minutes = parseInt(strDate.substr(10, 2));
	}
	if (timeLen >= 14) {
		seconds = parseInt(strDate.substr(12, 2));
	}
	var date = new Date(year, month, day, hour, minutes, seconds);
    return date;
};

/**
 * @class 두 일자간의 차이 일수 계산 <br>
 * @param {String} sStartDate - yyyyMMdd형태의 From 일자 ( 예 : "20121122" )
 * @param {String} sEndDate - yyyyMMdd형태의 To 일자   ( 예 : "20121202" )
 * @return {Number} 숫자 형태의 차이일수( 예 : 10 ) 단, sEndDate < sStartDate이면 음수가 return된다.
 */
pForm.gfnGetDiffDate = function(sStartDate, sEndDate)
{
    var vFromDate = new Date(parseInt(sEndDate.substring(0,4), 10), parseInt(sEndDate.substring(4, 6)-1, 10), parseInt(sEndDate.substring(6, 8), 10));
    var vToDate = new Date(parseInt(sStartDate.substring(0,4), 10), parseInt(sStartDate.substring(4, 6)-1, 10), parseInt(sStartDate.substring(6, 8), 10));
    
    return parseInt((vFromDate - vToDate) / (1000 * 60 * 60 * 24));
};

/**
* @class 두 일자간의 차이 일수 계산. 단, sStartDate, sEndDate의 일은 포함하지 않고 계산된다. <br>
* @param {String} sStartDate - yyyyMMdd형태의 From 일자 ( 예 : "20121122" )
* @param {String} sEndDate - yyyyMMdd형태의 To 일자   ( 예 : "20121202" )
* @return {Number} 숫자 형태의 차이월수 ( 예 : 10 ) 단, sEndDate < sStartDate이면 음수가 return된다.
*/
pForm.gfnGetDiffMonth = function(sStartDate, sEndDate)
{
	var nStartMon, nEndMon;
	
	nStartMon = parseInt(sStartDate.substr(0, 4), 10) * 12 + parseInt(sStartDate.substr(4, 2), 10);
	nEndMon = parseInt(sEndDate.substr(0, 4), 10) * 12 + parseInt(sEndDate.substr(4, 2), 10);
	
	return (nEndMon - nStartMon);
};

/**
* @class 입력된 날짜에 OffSet 으로 지정된 만큼의 날짜를 더함 <br>
* @param {String} strDate - 'yyyyMMdd' 형태로 표현된 날짜.
* @param {Number} nOffSet - 날짜로부터 증가 감소값.
* @return {String} date의 문자열 (ex. 20080821)
*/
pForm.gfnAddDate = function(strDate, nOffSet)
{
	var date = new Date();
	
    var iYear = parseInt(strDate.substr(0, 4));
    var iMonth = parseInt(strDate.substr(4, 2) - 1);
    var iDate = parseInt(strDate.substr(6, 2) - (nOffSet * -1));
    
	date.setFullYear(iYear,iMonth,iDate);	
	
	return this.gfnDateToStr(date);
};

/**
* @class 입력된 월에 OffSet 으로 지정된 만큼의 월을 더함 <br>
* @param {String} strDate - String Date Format
* @param {Number} OffSet - Integer Format
* @return {String} date
*/
pForm.gfnAddMonth = function(strDate, OffSet) 
{	
	var date, d, s, mon, val;

	/**
	 * @class 입력일자 해당월의 마지막 일 <br>
	 * @param {String} strMonth - 'yyyyMMdd' 형태로 표현된 날짜.
	 * @return {Number} 해당월의 마지막일자 2자리
	 */
	var gfnGetMonthLastDate = function(strMonth) {
		var iLastDay;
		var iYear = parseInt(strMonth.substr(0, 4), 10) ;
		var iMonth = parseInt(strMonth.substr(4, 2), 10);
		switch (iMonth) {
			case 2:
				if (((iYear%4)==0) && ((iYear%100)!=0) || ((iYear%400)==0)) {
					iLastDay = 29;
				} else {
					iLastDay = 28;			
				}
				break;
			case 4:
			case 6:
			case 9:
			case 11:
				iLastDay = 30;
				break;
			default:
				iLastDay = 31;
				break;
		}
		
		return iLastDay;
	};

    if (strDate) {
        date = this.gfnStrToDate(strDate);
        d = (new Date(date)).addMonth(OffSet);
    } else {
    	date = this.gfnStrToDate(this.gfnGetDate());
		d = (new Date(date)).addMonth(OffSet);
    }
    
    if (gfnGetMonthLastDate(strDate) == date.getDate()) {
    	var sY = new Date(d).getFullYear();
    	var sM = new Date(d).getMonth();
    	var eY = date.getFullYear();
    	var eM = date.getMonth();
    	
    	mon = -((eY - sY) * 12 + (eM - sM));
    	
    	if (mon != OffSet) {
   			val = OffSet - mon;
    		d = (new Date(d)).addMonth(-1);
    	}
    	
    	var ld = new Date((new Date(d)).getFullYear() 
    			, (new Date(d)).getMonth()
    			, gfnGetMonthLastDate(this.gfnDateToStr(new Date(d))));
    	
    	s = (new Date(ld)).getFullYear()
		   + (((new Date(ld)).getMonth() + 1) + "").padLeft(2, "0")
		   + (((new Date(ld)).getDate()) + "").padLeft(2, "0");
    } else {
    	s = (new Date(d)).getFullYear()
		   + (((new Date(d)).getMonth() + 1) + "").padLeft(2, "0")
		   + (((new Date(d)).getDate()) + "").padLeft(2, "0");
    }
	
	return (s);
};


/**
* @class 입력된 월에 OffSet 으로 지정된 만큼의 월을 더함 <br>
* @param {String} strDate - String Date Format
* @param {Number} OffSet - Integer Format
* @return {String} date
*/
pForm.gfnAddMonthYm = function(strMonth, offSet)
{
	var ym;
	
	if (strMonth.length == 8) {
		ym = this.gfnAddMonth(strMonth, offSet) ;
	} else if (strMonth.length == 6) {
		ym = this.gfnAddMonth(strMonth + "01", offSet) ;
	} else {
		return "";
	}
	return ym.substr(0, 6);
}

/**
 * @class 법정공휴일 구하기 <br>
 * @param {Number} nYear - yyyy
 * @return {Array} 휴일정보
 * @example : 
 */
pForm.gfnGetHolidays = function(nYear)
{
	var nYear;
	var aHoliday = new Array();

	/////// 음력 체크
	// 구정
	aHoliday[0] = this.gfnLunarToSolar((nYear-1) + "1230", false) + "설날";
	aHoliday[1] = this.gfnAddDate(aHoliday[0].substring(0, 8), 1) + "설날";
	aHoliday[2] = this.gfnAddDate(aHoliday[1].substring(0, 8), 1) + "설날";
	// 석가탄신일
	aHoliday[3] = this.gfnLunarToSolar(nYear + "0408", false) + "석가탄신일";
	// 추석
	aHoliday[4] = this.gfnLunarToSolar(nYear + "0814", false) + "추석";
	aHoliday[5] = this.gfnAddDate(aHoliday[4].substring(0, 8), 1) + "추석";
	aHoliday[6] = this.gfnAddDate(aHoliday[5].substring(0, 8), 1) + "추석";	

	/////// 양력 체크
	aHoliday[7] = nYear+"0101" + "신정";
	aHoliday[8] = nYear+"0301" + "삼일절";
	aHoliday[9] = nYear+"0505" + "어린이날";	
	aHoliday[10] = nYear+"0606" + "현충일";		
	aHoliday[11] = nYear+"0815" + "광복절";	
	aHoliday[12] = nYear +"1003" + "개천절";
	aHoliday[13] = nYear +"1009" + "한글날";
	aHoliday[14] = nYear+"1225" + "성탄절";			
	
	return aHoliday.sort();
};

/**
 * @class 양력을 음력으로 변환해주는 함수.<br>
 * [주의사항]<br>
 *  1. return값이 8자리가 아니고 9자리임에 주의<br>
 *  2. 처리가능 기간  1841 - 2043년
 * @param {String | Date} value - yyyyMMdd형태의 양력일자 ( 예 : "20121122" )
 * @return {String} Flag(평달 = "0", 윤달 = "1") + 'yyyyMMdd'형태의 음력일자
 * @example
 * var dt = this.gfnStr2Date("20130331");
 * var str = this.solarToLunar(dt);
 * trace(str); // output : 020130220
 * var str1 = "20130331";
 * var str = this.solarToLunar(str1);
 * trace(str); // output : 020130220
 */		
pForm.gfnSolarToLunar =  function(value) 
{
	var sMd         = "31,0,31,30,31,30,31,31,30,31,30,31";
	var arrMd       = [];
	var arrBaseInfo = [];
	var arrDt       = [];	// 매년의 음력일수를 저장할 배열 변수
	var nTd;		    			// 음력일을 계산하기 위해 양력일과의 차이를 저장할 변수
	var nTd1;			    		// 1840년까지의 날수
	var nTd2;				    	// 현재까지의 날수
	var nTemp;					    // 임시변수
	var nLy, nLm, nLd;			    // 계산된 음력 년, 월, 일을 저장할 변수
	var sLyoon;					    // 현재월이 윤달임을 표시

	var nY, nM, nD;

	nY = parseInt(value.substr(0, 4), 10);
	nM = parseInt(value.substr(4, 2), 10);
	nD = parseInt(value.substr(6, 2), 10);
	
	
	if (nY < 1841 || nY > 2043)	{
		return null;
	}

	arrBaseInfo = this.gfnSolarBase();
	arrMd = sMd.split(",");
	arrMd[1] = 28;
		
	//윤년여부 확인
	if ((nY % 4) == 0) {
		if ((nY % 100) != 0 || (nY % 400) == 0) { 
			arrMd[1] = 29;
		}
	} 

	// 672069 = 1840 * 365 + 1840/4 - 1840/100 + 1840/400 + 23  //1840년까지 날수
	nTd1 = 672069; 	 
		
	// 1841년부터 작년까지의 날수
	nTd2 = (nY - 1) * 365 + parseInt((nY - 1) / 4) - parseInt((nY - 1) / 100) + parseInt((nY - 1) / 400);
		
	// 전월까지의 날수를 더함
	for (var i = 0, s = (nM - 2); i <= s; i++) {
		nTd2 = nTd2 + parseInt(arrMd[i]);
	}

	// 현재일까지의 날수를 더함
	nTd2 = nTd2 + nD;

	// 양력현재일과 음력 1840년까지의 날수의 차이
	nTd = nTd2 - nTd1 + 1;
	
	// 1841년부터 음력날수를 계산
	for (var i = 0, s = (nY - 1841); i <= s; i++) {
		arrDt[i] = 0;
		for (var j = 0; j <= 11; j++) {
			switch (parseInt(arrBaseInfo[i * 12 + j])) {
				case 1:
					nTemp = 29;
					break;
				case 2:
					nTemp = 30;
					break;				
				case 3:
					nTemp = 58;	// 29 + 29
					break;				
				case 4:
					nTemp = 59;	// 29 + 30
					break;				
				case 5:
					nTemp = 59;	// 30 + 29
					break;				
				case 6:
					nTemp = 60;	// 30 + 30
					break;				
			}
			
			arrDt[i] = arrDt[i] + nTemp;
		}
	}
		
	// 1840년 이후의 년도를 계산 - 현재까지의 일수에서 위에서 계산된 1841년부터의 매년 음력일수를 빼가면수 년도를 계산
	nLy = 0;
	do {
		nTd = nTd - arrDt[nLy];
		nLy = nLy + 1;
	}
	while (nTd > arrDt[nLy]);
	
	nLm    = 0;
	sLyoon = "0";	// 현재월이 윤달임을 표시할 변수 - 기본값 평달
	do {

		if (parseInt(arrBaseInfo[nLy * 12 + nLm]) <= 2) {
			nTemp = parseInt(arrBaseInfo[nLy * 12 + nLm]) + 28;
			if (nTd > nTemp) {
				nTd = nTd - nTemp;
				nLm = nLm + 1;
			} else {
				break;
			}
		} else {
			switch (parseInt(arrBaseInfo[nLy * 12 + nLm])) {
				case 3:
					m1 = 29;
					m2 = 29;
					break;
				case 4: 
					m1 = 29;
					m2 = 30;
					break;					
				case 5: 
					m1 = 30;
					m2 = 29;
					break;					
				case 6: 
					m1 = 30;
					m2 = 30;
					break;					
			}

			if (nTd > m1) {
				nTd = nTd - m1;
				if (nTd > m2) {
					nTd = nTd - m2;
					nLm = nLm + 1;
				} else {
					sLyoon = "1";
				}
			} else {
				break;
			}
		}
	}
	while(1);
	
	nLy = nLy + 1841;
	nLm = nLm + 1;
	nLd = nTd;

	var sRtn = sLyoon + nLy; 
	sRtn = sRtn + nLm.toString().padLeft(2, "0"); 
	sRtn = sRtn + nLd.toString().padLeft(2, "0");    
	return sRtn;
};		

/**
 * @class 음력을 양력으로 변환. <br>
 * @param {String | Date} value - yyyyMMdd형태의 음력일자 ( 예 : "20121122" ).
 * @param {Boolean} leapMonth - 윤달 여부.
 * @return {String} 'yyyyMMdd'형태의 양력일자
 */
pForm.gfnLunarToSolar = function(value, leapMonth)
{

	var sMd         = "31,0,31,30,31,30,31,31,30,31,30,31";
	var arrMd       = [];	
	var arrBaseInfo = [];
	var nTd         = 0;
	var nSy, nSm, nSd;			    // 계산된 양력 년, 월, 일을 저장할 변수
	var nY1, nM1, nY2, nY3, nTemp;	// 임시변수	
	var nLeap;    
		
	var nLy, nLm, nLd;

	nLy = parseInt(value.substr(0, 4), 10);
	nLm = parseInt(value.substr(4, 2), 10);
	nLd = parseInt(value.substr(6, 2), 10);
	

	if (nLy < 1841 || nLy > 2043) {
		return null;
	}	

	arrBaseInfo = this.gfnSolarBase();
	arrMd = sMd.split(",");
	arrMd[1] = 28;
	
	//윤년여부 확인
	if ((nLy % 4) == 0) {
		if ((nLy % 100) != 0 || (nLy % 400) == 0) { 
			arrMd[1] = 29;
		}
	} 
		
	nY1   = nLy - 1841; //176
	nM1   = nLm - 1; //02
	nLeap = 0;
	
	if (parseInt(arrBaseInfo[nY1 * 12 + nM1]) > 2) {
		//윤년여부 확인
		if ((nLy % 4) == 0) {
			if ((nLy % 100) != 0 || (nLy % 400) == 0) { 
				nLeap = 1;
			}
		} 
	}
	if (nLeap == 1) {
		switch (parseInt(arrBaseInfo[nY1 * 12 + nM1])) {
			case 3:
				nTemp = 29;
				break;
			case 4:
				nTemp = 30;
				break;			
			case 5:
				nTemp = 29;
				break;			
			case 6:
				nTemp = 30;
				break;
		}
	} else {
		switch (parseInt(arrBaseInfo[nY1 * 12 + nM1])) {
			case 1:
				nTemp = 29;
				break;			
			case 2:
				nTemp = 30;
				break;			
			case 3:
				nTemp = 29;
				break;			
			case 4:
				nTemp = 29;
				break;			
			case 5:
				nTemp = 30;
				break;			
			case 6:
				nTemp = 30;
				break;			
		}
	}
	
	var tempY1 = nY1 - 1;
	for (var i = 0; i <= tempY1; i++) {
		for (var j = 0; j <= 11; j++) {
			switch (parseInt(arrBaseInfo[i * 12 + j])) {
				case 1:
					nTd = nTd + 29;
					break;
				case 2:
					nTd = nTd + 30;
					break;				
				case 3:
					nTd = nTd + 58;
					break;				
				case 4:
					nTd = nTd + 59;
					break;				
				case 5:
					nTd = nTd + 59;
					break;				
				case 6:
					nTd = nTd + 60;
					break;				
			}
		}
	}

	var tempM1 = nM1 - 1;
	for (var j = 0; j <= tempM1; j++) {
		switch (parseInt(arrBaseInfo[nY1 * 12 + j])) {
			case 1:
				nTd = nTd + 29;
				break;			
			case 2:
				nTd = nTd + 30;
				break;						
			case 3:
				nTd = nTd + 58;
				break;						
			case 4:
				nTd = nTd + 59;
				break;						
			case 5:
				nTd = nTd + 59;
				break;						
			case 6:
				nTd = nTd + 60;
				break;						
		}
	}

	if (nLeap == 1) {
		switch (parseInt(arrBaseInfo[nY1 * 12 + nM1])) {
			case 3:
				nTemp = 29;
				break;						
			case 4:
				nTemp = 29;
				break;						
			case 5:
				nTemp = 30;
				break;						
			case 6:
				nTemp = 30;
				break;						
		}
	}
	
	nTd = nTd + nLd + 22;
	
	if (leapMonth) {
		switch (parseInt(arrBaseInfo[nY1 * 12 + nM1])) {
			case 3:
				nTd = nTd + 29;
				break;						
			case 4:
				nTd = nTd + 30;
				break;						
			case 5:
				nTd = nTd + 29;
				break;						
			case 6:
				nTd = nTd + 30;
				break;						
		}
	}
	
	nY1 = 1840;
	do {
		nY1 = nY1 + 1;
		
		nLeap = 0;
		
		//윤년여부 확인
		if ((nY1 % 4) == 0) {
			if ((nY1 % 100) != 0 || (nY1 % 400) == 0) { 
				nLeap = 1;
			}
		} 

		if (nLeap == 1) {
			nY2 = 366;
		} else {
			nY2 = 365;
		}

		if (nTd <= nY2) {
			break;
		}
			
		nTd = nTd - nY2;
	}
	while(1);

	nSy = nY1;
	arrMd[1] = nY2 - 337;
	nM1 = 0;
	
	do {
		nM1 = nM1 + 1;
		if (nTd <= parseInt(arrMd[nM1-1])) {
			break;
		}
		nTd = nTd - parseInt(arrMd[nM1-1]);
	}
	while(1);
	
	nSm = nM1;
	nSd = nTd;
	nY3 = nSy;
	nTd = nY3 * 365 + parseInt(nY3 / 4) - parseInt(nY3 / 100) + parseInt(nY3 / 400);
	
	var tempSm = nSm - 1;
	for (var i = 0; i <= tempSm; i++) {
		nTd = nTd + parseInt(arrMd[i]);
	}

	nTd = nTd + nSd;

	var sRtn = nY3;
	sRtn = sRtn + nSm.toString().padLeft(2, "0"); 
	sRtn = sRtn + nSd.toString().padLeft(2, "0");    

	return sRtn;	
};

/**
 * @class 각 월별 음력 기준 정보 (처리가능 기간  1841 - 2043년) <br>
 * @return {String}
 */	 
pForm.gfnSolarBase = function ()
{
	var sBase;
			
	//1841
	sBase = "1,2,4,1,1,2,1,2,1,2,2,1,";
	sBase += "2,2,1,2,1,1,2,1,2,1,2,1,";
	sBase += "2,2,2,1,2,1,4,1,2,1,2,1,";
	sBase += "2,2,1,2,1,2,1,2,1,2,1,2,";
	sBase += "1,2,1,2,2,1,2,1,2,1,2,1,";
	sBase += "2,1,2,1,5,2,1,2,2,1,2,1,";
	sBase += "2,1,1,2,1,2,1,2,2,2,1,2,";
	sBase += "1,2,1,1,2,1,2,1,2,2,2,1,";
	sBase += "2,1,2,3,2,1,2,1,2,1,2,2,";
	sBase += "2,1,2,1,1,2,1,1,2,2,1,2,";
	//1851
	sBase += "2,2,1,2,1,1,2,1,2,1,5,2,";
	sBase += "2,1,2,2,1,1,2,1,2,1,1,2,";
	sBase += "2,1,2,2,1,2,1,2,1,2,1,2,";
	sBase += "1,2,1,2,1,2,5,2,1,2,1,2,";
	sBase += "1,1,2,1,2,2,1,2,2,1,2,1,";
	sBase += "2,1,1,2,1,2,1,2,2,2,1,2,";
	sBase += "1,2,1,1,5,2,1,2,1,2,2,2,";
	sBase += "1,2,1,1,2,1,1,2,2,1,2,2,";
	sBase += "2,1,2,1,1,2,1,1,2,1,2,2,";
	sBase += "2,1,6,1,1,2,1,1,2,1,2,2,";
	//1861
	sBase += "1,2,2,1,2,1,2,1,2,1,1,2,";
	sBase += "2,1,2,1,2,2,1,2,2,3,1,2,";
	sBase += "1,2,2,1,2,1,2,2,1,2,1,2,";
	sBase += "1,1,2,1,2,1,2,2,1,2,2,1,";
	sBase += "2,1,1,2,4,1,2,2,1,2,2,1,";
	sBase += "2,1,1,2,1,1,2,2,1,2,2,2,";
	sBase += "1,2,1,1,2,1,1,2,1,2,2,2,";
	sBase += "1,2,2,3,2,1,1,2,1,2,2,1,";
	sBase += "2,2,2,1,1,2,1,1,2,1,2,1,";
	sBase += "2,2,2,1,2,1,2,1,1,5,2,1,";
	//1871
	sBase += "2,2,1,2,2,1,2,1,2,1,1,2,";
	sBase += "1,2,1,2,2,1,2,1,2,2,1,2,";
	sBase += "1,1,2,1,2,4,2,1,2,2,1,2,";
	sBase += "1,1,2,1,2,1,2,1,2,2,2,1,";
	sBase += "2,1,1,2,1,1,2,1,2,2,2,1,";
	sBase += "2,2,1,1,5,1,2,1,2,2,1,2,";
	sBase += "2,2,1,1,2,1,1,2,1,2,1,2,";
	sBase += "2,2,1,2,1,2,1,1,2,1,2,1,";
	sBase += "2,2,4,2,1,2,1,1,2,1,2,1,";
	sBase += "2,1,2,2,1,2,2,1,2,1,1,2,";
	//1881
	sBase += "1,2,1,2,1,2,5,2,2,1,2,1,";
	sBase += "1,2,1,2,1,2,1,2,2,1,2,2,";
	sBase += "1,1,2,1,1,2,1,2,2,2,1,2,";
	sBase += "2,1,1,2,3,2,1,2,2,1,2,2,";
	sBase += "2,1,1,2,1,1,2,1,2,1,2,2,";
	sBase += "2,1,2,1,2,1,1,2,1,2,1,2,";
	sBase += "2,2,1,5,2,1,1,2,1,2,1,2,";
	sBase += "2,1,2,2,1,2,1,1,2,1,2,1,";
	sBase += "2,1,2,2,1,2,1,2,1,2,1,2,";
	sBase += "1,5,2,1,2,2,1,2,1,2,1,2,";
	//1891
	sBase += "1,2,1,2,1,2,1,2,2,1,2,2,";
	sBase += "1,1,2,1,1,5,2,2,1,2,2,2,";
	sBase += "1,1,2,1,1,2,1,2,1,2,2,2,";
	sBase += "1,2,1,2,1,1,2,1,2,1,2,2,";
	sBase += "2,1,2,1,5,1,2,1,2,1,2,1,";
	sBase += "2,2,2,1,2,1,1,2,1,2,1,2,";
	sBase += "1,2,2,1,2,1,2,1,2,1,2,1,";
	sBase += "2,1,5,2,2,1,2,1,2,1,2,1,";
	sBase += "2,1,2,1,2,1,2,2,1,2,1,2,";
	sBase += "1,2,1,1,2,1,2,5,2,2,1,2,";
	//1901
	sBase += "1,2,1,1,2,1,2,1,2,2,2,1,";
	sBase += "2,1,2,1,1,2,1,2,1,2,2,2,";
	sBase += "1,2,1,2,3,2,1,1,2,2,1,2,";
	sBase += "2,2,1,2,1,1,2,1,1,2,2,1,";
	sBase += "2,2,1,2,2,1,1,2,1,2,1,2,";
	sBase += "1,2,2,4,1,2,1,2,1,2,1,2,";
	sBase += "1,2,1,2,1,2,2,1,2,1,2,1,";
	sBase += "2,1,1,2,2,1,2,1,2,2,1,2,";
	sBase += "1,5,1,2,1,2,1,2,2,2,1,2,";
	sBase += "1,2,1,1,2,1,2,1,2,2,2,1,";
	//1911
	sBase += "2,1,2,1,1,5,1,2,2,1,2,2,";
	sBase += "2,1,2,1,1,2,1,1,2,2,1,2,";
	sBase += "2,2,1,2,1,1,2,1,1,2,1,2,";
	sBase += "2,2,1,2,5,1,2,1,2,1,1,2,";
	sBase += "2,1,2,2,1,2,1,2,1,2,1,2,";
	sBase += "1,2,1,2,1,2,2,1,2,1,2,1,";
	sBase += "2,3,2,1,2,2,1,2,2,1,2,1,";
	sBase += "2,1,1,2,1,2,1,2,2,2,1,2,";
	sBase += "1,2,1,1,2,1,5,2,2,1,2,2,";
	sBase += "1,2,1,1,2,1,1,2,2,1,2,2,";
	//1921
	sBase += "2,1,2,1,1,2,1,1,2,1,2,2,";
	sBase += "2,1,2,2,3,2,1,1,2,1,2,2,";
	sBase += "1,2,2,1,2,1,2,1,2,1,1,2,";
	sBase += "2,1,2,1,2,2,1,2,1,2,1,1,";
	sBase += "2,1,2,5,2,1,2,2,1,2,1,2,";
	sBase += "1,1,2,1,2,1,2,2,1,2,2,1,";
	sBase += "2,1,1,2,1,2,1,2,2,1,2,2,";
	sBase += "1,5,1,2,1,1,2,2,1,2,2,2,";
	sBase += "1,2,1,1,2,1,1,2,1,2,2,2,";
	sBase += "1,2,2,1,1,5,1,2,1,2,2,1,";
	//1931
	sBase += "2,2,2,1,1,2,1,1,2,1,2,1,";
	sBase += "2,2,2,1,2,1,2,1,1,2,1,2,";
	sBase += "1,2,2,1,6,1,2,1,2,1,1,2,";
	sBase += "1,2,1,2,2,1,2,2,1,2,1,2,";
	sBase += "1,1,2,1,2,1,2,2,1,2,2,1,";
	sBase += "2,1,4,1,2,1,2,1,2,2,2,1,";
	sBase += "2,1,1,2,1,1,2,1,2,2,2,1,";
	sBase += "2,2,1,1,2,1,4,1,2,2,1,2,";
	sBase += "2,2,1,1,2,1,1,2,1,2,1,2,";
	sBase += "2,2,1,2,1,2,1,1,2,1,2,1,";
	//1941
	sBase += "2,2,1,2,2,4,1,1,2,1,2,1,";
	sBase += "2,1,2,2,1,2,2,1,2,1,1,2,";
	sBase += "1,2,1,2,1,2,2,1,2,2,1,2,";
	sBase += "1,1,2,4,1,2,1,2,2,1,2,2,";
	sBase += "1,1,2,1,1,2,1,2,2,2,1,2,";
	sBase += "2,1,1,2,1,1,2,1,2,2,1,2,";
	sBase += "2,5,1,2,1,1,2,1,2,1,2,2,";
	sBase += "2,1,2,1,2,1,1,2,1,2,1,2,";
	sBase += "2,2,1,2,1,2,3,2,1,2,1,2,";
	sBase += "2,1,2,2,1,2,1,1,2,1,2,1,";
	//1951
	sBase += "2,1,2,2,1,2,1,2,1,2,1,2,";
	sBase += "1,2,1,2,4,2,1,2,1,2,1,2,";
	sBase += "1,2,1,1,2,2,1,2,2,1,2,2,";
	sBase += "1,1,2,1,1,2,1,2,2,1,2,2,";
	sBase += "2,1,4,1,1,2,1,2,1,2,2,2,";
	sBase += "1,2,1,2,1,1,2,1,2,1,2,2,";
	sBase += "2,1,2,1,2,1,1,5,2,1,2,2,";
	sBase += "1,2,2,1,2,1,1,2,1,2,1,2,";
	sBase += "1,2,2,1,2,1,2,1,2,1,2,1,";
	sBase += "2,1,2,1,2,5,2,1,2,1,2,1,";
	//1961
	sBase += "2,1,2,1,2,1,2,2,1,2,1,2,";
	sBase += "1,2,1,1,2,1,2,2,1,2,2,1,";
	sBase += "2,1,2,3,2,1,2,1,2,2,2,1,";
	sBase += "2,1,2,1,1,2,1,2,1,2,2,2,";
	sBase += "1,2,1,2,1,1,2,1,1,2,2,1,";
	sBase += "2,2,5,2,1,1,2,1,1,2,2,1,";
	sBase += "2,2,1,2,2,1,1,2,1,2,1,2,";
	sBase += "1,2,2,1,2,1,5,2,1,2,1,2,";
	sBase += "1,2,1,2,1,2,2,1,2,1,2,1,";
	sBase += "2,1,1,2,2,1,2,1,2,2,1,2,";
	//1971
	sBase += "1,2,1,1,5,2,1,2,2,2,1,2,";
	sBase += "1,2,1,1,2,1,2,1,2,2,2,1,";
	sBase += "2,1,2,1,1,2,1,1,2,2,2,1,";
	sBase += "2,2,1,5,1,2,1,1,2,2,1,2,";
	sBase += "2,2,1,2,1,1,2,1,1,2,1,2,";
	sBase += "2,2,1,2,1,2,1,5,2,1,1,2,";
	sBase += "2,1,2,2,1,2,1,2,1,2,1,1,";
	sBase += "2,2,1,2,1,2,2,1,2,1,2,1,";
	sBase += "2,1,1,2,1,6,1,2,2,1,2,1,";
	sBase += "2,1,1,2,1,2,1,2,2,1,2,2,";
	//1981
	sBase += "1,2,1,1,2,1,1,2,2,1,2,2,";
	sBase += "2,1,2,3,2,1,1,2,2,1,2,2,";
	sBase += "2,1,2,1,1,2,1,1,2,1,2,2,";
	sBase += "2,1,2,2,1,1,2,1,1,5,2,2,";
	sBase += "1,2,2,1,2,1,2,1,1,2,1,2,";
	sBase += "1,2,2,1,2,2,1,2,1,2,1,1,";
	sBase += "2,1,2,2,1,5,2,2,1,2,1,2,";
	sBase += "1,1,2,1,2,1,2,2,1,2,2,1,";
	sBase += "2,1,1,2,1,2,1,2,2,1,2,2,";
	sBase += "1,2,1,1,5,1,2,1,2,2,2,2,";
	//1991
	sBase += "1,2,1,1,2,1,1,2,1,2,2,2,";
	sBase += "1,2,2,1,1,2,1,1,2,1,2,2,";
	sBase += "1,2,5,2,1,2,1,1,2,1,2,1,";
	sBase += "2,2,2,1,2,1,2,1,1,2,1,2,";
	sBase += "1,2,2,1,2,2,1,5,2,1,1,2,";
	sBase += "1,2,1,2,2,1,2,1,2,2,1,2,";
	sBase += "1,1,2,1,2,1,2,2,1,2,2,1,";
	sBase += "2,1,1,2,3,2,2,1,2,2,2,1,";
	sBase += "2,1,1,2,1,1,2,1,2,2,2,1,";
	sBase += "2,2,1,1,2,1,1,2,1,2,2,1,";
	//2001
	sBase += "2,2,2,3,2,1,1,2,1,2,1,2,";
	sBase += "2,2,1,2,1,2,1,1,2,1,2,1,";
	sBase += "2,2,1,2,2,1,2,1,1,2,1,2,";
	sBase += "1,5,2,2,1,2,1,2,2,1,1,2,";
	sBase += "1,2,1,2,1,2,2,1,2,2,1,2,";
	sBase += "1,1,2,1,2,1,5,2,2,1,2,2,";
	sBase += "1,1,2,1,1,2,1,2,2,2,1,2,";
	sBase += "2,1,1,2,1,1,2,1,2,2,1,2,";
	sBase += "2,2,1,1,5,1,2,1,2,1,2,2,";
	sBase += "2,1,2,1,2,1,1,2,1,2,1,2,";
	//2011
	sBase += "2,1,2,2,1,2,1,1,2,1,2,1,";
	sBase += "2,1,6,2,1,2,1,1,2,1,2,1,";
	sBase += "2,1,2,2,1,2,1,2,1,2,1,2,";
	sBase += "1,2,1,2,1,2,1,2,5,2,1,2,";
	sBase += "1,2,1,1,2,1,2,2,2,1,2,2,";
	sBase += "1,1,2,1,1,2,1,2,2,1,2,2,";
	sBase += "2,1,1,2,3,2,1,2,1,2,2,2,";
	sBase += "1,2,1,2,1,1,2,1,2,1,2,2,";
	sBase += "2,1,2,1,2,1,1,2,1,2,1,2,";
	sBase += "2,1,2,5,2,1,1,2,1,2,1,2,";
	//2021
	sBase += "1,2,2,1,2,1,2,1,2,1,2,1,";
	sBase += "2,1,2,1,2,2,1,2,1,2,1,2,";
	sBase += "1,5,2,1,2,1,2,2,1,2,1,2,";
	sBase += "1,2,1,1,2,1,2,2,1,2,2,1,";
	sBase += "2,1,2,1,1,5,2,1,2,2,2,1,";
	sBase += "2,1,2,1,1,2,1,2,1,2,2,2,";
	sBase += "1,2,1,2,1,1,2,1,1,2,2,2,";
	sBase += "1,2,2,1,5,1,2,1,1,2,2,1,";
	sBase += "2,2,1,2,2,1,1,2,1,1,2,2,";
	sBase += "1,2,1,2,2,1,2,1,2,1,2,1,";
	//2031
	sBase += "2,1,5,2,1,2,2,1,2,1,2,1,";
	sBase += "2,1,1,2,1,2,2,1,2,2,1,2,";
	sBase += "1,2,1,1,2,1,5,2,2,2,1,2,";
	sBase += "1,2,1,1,2,1,2,1,2,2,2,1,";
	sBase += "2,1,2,1,1,2,1,1,2,2,1,2,";
	sBase += "2,2,1,2,1,4,1,1,2,1,2,2,";
	sBase += "2,2,1,2,1,1,2,1,1,2,1,2,";
	sBase += "2,2,1,2,1,2,1,2,1,1,2,1,";
	sBase += "2,2,1,2,5,2,1,2,1,2,1,1,";
	sBase += "2,1,2,2,1,2,2,1,2,1,2,1,";
	//2041
	sBase += "2,1,1,2,1,2,2,1,2,2,1,2,";
	sBase += "1,5,1,2,1,2,1,2,2,2,1,2,";
	sBase += "1,2,1,1,2,1,1,2,2,1,2,2";
	
	var arrBase = [];
	arrBase = sBase.split(",");
	
	return arrBase;
};

/**
 * @class 문자를 날짜로 변환. <br>
 * @param {String} strDate - String Date Format
 * @return {Date} date
 */
pForm.gfnStrToDate = function(inDate)
{
  var date =  new Date(parseInt(inDate.substr(0, 4)),parseInt(inDate.substr(4, 2)) - 1,parseInt(inDate.substr(6, 2)));
  return date;
};

/**
 * @class Date Type을 String으로 변환 <br>
 * @param {Date} date
 * @return {String} 'yyyyMMdd' 형태로 표현된 날짜
 */
pForm.gfnDateToStr = function(date)
{
	var strYear = date.getYear().toString();
	var strMonth = (date.getMonth() + 1).toString();
	var strDate = date.getDate().toString();
	
	if (strYear.length == 2) {
		strYear = "19" + strYear;
	} else if (strYear.length == 1) {
		strYear = "190" + strYear;
	}
		
	if (strMonth.length == 1) {
		strMonth = "0" + strMonth;
	}
	if (strDate.length == 1) {
		strDate = "0" + strDate;
	}
	
	return strYear + strMonth + strDate;
};

/**
 * @class 날짜 format에 맞게 변환 <br>
 * @param {String} date
		  {Date} date
 * @return {String} 'yyyy-MM-dd' 형태로 표현된 날짜
 */
pForm.gfnFormatDate = function(date, format) {
	if (!date) {
		return date;
	}
	if (typeof date == 'string') {
		date = this.gfnStrToDate(date);
	}
	if (!format) {
		format = 'yyyy-MM-dd';
	}
    return format.replace(/(yyyy|yy|MM|dd|E|hh|mm|ss|a\/p)/gi, function($1) {
        switch ($1) {
            case 'yyyy': 
				var y = date.getFullYear();
				if (y < 1000) {
					y = ('000' + y).substring(0, 4);
				}
				return y;
            case 'MM': 
				var m = date.getMonth() + 1;
				if (m < 10) {
					m = '0' + m;
				}
				return m;
            case 'dd': 
				var d = date.getDate();
				if (d < 10) {
					d = '0' + d;
				}
				return d;
			case 'E': 
				var weekName = ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'];
				return weekName[date.getDay()];
            case 'HH': 
				var h = date.getHours();
				if (h < 10) {
					h = '0' + h;
				}
				return h;
            case 'hh': 
				var h = ((h = date.getHours() % 12) ? hh : 12);
				if (h < 10) {
					h = '0' + h;
				}
				return h;
            case 'mm': 
				var m = date.getMinutes();
				if (m < 10) {
					m = '0' + m;
				}
				return m;
            case 'ss': 
				var s = date.getSeconds();
				if (s < 10) {
					s = '0' + s;
				}
				return s;
            case 'a/p': return date.getHours() < 12 ? '오전' : '오후';
            default: return $1;
        }
    });
}

/**
 * @class 년월일(yyyyMMdd)을 입력하면 해당 주차를 리턴한다. <br>
 * @param {String} strDate - 8자리 년월일(yyyyMMdd)
 * @return {String} 6자리 년도주차(yyyyWW)
 */
pForm.gfnGetWeek = function(strDate) 
{
	if (strDate.length != 8 || !this.gfnIsDigit(strDate)) {
		return "";
	}
	
	var year  = parseInt(strDate.substr(0, 4));
	var month = parseInt(strDate.substr(4, 2));
	var day   = parseInt(strDate.substr(6, 8));

	var startAt = 1; ///////////// 일요일 표시 부분 / 0 : 일요일(일월화...) / 1 : 월요일(...금토일)

	if (startAt == 0) {
		day = day + 1;
	}

	var a    = Math.floor((14 - month) / 12);
	var y    = year + 4800 - a;
	var m    = month + (12 * a) - 3;
	var b    = Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400);
	var J    = day + Math.floor(((153 * m) + 2) / 5) + (365 * y) + b - 32045;
	var d4   = (((J + 31741 - (J % 7)) % 146097) % 36524) % 1461;
	var L    = Math.floor(d4 / 1460);
	var d1   = ((d4 - L) % 365) + L;
	var week = Math.floor(d1 / 7) + 1;
		week = week.toString();
	return year+week.padLeft(2, "0");			
};


/**
 * @class 주민등록번호로 생년월일을 구한다. <br>
 * @param {String} ssn - 주민등록번호/외국인등록번호 13자리중 최소 7자 입력
 * @return {String} 8자리 날짜(YYYYMMMDD)문자열
 */
pForm.gfnGetBirthDateBySSN = function(ssn)
{
	var retVal;

	ssn = ssn.replace("-", ""); //하이픈제거
	
	if (!isNumber(ssn) || ssn.length < 6) {
		return retVal;
	}

	var yymmdd = ssn.substr(0, 6);
	var century;
	if (ssn.length > 6) {
		var genderFlag = Number(ssn.substr(6, 1));
		
		switch(genderFlag) {
			case 1:
			case 2:
			case 5:
			case 6:
				century = "19";
				break;
			case 3:
			case 4:
			case 7:
			case 8:
				century = "20";
				break;
			case 9:
			case 0:
				century = "18";
				break;
		}
	} else {
		var sTemp = this.gfnGetDate();
		if (sTemp.substr(2, 6) <= yymmdd) {
			century = "19";
		} else {
			century = "20";
		}
	}

	retVal = century + yymmdd;
	
	if (!this.gfnIsDate(retVal)) {
		retVal = null;
	}
	
	return retVal;	
};

/**
 * @class 주민번호 뒷 첫번째 자리로 년대를 return 한다. <br>
 * @param {String} sJuminNo	생년 월일 또는 주민 번호
 * @return {String} 주민번호 뒷 첫번째 자리로 년대를 return 한다.
 */
pForm.gfnGetBirthYear = function(sJuminNo)
{
	if (sJuminNo.toString().length != 13) {
		return "N";
	}
	
	if (!(sJuminNo).match(/^\d{6}\d{7}$/)) {
		return "N";
	}

	var vGb = sJuminNo.substr(6,1);

	if (vGb == "1" || vGb == "2" || vGb == "5" || vGb == "6") {
		return "19";
	} else if (vGb == "3" || vGb == "4" || vGb == "7" || vGb == "8") {
		return "20";
	}
};

/**
 * @class 기준년월일 기준으로 만나이를 구한다. <br>
 * @param {String} brtYmd - 생년월일
 * @param {String} stdYmd - 기준일자[생략시 현재일자]
 * @return {Number} 숫자형 나이
 */
pForm.gfnGetAge = function(brtYmd, stdYmd)
{
	var retVal = -1;
	
	if (gfnIsEmpty(stdYmd)) {
		stdYmd = gfnGetDate();
	}

	if (gfnIsDate(brtYmd) && gfnIsDate(stdYmd)) {
		var yDiff 	= Number(stdYmd.substr(0, 4)) - Number(brtYmd.substr(0, 4));
		var mdDiff	= Number(stdYmd.substr(4, 4)) - Number(brtYmd.substr(4, 4));
		   
		retVal = yDiff;
		if (mdDiff < 0) {	//before
			retVal = retVal - 1;
		}
	}

	return retVal;	
};

/**
* @class 요일 구하기
* @param {String} ymd  - 년월일 형식 일자
* @param {type}   type - 요일 형식
*/
pForm.gfnGetDayNm = function(ymd, type)
{
	if (this.gfnIsNull(ymd)) return "";
	var date = new Date();
	type = this.gfnIsNull(type) ? 1 : type;

	var oDay = { 1 : ["일", "월", "화", "수","목", "금", "토"]
	          ,  2 : ["일요일", "월요일", "화요일", "수요일","목요일", "금요일", "토요일"]
			  ,  3 : ["Sun", "Mon", "Tue", "Wed","Thu", "Fri", "Sat"]
			   }

	date.setDate(ymd.substr(6, 2));
	date.setMonth(ymd.substr(4, 2) - 1);
	date.setYear(ymd.substr(0, 4));

	return (oDay[type][date.getDay()]);
}

/************************************************************************************************
* 달력용 공통함수 - Instance 변수
************************************************************************************************/
pForm.ioCaMMProp    = {width:172, height:172, url:"Comm::CommCalMM.xfdl"};
pForm.ioCaMMFTProp  = {width:364, height:220, url:"Comm::CommCalMMFT.xfdl"};
pForm.ioCaYMDFTProp = {width:410, height:314, url:"Comm::CommCalYMDFT.xfdl"};

/************************************************************************************************
* 1. 달력용 공통함수 - Component Type - Start
************************************************************************************************/
/** type : Calendar
* @class 달력 초기화 함수 (컴포넌트용)
* @param {Calendar} objSrc   : (필)calendar component
*        {String}   calType  : (필)Calendar type (MM:월달력, MMFT:월달력from~to, YMDFT:일달력from~to)
*        {String}   callback : (필)callback
*        {Calendar} objFrom  : (필)from~to type에서 from calendar
*        {Calendar} objTo    : from~to type에서 to   calendar
*/
pForm.gfnCaCalendarInit = function(objSrc, calType, callback, objFrom, objTo)
{
	objSrc.uCaType     = calType;
	objSrc.uCaCallback = callback;
	objSrc.uCaObjFrom  = objFrom;
	objSrc.uCaObjTo    = objTo;
	objSrc.addEventHandler("ondropdown", this._gfnCaCalendar_ondropdown, this);
}

/** type : Calendar
 * @class 달력 popupdiv 띄우기
 */
pForm._gfnCaCalendar_ondropdown = function(obj)
{
	//1. type별 속성정의
	var calType  = obj.uCaType;
	var oCalProp;
	if (calType == "MM") {
		oCalProp = this.ioCaMMProp;
		obj.set_dateformat("yyyy-MM");
		obj.set_editformat("yyyy-MM");
	} else if (calType == "MMFT") {
		oCalProp = this.ioCaMMFTProp;
		obj.uCaObjFrom.set_dateformat("yyyy-MM");
		obj.uCaObjFrom.set_editformat("yyyy-MM");
		obj.uCaObjTo.set_dateformat("yyyy-MM");
		obj.uCaObjTo.set_editformat("yyyy-MM");
	} else if (calType == "YMDFT") {
		oCalProp = this.ioCaYMDFTProp;
	}

	var popDivNm = "popupDivCal" + calType;
	var objPopDiv;
	
	if (this.components[popDivNm] instanceof nexacro.PopupDiv) {
		objPopDiv = this.components[popDivNm];
	} else {
		objPopDiv = new PopupDiv();
		//objPopDiv.set_formscrollbartype("none none");
		//objPopDiv.set_formscrolltype("none");
		objPopDiv.init(popDivNm, 0, 0, oCalProp.width, oCalProp.height);
		this.addChild(popDivNm, objPopDiv); 
		objPopDiv.show();
		objPopDiv.set_async(false);
		objPopDiv.set_url(oCalProp.url);
	}	
	//objPopDiv.uCalForm    = this;
	objPopDiv.uCaCompType   = "CALENDER";
	objPopDiv.uCaObjCal     = obj;                //월달력 1개 에서만 사용
	objPopDiv.uCaObjFrom    = obj.uCaObjFrom;
	objPopDiv.uCaObjTo      = obj.uCaObjTo;
	objPopDiv.uCaCallback   = obj.uCaCallback;
	objPopDiv.uCaCallbackId = obj.id;
	
	objPopDiv.form.fnInit();
	
	if (calType == "MM") {
		var height  = obj.getOffsetHeight();
		objPopDiv.trackPopupByComponent(obj, 0, height);
	} else {
		var height  = obj.uCaObjFrom.getOffsetHeight();
		objPopDiv.trackPopupByComponent(obj.uCaObjFrom, 0, height);
	}
	return false;
}

/************************************************************************************************
* 1. 달력용 공통함수 - Component Type - end
************************************************************************************************/

/************************************************************************************************
* 2. 달력용 공통함수 - Grid Type - Start
************************************************************************************************/
/** type : Calendar
 * @class Grid용 달력 OPEN
 * @param {Grid}   objGrid   : (필)업무용 Grid
 *        {int}    row       : (필)row index
 *        {int}    cell      : (필)click cell
 *        {String} calType   : (필)Calendar type (MM:월달력, MMFT:월달력from~to, YMDFT:일달력from~to)
 *        {String} callback  : (필)callback
 *        {String} fromColId : (필)from column id
 *        {String} toColId   : to column id
 * @exec  this.gfnCaCalendarGrid(obj, e.row, e.cell,   "MM",    "fnCalCallback", "ym");
 *        this.gfnCaCalendarGrid(obj, e.row, e.cell-1, "YMDFT", "fnCalCallback", "ymdFrom", "ymdTo"); 
 */
pForm.gfnCaCalendarGrid = function(objGrid, row, cell, calType, callback, fromColId, toColId)
{
	objGrid.updateToDataset();
	var objDs = objGrid.getBindDataset();
	
	//1. type별 속성정의
	var oCalProp = (calType == "MM" ? this.ioCaMMProp : (calType == "MMFT" ? this.ioCaMMFTProp : (this.ioCaYMDFTProp)))

	//2. Calendar용 popupdiv 생성
	var popDivNm = "popupDivCalGrid_" + calType;
	var objPopDiv;
	if (this.gfnIsNull(this.components[popDivNm])) {
		objPopDiv = new PopupDiv();
		//objPopDiv.set_formscrollbartype("none none");
		//objPopDiv.set_formscrolltype("none");
		objPopDiv.init(popDivNm, 0, 0, oCalProp.width, oCalProp.height);
		this.addChild(popDivNm, objPopDiv); 
		objPopDiv.show();
		objPopDiv.set_async(false);
		objPopDiv.set_url(oCalProp.url);
	} else {
		objPopDiv = this.components[popDivNm];
	}
	
	//2. Grid Calendar Component와 연계할 값 Setting
	objPopDiv.uCaCompType   = "GRID";
	objPopDiv.uCaType       = calType;
	objPopDiv.uCaObjGrid    = objGrid;
	objPopDiv.uCaObjBusiDs  = objDs;
	objPopDiv.uCaRow        = row;
	objPopDiv.uCaCell       = cell;
	objPopDiv.uCaColdId     = fromColId;  //월달력 1개 인 경우에 사용
	objPopDiv.uCaFromColId  = fromColId;
	objPopDiv.uCaToColId    = toColId;
	objPopDiv.uCaCallback   = callback;
	objPopDiv.uCaCallbackId = objGrid.id + "_" + fromColId;
	
	objPopDiv.form.fnInit();
	
	//3. popupdiv 띄우기
	this.gfnOpenPopupDivGridCell(objGrid, objPopDiv, row, cell);
}

/**
* @class Grid에서 클릭 한 cell 밑으로  PopupDiv를 띄위기
* 예) this.gfnGridList(obj, this.PdivNm, e.row, e.cell);
*/
pForm.gfnOpenPopupDivGridCell = function(objGrid, objPopDiv, row, cell)
{
    var nTitleBarHeight = 30;  //Grid title height
	
	//1. 클릭된 cell의 Rect 값을 가져 옵니다.
	var aryRect = objGrid.getCellRect(row, cell);
	
    //2. cell 의 Rect 값은 left, right, width, height 값을 가져올수가 있습니다.
	var nX = aryRect.left;	
	var nW = aryRect.width;
	var nH = aryRect.height;
	
	//3. 2값은 그리드의 border 값
	var nY = aryRect.bottom + 2;  //nY = aryRect.top + 2;  <--이렇게 하면.. 입력 컬럼위에 Popup div가 띄워짐
	
	//4. cell 의 Rect 값을 가져와 popupDiv 를 띄워 줍니다.
	objPopDiv.trackPopupByComponent(objGrid, nX, nY); //, nW, nH);
} 
/************************************************************************************************
* 2. 달력용 공통함수 - Grid Type - End
************************************************************************************************/



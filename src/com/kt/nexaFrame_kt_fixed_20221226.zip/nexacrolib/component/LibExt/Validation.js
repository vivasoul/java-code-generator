﻿/**
*  Validation 관련 공통 함수 모음
*  @FileName 	Validation.js
*/

var pForm = nexacro.Form.prototype;

/************************************************************************************************
* 정합성 check 공통 기능
************************************************************************************************/

// Validation ERROR class 사용 여부
pForm.useErrorClass = false;

/**
* @class Dataset에 설정된 정합성체크 RuleSet을 Clear한다.
* @param {Dataset} obj - 데이터셋 Object
* @return N/A
*/
pForm.gfnClearValidation = function(obj)
{
	obj.validationRuleSet = "";
};

/**
* @class Dataset의 Column별로 설정된 정합성체크 Rule을 제거한다.
* @param  {Dataset} 데이터셋 Object
* @param  {String} 체크대상 컬럼명
* @return N/A
*/
pForm.gfnRemoveValidation = function(obj, sColumID)
{
	var newvalidObj = new Array();

	if (this.gfnIsExist(obj.validationRuleSet)) {
		validObj = JSON.parse(obj.validationRuleSet);

		for(var index in validObj) {
			var validationRule = validObj[index];

			// 제거 대상이 아닐때만 정합성체크 대상에 넣는다.
			if (validationRule.name != sColumID) {
				newvalidObj.push(validationRule);
			}
		}
	}

	obj.validationRuleSet = JSON.stringify(newvalidObj);
};

/**
* @class Dataset의 Column별로 정합성체크 Rule을 등록한다.
* @param {Dataset} obj - 데이터셋 Object
* @param {String} sColumID - 체크대상 컬럼명
* @param {String} sColumName - 컬럼명의 오류메세지 처리 제목
* @param {String} sValidRule - 정합성체크 Rule(required, length, min, max, code 등의 체크 형식)
* @return N/A
*/
pForm.gfnSetValidation = function(obj, sColumID, sColumName, sValidRule, sOption)
{
	var validObj = new Array();

	// title이 2개가 올 경우 구분자를 변경
	// checkrule == "equalto" || checkrule == "fromto" || checkrule == "comparebig" || checkrule == "comparesmall" || checkrule == "optrequiredto"
	if (sColumName.indexOf(",") != -1) sColumName = nexacro.replaceAll(sColumName, ",", "^_^");


	// Dataset에 RuleSet이 존재하면
	if (this.gfnIsExist(obj.validationRuleSet)) {
		validObj = JSON.parse(obj.validationRuleSet);
	}

// 	// Dataset에 RuleSet이 존재하면
// 	if (this.gfnIsExist(obj.validationRuleSet))	{
// 		validObj = JSON.parse(obj.validationRuleSet);
// 		for(var index in validObj) {
// 			// 컬럼에 Rule이 존재하면 변경 처리
// 			if( validObj[index].name == sColumID ) {
// 				validObj[index].title = sColumName;
// 				validObj[index].value = sValidRule;
// 				validObj[index].option = sOption;
// 				if (""+sValidRule.indexOf("required") > -1 && ""+sValidRule.indexOf("optrequiredto") <= -1) {
// 					validObj[index].notnull = true;
// 				} else {
// 					validObj[index].notnull = false;
// 				}
// 				obj.validationRuleSet = JSON.stringify(validObj);
// 				return true;
// 			}
// 		}
// 	}

	// Rule 지정
	var validationRule = { name   : sColumID	// Column
						 , title  : sColumName	// Title
						 , value  : sValidRule	// 정합성 Rule
						 , option : sOption	};	// 옵션
						
	// Rule에 필수여부 추가
	if (""+sValidRule.indexOf("required") > -1 && ""+sValidRule.indexOf("optrequiredto") <= -1 ) {
		validationRule.notnull = true;
	} else {
		validationRule.notnull = false;
	}
	validObj.push(validationRule);

	obj.validationRuleSet = JSON.stringify(validObj);
};


/**
* @class Dataset에 등록된 데이터 정합성체크 RuleSet에의해 정합성을 체크를 하고 이상여부를 리턴한다.
* @param  {Dataset||Grid,String} Check 대상 Object(Dataset, Grid)
							  Check 모드 A: 모든 row에 대해서 체크, U: 변경된 row에 대해서만 체크(default)
* @return {Boolean} 정상 true / 오류 false
* @참고 - 여러개의 Dataset에 대해 Validation 가능
	     - 수정된 Row가 아닌 전체 Row에 대해 Validation check
	     - if (this.gfnValidation(this.ds_list, this.ds_list2, "A") == false) return;
*/
pForm.gfnValidation = function()
{
	var updatecount = 0;
	var targetlist  = new Array();
	var checkmode   = "U";

	// Check 대상과 Check Mode(A/U)를 지정
	for(var m = 0, s = arguments.length; m < s; m++) {
		if( arguments[m] == "A" || arguments[m] == "U" ) {
			checkmode = arguments[m];
			
		// Check 대상 설정 : 데이타셋 or 그리드
		} else {
			targetlist.push(arguments[m]);
		}
	}

	// arguments로 넘어온 체크 대상 만큼 정합성 체크
	for (var m = 0, s = targetlist.length; m < s; m++) {
		var dataset;
		var objtype   = "";
		var checklist = new Array();

		// 데이터셋
		if( targetlist[m] instanceof Dataset ) {
			dataset = targetlist[m];
			objtype = "dataset";
		// 그리드
		} else if( targetlist[m] instanceof Grid ) {
			dataset = targetlist[m].getBindDataset();
			objtype = "grid";
		// 처리 제외
		} else {
			continue;
		}

		// 데이터셋의 RuleSet
		var validlist = new Array();
		if( this.gfnIsNotNull(dataset.validationRuleSet)) {
			validlist = JSON.parse(dataset.validationRuleSet);
		} else{
			continue;
		}

		// 삭제된 row 정합성 체크 건수 증가
		updatecount += parseInt(dataset.getDeletedRowCount());

		// 데이터셋의 row 만큼 정합성 체크
		for(var i = 0, t = dataset.getRowCount(); i < t; i++) {
			var rowtype = dataset.getRowType(i);

			// 삭제된 row
			if (rowtype == 8) {
				++updatecount;
				continue;
			}

			// checkmode에 따른 체크 대상 구분
			if (checkmode == "U") {
				// 변경 안된 Row는 정합성 체크 SKIP
				if (rowtype == 1) {
					continue;
				}

				// 추가, 수정은 정합성 체크
				if (rowtype == 2 || rowtype == 4) {
					++updatecount;
				}
			// 전체 row
			} else {
				++updatecount;
			}

			// Rule 만큼 처리
			for(var j = 0; j < validlist.length; j++) {
				var columid   = validlist[j].name;
				var columname = new String(validlist[j].title);
				var columvalue= dataset.getColumn(i, columid);
				var checklist = (""+validlist[j].value).split(",");
				var nullcheck = validlist[j].notnull;

				// 필수입력 체크 (required)
				if (nullcheck == true) {
					if (this.gfnIsTrimNull(columvalue))	{
						// Validation ERROR class 사용 시
						if (this.useErrorClass) {
							this.gfnResetValidationCss(arguments);
						}

						// row 이동 및 focus 저장
						dataset.set_rowposition(i);
						this.validationObject = arguments[m];
						this.validationColumn = columid;

						var title = "";
						if (columname.indexOf("^_^") != -1) {
							title = columname.split("^_^")[0];
						} else {
							title = columname;
						}

						// 메시지 처리 : ${} 필수 입력 항목입니다.
						//this.gfnAlert("msg.err.validator", [this.gfnGetKoreanTarget(title, "은(는)")+" 필수 입력 항목입니다."], null, "gfnValidationCallback");
						// 메시지 처리 : {0} 은(는) 필수 입력 항목입니다.
						this.gfnAlert("MSG1301", [title], null, "gfnValidationCallback"); //{0}은(는) 필수 입력 항목입니다.	

						return false;
					}
				}

				// 필수값이 아닌 경우는 체크할 값이 null이 아닌 경우에만 체크
				if (this.gfnIsNotNull(columvalue)) {
					// Rule에 따른 정합성 체크
					for(var k=0;k<checklist.length;k++)	{
						var msg = "";

						// 컬럼의 두개의 값을 이용해서 처리하는 check 대상
						var checkrule =  checklist[k].split(":")[0];
						if (checkrule == "equalto" || checkrule == "fromto" || checkrule == "comparebig" || checkrule == "comparesmall" || checkrule == "compareequal")	{
							var compare1;
							var compare2;

							if( checklist[k].split(":").length == 3 ) {
								compare1 = dataset.getColumn(i, checklist[k].split(":")[1]);
								compare2 = dataset.getColumn(i, checklist[k].split(":")[2]);
							} else {
								compare1 = dataset.getColumn(i, columid);
								compare2 = dataset.getColumn(i, checklist[k].split(":")[1]);
							}
							msg = this.gfnValidationCheckRule(columname, columvalue, checklist[k], compare1, compare2);
						} else if(checkrule == "optrequiredto") {
							var compare1;
							var compare2;

							if( checklist[k].split(":").length == 3 ) {
								compare1 = dataset.getColumn(i, checklist[k].split(":")[1]);
								compare2 = checklist[k].split(":")[2];
							} else {
								compare1 = dataset.getColumn(i, checklist[k].split(":")[1]);
								compare2 = null;
							}
							msg = this.gfnValidationCheckRule(columname, columvalue, checklist[k], compare1, compare2);

						// 컬럼의 한개 값을 이용해서 처리하는 check 대상
						} else {
							msg = this.gfnValidationCheckRule(columname, columvalue, checklist[k], null, null, validlist[j].option);
						}

						// 에러시
						if (this.gfnIsNotNull(msg))	{
							// Validation ERROR class 사용 시
							if (this.useErrorClass) {
								this.gfnResetValidationCss(arguments);
							}

							// row 이동 및 focus 저장
							dataset.set_rowposition(i);
							this.validationObject = arguments[m];
							this.validationColumn = columid;

							this.gfnAlert("MSG1000", [msg], null, "gfnValidationCallback"); //{0}

							return false;
						}
					}  // Rule에 따른 정합성 체크
				} else {  // 필수값이 아닌 경우는 체크할 값이 null인 경우에만 체크
					// Rule에 따른 정합성 체크
					for(var k = 0; k < checklist.length; k++) {
						var msg = "";

						// 컬럼의 두개의 값을 이용해서 처리하는 check 대상
						var checkrule =  checklist[k].split(":")[0];
						if (checkrule == "optrequiredto") {
							var compare1;
							var compare2;

							if( checklist[k].split(":").length == 3 ) {
								compare1 = dataset.getColumn(i, checklist[k].split(":")[1]);
								compare2 = checklist[k].split(":")[2];
							} else {
								compare1 = dataset.getColumn(i, checklist[k].split(":")[1]);
								compare2 = null;
							}
							msg = this.gfnValidationCheckRule(columname, columvalue, checklist[k], compare1, compare2);
						}

						// 에러시
						if (this.gfnIsNotNull(msg)) 	{
							// Validation ERROR class 사용 시
							if (this.useErrorClass) {
								this.gfnResetValidationCss(arguments);
							}

							// row 이동 및 focus 저장
							dataset.set_rowposition(i);
							this.validationObject = arguments[m];
							this.validationColumn = columid;

							// 메시지 처리 : ${}
							this.gfnAlert("MSG1000", [msg], null, "gfnValidationCallback");  //{0}

							return false;
						}
					}  // Rule에 따른 정합성 체크
				} // 필수값이 아닌 경우는 체크할 값이 null인 경우 체크
			}  // Rule 만큼 처리
		}  // 데이터셋의 row 만큼 정합성 체크
	}  // arguments로 넘어온 체크 대상 만큼 정합성 체크

	// Validation ERROR class 사용 시 cssclass 원복
	if (this.useErrorClass) {
		this.gfnResetValidationCss(arguments);
	}

	// 정합성 체크 건수 확인
	if (updatecount == 0) {
		this.gfnLog("정합성 체크 대상이 없어 Validation을 체크가 되지 않았습니다.","info");
		//return false;
	}

	return true;
};

/**
* @class 데이터의 정합성을 체크하여 그 결과를 리턴한다. 메세지가 "" 널이면.. 정상 널이 아니면 실패이다.
* @param {String} itemName - Column title
* @param {Stirng} itemValue - Column 값
* @param {String} validationRuleSet - validation Rule
* @return {Stirng} 정상이면 "" 실패이면 "XXX는 7자리입니다." 와 같은 완성형 에러메세지
*/
pForm.gfnValidationCheckRule = function(itemName, itemValue, validationRuleSet, compare1, compare2, option)
{
	var title     = "";
	var columname1 = "";
	var columname2 = "";
	if (itemName.indexOf("^_^") != -1) {
		title     = itemName.split("^_^")[0];
		columname1 = itemName.split("^_^")[0];
		columname2 = itemName.split("^_^")[1];
	} else {
		title = itemName;
	}

	var arrItem2  =  validationRuleSet.split(":");
	var checkrule =  arrItem2[0];

	checkrule = checkrule.toLowerCase();
	
	switch(checkrule) {
		// size 크기 지정 : length:7
		case "length":
			if( (itemValue+"").length != parseInt(arrItem2[1])) 	{
				return this.gfnGetMessage("MSG1304",[title, arrItem2[1]]);  //{0}의 입력값은 {1}자리이어야 합니다.
			}
			break;
		// size 크기의 범위 : rangelength:2:3
		case "rangelength":
			if( (itemValue+"").length < parseInt(arrItem2[1]) || (itemValue+"").length > parseInt(arrItem2[2])) {
				return this.gfnGetMessage("MSG1305",[title, arrItem2[1], arrItem2[2]]); //{0}은(는) {1}와(과) {2}사이의 자리이어야 합니다
			}
			break;
		// 최대 size 크기: maxlength:7
		case "maxlength":
			if (itemValue.length > parseInt(arrItem2[1])) {
				return this.gfnGetMessage("MSG1306",[title, arrItem2[1]]);  //{0}의 입력값의 길이는 {1}이하이어야 합니다.
			}
			break;
		// 최소 size 크기: minlength:7
		case "minlength":
			if (itemValue.length < parseInt(arrItem2[1])) {
				return this.gfnGetMessage("MSG1307",[title, arrItem2[1]]);  // {0} 의 입력값의 길이는 {1} 이상이어야 합니다.
			}
			break;
		// 최대 size 크기(Byte) : maxlengthB:3
		case "maxlengthbyte":
			if (this.lookupFunc("gfnLengthByte").call(itemValue) > parseInt(arrItem2[1])) {
				return this.gfnGetMessage("MSG1306",[title, arrItem2[1]]);  // {0} 의 입력값의 길이는 {1} 이하이어야 합니다.
			}
			break;
		// 최소 size 크기(Byte) : minlengthB:3
		case "minlengthbyte":
			if (this.lookupFunc("gfnLengthByte").call(itemValue) < parseInt(arrItem2[1])) {
				return this.gfnGetMessage("MSG1307",[title, arrItem2[1]]);  // {0} 의 입력값의 길이는 {1} 이상이어야 합니다.
			}
			break;
		// 숫자 여부 : digits
		case "digits":
			if (!this.lookupFunc("gfnIsDigit").call(itemValue)) {
				return this.gfnGetMessage("MSG1308",[title]);  // {0} 은(는) 숫자만 입력 가능합니다.
			}
			break;
		// 해당 숫자 이하 : min:7
		case "min":
			if (parseFloat(itemValue) < parseFloat(arrItem2[1])) {
				return this.gfnGetMessage("MSG1309",[title, arrItem2[1]]);   // {0} 은(는) {1} 이상의 숫자만 입력 가능합니다.
			}
			break;
		// 해당 숫자 이상 : max:7
		case "max":
			if (parseFloat(itemValue) > parseFloat(arrItem2[1])) {
				return this.gfnGetMessage("MSG1310",[title, arrItem2[1]]);   // {0} 은(는) {1} 이하의 숫자만 입력 가능합니다.
			}
			break;
		// 소숫점 자리수 비교 - declimit:3
		case "declimit":
			var isExistDot = (""+itemValue).indexOf(".");
			if (isExistDot == -1) {
				return this.gfnGetMessage("MSG1318",[title, arrItem2[1]]);   // {0} 은(는) 소숫점 {1} 자리로 구성되어야 합니다.
			} else {
				var decLen = (""+itemValue).substr(isExistDot + 1, itemValue.length);
				if (decLen.length != parseInt(arrItem2[1])) {
					return this.gfnGetMessage("MSG1318",[title, arrItem2[1]]);  // {0} 은(는) 소숫점 {1} 자리로 구성되어야 합니다.
				}
			}
			break;
		// 날짜 년월일 체크 : date
		case "date":
			if (!this.lookupFunc("gfnIsYMD").call(itemValue)) {
				return this.gfnGetMessage("MSG1311",[title]);  // {0} 은(는) 유효하지 않은 날짜 형식입니다.
			}
			break;
			
		// 날짜 년월일 시분 체크 : date
		case "datehm":
			if (!this.lookupFunc("gfnIsYmdHm").call(itemValue)) {
				return this.gfnGetMessage("MSG1311",[title]);  // {0} 은(는) 유효하지 않은 날짜 형식입니다.
			}
			break;
			
		// 날짜 년월 체크 : dateym
		case "dateym":
			if (!this.lookupFunc("gfnIsYM").call(itemValue)) {
				return this.gfnGetMessage("MSG1312",[title]);  // {0} 은(는) 유효하지 않은 년월 형식입니다.
			}
			break;
		// 사이의 값인지 비교 - range:40:100
		case "range":
			if (parseInt(itemValue) < parseInt(arrItem2[1]) || parseInt(itemValue) > parseInt(arrItem2[2])) {
				return this.gfnGetMessage("MSG1317",[title,arrItem2[1],arrItem2[2]]);  // {0} 은(는) {1} 와(과) {2} 사이의 값입니다.
			}
			break;
		// 코드값이 목록내의 값인지 비교 - code:1:2:3
		case "code":
			for (var i = 1; i < arrItem2.length; i++) {
				if (itemValue == arrItem2[i]) {
					return "";
				}
			}
			return this.gfnGetMessage("MSG1319",[title,nexacro.replaceAll(validationRuleSet.split("code:")[1],":",",")]);  // {0} 은(는) {1} 중 하나의 값이어야 합니다.
			break;
		// 타 칼럼값과 같은지 비교 - equalto:target칼럼명
		case "equalto":
			if( compare1 != compare2) {
				if (itemName.indexOf("^_^") != -1 ) {
					return this.gfnGetMessage("MSG1316",[columname1,columname2]);  // {0} 이(가) {1} 와(과) 일치하지 않습니다.
					
				// 비교대상 칼럼의 title을 넘겨주지 않았을 경우 해당 값을 표시
				} else {
					return this.gfnGetMessage("MSG1316",[title,compare2]);  // {0} 이(가) {1} 와(과) 일치하지 않습니다.
				}
			}
			break;
		// 날짜 from ~ to 비교 : comparedate:target칼럼명
		case "fromto":
			if (compare1 < compare2) {
				return this.gfnGetMessage("MSG1313",[columname1,columname2]);  // {0} 의 날짜가 {1} 의 날짜보다 작습니다.
			}
			break;
			
		// 날짜 시분 from ~ to 비교
		case "fromtohm":
			if (this.gfnIsExist(compare1) && this.gfnIsExist(compare1) && compare1 < compare2) {
				compare1 = compare1.toString();
				compare2 = compare2.toString();
				return this.gfnGetMessage("MSG1313",[columname1,columname2]);  // {0} 의 날짜가 {1} 의 날짜보다 작습니다.
			}
			break;					
			
		// 타 칼럼값보다 큰값인지 비교 - comparemax:target칼럼명
		case "comparebig":
			if( parseFloat(compare1) < parseFloat(compare2)) {
				if( itemName.indexOf("^_^") != -1 ) {
					return this.gfnGetMessage("MSG1314",[columname1,columname2]);  // {0} 이(가) {1} 보다 작습니다.
					
				// 비교대상 칼럼의 title을 넘겨주지 않았을 경우 해당 값을 표시
				} else {
					return this.gfnGetMessage("MSG1314",[title,compare2]);  // {0} 이(가) {1} 보다 작습니다.
				}
			}
			break;
		// 타 칼럼값과 작은값인지 비교 - comparemin:comparetarget
		case "comparesmall":
			if( parseFloat(compare1) > parseFloat(compare2)) {
				if( itemName.indexOf("^_^") != -1 ) {
					return this.gfnGetMessage("MSG1315",[columname1,columname2]);  // {0} 이(가) {1} 보다 큽니다.
					
				// 비교대상 칼럼의 title을 넘겨주지 않았을 경우 해당 값을 표시
				} else {
					return this.gfnGetMessage("MSG1315",[title,compare2]);  // {0} 이(가) {1} 보다 큽니다.
				}
			}
			break;
			
		// 동일한 값인지 체크
		case "compareequal":
			if( compare1 == compare2 ) {
				//if( itemName.indexOf("^_^") != -1 ) {
					return this.gfnGetMessage("MSG1327",[columname1,columname2]);  // {0} 는 {1}과 같을 수 없습니다.
				//}
			}
			break;	

		// 아래부터는 해당 프로젝트에서 추가한 Validation 함수로 체크 로직 추가 가능
		// 타 칼럼값이 Notnull일 경우 필수 - optrequiredto:target칼럼명
		case "optrequiredto":
			if(this.gfnIsNull(itemValue) && this.gfnIsNotNull(compare1) && this.gfnIsNull(compare2)) { //"optrequiredto:FIRST_NAME"
				return this.gfnGetMessage("MSG1323",[columname2,columname1]);  // {0}의 값이 있을 경우 {1}은(는) 필수 입력 항목입니다.
			} else if(this.gfnIsNull(itemValue) && this.gfnIsNotNull(compare1) && this.gfnIsNotNull(compare2) && compare1 == compare2 ) { //"optrequiredto:FIRST_NAME:홍"
				return this.gfnGetMessage("MSG1324",[columname2,compare2,columname1]);  // {0}의 값이 {1}인 경우 {2}은(는) 필수 입력 항목입니다.
			}

			break;
		// 주민등록번호 체크 - isssn
		case "isssn":
			if (!this.lookupFunc("gfnIsSSN").call(itemValue)) {
				return this.gfnGetMessage("MSG1320",[title,"주민번호"]);  // {0} 은(는) 올바른 {1}가 아닙니다.
			}
			break;
		// 외국인등록번호 체크 - isfrn
		case "isfrn":
			if (!this.lookupFunc("gfnIsFrnrIdNo").call(itemValue)) {
				return this.gfnGetMessage("MSG1320",[title,"외국인등록번호"]);  // {0} 은(는) 올바른 {1}가 아닙니다.
			}
			break;
		// 사업자등록번호 체크 - isbzid
		case "isbzid":
			if (!this.lookupFunc("gfnIsBzIdNo").call(itemValue)) {
				return this.gfnGetMessage("MSG1320",[title,"사업자등록번호"]);  // {0} 은(는) 올바른 {1}가 아닙니다.
			}
			break;
		// 법인등록번호 체크 - isfirmid
		case "isfirmid":
			if (!this.lookupFunc("gfnIsFirmIdNo").call(itemValue)) {
				return this.gfnGetMessage("MSG1320",[title,"법인등록번호"]);  // {0} 은(는) 올바른 {1}가 아닙니다.
			}
			break;
		// 신용카드번호 체크 - iscardno
		case "iscardno":
			if (!this.lookupFunc("gfnIsCardNo").call(itemValue)) {
				return this.gfnGetMessage("MSG1320",[title,"신용카드번호"]);  // {0} 은(는) 올바른 {1}가 아닙니다.
			}
			break;
		// 이메일 체크 - isemail
		case "isemail":
			if (!this.lookupFunc("gfnIsEmail").call(itemValue)) {
				return this.gfnGetMessage("MSG1321",[title]);  // e-mail이 잘못된 형태로 입력 되었습니다.
			}
			break;
		// 정규식 체크 - regexp
		// 참고 : 순수 정규표현식은 메시지가 부정확해서 사용하면 안됨
		case "regexp":
			if (!this.gfnIsRegExp(itemValue, option)) {
				return this.gfnGetMessage("MSG1322",[title]); //{0}은(는) 유효하지 않은 형식입니다.
			}
			break;
		
		// 정규식 체크 - regexpType
		case "regexptype":
			if (!this.gfnIsRegExpType(itemValue, option)) {
				return this.gfnGetRegExpMsg(title, option);
			}
			break;

		default:
			return "";
			break;
	}
	return "";
};

/**
* @class Validation 에러시 메세지 후 callBack함수
* @param {String} sid - 팝업ID
* @param {String} rtn - 전달값
* @return N/A
*/
pForm.gfnValidationCallback = function(sid, rtn)
{
	// Validation 오류시 focus 처리
	this.gfnSetValidationFocus(this.validationObject, this.validationColumn);
};

/**
* @class 정합성 체크 오류시 해당 콤포넌트의 ERROR 스타일 처리 및 포커스 처리
* @param  {Object} obj - Grid 및 Dataset
* @param  {String} bindcolumid - 입력오류항목 컬럼명
* @return N/A
*/
pForm.gfnSetValidationFocus = function(obj, bindcolumid)
{
	var binddataset;

	if (obj instanceof Grid) {
		binddataset = obj.getBindDataset();
	} else {
		binddataset = obj;
	}

	// 바인딩된 Components
	for(var j=0;j<this.binds.length;j++) {
		if( eval("this."+this.binds[j].datasetid) == binddataset && this.binds[j].columnid == bindcolumid ) {
			var targetobj = eval("this."+this.binds[j].compid);

			// Validation ERROR class 사용 시(PROJECT의 CSS에 맞게 수정 필요)
			if (this.useErrorClass) {
				var objtype = targetobj.valueOf();
				if (objtype == "[object Edit]") {
					targetobj.orgcssclass = targetobj.cssclass;
					targetobj.set_cssclass("edt_WF_Error");
				} else if (objtype == "[object MaskEdit]") {
					targetobj.orgcssclass = targetobj.cssclass;
					targetobj.set_cssclass("msk_WF_Error");
				} else if (objtype == "[object Combo]") {
					targetobj.orgcssclass = targetobj.cssclass;
					targetobj.set_cssclass("cmb_WF_Error");
				} else if (objtype == "[object Calendar]") {
					targetobj.orgcssclass = targetobj.cssclass;
					targetobj.set_cssclass("cal_WF_Error");
				} else if (objtype == "[object TextArea]") {
					targetobj.orgcssclass = targetobj.cssclass;
					targetobj.set_cssclass("txt_WF_Error");
				} else if (objtype == "[object Spin]") {
					targetobj.orgcssclass = targetobj.cssclass;
					targetobj.set_cssclass("spn_WF_Error");
				} else if (objtype == "[object Radio]") {
					targetobj.orgcssclass = targetobj.cssclass;
					targetobj.set_cssclass("rdo_WF_Error");
				} else if (objtype == "[object CheckBox]") {
					targetobj.orgcssclass = targetobj.cssclass;
					targetobj.set_cssclass("chk_WF_Error");
				}
			}

			targetobj.setFocus();
			return;
		}
	}

	// 그리드
	if (obj instanceof Grid) {
		obj.setCellPos(obj.getBindCellIndex("Body", bindcolumid));
		obj.showEditor(true);
		obj.setFocus();
		
	// 데이터셋
	} else {
		if (this.gfnIsNotNull(obj.bindgrid)) {
			var gridobj = obj.bindgrid;
			gridobj.setCellPos(gridobj.getBindCellIndex("Body", bindcolumid));
			gridobj.showEditor(true);
			gridobj.setFocus();
		}
	}
};

/**
* @class 정합성 체크 오류시 변경된 ERROR 스타일 원복 처리
* @param  {Object} validationarg - Dataset/Grid 목록
* @return N/A
*/
pForm.gfnResetValidationCss = function(validationarg)
{
   for(var m=0;m<validationarg.length;m++) {
       var dataset;

       // 데이터셋
       if (validationarg[m] instanceof Dataset) {
           dataset = validationarg[m];
       // 그리드
       } else if (validationarg[m] instanceof Grid) {
           dataset = validationarg[m].getBindDataset();
       } else{
           continue;
       }

       // 해당 데이터셋을 바인딩하는 Component에 대해 cssclassr값을 원래 값으로 복원
       for(var j=0;j<this.binds.length;j++) {
           var sBindDs = this.binds[j].datasetid;
           if(this.gfnIsNull(sBindDs)==true) continue;

           if (eval("this."+this.binds[j].datasetid) == dataset) {
               try {
                   var targetobj  = eval("this."+this.binds[j].compid);
                   if( targetobj.cssclass.indexOf("Error") != -1 ) {
                       targetobj.set_cssclass(targetobj.orgcssclass);
                       targetobj.orgcssclass = "";
                   }
               } catch(e) { }
           }
       }
   }
};

/**
* @class 한글의 은(는) 이(가) 을(를)에 대한 메세지처리를 초정/중성/종성의 갯수로 파악해서 처리한다.
* @param {String} itemName - 대상 한글
* @param {String} option - 접미사
* @return {String} 완성형 메세지
*/
pForm.gfnGetKoreanTarget = function(itemName, option)
{
   if (option == "은(는)") {
       if (itemName[itemName.length-1].toKorChars().length == 2) {
           return itemName+"는";
       } else {
           return itemName+"은";
		}
   } else if (option == "이(가)") {
       if (itemName[itemName.length-1].toKorChars().length == 2) {
           return itemName+"가";
       } else {
           return itemName+"이";
		}
   } else if (option == "을(를)") {
       if (itemName[itemName.length-1].toKorChars().length == 2) {
           return itemName+"를";
       } else {
           return itemName+"은";
		}
   } else {
        itemName;
   }
};

/**
* @class      	문자열(한글)의 초성/중성/종성의 정보를 가져온다.
* @return 		{Array} 초성/중성/종성의 갯수만큼을 Array 배열로 리턴한다.
*/
String.prototype.toKorChars = function()
{
   var cCho  = [ 'ㄱ', 'ㄲ', 'ㄴ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ' ],
       cJung = [ 'ㅏ', 'ㅐ', 'ㅑ', 'ㅒ', 'ㅓ', 'ㅔ', 'ㅕ', 'ㅖ', 'ㅗ', 'ㅘ', 'ㅙ', 'ㅚ', 'ㅛ', 'ㅜ', 'ㅝ', 'ㅞ', 'ㅟ', 'ㅠ', 'ㅡ', 'ㅢ', 'ㅣ' ],
       cJong = [ '', 'ㄱ', 'ㄲ', 'ㄳ', 'ㄴ', 'ㄵ', 'ㄶ', 'ㄷ', 'ㄹ', 'ㄺ', 'ㄻ', 'ㄼ', 'ㄽ', 'ㄾ', 'ㄿ', 'ㅀ', 'ㅁ', 'ㅂ', 'ㅄ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ' ],
       cho, jung, jong;

   var str = this,
       cnt = str.length,
       chars = [],
       cCode;

   for (var i = 0; i < cnt; i++) {
       cCode = str.charCodeAt(i);

		if (cCode == 32) { continue; }

       // 한글이 아닌 경우
       if (cCode < 0xAC00 || cCode > 0xD7A3) {
           chars.push(str.charAt(i));
           continue;
       }

       cCode  = str.charCodeAt(i) - 0xAC00;

       jong = cCode % 28; // 종성
       jung = ((cCode - jong) / 28 ) % 21 // 중성
       cho  = (((cCode - jong) / 28 ) - jung ) / 21 // 초성

       chars.push(cCho[cho], cJung[jung]);
		if (cJong[jong] !== '') { chars.push(cJong[jong]); }
   }

   return chars;
};

/**
* @class  정규표현식 검증
* @param {String} strValue
* @param {String} strRegExp
* @param {String} strFlags
* @return {Boolean}
*/
pForm.gfnIsRegExpType = function(itemValue, sOption)
{
	var pattern;
	switch(sOption) {
		case "Num":				    pattern = /^[0-9]*$/;  													break;
		case "Han":				    pattern = /^[가-힣]*$/;  												break;
		case "Eng":				    pattern = /^[a-zA-Z]*$/;  												break;
		//case "Url":                 pattern = "^[a-zA-Z0-9\\/.]*$"; 										break;
		//case "Email":			    pattern = "^[_a-z0-9-]+(.[_a-z0-9-]+)*@(?:\\w+\\.)+\\w+$";  			break;
		case "Email":			    pattern = /^([a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6})*$/;  		break;
		case "CellPhone":		    pattern = /^01(?:0|1|[6-9])[.-]?(\\d{3}|\\d{4})[.-]?(\\d{4})$/; 		break;
		//case "CellPhone":		    pattern = "/01[016789]-[^0][0-9]{2,3}-[0-9]{3,4}/"; 		break;
		case "Phone":			    pattern = /^\\d{2,3}[.-]?\\d{3,4}[.-]?\\d{4}$/; 						break;
		case "NumEng":			    pattern = /^[0-9a-zA-Z]*$/;  											break;
		case "EngHanSpace":		    pattern = /^[ a-zA-Z가-힣]*$/;  										break;
		case "NumEngHanSpace":	    pattern = /^[ 0-9a-zA-Z가-힣]*$/; 										break;
        case "NumEngHanSpaceMinus": pattern = /^[-, 0-9a-zA-Z가-힣]*$/;    								    break;
        case "NumEngHanSpaceSpa":   pattern = /^[/=().+-, 0-9a-zA-Z가-힣]*$/; 						        break;
		case "Reg":				    pattern = /\\d{6}[.-]?[1-4]\\d{6}/;  									break;
		case "IP":				    pattern = /([0-9]{1,3})\\.([0-9]{1,3})\\.([0-9]{1,3})\\.([0-9]{1,3})/;  break;
		case "Pass":			    pattern = /^[0-9a-zA-Z!@#$%^&*(),.?\\\":{}|<>]*$/; 					    break;
        case "YYYYMMDD":            pattern = /[0-9]{4}(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])/;		    break;
        case "YYYYMMDDHHMISS":      pattern = /[0-9]{4}(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])[0-9]{2}[0-9]{2}[0-9]{2}/;	break;
		default :
			this.gfnLog("정규표식이 존재 하지않는 type입니다.","info");
			return;
	}
	//var rtn = this.gfnIsRegExp(itemValue, pattern);;
	return pattern.test(itemValue);
}
// pForm.gfnIsRegExpType = function(itemValue, sOption)
// {
// 	var pattern;
// 	switch(sOption) {
// 		case "Num":				    pattern = "^[0-9]*$";  													break;
// 		case "Han":				    pattern = "^[가-힣]*$";  												break;
// 		case "Eng":				    pattern = "^[a-zA-Z]*$";  												break;
// 		//case "Url":                 pattern = "^[a-zA-Z0-9\\/.]*$"; 										break;
// 		//case "Email":			    pattern = "^[_a-z0-9-]+(.[_a-z0-9-]+)*@(?:\\w+\\.)+\\w+$";  			break;
// 		case "Email":			    pattern = "^([a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6})*$";  		break;
// 		case "CellPhone":		    pattern = "^01(?:0|1|[6-9])[.-]?(\\d{3}|\\d{4})[.-]?(\\d{4})$"; 		break;
// 		//case "CellPhone":		    pattern = "/01[016789]-[^0][0-9]{2,3}-[0-9]{3,4}/"; 		break;
// 		case "Phone":			    pattern = "^\\d{2,3}[.-]?\\d{3,4}[.-]?\\d{4}$"; 						break;
// 		case "NumEng":			    pattern = "^[0-9a-zA-Z]*$";  											break;
// 		case "EngHanSpace":		    pattern = "^[ a-zA-Z가-힣]*$";  										break;
// 		case "NumEngHanSpace":	    pattern = "^[ 0-9a-zA-Z가-힣]*$"; 										break;
//         case "NumEngHanSpaceMinus": pattern = "^[-, 0-9a-zA-Z가-힣]*$";    								    break;
//         case "NumEngHanSpaceSpa":   pattern = "^[/=().+-, 0-9a-zA-Z가-힣]*$"; 						        break;
// 		case "Reg":				    pattern = "\\d{6}[.-]?[1-4]\\d{6}";  									break;
// 		case "IP":				    pattern = "([0-9]{1,3})\\.([0-9]{1,3})\\.([0-9]{1,3})\\.([0-9]{1,3})";  break;
// 		case "Pass":			    pattern = "^[0-9a-zA-Z!@#$%^&*(),.?\\\":{}|<>]*$"; 					    break;
//         case "YYYYMMDD":            pattern = "[0-9]{4}(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])";		    break;
//         case "YYYYMMDDHHMISS":      pattern = "[0-9]{4}(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])[0-9]{2}[0-9]{2}[0-9]{2}";	break;
// 		default :
// 			this.gfnLog("정규표식이 존재 하지않는 type입니다.","info");
// 			return;
// 	}
// 	var rtn = this.gfnIsRegExp(itemValue, pattern);;
// 	return rtn;
// }

/**
* @class  정규표현식 오류시 메시지 생성
* @param  {String} title   : 컬럼명
* @param  {String} sOption : 정규표현식 type
* @return {string} message
*/
//NX1322	{0}은(는) 유효하지 않은 형식입니다.
//NX1326	{0}은(는) {1}만 입력 가능합니다.
//NX1311    {0}은(는) 유효하지 않은 날짜 형식입니다.
pForm.gfnGetRegExpMsg = function(title, sOption)
{
	var msg;
	switch(sOption) {
		case "Num":				    msg = this.gfnGetMessage("MSG1326",[title, "숫자"]);					break;
		case "Han":				    msg = this.gfnGetMessage("MSG1326",[title, "한글"]);					break;
		case "Eng":				    msg = this.gfnGetMessage("MSG1326",[title, "영문"]);  			 		break;
		case "Url":                 msg = this.gfnGetMessage("MSG1322",[title]);  			 				break;
		case "Email":			    msg = this.gfnGetMessage("MSG1326",[title, "이메일"]);  				break;
		case "CellPhone":		    msg = this.gfnGetMessage("MSG1322",[title]);  							break;
		case "Phone":			    msg = this.gfnGetMessage("MSG1322",[title]);  							break;
		case "NumEng":			    msg = this.gfnGetMessage("MSG1326",[title, "'숫자,영문자'"]); 			break;
		case "EngHanSpace":		    msg = this.gfnGetMessage("MSG1326",[title, "'공백,숫자,영문자'"]);  	break;
		case "NumEngHanSpace":	    msg = this.gfnGetMessage("MSG1326",[title, "'공백,숫자,영문자'"]); 	break;
        case "NumEngHanSpaceMinus": msg = this.gfnGetMessage("MSG1322",[title]);  			 				break;
        case "NumEngHanSpaceSpa":   msg = this.gfnGetMessage("MSG1322",[title]);  			 				break;
		case "Reg":				    msg = this.gfnGetMessage("MSG1322",[title]);							break;
		case "IP":				    msg = this.gfnGetMessage("MSG1322",[title]);  							break;
		case "Pass":			    msg = this.gfnGetMessage("MSG1322",[title]);  							break;
        case "YYYYMMDD":            msg = this.gfnGetMessage("MSG1311",[title]);  							break;
        case "YYYYMMDDHHMISS":      msg = this.gfnGetMessage("MSG1311",[title]);  							break;
	}

	return msg;
}

/************************************************************************************************
* Validation function List
************************************************************************************************/

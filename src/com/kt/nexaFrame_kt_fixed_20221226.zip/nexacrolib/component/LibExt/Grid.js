﻿/**
*  @FileName 	Grid.js 
*/
var pForm = nexacro.Form.prototype;

/**
* 1. grid object 관련 함수
*   - 
*   - 
* 2. grid head 관련 함수
*   - gfnCheckGridHeaderClick    : 그리드 헤더 전체선택, 전체선택해제
*   - 
* 3. grid body 관련 함수
*   - 
*   - 
* 4. grid cell 관련 함수
*   - gfnGridCellSetFocus        : grid cell focus처리 (alert callback용 또는 바로 호출 가능)
*   - 
* 5. grid summ 관련 함수
* 6. Grid 개인화 작업
* 9. 기타
*   - gfnGridSortClear           : 사용자가 grid header를 눌러 grid sort를 했을 경우 .. 이 sort했던 내용을 clear해주는 함수
*   - gfnGridSortClearNoneTarget : form안에 있는 모든 grid에서 대해서 grid sort가 적용된 grid에 대해서 clear 해줌
*   - gfnGridSortClearTarget     : grid sort가 적용된 grid에 대해서 clear 해줌
*   - gfnSetMaxlengthGrid       : grid.cell 에서 maxlength size만큼만 문자열 입력가능
*   - 
*/

/************************************************************************************************
* 1. grid object 관련 함수
************************************************************************************************/


/************************************************************************************************
* 2. grid head 관련 함수
************************************************************************************************/
/**
 * @class 그리드 헤더 전체선택, 전체선택해제
 * @param {Object} objGrid - 대상그리드
 * @param {Object} e	   - nexacro.GridClickEventInfo
 * @param {number} checkBoxBodyCell - checkbox가 존재 하는 body cell index (화면에서 하드코딩 해야 됨)
 * @param {string} checkColId - checkbox 컬럼 id
 * @return N/A
 * @example this.gfnCheckGridHeaderClick(obj, e, 0);
 */
pForm.gfnCheckGridHeaderClick = function(objGrid, e, checkBoxBodyCell, checkColId) 
{
	var objDS = objGrid.getBindDataset();
	checkColId = this.gfnIsNull(checkColId) ? "chk" : checkColId;
	
	if (e.cell == checkBoxBodyCell) {
		var chkVal;
		if (objGrid.getCellProperty("head", 0, 'text') != 1) {
			chkVal = 1;
		} else {
			chkVal = 0;
		}
		objGrid.setCellProperty("head", 0, 'text', chkVal);
		
		for (var i=0; i < objDS.rowcount; i++) {
			var displaytype = objGrid.getCellPropertyValue(i, checkBoxBodyCell, "displaytype");
			var edittype    = objGrid.getCellPropertyValue(i, checkBoxBodyCell, "edittype");
			if (displaytype == "checkboxcontrol" && edittype == "checkbox") objDS.setColumn(i, checkColId, chkVal);
		}
	}
}


/************************************************************************************************
* 3. grid body 관련 함수
************************************************************************************************/



/************************************************************************************************
* 4. grid cell 관련 함수
************************************************************************************************/
/**
 * @class grid cell focus처리 (alert callback용 또는 바로 호출 가능)
 *        함수를 호출 시 form variable에 값을 setting해야 됨
 *        주로 callback함수에서 사용
 * @param {Object} objGrid - 대상그리드
 * @return N/A
 * @example 
    1. alert 및 confirm창에서 callback으로 활용방법
	   this.fvFocusGrid  = this.grdEmp;
	   this.fvFocusRow   = 2;
	   this.fvFocusColId = "empNo";
	   this.gfnAlert("msg.server.error", "", "", "gfnGridCellSetFocus");
	2. 함수 바로 호출 방법
	   this.gfnGridCellSetFocus(this.grdEmp, 1, "empNo");
 */
pForm.gfnGridCellSetFocus = function()
{
	var objGrd, row, colId;
	//1. argument로 focus정보를 넘겨준 경우
	if (arguments.length == 3) {
		objGrd = arguments[0];
		row    = arguments[1];
		colId  = arguments[2];
		
	//2. alert, confirm() 함수 호출 시 callback함수로 호출 한 경우
	} else {
		objGrd = this.fvFocusGrid;
		row    = this.fvFocusRow;
		colId  = this.fvFocusColId;
	}
	
	//3. grid setfocus()처리
	var bindDs = objGrd.getBindDataset();
	bindDs.set_rowposition(row);
	var idx = objGrd.getBindCellIndex("body", colId)
	objGrd.setCellPos(idx);
	objGrd.showEditor(true);
	objGrd.setFocus();	
}


/************************************************************************************************
* 5. grid summ 관련 함수
************************************************************************************************/

/************************************************************************************************
* 6. Grid 개인화 작업 Start
************************************************************************************************/
/************************************************************************************************
** 개발 Step
*  1. onload 시점에 개인화하려는         Grid formats을   _dsPersonForm에 저장
*  2. onload시점에 db에 존재 하는 개인화된 Grid formats으로 _dsPersonDb으로 조회
*     - callback에서 Grid 개인화한 Formats이 존재 하면 Grid formats을 변경
*     - 만약, 업무변경으로 개발자가 Grid formats을 변경 했으면 db개인화된 formats을 사용하지 않는다.
*            그리고, 화면 formats으로 personFormats값을 변경해준다. (필)
*  3. close시점에 개인화한 Grid formats을 db에 저장 (_dsPersonForm)
** Grid개인화용 Datase
*  1. _dsPersonForm : onload시점에 Form에 존재 하는 초기 Grid formats 보존용 (initFormats column)
*  2. _dsPersonDb   : DB에 저장되어 있는 formats 조회용
*  3. _dsPersonForm : close시점에 사용자가 변경한  Grid formats 보존용(closeFormats column)
** 개발참고사항
*  1. grid.user Proeprty.uPersonFlag = true 로 추가한 grid만 개인화 함
*  2. form내부에 grid id는 unique해야 됨
*  3. grid의 format id는 1개만 가능
************************************************************************************************/

/**
* @class 개인화정보 초기화
*/
pForm.gfnPersonOnload = function(objForm)
{
	//1. 화면 Component순환
	//   - 현재 grid format 얻기 (_dsPersonForm)
	this.gfnPersonComp("onload", objForm, objForm);
	
	//2. db에 저장된 개인화정보 조회 (_dsPersonDb)
	this.gfnPersonTran(objForm, "view");
	
	//trace(this._dsPersonForm.saveXML());
}

/**
* @class 개인화정보 저장
*/
pForm.gfnPersonClose = function(objForm)
{
	//1. component 순환
	//   - 사용자가 grid formats을 변경한 grid formats만 얻기
	this.gfnPersonComp("close", objForm, objForm);
	
	//2. form close시점에 db에 저장
	var findRow = this._dsPersonForm.findRowExpr("closeFormats >= ' '");
trace('gfnPersonClose findRow->'+ findRow);
	if (findRow >= 0) {
		this.gfnPersonTran(objForm, "save");
	}
}

/**
* @class 화면 Component순환
* @param type - onload : 초기 grid format 얻기
*             - view   : db조회 후 db에 적용된 formats으로 화면 grid formats 변경
*             - close  : form close시점에 사용자가 변경한 formats 을 저장
*/
pForm.gfnPersonComp = function(type, objForm, subForm)
{
	var arrComp = subForm.components;
	var length  = arrComp.length;

	for (var i=0; i<length; i++) {
		if (arrComp[i] instanceof nexacro.Div) {
			if (this.gfnIsNull(arrComp[i].url)) {
				this.gfnPersonComp(type, objForm, arrComp[i].form);
			}
		} else if (arrComp[i] instanceof nexacro.Tab) {
			var nPages = arrComp[i].tabpages.length;

			for (var j=0; j<nPages;j++) {
				// URL로 링크된 경우에는 존재하는 경우에는 해당 링크된 Form Onload에서 처리하도록 한다.
				if (this.gfnIsNull(arrComp[i].tabpages[j].url)) {
					this.gfnPersonComp(type, objForm, arrComp[i].tabpages[j].form);
				}
			}
			
		} else if (arrComp[i] instanceof nexacro.Grid) {
			if (arrComp[i].uPersonFlag == "true") {
				//1. form onload
				if (type == "onload") {
					this.gfnPersonFormat(objForm, arrComp[i]);
					
				//2. form onload 후 db조회 후 callback
				//   - db에 저장된 formats 으로 grid formats 재 적용
				} else if (type == "view") {
					this.gfnPersonReplace(objForm, arrComp[i]);
				
				//3. form close시점에 dataset에 저장
				} else if (type == "close") {
					this.gfnPersonSave(objForm, arrComp[i]);
				}
			}
		}
	}
}

/**
* @class 화면 초기 grid format 얻기
*/
pForm.gfnPersonFormat = function(objForm, objGrd)
{
	//현재 화면에 존재 하는 Grid formats 값 저장
	if (this.gfnIsNull(objForm.all['_dsPersonForm'])) {
		var _dsPersonForm = new Dataset;
		objForm.addChild("_dsPersonForm", _dsPersonForm);
		objForm._dsPersonForm.addColumn("formId");
		objForm._dsPersonForm.addColumn("empId");
		objForm._dsPersonForm.addColumn("gridId");
		objForm._dsPersonForm.addColumn("initFormats");   //form onload시점에 formats
		objForm._dsPersonForm.addColumn("personFormats");     //db에 저장된 formats
		objForm._dsPersonForm.addColumn("closeFormats");  //form close 시점에 formats
	}
	
	var row = objForm._dsPersonForm.addRow()
	objForm._dsPersonForm.setColumn(row, "formId",  objForm.id);
	objForm._dsPersonForm.setColumn(row, "empId",   "empId");
	objForm._dsPersonForm.setColumn(row, "gridId",  objGrd.id);
	objForm._dsPersonForm.setColumn(row, "initFormats", nexacro.replaceAll(objGrd.getCurFormatString(), "\n", ""));
// trace("onload format &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& ");
// trace(nexacro.replaceAll(objGrd.getCurFormatString(), "\n", "");
}

/**
* @class db에 저장된 formats 으로 grid formats 재 적용
*/
pForm.gfnPersonReplace = function(objForm, objGrd)
{
	//1. 서버에 개인화된 formats없으면 return
	var findRow = this._dsPersonDb.findRow("gridId", objGrd.id);
	if (findRow <= -1) return;
		
	var personFormats = this._dsPersonDb.getColumn(findRow, "personFormats");
	if (this.gfnIsNull(personFormats)) return;
	
	//2 업무변경으로 개발자가 Grid formats을 변경 했으면 db개인화된 formats을 사용하지 않는다.
	//  화면 formats으로 personFormats값을 변경해준다.
	var initFormats = this._dsPersonDb.getColumn(findRow, "initFormats");
	var currFormats = nexacro.replaceAll(objGrd.getCurFormatString(), "\n", ""); 
	if (currFormats != initFormats) {
		personFormats = currFormats;
		
	//3. db에 저장된 formats 으로 grid formats 재 적용
	} else {
		objGrd.set_enableevent(false);
		objGrd.set_enableredraw(false);
		objGrd.set_formats(personFormats);
		objGrd.set_enableevent(true);
		objGrd.set_enableredraw(true);
	}
	
	//4. 개인화했던 formats을  close시점에 검증할 dataset에 보전
	var targetRow = this._dsPersonForm.findRow("gridId", objGrd.id);
	if (targetRow >= 0) {
		//this._dsPersonForm.setColumn(targetRow, "initFormats",   currFormats);
		this._dsPersonForm.setColumn(targetRow, "personFormats", personFormats);
	}
}

/**
* @class Grid formats이 달라진 경우 Save
*/
pForm.gfnPersonSave = function(objForm, objGrd)
{
	var closeFormats = nexacro.replaceAll(objGrd.getCurFormatString(), "\n", "");     //close시점에 formats
	
	var findRow       = objForm._dsPersonForm.findRow("gridId", objGrd.id);
	var initFormats   = objForm._dsPersonForm.getColumn(findRow, "initFormats");      //form초기 formats
	var personFormats = objForm._dsPersonForm.getColumn(findRow, "personFormats");    //db에 저장된 formats
	var ifFormats     = this.gfnIsExist(personFormats) ? personFormats : initFormats; //비교대상 formats
//trace("-----------------");
//trace('initFormats ->' + initFormats);
//trace('personFormats   ->' + personFormats);
//trace('closeFormats->' + closeFormats);
	if (closeFormats != ifFormats) {
trace('변경 -> ' + findRow);
		objForm._dsPersonForm.setColumn(findRow, "closeFormats", closeFormats);
	}
}

/**
* @class db에 저장된 개인화정보 조회 (_dsPersonDb)
* @param {form}   objForm - 업무화면 form
*        {string} type    - view : form onload시점에 db에 저장 된 grid formats 조회
*                         - save : form onlcose시점에 현재 grid formats 저장
*/
pForm.gfnPersonTran = function(objForm, type)
{
	if (type == "view") {
		//TO-DO : 플젝에 적용시 gdsTemp dataset 주석문장 해제 하고 script보정
		//1. grid 개인화 검색용 dataset
		//gdsTemp.clear();
		//gdsTemp.addColumn("formId");
		//gdsTemp.addColumn("empId");
		//gdsTemp.addRow(0);
		//gdsTemp.setColumn(0, "formId", objForm.id);
		//gdsTemp.setColumn(0, "empId",  "empId");
		
		//2. 서버에 존재 하는 Grid 초기 formats과 개인화된 formats을 받아올 dataset
		if (this.gfnIsNull(objForm.all['_dsPersonDb'])) {
			var _dsPersonDb = new Dataset;
			objForm.addChild("_dsPersonDb", _dsPersonDb);
		}
		
		var svcId	 = "gfnPersonTranView";
		var service	 = "";
		var inDs	 = "dsSearch=gdsTemp";
		var outDs	 = "_dsPersonDb=dsPerson";
		var callback = "gfnPersonCallback";
		var bLoadingImg = false;
		//TO-DO : 플젝에 적용시 주석문 해제 하고 다음줄은 삭제
		//this.gfnTransaction(svcId, service, inDs, outDs, null, callback, null, null, bLoadingImg);
		//(sSvcId, sService, sInDs, sOutDs, sArgs, sCallback, bAsync, bErrMute, bLoadingImg)
		this.gfnPersonCallback(svcId, "0", "");
	} else {
		var svcId	= "gfnPersonTranSave";
		var service	= "";
		var inDs	= "dsPerson=_dsPersonForm";
		var outDs	= "";
		var bLoadingImg = false;
		//TO-DO : 플젝에 적용시 주석문 해제
		//this.gfnTransaction(svcId, service, inDs, outDs, null, "none", null, null, bLoadingImg);
	}
}

/**
* @class db에 저장된 개인화정보 조회 callback
*/
pForm.gfnPersonCallback = function(svcId, errCd, errMsg)
{
	if( errCd < 0 ) { this.gfnAlertMsg(errMsg);	return; }
//trace("gfnPersonCallback->" + svcId);
	
	if (svcId == "gfnPersonTranView") {
//trace('gfnPersonCallback---');
		//TO-DO : 샘플이기 때문에 db조회가 안돼 강제로 insert 처리 - start [임시 script 삭제 필요]
		this._dsPersonDb.addColumn("formId");
		this._dsPersonDb.addColumn("empId");
		this._dsPersonDb.addColumn("gridId");
		this._dsPersonDb.addColumn("initFormats");    //초기 개발된 formats
		this._dsPersonDb.addColumn("personFormats");  //개인화한 formats
		
		this._dsPersonDb.addRow();
		this._dsPersonDb.setColumn(0, "formId",  "Personalization");
		this._dsPersonDb.setColumn(0, "empId",   "empId");
		this._dsPersonDb.setColumn(0, "gridId",  "grd00");
		this._dsPersonDb.setColumn(0, "initFormats", '<Format id="default"><Columns><Column size="80"/><Column size="80"/><Column size="80"/><Column size="80"/><Column size="80"/><Column size="80"/></Columns><Rows><Row band="head" size="24"/><Row band="body" size="24"/></Rows><Band id="head"><Cell col="0" row="0" text="가나다"/><Cell col="1" row="0" text="Column1"/><Cell col="2" row="0" text="abc"/><Cell col="3" row="0" text="Column3"/><Cell col="4" row="0" text="Column4"/><Cell col="5" row="0" text="Column5"/></Band><Band id="body"><Cell col="0" row="0" text="bind:Column0"/><Cell col="1" row="0" text="bind:Column1"/><Cell col="2" row="0" text="bind:Column2"/><Cell col="3" row="0" text="bind:Column3"/><Cell col="4" row="0" text="bind:Column4"/><Cell col="5" row="0" text="bind:Column5"/></Band></Format>');
		this._dsPersonDb.setColumn(0, "personFormats", '<Format id="default"><Columns><Column size="80"/><Column size="80"/><Column size="80"/><Column size="80"/><Column size="80"/><Column size="80"/></Columns><Rows><Row band="head" size="24"/><Row band="body" size="24"/></Rows><Band id="head"><Cell col="0" row="0" text="한글1aaaa"/><Cell col="1" row="0" text="한글2"/><Cell col="2" row="0" text="한글3"/><Cell col="3" row="0" text="Column3"/><Cell col="4" row="0" text="Column4"/><Cell col="5" row="0" text="Column5"/></Band><Band id="body"><Cell col="0" row="0" text="bind:Column0"/><Cell col="1" row="0" text="bind:Column1"/><Cell col="2" row="0" text="bind:Column2"/><Cell col="3" row="0" text="bind:Column3"/><Cell col="4" row="0" text="bind:Column4"/><Cell col="5" row="0" text="bind:Column5"/></Band></Format>');

// 		this._dsPersonDb.addRow();
// 		this._dsPersonDb.setColumn(1, "formId",  "Personalization");
// 		this._dsPersonDb.setColumn(1, "empId",   "empId");
// 		this._dsPersonDb.setColumn(1, "gridId",  "grd01");
// 		this._dsPersonDb.setColumn(1, "personFormats", '<Formats><Format id="default"><Columns><Column size="80"/><Column size="80"/><Column size="80"/><Column size="80"/><Column size="80"/><Column size="80"/></Columns><Rows><Row size="24" band="head"/><Row size="24"/></Rows><Band id="head"><Cell text="한글1aaaa"/><Cell col="1" text="한글2"/><Cell col="2" text="한글3"/><Cell col="3" text="Column3"/><Cell col="4" text="Column4"/><Cell col="5" text="Column5"/></Band><Band id="body"><Cell text="bind:Column0"/><Cell col="1" text="bind:Column1"/><Cell col="2" text="bind:Column2"/><Cell col="3" text="bind:Column3"/><Cell col="4" text="bind:Column4"/><Cell col="5" text="bind:Column5"/></Band></Format><Format id="format00"><Columns><Column size="80"/><Column size="80"/><Column size="80"/></Columns><Rows><Row size="24" band="head"/><Row size="24"/></Rows><Band id="head"><Cell text="aaa"/><Cell col="1" text="bbb"/><Cell col="2" text="ccc"/></Band><Band id="body"><Cell text="bind:Column0"/><Cell col="1" text="bind:Column1"/><Cell col="2" text="bind:Column2"/></Band></Format></Formats>');
		
// trace("view-------------------------");
// trace(this._dsPersonDb.saveXML());		
		
		//TO-DO end [임시 script 삭제 필요]
		
		
		
		//서버에 저장된 개인화 formats 으로 화면 format변경
		this.gfnPersonComp("view", this, this)
	} else if (svcId == "gfnPersonTranSave") {
		
	} 
}

/************************************************************************************************
* 6. Grid 개인화 작업 End
************************************************************************************************/




/************************************************************************************************
* 9. 기타
************************************************************************************************/
/**
 * @class 사용자가 grid header를 눌러 grid sort를 했을 경우 .. 이 sort했던 내용을 clear해주는 함수
 *          - 호출할 수 있는 곳 : 업무단 화면에서 [검색]버튼 클릭 시 호출 해주는 용도
 * 	var arrObjGrid = new Array();
	arrObjGrid[0] = this.grdGoodList;
	arrObjGrid[1] = this.grdDeptSale;
	//this.gfnSortClear(this, arrObjGrid);
	this.gfnGridSortClear(this);
 */
pForm.gfnGridSortClear = function(objForm, arrObjGrid)
{
	//1. grid를 지정하지 않았을 경우
	if (this.gfnIsNull(arrObjGrid)) {
		this.gfnGridSortClearNoneTarget(objForm);
		
	//2. grid를 지정했을 경우
	} else {
		this.gfnGridSortClearTarget(arrObjGrid);
	}
}

/**
 * @class form안에 있는 모든 grid에서 대해서 grid sort가 적용된 grid에 대해서 clear 해줌
 *         - grid를 지정하지 않았을 경우
 */
pForm.gfnGridSortClearNoneTarget = function(objForm) {
	var arrComp = objForm.all;
	for(var i=0; i<(arrComp.length); i++) {
 		if(arrComp[i] instanceof nexacro.NormalDataset) { 
			//dataset
		} else if(arrComp[i] instanceof nexacro.Grid) { 
			//grid
			this.gfnGridSortClearTarget([arrComp[i]]);
		} else if(arrComp[i] instanceof nexacro.Div) { 
			this.gfnGridSortClearNoneTarget(arrComp[i].form);
		} else if(arrComp[i] instanceof nexacro.Tab) { 
			for(var idx=0; idx<arrComp[i].getTabpageCount(); idx++) {
				this.gfnGridSortClearNoneTarget(arrComp[i].tabpages[idx].form);
			}
		} else {
			//etc component
		}
	}
}

/**
* @class grid sort가 적용된 grid에 대해서 clear 해줌
*         - grid를 지정했을 경우
*/
pForm.gfnGridSortClearTarget = function(arrObjGrid)
{
	for(var i=0; i<arrObjGrid.length; i++) {
		var orgDsKeystring = arrObjGrid[i]._orgDsKeystring;
		var objDs = arrObjGrid[i].getBindDataset();
		if (this.gfnIsExist(orgDsKeystring)) {
			this._gfnClearSortMark(arrObjGrid[i]);
			objDs.set_keystring(orgDsKeystring);
		} else if (orgDsKeystring == "none") {
			this._gfnClearSortMark(arrObjGrid[i]);  //_gfnClearSortMark()함수에서 keystring("")을 clear 해줌
		}
	}
}

/**
* @class grid.cell maxlength 처리
* @param {object} objGrd  : nexacro.Grid
* @param {String} colList : 컬럼리스트
* @param {object} val     : 현재 editing되고 있는 값
* @exam  this.gfnSetMaxlengthGrid(obj, "cd,nm", obj.getEditingValue());
*/
pForm.gfnSetMaxlengthGrid = function(objGrd, colList, val)
{
	var idx       = objGrd.getCellPos();
	var maxLength = objGrd.getCellProperty("body", idx, "editmaxlength");
	var posColId  = this.gfnGridGetBindColumnNameByIndex(objGrd, idx);
	colList  = "," + colList  + ",";
	posColId = "," + posColId + ",";
	if( colList.indexOf(posColId) < 0) return;
	if (maxLength <= 0 || this.gfnIsNull(maxLength)) return;
	if (this.gfnIsNull(val))                         return;

 	var newVal = this.gfnSubstrByte(val, maxLength);
 	if (val != newVal) {
		objGrd.setEditingValue(newVal);
 	}
};

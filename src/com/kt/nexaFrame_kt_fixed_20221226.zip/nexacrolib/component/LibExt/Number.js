var pForm = nexacro.Form.prototype;

/**
 * @class 문자형을 숫자형으로 변환<br>
 * @param {String} val - 문자형 값. 숫자형도 가능
 * @return {Number} 숫자형으로 return (값이 없으면 공백으로 return)
 */
pForm.gfnToNumber = function(val)
{
	if (this.gfnIsNull(val)) return "";
	
	return nexacro.toNumber(val);
}

/**
 * @class 문자형을 숫자형으로 변환 (Dataset에서 값을 받아 얻어서 처리)<br>
 * @param {Object} objDs - 작업용 Dataset
 * @param {number} row   - 값을 얻어올 row
 * @param {String} colId - 값을 얻어올 columnd id
 * @param {number} defVal - dataset에서 값이 null이면 return할 값
 * @return {Number} 숫자형으로 return (값이 없으면 공백으로 return)
 */
pForm.gfnToNumberDs = function(objDs, row, colId, defVal)
{
	var val = objDs.getColumn(row, colId);
	if (this.gfnIsNull(val)) return defVal;
	
	return nexacro.toNumber(val);
}


/**
 * @class 입력받은 Number에 컴마를 추가한다. 숫자 format지정<br>
 * @param {Number} nNumber - 숫자
 * @param {Number} [nDetail] - 반올림할 소숫점 이하의 자릿수.
 * @return {String} Comma 가 포함하고 있는 숫자
 */
pForm.gfnAppendComma = function(nNumber,nDetail)
{
	if (nNumber == null) {
		return "";
	}
	if (nDetail	== null) {
		nDetail	= 0;
	}
	
	nNumber = parseFloat(nNumber);
	nNumber = nexacro.round(nNumber, nDetail);
	
	var strNumber = new String(nNumber);
	var arrNumber = strNumber.split(".");
	var strFormatNum = "";
	var j = 0;
	
	for (var i = arrNumber[0].length - 1; i >= 0; i--) {
		if (i != strNumber.length && j == 3) {
			strFormatNum = arrNumber[0].charAt(i) + "," + strFormatNum;
			j = 0;
		} else {
			strFormatNum = arrNumber[0].charAt(i) + strFormatNum;
		}
		j++;
	}
	
	if (arrNumber.length > 1) {
		strFormatNum = strFormatNum + "." + arrNumber[1];
	}
	
	return strFormatNum;
};

/**
 * @class 컴마를 제거한다. <br>
 * @param {String} strValue - 컴마가 포함된 스트링
 * @return {String} 컴마가 제거된 스트링이 반환된다.
 */
pForm.gfnRemoveComma = function(strValue)
{
	return strValue.replace(/\,/g, "");
};

/**
 * @class 입력 문자열중 숫자값만 남긴다. <br>
 * @param {String} strValue - 입력문자열
 * @return {String} 숫자문자열
 */
pForm.gfnGetDigit = function(strValue)
{
	var regExp = new RegExp("\\D","g");
	var strRet = strValue.replace(regExp,"");

	return strRet;
};

/**
* @class  입력된 값이 Number 인지 확인하는 함수
* @param {String} value Number 인지 여부를 확인할 문장.
* @return {Integer} Number 일 때 TRUE, 아니면 FALSE를 Return 합니다.
*/
pForm.gfnIsDigit = function(value)
{
   if (typeof (value) != "number")
   {
      value = Number(value);
   }
   return !isNaN(value);
};

// pForm.gfnIsDigit = function(sNum)
// {
// 	var c;
// 	var point_cnt=0;
// 	var ret=true;
// 
// 	if ( this.gfnIsNull(sNum) )	return false;
// 
// 	for (var i=0; i<sNum.length; i++)
// 	{
// 		c = sNum.charAt(i);
// 		if (i == 0 && (c == "+" || c == "-"));
// 		else if (c >= "0" && c <= "9");
// 		else if (c == ".")
// 		{
// 			point_cnt++;
// 			if ( point_cnt > 1 )
// 			{
// 				ret = false;
// 				break;
// 			}
// 		}
// 		else
// 		{
// 			ret = false;
// 			break;
// 		}
// 	}
// 	return ret;
// };

/**
* @class 입력된 16진수를 10진수로 변환하는 함수
* @param {String} strVal - 16진수 문자열
* @return {Number} 10진수 숫자
*/
pForm.gfn16To10 = function(strVal)
{
	var n;
	n = (strVal).toString(10);
	
	return n;
};

/**
* @class 입력된 10진수를 16진수로 변환하는 함수 <br>
* @param {Number} nVal - 10진수
* @return {String} 16진수 문자열
*/
pForm.gfn10To16 = function(nVal)
{
	var n;
	n = (nVal).toString(16);

	return n;
};

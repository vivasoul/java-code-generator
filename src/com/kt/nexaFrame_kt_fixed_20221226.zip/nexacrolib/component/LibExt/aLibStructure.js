/*
	Component.js : dynamic component
				 , combo, edit, maskedit, TextArea, Static, Radio, CheckBox, 
				 , ListBox, Spin, GroupBox,  ImageViewer, ProgressBar
				 , Plugin, ListView, NxPivot
	Dataset.js   : Dataset
	Date.js      : Date Util, Calendar, 
	Div.js       : Div
	Excel.js     : Excel
	File.js      : FileDialog, FileDownload, FileDownTranfer
				   FileUpload, FileUpTransfer
	Frame.js     : Frame, Menu, PopupMenu, Tab, 
	Grid.js      : Grid
	Number.js    : Number
	OutComp.js   : 외부모듈 (External Component)
				   WebBrowser, webEditor, jSon, Chart, Report, Barcode, 보안
	Popup.js     : Popup, PopupDiv
	String.js    : String
	Transaction.js : Transactin, 공통코드 조회
	Util.js      : Utility, Message
	Validation.js : validation main
*/

/* javascript 중 좀더 쉽게 쓰는 비법 

   1. string_value.indexOf("ABC") -> string_value.includes("ABC") : boolean 값이 return되어 수월함
   2. array_value.indexOf("ABC")  -> 문법도 정상적인 문법임. 해당 배열요소 index가 return 됨



*/
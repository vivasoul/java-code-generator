var pForm = nexacro.Form.prototype;

/**
 * @class 정규식을 이용한 trim 구현 - 문자열 양 옆의 공백 제거 <br>
 * @param {String} sValue - 변경하려는 값
 * @return {String} 문자열
 */
pForm.gfnTrim = function(sValue)
{
    if (this.gfnIsNull(sValue)) {
		return "";
	}
	return nexacro.trim(sValue);
};

/**
 * @class 정규식을 이용한 trim 구현 - 문자열 전체의 공백 제거 <br>
 * @param {String} sValue - 변경하려는 값
 * @return {String} 문자열
*/
pForm.gfnTrimAll = function(sValue)
{
    var objValue = new String(sValue);
    var sRtnValue = "";
    var i;

    if (sValue != null) {
        for (var i = 0, s = objValue.length; i < s; i++ ) {
            if (objValue.charAt(i) != " ") {
                sRtnValue = sRtnValue + objValue.charAt(i);
            }
        }
    } else {
        return -1;
    }
    
    return sRtnValue;
};

/**
* @class 문자열의 좌측부터 지정한 길이만큼 가져오는 함수
* @param {String} sOrg - 원본 문자열
* @param {Number} nSize - 얻어올 크기. [Default Value = 0]
* @return {String} 문자열
*/
pForm.gfnLeft = function (sOrg, nSize)
{
	return new String(sOrg).substr(0, nSize);
}

/**
* @class 문자열의 우측부터 지정한 길이만큼 가져오는 함수 <br>
* @param {String} sOrg - 원본 문자열
* @param {Number} nSize - 출력될 문자열의 길이
* @return {String} 결과값
*/
pForm.gfnRight = function(sOrg, nSize)
{
	if (this.gfnIsNull(sOrg) || this.gfnIsNull(nSize)) {
		return "";
	}

	if (sOrg.length < nSize) {
		return sOrg;
	} else {
		return sOrg.substr(sOrg.length - nSize, nSize);
	}
};

/**
* @class 문자 전체 길이를 계산
* @param {String} sVal - 문자열
                  - 문자, 숫자, 특수문자 : 1 로 Count
                  - 그외 한글/한자 : 2 로 count 되어 합산 
* @return {Integer} Type에 따라 구해진 길이
*/
pForm.gfnLengthByte = function (sVal)
{
	var lengthByte = 0;

	if (this.gfnIsNull(sVal)) {
		return -1;
	}

	for (var i = 0, s = sVal.length; i < s; i++) {
		if (sVal.charCodeAt(i) > 127) {
			lengthByte += 2;
		} else {
			lengthByte += 1;
		}
	}

	return lengthByte;
}

/**
* @class unicode size방식으로 substring후 return
* @param {String} val - 문자열
* @param {number} len - 자르고 싶은 문자(unicode)수
*/
pForm.gfnSubstrByte = function(val, len)
{
	if (this.gfnIsNull(val)) return "";
	var byteLength = 0;
	for (var i = 0; i < val.length; i++) {
		var oneChar = escape(val.charAt(i));
		if ( oneChar.length == 1 ) 
		{
			byteLength ++;
		} else if (oneChar.indexOf("%u") != -1) {
			byteLength += 2;
		} else if (oneChar.indexOf("%") != -1) {
			byteLength += oneChar.length/3;
		}
		if(len < byteLength) 
		{
			var str = val.substr(0, i)
			return str;
		}
	}
	return val;
}


/**
 * @class 문자열의 위치를 대소문자 구별하여 거꾸로 부터 찾아 첫번째 나온 index 반환<br>
 * @param {String} sOrg - 원래 문자열( 예 : "aaBBbbccBB" )
 * @param {String} sFind - 찾고자 하는 문자열( 예 : "BB" )
 * @param {Number} nStart - 검색 시작위치 (옵션 : Default=문자열의 끝 )
 * @return {Number}
 * @example
 * var nPos = this.gfnPosReverse("aaBBbbccBB", "BB"); <br>
 * 성공 = 찾고자 하는 문자열의 시작위치 ( 예 : 8 ) <br>
 * 실패 = -1 <br>
 */
pForm.gfnPosReverse = function (sOrg, sFind, nStart)
{
	var pos;

	if (this.gfnIsNull(sOrg) || this.gfnIsNull(sFind)) {
		return -1;
	}
	if (this.gfnIsNull(nStart)) {
		nStart = sOrg.length - 1;
	}

	for (pos = nStart; pos >= 0; pos--) {
		if (sOrg.substr(pos, sFind.length) == sFind) {
			break;
		}
	}

	return pos;
};


/**
* @class 특수문자를 제거한다 <br>
* @param {String} strValue
* @return {String} 특수문자를 제거한 문자열
*/
pForm.gfnRemoveSpecialChar = function(strValue)
{
   var strSpecial = "~!@#$%^&*-+./=_`{|}()\\?<>";
   
   for (var i = 0, s = strValue.length; i < s; i++) {
		for (var j = 0, t = strSpecial.length; j < t; j++) {
			if (strValue.charAt(i) == strSpecial.charAt(j)) {
				strValue = strValue.replace(strValue.charAt(i), "");
			}
		}
	}

   return strValue;
};

/** 
 * @class HTML TAG 제거 함수 <br>
 * @param {String} sHtml - 제거대상 문자열
 * @param {String} sTag - 제거할 tag(없으면 전체 tag제거)
 * @return {String}
 * @example
 * var str = this.gfnRemoveHtmlTag("정상적으로<BR>처리되었습니다.");
 */
pForm.gfnRemoveHtmlTag = function(sHtml, sTag)
{
	if (this.gfnIsNull(sTag)) {
	    sHtml = nexacro.replaceAll(sHtml, "<br>", "\n");	
		sHtml = nexacro.replaceAll(sHtml, "<BR>", "\n");	
	    var regExp = new RegExp("<(/)?([0-9a-zA-Z]*)(\\s[0-9a-zA-Z]*=[^>]*)?(\\s)*(/)?>", "g"); 
	    sHtml = sHtml.replace(regExp, "");
	} else if(sTag.toUpperCase() == "<BR>") {
	    sHtml = nexacro.replaceAll(sHtml, "<br>", "\n");	
		sHtml = nexacro.replaceAll(sHtml, "<BR>", "\n");	
	} else {
	    sHtml = nexacro.replaceAll(sHtml, sTag.toUpperCase(), "");	
		sHtml = nexacro.replaceAll(sHtml, sTag.toLowerCase(), "");	
	}
	return sHtml;
};




/**
 * 문자열 길이 계산.
 * @param {string} str 대상 문자열.
 * @param {string=} unit 문자열의 길이를 검사하는 단위 . 
				   "utf16" - 한문자당 1의 값으로 합산함(default).
				   "utf8"  - 한 문자당 영문1, 다국어 2~5의 값으로 합산함.
				   "ascii" - 한문자당 영문 1, 한글 2의 값으로 합산함.
 * @return {number} 문자열 길이.
 * @example
 * var str = "unit 문자열";
 * var len = this.gfnGetLength(str);
 * trace(len); // output : 8
 * len = this.gfnGetLength(str, "ascii");
 * trace(len); // output : 11
 * len = this.gfnGetLength(str, "utf8");
 * trace(len); // output : 14
 * @memberOf this
 */	 		 
pForm.gfnGetLength = function(str, unit)
{
	if ( !str ) return 0;
	
	var pThis = this;
	
	if ( unit == "utf8" )
	{
		return pThis._utf8ByteCount(str);
	}
	else if ( unit == "ascii" )
	{
		return pThis._asciiByteCount(str);
	}
	else
	{
		return str.length;
	}
}

/**
 * utf8을 기준으로 문자열 길이계산.
 * @private
 * @param {string} str 대상 문자열.
 * @return {number} 문자열 길이.
 * @memberOf this
 */	 		 
pForm._utf8ByteCount = function(str)
{
	if (str === undefined) return 0;
	
	var pThis = this;
	var count = 0,
		ch,
		high,
		low,
		isHighSurrogate = pThis._isHighSurrogate,
		utf8Len = pThis._utf8Len,
		toCodepoint = pThis._toCodepoint;

	for(var i=0, n = str.length; i< n; i++) 
	{
		ch = str.charCodeAt(i);
		
		if(isHighSurrogate(ch)) 
		{
			high = ch;
			low = str.charCodeAt(++i);
			count += utf8Len(toCodepoint(high, low));
		} 
		else 
		{
			count += utf8Len(ch);
		}
	}
	return count;
} 	

/**
 * ascii를 기준으로 문자열 길이계산.
 * @private
 * @param {string} str 대상 문자열.
 * @return {number} 문자열 길이.
 * @memberOf this
 */	 		 
pForm._asciiByteCount = function(str)
{
	if (str === undefined) return 0;
	
	var i, j=0, val; 
	for(i=0, n = str.length; i< n; i++) 
	{ 
		val = str.charCodeAt(i);
		if ( val > 255 ) j++;
		j++; 
	}
	return j;
}

/**
 * uft8 문자열 길이계산.
 * @private
 * @param {string} codePoint 문자셋 수치보정값.
 * @return {number} 문자열 길이.
 * @memberOf this
 */	 		 
pForm._utf8Len = function(codePoint)
{
	if(codePoint >= 0xD800 && codePoint <= 0xDFFF)
	{
		trace("Illegal argument: "+codePoint);
	}
	if(codePoint < 0)
	{
		trace("Illegal argument: "+codePoint);
	}
	if(codePoint <= 0x7F) return 1;
	if(codePoint <= 0x7FF) return 2;
	if(codePoint <= 0xFFFF) return 3;
	if(codePoint <= 0x1FFFFF) return 4;
	if(codePoint <= 0x3FFFFFF) return 5;
	if(codePoint <= 0x7FFFFFFF) return 6;

	trace("Illegal argument: "+codePoint);
}

/**
 * 유니코드 보충언어판(Supplementary Plane)의 상위 대행코드(High Surrogate) 여부.
 * @private
 * @param {string} codeUnit 확인 할 문자.
 * @return {boolean} 상위 대행코드(High Surrogate) 여부.
 * @memberOf this
 */	 		 
pForm._isHighSurrogate = function(codeUnit)
{
	return codeUnit >= 0xD800 && codeUnit <= 0xDBFF;
}

/**
 * 유니코드 보충언어판(Supplementary Plane)의 하위 대행코드(Low Surrogate) 여부.
 * @private
 * @param {string} codeUnit 확인 할 문자.
 * @return {boolean} 하위 대행코드(Low Surrogate) 여부.
 * @memberOf this
 */	 		 
pForm._isLowSurrogate = function(codeUnit)
{
	return codeUnit >= 0xDC00 && codeUnit <= 0xDFFF;
}

/**
 * 문자셋의 수치보정값 처리
 * @private
 * @param {number} highCodeUnit 상위 대행코드.
 * @param {number} lowCodeUnit 하위 대행코드.
 * @return {number} 문자셋의 수치보정값
 * @memberOf this
 */
pForm._toCodepoint = function(highCodeUnit, lowCodeUnit)
{
	var pThis = this;
	
	if(!pThis._isHighSurrogate(highCodeUnit))
	{
		trace("Illegal argument: "+highCodeUnit);
	}
	if(!pThis._isLowSurrogate(lowCodeUnit))
	{
		trace("Illegal argument: "+lowCodeUnit);
	}
	highCodeUnit = (0x3FF & highCodeUnit) << 10;
	var u = highCodeUnit | (0x3FF & lowCodeUnit);
	return u + 0x10000;	 	
}


pForm.gfnURLEncode = function(sStr)
{
	var strSpecial=";,/?:@&=+$-_.!~*'()#";//"!\"#$%&'()*+,/:;<=>?[]^`{|}~%"; 
    var i, acode, cchr;

    var URLEncode = "";
    var sbuff = new Buffer(sStr, "EUC_KR");
    for(var i = 0; i <  sbuff.length; i++) {
        cchr = sbuff.getText(i, 1);
        acode = sbuff.getByte(i);//.charCodeAt(i);	//Asc(Mid(URLEncode, i, 1))
        if( (strSpecial.indexOf(cchr) != -1 && cchr != "") 
			|| (acode >=48 && acode <=57) || (acode >= 65 && acode <=90) 
			|| (acode >= 97 && acode <=122) ) {
			URLEncode += cchr;
        } else if(acode == 32) {
			URLEncode += "+";
		} else {
            URLEncode += "%" + acode.toString(16);
        }
    }    
    return URLEncode;
}
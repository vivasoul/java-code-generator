# OYWMS

## 기술 스택
* Oracle OpenJdk 11 (build 11+28) https://jdk.java.net/java-se-ri/11
* Spring Boot 2.7.7
* Gradle 7.6
* MyBatis
* Lombok
* JUnit 5
* Logback
* Springdoc-openapi (Swagger)

## commit 메세지 작성 방법
```
feat: 새 기능(new feature for the user, not a new feature for build script)
fix: 버그 픽스(bug fix for the user, not a fix to a build script)
docs: 문서수정(changes to the documentation)
style: 스타일 변경(formatting, missing semi colons, etc; no production code change)
refactor: 리팩토링(refactoring production code, eg. renaming a variable)
test: 테스트(adding missing tests, refactoring tests; no production code change)
chore: 그외 잡무(updating grunt tasks etc; no production code change)
```

## 개발 주의 사항
```
1. @Autowired 주입대신 생성자 주입 사용
2. 선언적 트랜잭션 사용
3. Value Object implements Serializable (serialVersionUID IDE에서 자동추가기능 활용)  
```
## Controller, Service 메서드명 규칙
```
- 조회(단건,다건) : get*
- 저장(신규,수정) : save*
- 삭제 : delete*
- 엑셀 : excel*
- 출력 : print*


ex) 코드관리
1. 조회
  - 마스터 : getCode
  - 디테일 : getCodeDetail

2. 저장
  - 마스터 : saveCode
  - 디테일 : saveCodeDetail

3. 삭제
  - 마스터 : deleteCode
  - 디테일 : deleteCodeDetail

4. 엑셀 : excelCode
5. 출력 : printCode
```

## Mapper 메서드명 규칙
```
1. 조회 : select*
2. 신규 : insert*
3. 수정 : update*
4. 삭제 : delete* (UPDATE문 실행)
```



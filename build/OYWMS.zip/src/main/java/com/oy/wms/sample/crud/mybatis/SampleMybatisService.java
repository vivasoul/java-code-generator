package com.oy.wms.sample.crud.mybatis;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@RequiredArgsConstructor
//@Transactional
@Service
@Slf4j
public class SampleMybatisService {

    private final SampleMybatisMapper mapper;

    public List<Vo> getList(Vo searchVo) {
        return mapper.getList(searchVo);
    }

    @Transactional
    public void put(Vo vo) {
        mapper.put(vo);
    }

    @Transactional
    public void set(Vo vo) {
        mapper.set(vo);
    }

    @Transactional
    public void del(int sampleSn) {
        mapper.del(sampleSn);
    }

    public Vo get(int sampleSn) {
        return mapper.get(sampleSn);
    }
}

package com.oy.wms.baim.sample;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.java.xapi.data.DataSet;
import com.nexacro.java.xapi.data.PlatformData;
import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.config.exception.NexacroBizException;
import com.oy.wms.baim.sample.vo.SampleVO;
import com.oy.wms.login.vo.LoginVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/sample")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Sample", description = " 등록/조회/수정/삭제")
public class SampleController {
//	@Resource(name = "sampleService")
	private final SampleService sampleService;
	
	@PostMapping("/plusOneEachRow.do")
	public NexacroResult testView(PlatformData platformData, Model model) {
		
		NexacroResult nexacroResult = new NexacroResult();
		try {
			DataSet dsInput = platformData.getDataSet("dsInput");
			DataSet dsOutput = new DataSet("dsOutput");
			
			dsInput.copyTo(dsOutput, false);
			
			int rowCnt = dsInput.getRowCount();
			for(int i=0; i<rowCnt; i++) {
				int nIdx = dsOutput.newRow();
				dsOutput.set(nIdx, "rowIdx", dsInput.getInt(i, "rowIdx"));
				dsOutput.set(nIdx, "value", dsInput.getInt(i, "value")+1);
			}
			
			nexacroResult.addDataSet(dsOutput);
		} catch(Exception e) {
			nexacroResult.setErrorCode(-999);
			nexacroResult.setErrorMsg(e.getMessage());
		}
		return nexacroResult;
	}

	@Operation(summary = "Sample 목록 조회", description = "목록을 조회합니다")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "목록조회성공")
			, @ApiResponse(responseCode = "404", description = "존재하지 않는 리소스접근")
	})
	@PostMapping("/selectData.do") 
	public NexacroResult selectData(@ParamDataSet(name = "dsSearch",required = false) SampleVO input) {
		NexacroResult result = new NexacroResult();
		try {
			List<SampleVO> dsOutput = sampleService.selectSome("");
			
			result.addDataSet("dsList", dsOutput);
		} catch(Exception e) {
			result.setErrorCode(-999);
			result.setErrorMsg(e.getMessage());
		}
		return result;
	}
	
	@PostMapping("/insertData.do") 
	public NexacroResult insertData(@ParamDataSet(name = "dsList") List<SampleVO> dsList) {
		NexacroResult nexacroResult = new NexacroResult();
		try {
			if(!dsList.isEmpty()) {
				sampleService.insertRow(dsList.get(0));
			} else {
				log.warn("No data available");
			}
		} catch(Exception e) {
			nexacroResult.setErrorCode(-999);
			nexacroResult.setErrorMsg(e.getMessage());
		}
		return nexacroResult;
	}
	
	@PostMapping("/updateData.do") 
	public NexacroResult updateData(@ParamDataSet(name = "dsList") List<SampleVO> dsList) {
		NexacroResult nexacroResult = new NexacroResult();
		try {
			if(!dsList.isEmpty()) {
				sampleService.updateRow(dsList.get(0));
			} else {
				log.warn("No data available");
			}			

		} catch(Exception e) {
			nexacroResult.setErrorCode(-999);
			nexacroResult.setErrorMsg(e.getMessage());
		}
		return nexacroResult;
	}
	
	@PostMapping("/deleteData.do") 
	public NexacroResult deleteData(@ParamDataSet(name = "dsList") List<SampleVO> dsList) {
		NexacroResult nexacroResult = new NexacroResult();
		try {
			if(!dsList.isEmpty()) {
				sampleService.deleteRow(dsList.get(0));
			} else {
				log.warn("No data available");
			}	
		} catch(Exception e) {
			nexacroResult.setErrorCode(-999);
			nexacroResult.setErrorMsg(e.getMessage());
		}
		return nexacroResult;
	}	
	
	@PostMapping("/mergeData.do")
	public NexacroResult mergeData(@ParamDataSet(name = "dsList") List<SampleVO> dsList, @ParamDataSet(name = "dsList") SampleVO firstRow) throws Exception{
		NexacroResult result = new NexacroResult();
		
		System.out.println("firstRow text = "+firstRow.getTxt());
		if(!dsList.isEmpty()) {
			//sampleService.aopTest(parameters);
			
			System.out.println(dsList);
			sampleService.mergeRows(dsList);
		} else {
			log.warn("No data available");
			throw new NexacroBizException(-1);
		}			
		
		return result;
	}
	
	
	/*
	 * Nexa-Mybatis 연동
	 * 0. DataSet.ROW_TYPE 프로퍼티 관련항여..(매우 중요!!!)
	 * 		- INSERT/UPDATE/DELETE 동작 수행을 위한 DataSetRowType 값을 제대로 얹혀서 서버로 받으려면
	 * 		  클라이언트에서 dataSet실어 보낼 때 ":U" suffix를 붙여줘야 한다.
	 * 		- ex) this.gfnTransaction(..., "dsInput=dsInput:U", ...);
	 * 	
	 * 1. input 처리 관련 
	 *  1-1. @ParamDataSet(name = "") 이용한 파라미터 바인딩(nexa에서 input용으로 넘긴 DataSet만 바인딩 가능) 
	 *  	- List<Map<String, Object>> 타입으로 바인딩 한다.
	 *  	- ex)  someMethod( @ParamDataSet(name = "dsInput ") List<Map<String, Object>> dsInput, ...)
	 *  	- DataSet이 검색조건과 같이 하나의 row만 존재한다면, Map<String, Object>로 받을 수도 있다.(첫번쨰 열의 정보만 가지고있음)
	 *  
	 *  1-2. @ParamVariable(name="") 이용한 파라미터 바인딩 (nexa에서 sArgs로 넘긴 값들만 바인딩 가능)
	 *  	- Java 기본 자료형 및 그 외 POJO 타입으로 반환가능
	 *  	- ex)  someMethod( @ParamVariable(name="productId") String productId, ...)
	 *  
	 *  1-3. PlatformData 타입을 향한 파라미터 바인딩 
	 *  	- 단순히 PlatformData 자료형의 파라미터를 선언하면 된다.
	 *  	- ex)  someMethod( PlatformData platformData, ...)
	 * 
	 * 2. output 처리 관련
	 * 	nexacroResult 인스턴스 생성 후
	 *  반환된 List<Map<String, Object>> 타입의 데이터를 
	 *  addDataSet 메소드 호출에 넣어주면 된다.
	 * 
	 */
	
	private void setUserId(SampleVO vo) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		vo.setRegUserId(userId);
		vo.setModiUserId(userId);
	}
}

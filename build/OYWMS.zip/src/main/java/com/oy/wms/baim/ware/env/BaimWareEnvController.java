package com.oy.wms.baim.ware.env;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/baim/ware/env")
public class BaimWareEnvController {
	
	private final BaimWareEnvService baimWareEnvService;
	
	/**
	 * 창고환경정보관리 목록 조회
	 */
	@PostMapping("/getBaimWareEnvList") 
	public NexacroResult getBaimWareEnvList(@ParamDataSet(name = "dsSearch",required = false) BaimWareEnvVO input) {
		NexacroResult result = new NexacroResult();
		List<BaimWareEnvVO> dsOutput = baimWareEnvService.getBaimWareEnvList("");
		result.addDataSet("dsList", dsOutput);
		return result;
	}
	
	/**
	 * 창고환경정보관리 저장
	 */
	@PostMapping("/saveBaimWareEnvList")
	public NexacroResult saveBaimWareEnvList(@ParamDataSet(name = "dsList") List<BaimWareEnvVO> dsList) throws Exception{
		NexacroResult result = new NexacroResult();
		int res = baimWareEnvService.saveBaimWareEnvList(dsList);
		if(res < 1) {
			result.setErrorCode(-1);
		}
		
		return result;
	}
	
	/**
	 * 창고환경정보관리 삭제
	 */
	@PostMapping("/deleteBaimWareEnvList")
	public NexacroResult deleteBaimWareEnvList(@ParamDataSet(name = "dsList") List<BaimWareEnvVO> data) throws Exception {

		NexacroResult result = new NexacroResult();
		int res = baimWareEnvService.deleteBaimWareEnvList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
}

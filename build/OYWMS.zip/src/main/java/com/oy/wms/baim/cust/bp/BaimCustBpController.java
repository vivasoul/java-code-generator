package com.oy.wms.baim.cust.bp;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.login.vo.LoginVO;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/baim/cust/bp")
public class BaimCustBpController {
	
	private final BaimCustBpService baimCustBpService;
	
	/**
	 * 고객사별 거래처관리 목록 조회
	 */
	@PostMapping("/getCustBpList")
	public NexacroResult getCustBList(@ParamDataSet(name = "dsSearch") BaimCustBpVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimCustBpVO> list =  baimCustBpService.selectCustBpList(input);
		result.addDataSet("dsList", list);
		
		return result;
	}
	
	/**
	 * 고객사별 거래처관리 추가,수정
	 */
	@PostMapping("/saveCustBpList")
	public NexacroResult saveCustBpList(@ParamDataSet(name = "dsList") List<BaimCustBpVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		setUserId(data);
		int res = baimCustBpService.saveCustBpList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}
		return result;
	}
	
	/**
	 * 고객사별 거래처관리 삭제
	 */
	@PostMapping("/deleteCustBpList")
	public NexacroResult deleteCustBpList(@ParamDataSet(name = "dsList") List<BaimCustBpVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		setUserId(data);
		int res = baimCustBpService.deleteCustBpList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}
		return result;
	}
	
	/**
	 * 사용자 세팅
	 */
	private void setUserId(List<BaimCustBpVO> vo) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		
		for(BaimCustBpVO row : vo) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}
	
}

package com.oy.wms.syst.user.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SysUserConnHVO {
	private String connHistSeq;
	private String userId;
	private String userNm;
	private String logCont;
	private String connIpAddr;
	private String connDivCd;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private String adminYn;
}

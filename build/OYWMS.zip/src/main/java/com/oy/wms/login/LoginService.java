package com.oy.wms.login;

import java.util.List;

import org.springframework.stereotype.Service;

import com.oy.config.exception.NexacroBizException;
import com.oy.wms.login.vo.CodeVO;
import com.oy.wms.login.vo.LoginVO;
import com.oy.wms.login.vo.MenuVO;

import lombok.RequiredArgsConstructor;

@Service("loginService")
@RequiredArgsConstructor
public class LoginService {
	
	private final LoginMapper loginMapper;
	
	private final int MAX_ERR_CNT = 5;
	
	/**
	 * 로그인 작업 수행
	 * */
	/* throws LoginFailureException or NexacroBizException */
	public LoginVO actionLogin(LoginVO loginVO) throws Exception {
		/* 0. validate the userVO */
		String userId = loginVO.getUserId();
		
		/* 1. load a user data */
		LoginVO userVO = loginMapper.selectUser(userId);
		
		/* 2. check user authentication */
		if(userVO == null) {
			/* could not find the user information */
			throw new NexacroBizException(-100);
			
		} else if(userVO.getPwdErrCnt() > MAX_ERR_CNT) {
			/* exceed a login-failure count */
			throw new NexacroBizException(-101);
			
		} else if (!loginVO.getPwd().equals(userVO.getPwd())) {
			/* password not matched */
			loginMapper.upadtePwdErrCnt(userId);
			throw new NexacroBizException(-102);
			
		} else {
			
			/* 3. check temp-password */
			if ("Y".equals(userVO.getTempPwdModiYn())) {
				
			} else {
				/* 4. check the user-login duplicated? */	
				
			}
			userVO.setPwd(null);
		}
		/* write a log on success? or failure too..? */
		
		return userVO;
	}	
	
	/**
	 * 메뉴정보 조회
	 * */	
	public List<MenuVO> getMenu(String userId) {
		
		return loginMapper.selectMenu(userId);
	}
	
	/**
	 * 코드정보 조회
	 * */	
	public List<CodeVO> getCode() {
		
		return loginMapper.selectCode();
	}
}

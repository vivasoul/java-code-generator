package com.oy.wms.syst.hist;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oy.config.mvc.Parameters;
import com.oy.wms.syst.hist.vo.PrgmErrHistVO;
import com.oy.wms.syst.hist.vo.PrgmUseHistVO;

import lombok.extern.slf4j.Slf4j;

@Service("systHistService")
@Slf4j
public class SystHistService {

	@Autowired
	private SystHistMapper systHistMapper;
	
	/**
	 * 프로그램사용이력 조회
	 */
	public List<PrgmUseHistVO> getPrgmUseHist(PrgmUseHistVO input) throws Exception {
		//dsIn = dsCond
		//dsOut = dsOut
		
		return systHistMapper.selectPrgmUseHist(input);
	}

	/**
	 * 프로그램사용이력 추가
	 */
	public int insertPrgmUseHist(PrgmUseHistVO vo) {
		
		int res = systHistMapper.insertPrgmUseHist(vo);
				
		return res;
	}
	
	/**
	 * 프로그램오류이력 조회
	 */
	public List<PrgmErrHistVO> getPrgmErrHist(PrgmErrHistVO input) throws Exception {
		//dsIn = dsCond
		//dsOut = dsOut		
		
		return systHistMapper.selectPrgmErrHist(input);
	}
	
	/**
	 * 프로그램오류이력 추가
	 */
	public int insertPrgmErrHist(PrgmErrHistVO vo) {
		
		int res = systHistMapper.insertPrgmErrHist(vo);
		
		return res;
	}		
}

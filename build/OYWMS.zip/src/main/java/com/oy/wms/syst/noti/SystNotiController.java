package com.oy.wms.syst.noti;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.config.mvc.Parameters;
import com.oy.wms.baim.strt.set.aloc.BaimAlocStrtVO;
import com.oy.wms.login.vo.LoginVO;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/syst/noti")
public class SystNotiController {

	private final SystNotiService systNotiService;
	
	/**
	 * 공지사항 조회
	 */
	@PostMapping("/getNoti")
	public NexacroResult getNoti(@ParamDataSet(name = "dsSearch") SystNotiVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		List<SystNotiVO> list =  systNotiService.getNoti(input);
		result.addDataSet("dsList", list);		
		
		return result;
	}
	
	/**
	 * 공지사항 저장
	 */
	@PostMapping("/saveNoti")
	public NexacroResult saveNoti(@ParamDataSet(name = "dsList") List<SystNotiVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserId(data);
		int res = systNotiService.saveNoti(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;		
	}
	
	/**
	 * 공지사항 삭제
	 */
	@PostMapping("/deleteNoti")
	public NexacroResult deleteNoti(@ParamDataSet(name = "dsList") List<SystNotiVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserId(data);
		int res = systNotiService.deleteNoti(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}				
		
		return result;
	}
	
	private void setUserId(List<SystNotiVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(SystNotiVO vo : data) {
			vo.setRegUserId(userId);
			vo.setModiUserId(userId);
		}
	}
}

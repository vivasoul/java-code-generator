package com.oy.wms.baim.strt.set.lotcrt;


import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.baim.strt.set.dist.BaimDistStrtVO;
import com.oy.wms.login.vo.LoginVO;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/baim/strt/crt")
public class BaimLotCrtStrtController {
	
	private final BaimLotCrtStrtService baimLotCrtStrtService;
		
	/**
	 * 로트생성전략 조회
	 */
	@PostMapping("/getStrategies")
	public NexacroResult getLotCreationStrategy(@ParamDataSet(name = "dsSearch") BaimLotCrtStrtVO dsIn) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimLotCrtStrtVO> list =  baimLotCrtStrtService.getLotCreationStrategy(dsIn);
		result.addDataSet("dsList", list);	
		
		return result;
	}
	
	/**
	 * 로트생성전략 저장
	 */
	@PostMapping("/saveStrategies")
	public NexacroResult saveLotCreationStrategy(@ParamDataSet(name = "dsList") List<BaimLotCrtStrtVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserId(data);
		int res = baimLotCrtStrtService.saveLotCreationStrategy(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
	
	/**
	 * 로트생성전략 삭제
	 */
	@PostMapping("/deleteStrategies")
	public NexacroResult deleteLotCreationStrategy(@ParamDataSet(name = "dsList") List<BaimLotCrtStrtVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserId(data);
		int res = baimLotCrtStrtService.deleteLotCreationStrategy(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}			
		
		return result;
	}
	
	private void setUserId(List<BaimLotCrtStrtVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(BaimLotCrtStrtVO vo : data) {
			vo.setRegUserId(userId);
			vo.setModiUserId(userId);
		}
	}

}

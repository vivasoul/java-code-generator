package com.oy.wms.baim.bom.vo;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;
import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class BaimBomDtlVO implements Serializable ,DataSetRowTypeAccessor {
	
	private static final long serialVersionUID = 878155180939091337L;
	
	private String bomNo;
	private String bomDtlNo;
	private String lowerCustId;
	private String lowerItemCd;
	private String needQty;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private String chk;
	
	private int rowType;
}
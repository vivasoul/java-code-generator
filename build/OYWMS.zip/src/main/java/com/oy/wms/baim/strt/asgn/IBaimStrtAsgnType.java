package com.oy.wms.baim.strt.asgn;

public interface IBaimStrtAsgnType {
	String WAREHOUSE = "W";
	String CUSTROMER = "C";
	String ITEMGROUP = "G";
	String ITEM = "I";
}

package com.oy.wms.syst.auth;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.oy.wms.syst.auth.vo.SystAuthMenuVO;
import com.oy.wms.syst.auth.vo.SystAuthVO;
import com.oy.wms.syst.auth.vo.SystAuthBtnVO;

@Mapper
public interface SystAuthMapper {
	
	//권한설정 - 권한관리 조회
	List<SystAuthVO> selectAuth(SystAuthVO vo);
	
	//권한설정 - 권한코드 중복 체크 
	boolean checkDupAuthCd(SystAuthVO vo);
	
	//권한설정 - 권한관리 I
	int insertAuth(SystAuthVO vo);
	
	//권한설정 - 권한관리 U	
	int updateAuth(SystAuthVO vo);
	
	//권한설정 - 권한관리 D
	int deleteAuth(SystAuthVO vo);
	
	// 권한설정 - 메뉴리스트 - 권한을 가진 메뉴
	List<SystAuthMenuVO> selectMenuByAuth(String authCd);
	
	// 권한설정 - 메뉴리스트 - 전체 메뉴 중 권한이 없는 메뉴
	List<SystAuthMenuVO> selectMenu(String authCd);
	
	// 권한설정 - 메뉴리스트 - 권한 메뉴 I/U
	int mergeAuthMenuList(SystAuthMenuVO row);
	
	// 권한설정 - 메뉴리스트 - 권한 메뉴 D
	int deleteAuthMenuList(SystAuthMenuVO row);		
	
	// 권한별메뉴 - 메뉴별 기능버튼 조회
	List<SystAuthBtnVO> selectAuthBtn(SystAuthBtnVO param);
	
	// 권한별메뉴 - 메뉴별 기능버튼 저장
	int updateAuthBtn(SystAuthBtnVO row);
}

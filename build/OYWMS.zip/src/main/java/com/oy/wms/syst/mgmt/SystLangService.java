package com.oy.wms.syst.mgmt;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;
import com.oy.wms.syst.mgmt.vo.SystLangVO;
import com.oy.wms.syst.mgmt.vo.SystMsgVO;
import com.oy.wms.syst.mgmt.vo.SystTermVO;

@Service("systLangService")
public class SystLangService {

	private static final String ROW_CHECKED = "1";

	@Autowired
	private SystLangMapper systLangMapper;

	/**
	 * 다국어용어 조회
	 * 
	 * @param input
	 * @return Parameters
	 * @throws Exception
	 */
	public int saveLangTerm(List<SystTermVO> data) throws Exception {

		if (data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}

		int res = 0;
		for (SystTermVO row : data) {
			int chkUpdate = systLangMapper.chkLangTermUpdate(row);
			
			if (chkUpdate == 0) { // 존재하지 않는 경우 -> insert
				systLangMapper.insertLangTerm(row);
			} else if (chkUpdate != 0) { // 존재하는 경우 -> update
				systLangMapper.updateLangTerm(row);
			}
		}
		return res;
	}

	/**
	 * 다국어용어 조회
	 * 
	 * @param input
	 * @return Parameters
	 * @throws Exception
	 */
	public List<SystTermVO> getLangTerm(SystTermVO input) throws Exception {
		return systLangMapper.selectLangTerm(input);
	}

	/**
	 * 다국어용어 삭제
	 * 
	 * @param input
	 * @return Parameters
	 * @throws Exception
	 */
	public int deleteLangTerm(List<SystTermVO> data) throws Exception {

		int res = 0;
		
		for (SystTermVO row : data) {
			System.out.println("data : " + row.getTermCd());
			res += systLangMapper.deleteLangTerm(row);
		}

		return res;

	}

	/**
	 * 다국어메세지 저장
	 * 
	 * @param input
	 * @return Parameters
	 * @throws Exception
	 */
	public int saveLangMsg(List<SystMsgVO> data) throws Exception {

		if (data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}

		int res = 0;
		for (SystMsgVO row : data) {
			int chkUpdate = systLangMapper.chkLangMsgUpdate(row);
			if (chkUpdate == 0) { // 존재하지 않는 경우 -> insert
				systLangMapper.insertLangMsg(row);
			} else if (chkUpdate != 0) { // 존재하는 경우 -> update
				systLangMapper.updateLangMsg(row);
			}
		}
		return res;

	}

	/**
	 * 다국어메세지 조회
	 * 
	 * @param input
	 * @return Parameters
	 * @throws Exception
	 */
	public List<SystMsgVO> getLangMsg(SystMsgVO input) throws Exception {
		return systLangMapper.selectLangMsg(input);
	}

	/**
	 * 다국어메세지 삭제
	 * 
	 * @param input
	 * @return Parameters
	 * @throws Exception
	 */
	public int deleteLangMsg(List<SystMsgVO> data) throws Exception {

		int res = 0;
		for (SystMsgVO row : data) {

			String chk = (String) row.getChk();

			// 체크된 행만 처리
			if (!ROW_CHECKED.equals(chk))
				continue;

			res += systLangMapper.deleteLangMsg(row);
		}
		return res;
	}

	/**
	 * 언어코드 조회
	 */
	public List<SystLangVO> getLangCode(SystLangVO input) throws Exception {
		return systLangMapper.selectLangCode(input);
	}

	/**
	 * 언어코드 저장
	 */
	public int saveLangCode(List<SystLangVO> data) throws Exception {

		if (data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}

		int res = 0;
		for (SystLangVO row : data) {

			int rowType = row.getRowType();

			switch (rowType) {
			case DataSet.ROW_TYPE_INSERTED:
				if(systLangMapper.checkDupLangCode(row)) {
					throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
				} else {
					res += systLangMapper.insertLangCode(row);
				}
				break;
			case DataSet.ROW_TYPE_UPDATED:
				res += systLangMapper.updateLangCode(row);
				break;
			}
		}
		return res;
	}

	/**
	 * 언어코드 삭제
	 */
	public int deleteLangCode(List<SystLangVO> data) throws Exception {

		if (data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}

		int res = 0;
		for (SystLangVO row : data) {

			int rowType = row.getRowType();

			switch (rowType) {
			case DataSet.ROW_TYPE_DELETED:
				res += systLangMapper.deleteLangCode(row);
				break;
			}
		}
		return res;
	}
}

package com.oy.wms.baim.strt.set.puta;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;
import com.oy.wms.baim.strt.set.puta.vo.BaimPutaStrtDVO;
import com.oy.wms.baim.strt.set.puta.vo.BaimPutaStrtMVO;
import com.oy.wms.baim.ware.vo.BaimCntrVO;

import lombok.RequiredArgsConstructor;

@Service("baimPutaStrtService")
@RequiredArgsConstructor
public class BaimPutaStrtService {
	
	private final BaimPutaStrtMapper baimPutaStrtMapper;

	/**
	 * 적치전략설정 조회
	 */
	List<BaimPutaStrtMVO> selectPutaStrtList(BaimPutaStrtMVO vo) {
		return baimPutaStrtMapper.selectPutaStrtList(vo);
	}
	
	/**
	 * 적치전략설정 저장
	 */
	int savePutaStrtList(List<BaimPutaStrtMVO> data) throws NexacroBizException {
		
		if(data.isEmpty()){
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimPutaStrtMVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
			case DataSet.ROW_TYPE_INSERTED :
				res += baimPutaStrtMapper.insertPutaStrtList(row);
				break;
			case DataSet.ROW_TYPE_UPDATED :
				res += baimPutaStrtMapper.updatePutaStrtList(row);
				break;
			}
		}
		return res;
	}
	
	/**
	 * 적치전략설정 삭제
	 */
	public int deletePutaStrtList(List<BaimPutaStrtMVO> data) {
		int res = 0;
		
		for(BaimPutaStrtMVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED : 
					res += baimPutaStrtMapper.deletePutaStrtList(row);
					break;
			}
		}
		return res;
	}
	
	
	/**
	 * 상세적치전략설정 조회
	 */
	List<BaimPutaStrtDVO> selectPutaStrtListDetail(BaimPutaStrtDVO vo) {
		return baimPutaStrtMapper.selectPutaStrtListDetail(vo);
	}
	
	/**
	 * 상세적치전략설정 저장
	 */
	int savePutaStrtListDetail(List<BaimPutaStrtDVO> data) throws NexacroBizException {
		
		if(data.isEmpty()){
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimPutaStrtDVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
			case DataSet.ROW_TYPE_INSERTED :
				res += baimPutaStrtMapper.insertPutaStrtListDetail(row);
				break;
			case DataSet.ROW_TYPE_UPDATED :
				res += baimPutaStrtMapper.updatePutaStrtListDetail(row);
				break;
			}
		}
		return res;
	}
	
	/**
	 * 상세적치전략설정 삭제
	 */
	public int deletePutaStrtListDetail(List<BaimPutaStrtDVO> data) {
		int res = 0;
		
		for(BaimPutaStrtDVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED : 
					res += baimPutaStrtMapper.deletePutaStrtListDetail(row);
					break;
			}
		}
		return res;
	}
	
}

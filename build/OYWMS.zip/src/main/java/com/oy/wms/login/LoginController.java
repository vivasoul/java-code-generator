package com.oy.wms.login;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.login.vo.CodeVO;
import com.oy.wms.login.vo.LoginVO;
import com.oy.wms.login.vo.MenuVO;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class LoginController {
	
	private final LoginService loginService;

	@PostMapping("/login")
	public NexacroResult doLogin(@ParamDataSet(name = "dsUser") LoginVO loginVO, HttpSession session) throws Exception{
		NexacroResult result = new NexacroResult();
		
		/* 1. do login  */
		String userId = loginVO.getUserId();
		LoginVO userVO = loginService.actionLogin(loginVO);
		
		/* 2. load common data */
		List<MenuVO> menus = loginService.getMenu(userId);
		List<CodeVO> codes = loginService.getCode();
		
		/* 3. save user-information to the session  */
		session.setAttribute("user", userVO);
		//save user-auth-map
		//save user-locale
		
		/* 4. set dataset to send a response */
		result.addDataSet("dsUser", userVO);
		result.addDataSet("dsMenu", menus);
		result.addDataSet("dsCode", codes);
		//dsFav		
		//dsCode(☆)
		//dsMsg(☆)
		//dsTerm(☆)
		
		return result;
	}
}

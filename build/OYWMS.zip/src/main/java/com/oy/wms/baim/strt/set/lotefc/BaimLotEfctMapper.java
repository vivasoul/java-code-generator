package com.oy.wms.baim.strt.set.lotefc;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BaimLotEfctMapper {

	/**
	 * 로트유효성전략 목록 조회
	 */
	List<BaimLotEfctVO> selectEftcStrtList(BaimLotEfctVO vo);

	/**
	 * 로트유효성전략 추가
	 */
	int insertEftcStrtList(BaimLotEfctVO vo);
	
	/**
	 * 로트유효성전략 수정
	 */
	int updateEftcStrtList(BaimLotEfctVO vo);
	
	/**
	 * 로트유효성전략 삭제
	 */
	int deleteEftcStrtList(BaimLotEfctVO vo);
	
	/**
	 * 로트유효성전략 중복 조회
	 */
	boolean checkDupDistStrt(BaimLotEfctVO vo);	
}

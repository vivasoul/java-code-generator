package com.oy.wms.baim.strt.set.repl;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.baim.strt.set.dist.BaimDistStrtVO;
import com.oy.wms.login.vo.LoginVO;

import lombok.RequiredArgsConstructor;


@Controller
@RequiredArgsConstructor
@RequestMapping("/baim/strt/repl")
public class BaimReplStrtController {
	
	private final BaimReplStrtService baimReplStrtService;
	
	/**
	 * 재고보충전전략 목록 조회
	 */
	@PostMapping("/getBaimReplStrt")
	public NexacroResult getBaimReplStrt(@ParamDataSet(name = "dsSearch") BaimReplStrtVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimReplStrtVO> list =  baimReplStrtService.selectBaimReplStrt(input);
		result.addDataSet("dsList", list);
		
		return result;
	}
	
	/**
	 * 재고보충전전략 저장
	 */
	@PostMapping("/saveBaimReplStrt")
	public NexacroResult saveReplStrt(@ParamDataSet(name = "dsList") List<BaimReplStrtVO> data) throws Exception {

		NexacroResult result = new NexacroResult();
		
		setUserId(data);
		int res = baimReplStrtService.saveBaimReplStrtList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
	/**
	 * 재고보충전전략 삭제
	 */
	@PostMapping("/deleteBaimReplStrt")
	public NexacroResult deleteBaimReplStrt(@ParamDataSet(name = "dsList") List<BaimReplStrtVO> data) throws Exception {

		NexacroResult result = new NexacroResult();
		
		setUserId(data);
		int res = baimReplStrtService.deleteBaimReplStrtList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
	private void setUserId(List<BaimReplStrtVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(BaimReplStrtVO vo : data) {
			vo.setRegUserId(userId);
			vo.setModiUserId(userId);
		}
	}
}

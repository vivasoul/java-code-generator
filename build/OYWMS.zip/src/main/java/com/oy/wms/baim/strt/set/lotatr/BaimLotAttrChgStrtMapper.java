package com.oy.wms.baim.strt.set.lotatr;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BaimLotAttrChgStrtMapper {
	
	// 로트속성변경전략 조회
	List<BaimLotAttrChgStrtVO> selectLotPropertyChangeStrategy(BaimLotAttrChgStrtVO param);

	// 로트속성변경전략 등록
	int insertLotPropertyChangeStrategy(BaimLotAttrChgStrtVO row);
			
	// 로트속성변경전략 수정
	int updateLotPropertyChangeStrategy(BaimLotAttrChgStrtVO row);
			
	// 로트속성변경전략 삭제
	int deleteLotPropertyChangeStrategy(BaimLotAttrChgStrtVO row);
		
	
}

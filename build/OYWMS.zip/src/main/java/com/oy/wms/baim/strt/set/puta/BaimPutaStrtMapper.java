package com.oy.wms.baim.strt.set.puta;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.oy.wms.baim.strt.set.puta.vo.BaimPutaStrtDVO;
import com.oy.wms.baim.strt.set.puta.vo.BaimPutaStrtMVO;

@Mapper
public interface BaimPutaStrtMapper {

	/**
	 * 적치전략설정 조회
	 */
	List<BaimPutaStrtMVO> selectPutaStrtList(BaimPutaStrtMVO vo);

	/**
	 * 적치전략설정 추가
	 */
	int insertPutaStrtList(BaimPutaStrtMVO vo);
	
	/**
	 * 적치전략설정 수정
	 */
	int updatePutaStrtList(BaimPutaStrtMVO vo);
	
	/**
	 * 적치전략설정 삭제
	 */
	int deletePutaStrtList(BaimPutaStrtMVO vo);
	
	/**
	 *  상세적치전략설정 조회
	 */
	List<BaimPutaStrtDVO> selectPutaStrtListDetail(BaimPutaStrtDVO vo);
	
	/**
	 * 상세적치전략설정 추가
	 */
	int insertPutaStrtListDetail(BaimPutaStrtDVO vo);
	
	/**
	 * 상세적치전략설정 수정
	 */
	int updatePutaStrtListDetail(BaimPutaStrtDVO vo);
	
	/**
	 * 상세적치전략설정 삭제
	 */
	int deletePutaStrtListDetail(BaimPutaStrtDVO vo);
	
}

package com.oy.wms.baim.strt.set.repl;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BaimReplStrtMapper {

	/**
	 * 재고보충전전략 목록 조회
	 */
	List<BaimReplStrtVO> selectBaimReplStrt(BaimReplStrtVO vo);

	/**
	 * 재고보충전전략 추가
	 */
	int insertBaimReplStrt(BaimReplStrtVO vo);

	/**
	 * 재고보충전전략 수정
	 */
	int updateBaimReplStrt(BaimReplStrtVO vo);

	/**
	 * 재고보충전전략 삭제
	 */
	int deleteBaimReplStrt(BaimReplStrtVO row);
	
	/**
	 * 재고보충전전략 중복 조회
	 */
	boolean checkDupReplStrt(BaimReplStrtVO row);
}

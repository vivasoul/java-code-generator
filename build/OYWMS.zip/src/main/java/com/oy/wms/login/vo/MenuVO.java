package com.oy.wms.login.vo;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MenuVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6217662154587804115L;
	
	private String menuId;
	private String menuNm;
	private String upMenuId;
	private String menuLvl;
	private String menuPath;
	private String menuImg;
	private String pgmUrl;
	private String visibleYn;
	private String searchAuthYn;
	private String saveAuthYn;
	private String deleteAuthYn;
	private String prntAuthYn;
	private String excelAuthYn;
	private String favoYn;
}

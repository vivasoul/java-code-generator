package com.oy.wms.baim.strt.set;


import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;
import com.oy.wms.baim.strt.set.dist.BaimDistStrtVO;
import com.oy.wms.login.vo.LoginVO;

import lombok.RequiredArgsConstructor;

/*
--전략설정(조회/생성/수정): baim.strt.asgn
	창고전략지정
	고객전략지정
	상품그룹전략지정
	상품전략지정

--전략생성(조회/생성/수정): baim.strt.set
	전략세트설정
	
--세부전략생성(조회/생성/수정)	
	(이전)할당전략	
	--할당전략			: baim.strt.set.aloc   (개발완료 - 패키지 변경 필요)
	--재고보충전략		: baim.strt.set.repl   (개발완료 - 패키지 변경 필요)
	--적치전략			: baim.strt.set.puta
	--피킹전략			: baim.strt.set.pick	//현재 도메인 존재X
	--로트생성전략		: baim.strt.set.lotcrt (개발완료 - 패키지 변경 필요)	
	--로트속성변경전략	: baim.strt.set.lotatr (개발완료 - 패키지 변경 필요)
	--로트유효성전략		: baim.strt.set.loteft (개발완료 - 패키지 변경 필요)
*/
@Controller
@RequestMapping("/baim/strt")
@RequiredArgsConstructor
public class BaimStrtController {
	
	private final BaimStrtService baimStrtService;

	/**
	 * 전략세트 조회
	 */
	@PostMapping("/getStrtSet")
	public NexacroResult getStrtSet(@ParamDataSet(name = "dsSearch") BaimStrtVO dsIn) throws Exception {

		NexacroResult result = new NexacroResult();
		List<BaimStrtVO> list =  baimStrtService.getStrtSet(dsIn);
		result.addDataSet("dsList", list);	
		
		return result;
	}
	
	/**
	 * 전략세트 저장
	 */
	@PostMapping("/saveStrtSet")
	public NexacroResult saveStrtSet(@ParamDataSet(name = "dsList") List<BaimStrtVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserId(data);
		int res = baimStrtService.saveStrtSet(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
	
	/**
	 * 전략세트 삭제
	 */
	@PostMapping("/deleteStrtSet")
	public NexacroResult deleteStrtSet(@ParamDataSet(name = "dsList") List<BaimStrtVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserId(data);
		int res = baimStrtService.deleteStrtSet(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}			
		
		return result;
	}	
	
	/**
	 * 전략세트 중복 체크
	 */
	@PostMapping("/chkStrtSetDup")
	public NexacroResult chkStrtSetDup(@ParamDataSet(name = "dsDetail") BaimStrtVO dsIn) throws Exception {

		NexacroResult result = new NexacroResult();
		String dupYn =  baimStrtService.getStrtSetDup(dsIn);
		
		if("Y".equals(dupYn)) {
			throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode()); //중복된 항목이 존재합니다.
		}
		
		return result;
	}
	
	private void setUserId(List<BaimStrtVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(BaimStrtVO vo : data) {
			vo.setRegUserId(userId);
			vo.setModiUserId(userId);
		}
	}	
}

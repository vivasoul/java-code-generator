package com.oy.wms.baim.strt.set.lotefc;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimLotEfctVO implements DataSetRowTypeAccessor {
	private String cntrCd;
	private String cntrNm;
	private String whCd;
	private String whNm;
	private String lotEfctChkCd;
	private String whibYmdUseYn;
	private String prodYmdUseYn;
	private String validDtimeUseYn;
	private String prodLotNoUseYn;
	private String markDscrUseYn;
	private String lotAttr1UseYn;
	private String lotAttr2UseYn;
	private String lotAttr3UseYn;
	private String lotAttr4UseYn;
	private String lotAttr5UseYn;
	private String lotAttr6UseYn;
	private String lotAttr7UseYn;
	private String lotAttr8UseYn;
	private String lotAttr9UseYn;
	private String lotAttr10UseYn;
	private String lotEfctChkDscr;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;

	private String chk;
	private int rowType;
}

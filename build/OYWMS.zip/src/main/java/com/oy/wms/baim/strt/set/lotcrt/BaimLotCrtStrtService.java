package com.oy.wms.baim.strt.set.lotcrt;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;

import lombok.RequiredArgsConstructor;

@Service("baimLotCrtStrtService")
@RequiredArgsConstructor
public class BaimLotCrtStrtService {
	
	private static final String ROW_CHECKED = "1";
	
	private final BaimLotCrtStrtMapper baimLotCrtStrtMapper;
	
	
	/**
	 * 로트생성전략 조회
	 */
	public List<BaimLotCrtStrtVO> getLotCreationStrategy(BaimLotCrtStrtVO input) throws Exception {
		//dsIn = dsIn
		//dsOut = dsOut
		
		return baimLotCrtStrtMapper.selectLotCreationStrategy(input);
	}
	
	/**
	 * 로트생성전략 저장
	 */
	public int saveLotCreationStrategy(List<BaimLotCrtStrtVO> data) throws Exception {
		//dsIn = dsIn		
		if(data.isEmpty()) {
			// TODO (2022.12.29) 다국어 조회 처리 필요
//			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), CommonLang.select({CntryLangCd}, {MsgCd}, "저장할 데이터가 존재하지 않습니다."));
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimLotCrtStrtVO row : data) {
			
			String chk = row.getChk();
			
			// 체크된 행만 처리
			if(chk != null && !chk.equals(ROW_CHECKED)) continue;
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					res += baimLotCrtStrtMapper.insertLotCreationStrategy(row);
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += baimLotCrtStrtMapper.updateLotCreationStrategy(row);
					break;
			}
		}
		
		return res;
		
	}
	
	/**
	 * 로트생성전략 삭제
	 */
	public int deleteLotCreationStrategy(List<BaimLotCrtStrtVO> data) throws Exception {
		//dsIn = dsCode
		
		int res = 0;
		for(BaimLotCrtStrtVO row : data) {
			
			String chk = row.getChk();
			
			// 체크된 행만 처리
			if(chk != null && !chk.equals(ROW_CHECKED)) continue;
			
			res += baimLotCrtStrtMapper.deleteLotCreationStrategy(row);
		}
		
		return res;
	}

}

package com.oy.wms.baim.bom;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.oy.wms.baim.bom.vo.BaimBomMainVO;
import com.oy.wms.baim.bom.vo.BaimBomDtlVO;

@Mapper
public interface BaimBomMapper {
	
	// BOM 조회
	List<BaimBomMainVO> selectBomMList(BaimBomMainVO vo);	
	// BOM 입력
	int insertBomMain(BaimBomMainVO vo);	
	// BOM 수정
	int updateBomMain(BaimBomMainVO vo);
	// BOM 삭제	
	int deleteBomMain(BaimBomMainVO vo);
	// BOM 상세 조회	
	List<BaimBomDtlVO> selectBomDList(BaimBomDtlVO vo);	
	// BOM 상세 입력
	int insertBomDtl(BaimBomDtlVO vo);	
	// BOM 상세 수정
	int updateBomDtl(BaimBomDtlVO vo);
	// BOM 상세 삭제	
	int deleteBomDtl(BaimBomDtlVO vo);
	// BOM 상세 이력 입력
	int insertBomDHist(BaimBomDtlVO vo);
	// BOM 상세 삭제 이력 입력
	int deleteBomDHist(BaimBomDtlVO vo); 
	// BOM_DTL_NO MAX 값
	String selectBomDtlLastNo(BaimBomDtlVO vo);	
	// BOM 메인 하위에 있는 디테일 로우 리스트
	List<BaimBomDtlVO> selectBomDRtn(BaimBomMainVO vo);		
	
}

package com.oy.wms.syst.mgmt.vo;

import java.io.Serializable;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SystLangVO implements Serializable ,DataSetRowTypeAccessor {

	private static final long serialVersionUID = -2831469862610127506L;

	private String chk;
	
	private String langCd;
	private String langNm;
	private String langDscr;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	
	private int rowType;
}

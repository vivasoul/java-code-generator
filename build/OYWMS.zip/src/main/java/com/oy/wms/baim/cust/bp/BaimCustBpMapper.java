package com.oy.wms.baim.cust.bp;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BaimCustBpMapper {

	// 고객사별 거래처관리 목록 조회
	List<BaimCustBpVO> selectCustBpList(BaimCustBpVO vo);

	// 고객사별 거래처관리 추가
	int insertCustBpList(BaimCustBpVO row);

	// 고객사별 거래처관리 수정
	int updateCustBpList(BaimCustBpVO row);

	// 고객사별 거래처관리 삭제
	int deleteCustBpList(BaimCustBpVO row);

	// 고객사별 거리처관리 중복체크
	boolean checkDupCustBp(BaimCustBpVO row);

}

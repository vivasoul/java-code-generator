package com.oy.wms.baim.bom.vo;

import java.io.Serializable;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimBomMainVO implements Serializable ,DataSetRowTypeAccessor {

	private static final long serialVersionUID = -1828687708354422621L;
	
	private String bomNo;
	private String upperCustId;
	private String upperItemCd;
	private String upperItemCdNm;
	private String bomDscr;
	private String validStartDtime;
	private String expryDtime;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private String chk;
	
	private int rowType;	
}
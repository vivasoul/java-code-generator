package com.oy.wms.baim.strt.asgn;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.annotation.ParamVariable;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.baim.strt.set.BaimStrtVO;
import com.oy.wms.login.vo.LoginVO;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/baim/strtAsgn")
public class BaimStrtAsgnController {
	
	private final BaimStrtAsgnService baimStrtAsgnService;
	
	/**
	 *  전략설정 조회
	 */
	@PostMapping("/getStrtAsgn")
	public NexacroResult getStrtAsgn(@ParamDataSet(name = "dsSearch") BaimStrtAsgnVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		String mngTypeCd = input.getMngTypeCd();
		List<BaimStrtAsgnVO> list = null;
		
		switch(mngTypeCd) {
			case IBaimStrtAsgnType.WAREHOUSE: list = baimStrtAsgnService.getStrtWareAsgn(input); break;
			case IBaimStrtAsgnType.CUSTROMER: list = baimStrtAsgnService.getStrtCustAsgn(input); break;
			case IBaimStrtAsgnType.ITEMGROUP: list = baimStrtAsgnService.getStrtItemGrpAsgn(input); break;
			case IBaimStrtAsgnType.ITEM: 	  list = baimStrtAsgnService.getStrtItemAsgn(input); break;
		}
		
		result.addDataSet("dsList", list);
		
		return result;
	}	
	
	/**
	 *  전략설정 저장
	 */
	@PostMapping("/saveStrtAsgn")
	public NexacroResult saveStrtAsgn(@ParamDataSet(name = "dsList") List<BaimStrtAsgnVO> data
									 ,@ParamVariable(name = "mngTypeCd") String mngTypeCd) throws Exception {

		NexacroResult result = new NexacroResult();
		
		int res = 0;
		setUserId(data);
		switch(mngTypeCd) {
			case IBaimStrtAsgnType.WAREHOUSE: res = baimStrtAsgnService.saveStrtWareAsgn(data); break;
			case IBaimStrtAsgnType.CUSTROMER: res = baimStrtAsgnService.saveStrtCustAsgn(data); break;
			case IBaimStrtAsgnType.ITEMGROUP: res = baimStrtAsgnService.saveStrtItemGrpAsgn(data); break;
			case IBaimStrtAsgnType.ITEM: 	  res = baimStrtAsgnService.saveStrtItemAsgn(data); break;
		}		
		
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}	
	
	/**
	 *  전략설정 삭제
	 */	
	@PostMapping("/deleteStrtAsgn")
	public NexacroResult deleteStrtAsgn(@ParamDataSet(name = "dsList") List<BaimStrtAsgnVO> data
									   ,@ParamVariable(name = "mngTypeCd") String mngTypeCd) throws Exception {

		NexacroResult result = new NexacroResult();
		
		int res = 0;
		setUserId(data);
		switch(mngTypeCd) {
			case IBaimStrtAsgnType.WAREHOUSE: res = baimStrtAsgnService.deleteStrtWareAsgn(data); break;
			case IBaimStrtAsgnType.CUSTROMER: res = baimStrtAsgnService.deleteStrtCustAsgn(data); break;
			case IBaimStrtAsgnType.ITEMGROUP: res = baimStrtAsgnService.deleteStrtItemGrpAsgn(data); break;
			case IBaimStrtAsgnType.ITEM: 	  res = baimStrtAsgnService.deleteStrtItemAsgn(data); break;
		}			
		
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
	private void setUserId(List<BaimStrtAsgnVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(BaimStrtAsgnVO vo : data) {
			vo.setRegUserId(userId);
			vo.setModiUserId(userId);
		}
	}		
}

package com.oy.wms.syst.menu;


import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.login.vo.LoginVO;

import lombok.RequiredArgsConstructor;


@Controller
@RequiredArgsConstructor
@RequestMapping("/systauth")
public class SystMenuController {
	
	private final SystMenuService systMenuService;
	/**
	 * 메뉴설정 - 메뉴 조회
	 */
	@PostMapping("/getMenu")
	public NexacroResult getMenu(@ParamDataSet(name = "dsSearch") SystMenuVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<SystMenuVO> list =  systMenuService.getMenu(input);
		result.addDataSet("dsList", list);		
		
		return result;
	}
	
	/**
	 * 메뉴설정 - 메뉴 저장
	 */
	@PostMapping("/saveMenu")
	public NexacroResult saveMenu(@ParamDataSet(name = "dsList") List<SystMenuVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		setUserId(data);
		int res = systMenuService.saveMenu(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;		
	}
	
	/**
	 * 메뉴설정 - 메뉴 삭제
	 */
	@PostMapping("/deleteMenu")
	public NexacroResult deleteMenu(@ParamDataSet(name = "dsList") List<SystMenuVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		setUserId(data);
		int res = systMenuService.deleteMenu(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}				
		
		return result;
	}
	
	/**
	 * 메뉴 관련 사용자 세팅
	 */
	private void setUserId(List<SystMenuVO> vo) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		
		for(SystMenuVO row : vo) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}
	
}

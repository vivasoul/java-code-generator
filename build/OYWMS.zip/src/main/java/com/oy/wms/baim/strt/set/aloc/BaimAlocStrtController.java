package com.oy.wms.baim.strt.set.aloc;


import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.login.vo.LoginVO;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/baim/strt/aloc")
public class BaimAlocStrtController {
	
	private final BaimAlocStrtService baimAlocStrtService;
	
	/**
	 * 할당전략 조회
	 */
	@PostMapping("/getStrategies")
	public NexacroResult get(@ParamDataSet(name = "dsSearch") BaimAlocStrtVO vo) throws Exception {

		NexacroResult result = new NexacroResult();
		List<BaimAlocStrtVO> list =  baimAlocStrtService.getAllocationStrategySettings(vo);
		result.addDataSet("dsList", list);	
		
		return result;
	}
	
	/**
	 * 할당전략 저장
	 */
	@PostMapping("/saveStrategies")
	public NexacroResult saveStrategy(@ParamDataSet(name = "dsList") List<BaimAlocStrtVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserId(data);
		int res = baimAlocStrtService.saveAllocationStrategySettings(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
	
	/**
	 * 할당전략 삭제
	 */
	@PostMapping("/deleteStrategies")
	public NexacroResult deleteSrategy(@ParamDataSet(name = "dsList") List<BaimAlocStrtVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserId(data);
		int res = baimAlocStrtService.deleteAllocationStrategySettings(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}			
		
		return result;
	}
	
	private void setUserId(List<BaimAlocStrtVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(BaimAlocStrtVO vo : data) {
			vo.setRegUserId(userId);
			vo.setModiUserId(userId);
		}
	}
}

package com.oy.wms.baim.code;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;
import com.oy.wms.baim.code.vo.BaimCodeDVO;
import com.oy.wms.baim.code.vo.BaimCodeMVO;

import lombok.RequiredArgsConstructor;

@Service("baimCodeService")
@RequiredArgsConstructor
public class BaimCodeService {
	
	private final BaimCodeMapper baimCodeMapper;
	
	
	/**
	 * 기준코드 조회
	 */
	public List<BaimCodeMVO> getCode(BaimCodeMVO input) throws Exception {
		return baimCodeMapper.selectCode(input);
	}

	/**
	 * 기준코드상세 조회
	 */
	public List<BaimCodeDVO> getCodeDetail(BaimCodeDVO input) throws Exception {
		return baimCodeMapper.selectCodeDetail(input);
	}

	/**
	 * 기준코드 저장
	 */
	public int saveCode(List<BaimCodeMVO> data) throws Exception {

		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimCodeMVO row: data) {			
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					if(baimCodeMapper.checkDupCode(row)) {
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
					} else {
						res += baimCodeMapper.insertCode(row);
					}
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += baimCodeMapper.updateCode(row);
					break;
			}
		}
		return res;
	}
	
	/**
	 * 기준코드상세 저장
	 */
	public int saveCodeDetail(List<BaimCodeDVO> data) throws Exception {

		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimCodeDVO row : data) {
			
			int rowType = row.getRowType();
			
			int existCnt = baimCodeMapper.isExistCode(row);
			
			if(existCnt == 0) {
				throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "존재하지않는 기준코드입니다.");
			}
			
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					if(baimCodeMapper.checkDupCodeDetail(row)) {
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
					} else {
						res += baimCodeMapper.insertCodeDetail(row);
					}
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += baimCodeMapper.updateCodeDetail(row);
					break;
			}
		}
		return res;	
	}
	
	/**
	 * 기준코드 삭제
	 */
	public int deleteCode(List<BaimCodeMVO> data) throws Exception {
		int res = 0;
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "삭제할 데이터가 존재하지 않습니다.");
		}		
		
		for(BaimCodeMVO row: data) {			
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED:
					res += baimCodeMapper.deleteCode(row);
					break;
			}
		}
		return res;
	}

	/**
	 * 기준코드상세 삭제
	 */
	public int deleteCodeDetail(List<BaimCodeDVO> data) throws Exception {
		
		int res = 0;
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "삭제할 데이터가 존재하지 않습니다.");
		}		
		
		for(BaimCodeDVO row: data) {			
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED:
					res += baimCodeMapper.deleteCodeDetail(row);
					break;
			}
		}
		return res;
	}
}

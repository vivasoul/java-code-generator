package com.oy.wms.syst.user.vo;

import java.io.Serializable;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SystUserAuthVO implements Serializable ,DataSetRowTypeAccessor {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2442870641083203674L;

	private String chk;
	
	private String userId;
	private String cntrCd;
	private String custId;
	
	private String authCd;
	private String authNm;
	
	private String whCd;
	private String whNm;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private int rowType;
}
package com.oy.wms.syst.noti;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SystNotiVO implements DataSetRowTypeAccessor {
	
	private int notiSeq;
	private String title;
	private String notiCont;
	private String postStartYmd;
	private String postEndYmd;
	private String atchFileNo;
	private String popupYn;
	private String notcTrgtCustId;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private String chk;
	
	private int rowType;
}
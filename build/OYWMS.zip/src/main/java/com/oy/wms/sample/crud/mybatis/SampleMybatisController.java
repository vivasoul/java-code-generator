package com.oy.wms.sample.crud.mybatis;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.baim.sample.SampleService;
import com.oy.wms.baim.sample.vo.SampleVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;

@RestController
//@RequiredArgsConstructor
@Slf4j
@Tag(name = "Sample RestController Mybatis", description = " 등록/조회/수정/삭제")
public class SampleMybatisController {
    //    @Resource(name = "sampleService")
    private final SampleMybatisService sampleMybatisService;
    private final SampleService sampleService;

    @Autowired //생성자가 하나일경우는 생략 가능
    public SampleMybatisController(SampleMybatisService sampleMybatisService, SampleService sampleService) {
        this.sampleMybatisService = sampleMybatisService;
        this.sampleService = sampleService;
    }

    @Operation(summary = "Sample 목록 조회", description = "목록을 조회합니다")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "목록조회성공")
            , @ApiResponse(responseCode = "404", description = "존재하지 않는 리소스접근")
    })
    @PostMapping("/sample/mybatis/selectData")
    public ResponseEntity<List<SampleVO>> selectData() {
        List<SampleVO> list = sampleService.selectSome("");
        if (list.isEmpty()) {
            return new ResponseEntity<List<SampleVO>>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<SampleVO>>(list, HttpStatus.OK);
    }

    @Operation(summary = "Sample 목록 조회", description = "목록을 조회합니다")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "목록조회성공")
            , @ApiResponse(responseCode = "404", description = "존재하지 않는 리소스접근")
    })
    @GetMapping("/sample/mybatis/getList")
    public ResponseEntity<List<Vo>> getList(@ModelAttribute("searchVo") Vo searchVo) {
        List<Vo> list = sampleMybatisService.getList(searchVo);
        if (list.isEmpty()) {
            return new ResponseEntity<List<Vo>>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Vo>>(list, HttpStatus.OK);
    }

    @Operation(summary = "Sample 항목 조회", description = "항목을 조회합니다")
//    // @formatter:off
//    @ApiImplicitParams({
//        @ApiImplicitParam(name = "sampleSn", value = "고유번호", required = true, dataType = "int", paramType = "query")
//    })
    // @formatter:on
    @GetMapping("/sample/mybatis/get/{sampleSn}")
    public ResponseEntity<?> get(Vo vo, @RequestBody Vo searchVo, @PathVariable("sampleSn") int sampleSn) {
        vo = sampleMybatisService.get(sampleSn);
        if (vo == null) {
            return new ResponseEntity<Object>(new String("SampleSn " + sampleSn + " not found"), HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Vo>(vo, HttpStatus.OK);
    }

    @Operation(summary = "Sample 항목 등록")
//    // @formatter:off
//    @ApiImplicitParams({
//        @ApiImplicitParam(name = "sampleSn", value = "고유번호", required = true, dataType = "int", paramType = "body", example = "1")
//        , @ApiImplicitParam(name = "nm", value = "이름", required = true, dataType = "string", paramType = "body", example = "영희")
//        , @ApiImplicitParam(name = "description", value = "내용", dataType = "string", paramType = "body", example = "Sample 내용")
//    })
//    // @formatter:on
    @PostMapping("/sample/mybatis/put")
    public ResponseEntity<String> put(@RequestBody Vo vo, @RequestParam("aa") String aa, UriComponentsBuilder ucBuilder) {
        sampleMybatisService.put(vo);
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("").buildAndExpand("").toUri());
        return new ResponseEntity<String>(headers, HttpStatus.CREATED);
    }

    @Operation(summary = "Sample 항목 수정")
    @PutMapping("/sample/mybatis/set/{userId}")
    public ResponseEntity<Vo> set(@RequestBody Vo vo, @PathVariable("userId") int userId) {
        vo.setUserId(userId);
        sampleMybatisService.set(vo);
        return new ResponseEntity<Vo>(vo, HttpStatus.OK);
    }

    @Operation(summary = "Sample 항목 삭제")
    @DeleteMapping("/sample/mybatis/del/{sampleSn}")
    public ResponseEntity<Vo> del(@PathVariable("sampleSn") int sampleSn) {
        sampleMybatisService.del(sampleSn);
        return new ResponseEntity<Vo>(HttpStatus.NO_CONTENT);
    }
}
package com.oy.wms.baim.code.vo;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;
import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimCodeDVO implements Serializable ,DataSetRowTypeAccessor {
	
	private static final long serialVersionUID = 4879002515196732178L;
	
	private String stdCd;
	private String stdDtlCd;
	private String stdDtlCdNm;
	private String cdDscr;
	private String sortOrdr;
	private String etcVal1;
	private String etcVal2;
	private String etcVal3;
	private String etcVal4;
	private String etcVal5;
	private String etcVal6;
	private String etcVal7;
	private String etcVal8;
	private String etcVal9;
	private String etcVal10;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private String chk;
	private int rowType;
}

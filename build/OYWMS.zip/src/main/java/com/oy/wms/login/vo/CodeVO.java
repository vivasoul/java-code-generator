package com.oy.wms.login.vo;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CodeVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7401321021676948666L;
	
	private String groupCd;
	private String groupNm;
	private String codeCd;
	private String codeNm;
	private String ref1;
	private String ref2;
	private String ref3;
	private String ref4;
	private String ref5;
	private String ref6;
	private String ref7;
	private String ref8;
	private String ref9;
	private String ref10;
	private String useYn;
}

package com.oy.wms.baim.ware.vo;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimWareVO implements DataSetRowTypeAccessor {

	private String cntrCd;
	private String cntrNm;
	private String whCd;
	private String whTypeCd;
	private String whNm;
	private String dscr;
	private String ifCntrCd;
	private String areaUseYn;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private String chk;
	private int rowType;

}

package com.oy.wms.syst.mgmt;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.oy.wms.syst.mgmt.vo.SystLangVO;
import com.oy.wms.syst.mgmt.vo.SystMsgVO;
import com.oy.wms.syst.mgmt.vo.SystTermVO;

@Mapper 
public interface SystLangMapper {
	
	// 공통메세지 조회
	String selectCommonMsg(SystMsgVO row);
		
	// 다국어용어 등록
	int insertLangTerm(SystTermVO row);
	
	// 다국어용어 조회
	List<SystTermVO> selectLangTerm(SystTermVO row);
	
	// 다국어용어 신규 확인 조회
	int chkLangTermUpdate(SystTermVO row);
	
	// 다국어용어 업데이트
	int updateLangTerm(SystTermVO row);
	
	// 다국어용어 삭제
	int deleteLangTerm(SystTermVO row);
	
	// 다국어메세지 등록
	int insertLangMsg(SystMsgVO row);
	
	// 다국어용어 신규 확인 조회
	int chkLangMsgUpdate(SystMsgVO row);
	
	// 다국어메세지 조회
	List<SystMsgVO> selectLangMsg(SystMsgVO row);
	
	// 다국어메세지 업데이트
	int updateLangMsg(SystMsgVO row);
	
	// 다국어메세지 삭제
	int deleteLangMsg(SystMsgVO row);
	
	// 언어코드 조회
	List<SystLangVO> selectLangCode(SystLangVO row);
	
	// 언어코드 등록
	int insertLangCode(SystLangVO row);

	// 언어코드 업데이트
	int updateLangCode(SystLangVO row);
	
	// 언어코드 삭제
	int deleteLangCode(SystLangVO row);
	
	// 언어코드 중복체크
	boolean checkDupLangCode(SystLangVO row);
	
}

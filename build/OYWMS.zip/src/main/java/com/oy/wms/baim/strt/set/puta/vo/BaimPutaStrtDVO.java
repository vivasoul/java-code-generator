package com.oy.wms.baim.strt.set.puta.vo;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;
import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimPutaStrtDVO implements Serializable ,DataSetRowTypeAccessor {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1092923301644836207L;
	private String cntrCd;
	private String whCd;
	private String whNm;
	private String putaStrtCd;
	private String dtlNo;
	private String putaTypeCd;
	private String putaSectCd;
	private String putaZoneCd;
	private String fromCellCd;
	private String toCellCd;
	private String locTypeCd1;
	private String locTypeCd2;
	private String locTypeCd3;
	private String locTypeCd4;
	private String cellTypeCd1;
	private String cellTypeCd2;
	private String cellTypeCd3;
	private String cellTypeCd4;
	private String hldSttsCd;
	private String putaLocCd;
	private String mixedItemYn;
	private String mixedLotYn;
	private String wtChkYn;
	private String volChkYn;
	private String emptyCellChkYn;
	private String putaCellTypeCd;
	private String whibTypeCheckYn;
	private String zoneCd;
	private String putaStrtDscr;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private String chk;
	private int rowType;
}
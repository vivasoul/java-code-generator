package com.oy.wms.baim.strt.set.puta.vo;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimPutaStrtMVO implements DataSetRowTypeAccessor {
	
	private String chk;
	private String cntrCd;
	private String whCd;
	private String whNm;
	private String putaStrtCd;
	private String putaStrtDscr;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	
	private int rowType;
}

package com.oy.wms.baim.item;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;
import com.oy.wms.baim.item.vo.BaimAltnCodeVO;
import com.oy.wms.baim.item.vo.BaimItemGrpVO;
import com.oy.wms.baim.item.vo.BaimItemHistVO;
import com.oy.wms.baim.item.vo.BaimItemVO;
import com.oy.wms.baim.item.vo.BaimItemUnitVO;

import lombok.RequiredArgsConstructor;


@Service("baimItemService")
@RequiredArgsConstructor
public class BaimItemService {

	private final BaimItemMapper baimItemMapper;
	
	/**
	 * 상품그룹 조회
	 **/
	public List<BaimItemGrpVO> selectItemGrpList(BaimItemGrpVO vo) {
		
		return baimItemMapper.selectItemGrpList(vo);
	}
	
	/**
	 * 상품그룹 저장
	 **/
	public int saveItemGrpList(List<BaimItemGrpVO> data) throws NexacroBizException{
		
		if(data.isEmpty()) {
			// TODO (2022.12.29) 다국어 조회 처리 필요
//			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), CommonLang.select({CntryLangCd}, {MsgCd}, "저장할 데이터가 존재하지 않습니다."));
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimItemGrpVO row: data) {			
						
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					if(baimItemMapper.checkDupItemGrp(row)) {
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
					} else {
						res += baimItemMapper.insertItemGrp(row);
					}		   
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += baimItemMapper.updateItemGrp(row);					
					break;
			}
			
			
		}
		
		return res;
	}
	
	/**
	 * 상품그룹 삭제
	 **/	
	public int deleteItemGrpList(List<BaimItemGrpVO> data) {
		int res = 0;
		for(BaimItemGrpVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
			case DataSet.ROW_TYPE_DELETED:
				res += baimItemMapper.deleteItemGrp(row);
				break;	
			}
		}
		
		return res;
	}
	
	/**
	 * 상품이력 조회
	 **/
	public List<BaimItemHistVO> selectItemHistList(BaimItemHistVO vo) {
		
		return baimItemMapper.selectItemHistList(vo);
	}
	
	/**
	 * 상품대체코드 조회
	 **/
	public List<BaimAltnCodeVO> selectAltnCodeList(BaimAltnCodeVO vo) {
		
		return baimItemMapper.selectAltnCodeList(vo);
	}
	
	/**
	 * 상품대체코드 저장
	 **/
	public int saveAltnCodeList(List<BaimAltnCodeVO> data) throws NexacroBizException{
		
		if(data.isEmpty()) {
			// TODO (2022.12.29) 다국어 조회 처리 필요
//			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), CommonLang.select({CntryLangCd}, {MsgCd}, "저장할 데이터가 존재하지 않습니다."));
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimAltnCodeVO row: data) {			
						
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					res += baimItemMapper.insertAltnCode(row);
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += baimItemMapper.updateAltnCode(row);
					break;
			}
		}
		
		return res;
	}
	
	/**
	 * 상품대체코드 삭제
	 **/	
	public int deleteAltnCodeList(List<BaimAltnCodeVO> data) {
		int res = 0;
		for(BaimAltnCodeVO row : data) {
			
			res += baimItemMapper.deleteAltnCode(row);
		}
		
		return res;
	}

	//상품관리 조회
	public List<BaimItemVO> selectItemList(BaimItemVO vo) {
		
		return baimItemMapper.selectItemList(vo);
	}
	
	//상품관리 I/U
	public int saveItemList(List<BaimItemVO> data) throws NexacroBizException{
		
		int res = 0;
		for(BaimItemVO row: data) {			
						
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					if(baimItemMapper.checkDupItem(row)) {
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
					} else {
						res += baimItemMapper.mergeItem(row);
						       baimItemMapper.insertItemHist(row);
					}		
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += baimItemMapper.updateItem(row);
						   baimItemMapper.insertItemHist(row);
					break;
			}
		}
		
		return res;
	}
	
	//상품관리 삭제 시 하위 단위 테이블 정보도 같이 삭제
	public int deleteItemList(List<BaimItemVO> data) {
		int res = 0;
		String modiUserId =  data.get(0).getModiUserId();//단위 테이블도 같이 삭제하면서 수정자 정보를 넣어줘야함
		for(BaimItemVO row : data) {
			int rowType = row.getRowType();
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED:			
					res += baimItemMapper.deleteItem(row);
					       baimItemMapper.deleteItemHist(row);
					List<BaimItemUnitVO> rtn = selectItemDRtn(row);		
					for(int i =0; i < rtn.size(); i++) {
						rtn.get(i).setModiUserId(modiUserId);
						baimItemMapper.deleteItemDtl(rtn.get(i));
						baimItemMapper.deleteItemDtlHist(rtn.get(i));
					}					
					break;
			}		
		}
		
		return res;
	}	

	//상품 하위 단위 리스트 조회
	private List<BaimItemUnitVO> selectItemDRtn(BaimItemVO row) {
		return baimItemMapper.selectItemDRtn(row);
	}
	
	//상품 단위 조회
	public List<BaimItemUnitVO> selectItemDList(BaimItemUnitVO vo) {
		
		return baimItemMapper.selectItemDList(vo);
	}
	
	//상품 단위 저장
	public int saveItemDList(List<BaimItemUnitVO> data) throws NexacroBizException{
		
		int res = 0;
		for(BaimItemUnitVO row: data) {			
						
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					res += baimItemMapper.mergeItemDtl(row);
					       baimItemMapper.insertItemDtlHist(row);
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += baimItemMapper.updateItemDtl(row);
				           baimItemMapper.insertItemDtlHist(row);
					break;
				case DataSet.ROW_TYPE_DELETED:
					res += baimItemMapper.deleteItemDtl(row);
				           baimItemMapper.deleteItemDtlHist(row);
					break;		
			}
		}
		
		return res;
	}	
	
}

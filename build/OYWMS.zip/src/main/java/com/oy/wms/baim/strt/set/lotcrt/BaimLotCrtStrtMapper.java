package com.oy.wms.baim.strt.set.lotcrt;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BaimLotCrtStrtMapper {
		
	// 로트생성전략 조회
	List<BaimLotCrtStrtVO> selectLotCreationStrategy(BaimLotCrtStrtVO param);

	// 로트생성전략 등록
	int insertLotCreationStrategy(BaimLotCrtStrtVO row);
		
	// 로트생성전략 수정
	int updateLotCreationStrategy(BaimLotCrtStrtVO row);
		
	// 로트생성전략 삭제
	int deleteLotCreationStrategy(BaimLotCrtStrtVO row);
		
}

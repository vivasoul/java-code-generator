package com.oy.wms.baim.ware;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.baim.strt.set.BaimStrtVO;
import com.oy.wms.baim.ware.vo.BaimCntrVO;
import com.oy.wms.baim.ware.vo.BaimWareVO;
import com.oy.wms.login.vo.LoginVO;

import lombok.RequiredArgsConstructor;

@Controller
//@RequiredArgsConstructor
@RequestMapping("/baim/ware")
public class BaimWareController {

	private final BaimWareService baimWareService;
	
	public BaimWareController(BaimWareService baimWareService) {
		this.baimWareService = baimWareService;
	}
	
	/**
	 * 센터 조회
	 */
	@PostMapping("/getCntr")
	public NexacroResult getCntr(@ParamDataSet(name = "dsSearch") BaimCntrVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimCntrVO> list =  baimWareService.getCntr(input);
		result.addDataSet("dsList", list);			
		
		return result;
	}	
	
	/**
	 * 센터 저장
	 */
	@PostMapping("/saveCntr")
	public NexacroResult saveCntr(@ParamDataSet(name = "dsList") List<BaimCntrVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserIdCntr(data);
		int res = baimWareService.saveCntr(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}			
		
		return result;
	}
	
	/**
	 * 센터 삭제
	 */
	@PostMapping("/deleteCntr")
	public NexacroResult deleteCntr(@ParamDataSet(name = "dsList") List<BaimCntrVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserIdCntr(data);
		int res = baimWareService.deleteCntr(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}				
		
		return result;
	}	
	
	/**
	 * 창고 조회
	 */
	@PostMapping("/getWare")
	public NexacroResult getWare(@ParamDataSet(name = "dsSearch") BaimWareVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimWareVO> list =  baimWareService.getWare(input);
		result.addDataSet("dsList", list);			
		
		return result;
	}
	
	
	/**
	 * 창고 저장
	 */
	@PostMapping("/saveWare")
	public NexacroResult saveWare(@ParamDataSet(name = "dsList") List<BaimWareVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserIdWare(data);
		int res = baimWareService.saveWare(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}			
		
		return result;
	}

	
	/**
	 * 창고 삭제
	 */
	@PostMapping("/deleteWare")
	public NexacroResult deleteWare(@ParamDataSet(name = "dsList") List<BaimWareVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserIdWare(data);
		int res = baimWareService.deleteWare(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}				
		
		return result;
	}
	
	private void setUserIdCntr(List<BaimCntrVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(BaimCntrVO vo : data) {
			vo.setRegUserId(userId);
			vo.setModiUserId(userId);
		}
	}	
	
	private void setUserIdWare(List<BaimWareVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(BaimWareVO vo : data) {
			vo.setRegUserId(userId);
			vo.setModiUserId(userId);
		}
	}	
}
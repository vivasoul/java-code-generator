package com.oy.wms.syst.menu;

import java.io.Serializable;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SystMenuVO implements Serializable ,DataSetRowTypeAccessor {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7973578241449439224L;
	
	private String menuCd;
	private String upperMenuCd;
	private String refMenuCd;
	private String menuNm;
	private String menuTypeCd;
	private String menuUrl;
	private String menuDscr;
	private String menuImgPath;
	private String mainMenuSortOrdr;
	private String subMenuSortOrdr;
	private String popupYn;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	
	private String workScope;	// 영업구분 
	
	private String chk;
	private int rowType;
}
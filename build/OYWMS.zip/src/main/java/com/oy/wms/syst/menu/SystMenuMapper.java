package com.oy.wms.syst.menu;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SystMenuMapper {
		
	// 메뉴 조회
	List<SystMenuVO> selectMenu(SystMenuVO param);

	// 메뉴 등록
	int insertMenu(SystMenuVO row);
	
	// 메뉴 수정
	int updateMenu(SystMenuVO row);
	
	// 메뉴 삭제
	int deleteMenu(SystMenuVO row);

	// 메뉴 중복 체크
	boolean checkDupMenu(SystMenuVO row);
		
}

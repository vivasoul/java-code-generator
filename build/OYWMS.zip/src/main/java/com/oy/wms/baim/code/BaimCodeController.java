package com.oy.wms.baim.code;


import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.baim.code.vo.BaimCodeDVO;
import com.oy.wms.baim.code.vo.BaimCodeMVO;
import com.oy.wms.login.vo.LoginVO;

import lombok.RequiredArgsConstructor;


@Controller
@RequiredArgsConstructor
@RequestMapping("/baimMgmt")
public class BaimCodeController {
	
	private final BaimCodeService baimCodeService;
	
	/**
	 * 기준코드 조회
	 */
	@PostMapping("/getCode")
	public NexacroResult getCode(@ParamDataSet(name = "dsSearch", required = false) BaimCodeMVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimCodeMVO> list =  baimCodeService.getCode(input);
		result.addDataSet("dsList", list);
		
		return result;
	}
	

	/**
	 * 기준코드상세 조회
	 */
	@PostMapping("/getCodeDetail")
	public NexacroResult getCodeDetail(@ParamDataSet(name = "dsDtlSearch") BaimCodeDVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimCodeDVO> list =  baimCodeService.getCodeDetail(input);
		result.addDataSet("dsDtlList", list);
		
		return result;
	}
	
	
	/**
	 * 기준코드 저장
	 */
	@PostMapping("/saveCode")
	public NexacroResult saveCode(@ParamDataSet(name = "dsList") List<BaimCodeMVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		setUserIdM(data);
		int res = baimCodeService.saveCode(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}
		
		return result;
	}

	/**
	 * 기준코드상세 저장
	 */
	@PostMapping("/saveCodeDetail")
	public NexacroResult saveCodeDetail(@ParamDataSet(name = "dsDtlList") List<BaimCodeDVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		setUserIdD(data);
		int res = baimCodeService.saveCodeDetail(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}
		
		return result;
	}

	/**
	 * 기준코드 삭제
	 */
	@PostMapping("/deleteCode")
	public NexacroResult deleteCode(@ParamDataSet(name = "dsList") List<BaimCodeMVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		setUserIdM(data);
		int res = baimCodeService.deleteCode(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
	
	/**
	 * 기준코드상세 삭제
	 */
	@PostMapping("/deleteCodeDetail")
	public NexacroResult deleteCodeDetail(@ParamDataSet(name = "dsDtlList") List<BaimCodeDVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		setUserIdD(data);
		int res = baimCodeService.deleteCodeDetail(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}	
		
		return result;
	}

	/**
	 * 코드 마스터 사용자 세팅
	 */
	private void setUserIdM(List<BaimCodeMVO> vo) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		
		for(BaimCodeMVO row : vo) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}
	
	/**
	 * 코드 디테일 사용자 세팅
	 */
	private void setUserIdD(List<BaimCodeDVO> vo) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		
		for(BaimCodeDVO row : vo) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}
}

package com.oy.wms.syst.noti;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nexacro.java.xapi.data.DataSet;
import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;
import com.oy.config.mvc.Parameters;

import lombok.RequiredArgsConstructor;

@Service("SystNotiService")
@RequiredArgsConstructor
public class SystNotiService {

	private final SystNotiMapper systNotiMapper;
	
	/**
	 * 공지사항 조회
	 */
	public List<SystNotiVO> getNoti(SystNotiVO input) throws Exception {
		
		return systNotiMapper.selectNoti(input);
	}
	
	/**
	 * 공지사항 등록
	 */
	public int saveNoti(List<SystNotiVO> data) throws Exception {
		if(data.isEmpty()) {
			// TODO (2022.12.29) 다국어 조회 처리 필요
//			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), CommonLang.select({CntryLangCd}, {MsgCd}, "저장할 데이터가 존재하지 않습니다."));
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(SystNotiVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					res += systNotiMapper.insertNoti(row);
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += systNotiMapper.updateNoti(row);
					break;
			}
		}		
		return res;
	}
	
	/**
	 * 공지사항 삭제 
	 */
	public int deleteNoti(List<SystNotiVO> data) throws Exception {
		
		int res = 0;
		
		for(SystNotiVO row : data) {
			int rowType = row.getRowType();
			
			switch(rowType) {
			case DataSet.ROW_TYPE_DELETED : 
				res += systNotiMapper.deleteNoti(row);
				break;
			}		
		}
		return res;
	}
	
}

package com.oy.wms.baim.locn;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;
import com.oy.wms.baim.locn.vo.BaimCellVO;
import com.oy.wms.baim.locn.vo.BaimLocVO;
import com.oy.wms.baim.locn.vo.BaimZoneVO;

@Service("baimLocnService")
public class BaimLocnService {
	 
	private final BaimLocnMapper baimLocMapper;
	
	public BaimLocnService(BaimLocnMapper baimLocMapper) {
		this.baimLocMapper = baimLocMapper;
	}
	
	/**
	 * ZONE 조회
	 */
	public List<BaimZoneVO> getZone(BaimZoneVO data) throws Exception {
		//dsIn = dsIn
		
		return baimLocMapper.selectZone(data);
	}
	
	
	/**
	 * ZONE 저장
	 */
	@Transactional
	public int saveZone(List<BaimZoneVO> data) throws Exception {
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimZoneVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					if(baimLocMapper.checkDupZone(row)) {
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
					} else {
						res += baimLocMapper.insertZone(row);
					}
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += baimLocMapper.updateZone(row);
					break;
			}
		}
		
		return res;
		
	}
	
	
	/**
	 * ZONE 삭제
	 */
	@Transactional
	public int deleteZone(List<BaimZoneVO> data) throws Exception {
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "삭제할 데이터가 존재하지 않습니다.");
		}		
		
		int res = 0;
		for(BaimZoneVO row : data) {
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED:
						res += baimLocMapper.deleteZone(row);
						break;
			}
			
		}
		
		return res;
	}
	
	
	/**
	 * Location 조회
	 */
	public List<BaimLocVO> getLocation(BaimLocVO input) throws Exception {
		
		return baimLocMapper.selectLocation(input);
	}
	
	
	/**
	 * Location 저장
	 */
	@Transactional
	public int saveLocation(List<BaimLocVO> data) throws Exception {
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimLocVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					if(baimLocMapper.checkDupLocation(row)) {
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
					} else {
						res += baimLocMapper.insertLocation(row);
					}
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += baimLocMapper.updateLocation(row);
					break;
			}
		}
		
		return res;
		
	}
	
	
	/**
	 * Location 삭제
	 */
	@Transactional
	public int deleteLocation(List<BaimLocVO> data) throws Exception {
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "삭제할 데이터가 존재하지 않습니다.");
		}		
		
		int res = 0;
		for(BaimLocVO row : data) {
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED:
					res += baimLocMapper.deleteLocation(row);
					break;
			
			}
			
		}
		
		return res;
	}
	
	
	/**
	 * Cell 조회
	 */
	public List<BaimCellVO> getCell(BaimCellVO input) throws Exception {
		
		return baimLocMapper.selectCell(input);
	}
	
	
	/**
	 * CELL 저장
	 */
	@Transactional
	public int saveCell(List<BaimCellVO> data) throws Exception {
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimCellVO row : data) {
						
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					if(baimLocMapper.checkDupCell(row)) {
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
					} else {
						res += baimLocMapper.insertCell(row);
					}
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += baimLocMapper.updateCell(row);
					break;
			}
		}
		
		return res;
		
	}
	
	
	/**
	 * Cell 삭제
	 */
	@Transactional
	public int deleteCell(List<BaimCellVO> data) throws Exception {
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "삭제할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimCellVO row : data) {
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED:
					res += baimLocMapper.deleteCell(row);
					break;
			}
		}
		
		return res;
	}

}

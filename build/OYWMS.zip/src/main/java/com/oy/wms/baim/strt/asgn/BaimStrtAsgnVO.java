package com.oy.wms.baim.strt.asgn;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimStrtAsgnVO implements DataSetRowTypeAccessor {
	private String mngTypeCd; //관리정보구분(창고/고객시/품목그룹/품목)
	private String cntrCd;
	private String cntrNm;
	private String whCd;
	private String whNm;
	private String custId;
	private String custNm;
	private String itemCd;
	private String itemNm;
	private String itemGrpCd;
	private String itemGrpNm;
	private String strtSetCd;
	private String bfAllocStrtCd;
	private String bfAllocStrtDscr;
	private String allocStrtCd;
	private String allocStrtDscr;
	private String stockReplStrtCd;
	private String stockReplStrtDscr;
	private String putaStrtCd;
	private String putaStrtDscr;
	private String lotGenStrtCd;
	private String lotGenStrtDscr;
	private String lotAttrChgStrtCd;
	private String lotAttrChgStrtDscr;
	private String lotEfctChkCd;
	private String lotEfctChkDscr;
	private String agvStockReplYn;
	private String delYn;
	private String strtSetDscr;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	
	private int chk;
	private int rowType;
}
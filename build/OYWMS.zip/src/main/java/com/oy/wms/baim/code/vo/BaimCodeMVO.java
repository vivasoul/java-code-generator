package com.oy.wms.baim.code.vo;

import java.io.Serializable;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimCodeMVO implements Serializable ,DataSetRowTypeAccessor {
	
	private static final long serialVersionUID = 2117593742233832698L;
	
	private String stdCd;
	private String stdCdNm;
	private String userTypeCd;
	private String userTypeNm;
	private String mlngYn;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private String chk;
	private int rowType;
	
}

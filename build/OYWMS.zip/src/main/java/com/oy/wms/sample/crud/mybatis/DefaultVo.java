package com.oy.wms.sample.crud.mybatis;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@Data
public class DefaultVo implements Serializable {
    private static final long serialVersionUID = 8609625522601627023L;

//    @ApiModelProperty(hidden = true)
    private boolean del = false;

//    @ApiModelProperty(hidden = true)
    private String firstId = "";

//    @ApiModelProperty(hidden = true)
    private String firstDt = "";

//    @ApiModelProperty(hidden = true)
    private String lastId = "";

//    @ApiModelProperty(hidden = true)
    private String lastDt = "";

    public String toString() {
        return ToStringBuilder.reflectionToString(this);
//        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    public String toStringDefault() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.DEFAULT_STYLE);
    }

    public String toStringMultiline() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    public String toStringNoFieldName() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.NO_FIELD_NAMES_STYLE);
    }

    public String toStringShortPrefix() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }

    public String toStringSimple() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SIMPLE_STYLE);
    }

}

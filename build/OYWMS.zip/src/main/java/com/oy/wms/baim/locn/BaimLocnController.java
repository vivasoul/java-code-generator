package com.oy.wms.baim.locn;


import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.baim.locn.vo.BaimCellVO;
import com.oy.wms.baim.locn.vo.BaimLocVO;
import com.oy.wms.baim.locn.vo.BaimZoneVO;
import com.oy.wms.baim.strt.asgn.BaimStrtAsgnVO;
import com.oy.wms.login.vo.LoginVO;


@Controller
@RequestMapping("/baim/locn")
public class BaimLocnController {
	
	private final BaimLocnService baimLocnService;
	
	public BaimLocnController(BaimLocnService baimLocnService) {
		this.baimLocnService = baimLocnService;
	}	
	
	/**
	 * ZONE 저장
	 */
	@PostMapping("/saveZone")
	public NexacroResult saveZone(@ParamDataSet(name = "dsList") List<BaimZoneVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setZoneUserId(data);
		int res = baimLocnService.saveZone(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}
		
		return result;
	}
	
	/**
	 * ZONE 조회
	 */
	@PostMapping("/getZone")
	public NexacroResult getZone(@ParamDataSet(name = "dsSearch") BaimZoneVO dsIn) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimZoneVO> list =  baimLocnService.getZone(dsIn);
		result.addDataSet("dsList", list);				
		
		return result;
	}

	
	/**
	 * ZONE 삭제
	 */
	@PostMapping("/deleteZone")
	public NexacroResult deleteZone(@ParamDataSet(name = "dsList") List<BaimZoneVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		int res = baimLocnService.deleteZone(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
	
	/**
	 * Location 저장
	 */
	@PostMapping("/saveLocation")
	public NexacroResult saveLocation(@ParamDataSet(name = "dsList") List<BaimLocVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setLocUserId(data);
		int res = baimLocnService.saveLocation(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
	/**
	 * Location 조회
	 */
	@PostMapping("/getLocation")
	public NexacroResult getLocation(@ParamDataSet(name = "dsSearch") BaimLocVO dsIn) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimLocVO> list =  baimLocnService.getLocation(dsIn);
		result.addDataSet("dsList", list);			
		
		return result;
	}

	
	/**
	 * Location 삭제
	 */
	@PostMapping("/deleteLocation")
	public NexacroResult deleteLocation(@ParamDataSet(name = "dsList") List<BaimLocVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		int res = baimLocnService.deleteLocation(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}			
		
		return result;
	}
	
	
	/**
	 * Cell 저장
	 */
	@PostMapping("/saveCell")
	public NexacroResult saveCell(@ParamDataSet(name = "dsList") List<BaimCellVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setCellUserId(data);
		int res = baimLocnService.saveCell(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}			
		
		return result;
	}
	
	/**
	 * Cell 조회
	 */
	@PostMapping("/getCell")
	public NexacroResult getCell(@ParamDataSet(name = "dsSearch") BaimCellVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimCellVO> list =  baimLocnService.getCell(input);
		result.addDataSet("dsList", list);			
		
		return result;
	}

	
	/**
	 * Location 삭제
	 */
	@PostMapping("/deleteCell")
	public NexacroResult deleteCell(@ParamDataSet(name = "dsList") List<BaimCellVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		int res = baimLocnService.deleteCell(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}				
		
		return result;
	}

	private void setZoneUserId(List<BaimZoneVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(BaimZoneVO vo : data) {
			vo.setRegUserId(userId);
			vo.setModiUserId(userId);
		}
	}
	
	private void setLocUserId(List<BaimLocVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(BaimLocVO vo : data) {
			vo.setRegUserId(userId);
			vo.setModiUserId(userId);
		}
	}	
	
	private void setCellUserId(List<BaimCellVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(BaimCellVO vo : data) {
			vo.setRegUserId(userId);
			vo.setModiUserId(userId);
		}
	}	
}

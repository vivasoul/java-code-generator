package com.oy.wms.baim.item;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.baim.item.vo.BaimAltnCodeVO;
import com.oy.wms.baim.item.vo.BaimItemGrpVO;
import com.oy.wms.baim.item.vo.BaimItemHistVO;
import com.oy.wms.baim.item.vo.BaimItemUnitVO;
import com.oy.wms.baim.item.vo.BaimItemVO;
import com.oy.wms.login.vo.LoginVO;

import lombok.RequiredArgsConstructor;



@Controller
@RequiredArgsConstructor
@RequestMapping("/baim/item")
public class BaimItemController {
	
	private final BaimItemService baimItemService;
	
	/**
	 * 상품그룹 조회
	 */
	@PostMapping("/getItemGrpList")
	public NexacroResult getItemGrpList(@ParamDataSet(name = "dsSearch") BaimItemGrpVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimItemGrpVO> list =  baimItemService.selectItemGrpList(input);
		result.addDataSet("dsList", list);
		
		return result;
	}
	
	/**
	 * 상품그룹 저장
	 */
	@PostMapping("/saveItemGrp")
	public NexacroResult saveItemGrpList(@ParamDataSet(name = "dsList") List<BaimItemGrpVO> data) throws Exception {

		NexacroResult result = new NexacroResult();
		setUserId_grp(data);
		int res = baimItemService.saveItemGrpList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}	
	
	/**
	 * 상품그룹 삭제
	 */
	@PostMapping("/deleteItemGrp")
	public NexacroResult deleteItemGrp(@ParamDataSet(name = "dsList") List<BaimItemGrpVO> data) throws Exception {

		NexacroResult result = new NexacroResult();
		setUserId_grp(data);
		int res = baimItemService.deleteItemGrpList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}	
	
	/**
	 * 상품이력 조회
	 */
	@PostMapping("/getItemHist")
	public NexacroResult getItemHistList(@ParamDataSet(name = "dsSearch") BaimItemHistVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimItemHistVO> list =  baimItemService.selectItemHistList(input);
		result.addDataSet("dsList", list);
		
		return result;
	}			
	
	/**
	 * 상품대체코드 조회
	 */
	@PostMapping("/getAltnCode")
	public NexacroResult getAltnCodeList(@ParamDataSet(name = "dsSearch") BaimAltnCodeVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimAltnCodeVO> list =  baimItemService.selectAltnCodeList(input);
		result.addDataSet("dsList", list);
		
		return result;
	}		
	
	/**
	 * 상품대체코드 저장
	 */
	@PostMapping("/saveAltnCode")
	public NexacroResult saveAltnCodeList(@ParamDataSet(name = "dsList") List<BaimAltnCodeVO> data) throws Exception {

		NexacroResult result = new NexacroResult();
		int res = baimItemService.saveAltnCodeList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}		
	
	/**
	 * 상품대체코드 삭제
	 */	
	@PostMapping("/deleteAltnCode")
	public NexacroResult deleteAltnCodeList(@ParamDataSet(name = "dsList") List<BaimAltnCodeVO> data) throws Exception {

		NexacroResult result = new NexacroResult();
		int res = baimItemService.deleteAltnCodeList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}

	/**
	 * 상품마스터 조회
	 */
	@PostMapping("/getItemList")
	public NexacroResult getItemList(@ParamDataSet(name = "dsSearch") BaimItemVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimItemVO> list =  baimItemService.selectItemList(input);
		result.addDataSet("dsList", list);
		
		return result;
	}	
	
	/**
	 * 상품마스터 저장
	 */
	@PostMapping("/saveItem")
	public NexacroResult saveItemList(@ParamDataSet(name = "dsList") List<BaimItemVO> data, 
			@ParamDataSet(name = "dsListDtl") List<BaimItemUnitVO> dataDtl) throws Exception {

		NexacroResult result = new NexacroResult();
		
		setUserId_item(data);
		int res = baimItemService.saveItemList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}	
		setUserId_itemDtl(dataDtl);
		int resDtl = baimItemService.saveItemDList(dataDtl);
		if(resDtl < 1) {
			result.setErrorCode(-1);
		}
		
		return result;
	}		
	
	/**
	 * 상품마스터 삭제
	 */
	@PostMapping("/deleteItem")
	public NexacroResult deleteItemList(@ParamDataSet(name = "dsList") List<BaimItemVO> data) throws Exception {

		NexacroResult result = new NexacroResult();
		
		setUserId_item(data);
		int res = baimItemService.deleteItemList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}		
	
	/**
	 * 상품 단위 조회
	 */	
	@PostMapping("/getItemDList")
	public NexacroResult getItemDList(@ParamDataSet(name = "dsSearchDtl") BaimItemUnitVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimItemUnitVO> list =  baimItemService.selectItemDList(input);
		result.addDataSet("dsListDtl", list);
		
		return result;
	}	

	//상품용 유저 정보
	private void setUserId_item(List<BaimItemVO> vo) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		
		for(BaimItemVO row : vo) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}
	//상품단위용 유저 정보
	private void setUserId_itemDtl(List<BaimItemUnitVO> vo) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		
		for(BaimItemUnitVO row : vo) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}	
	
	//상품그룹용 유저 정보
	private void setUserId_grp(List<BaimItemGrpVO> vo) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		
		for(BaimItemGrpVO row : vo) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}	
}

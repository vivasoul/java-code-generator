package com.oy.wms.baim.locn.vo;

import java.io.Serializable;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimCellVO implements Serializable, DataSetRowTypeAccessor {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2762409244073922946L;
	private String cntrCd;
	private String whCd;
	private String zoneCd;
	private String locCd;
	private String cellCd;
	private String cntrNm;
	private String whNm;
	private String cellNm;
	private int prtyRank;
	private String dtlNo;
	private String cellSaveCd;
	private String cellSttsCd;
	private String locSttsCd;
	private String zoneSttsCd;
	private String sectSttsCd;
	private String hldSttsCd;
	private String dockYn;
	private String mixedItemYn;
	private String mixedLotYn;
	private String routeSno;
	private String saveRackTypeCd;
	private String putaItemCd;
	private float hgt;
	private float wdth;
	private float len;
	private String lenUnitCd;
	private String lossIdYn;
	private String lossLotYn;
	private String putaCellTypeCd;
	private String cellDivCd;
	private float drawWdth;
	private float drawHgt;
	private float drawItemXposVal;
	private float drawItemYposVal;
	private float drawItemWdth;
	private float drawItemHgt;
	private String cellFlno;
	private String putaPossYn;
	private String allocFailRsn;
	private String cellVolTypeCd;
	private String cellFlnoTypeCd;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private String chk;
	private int rowType;
}

package com.oy.wms.syst.user;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.login.vo.LoginVO;
import com.oy.wms.syst.user.vo.SysUserConnHVO;
import com.oy.wms.syst.user.vo.SystUserAuthVO;
import com.oy.wms.syst.user.vo.SystUserVO;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/systMgmt")
@RequiredArgsConstructor
public class SystUserController {
	
	private final SystUserService systUserService;
		
	/**
	 * 사용자리스트 조회
	 */
	@PostMapping("/getUser")
	public NexacroResult getUser(@ParamDataSet(name = "dsSearch") SystUserVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<SystUserVO> list =  systUserService.getUser(input);
				
		result.addDataSet("dsList", list);

		
		return result;
	}	
	
	/**
	 * 사용자리스트 저장
	 */
	@PostMapping("/saveUser")
	public NexacroResult saveUser(@ParamDataSet(name = "dsList") List<SystUserVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
			
		setUserId(data);
		int res = systUserService.saveUser(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}else if(res==1004) {
			result.setErrorCode(1004);
		}				
		
		return result;
	}	
	
	/**
	 * 사용자리스트 삭제
	 */
	@PostMapping("/deleteUser")
	public NexacroResult deleteUser(@ParamDataSet(name = "dsList") List<SystUserVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		setUserId(data);
		int res = systUserService.deleteUser(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}				
		
		return result;
	}		
	
	/**
	 * 사용자 비밀번호 초기화
	 */
	@PostMapping("/saveUserPwReset")
	public NexacroResult saveUserPwReset(@ParamDataSet(name = "dsList") List<SystUserVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		setUserId(data);
		int res = systUserService.saveUserPwReset(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}				
		
		return result;
	}	
	
	/**
	 * 사용자 리스트 상세정보 - 창고목록 조회
	 */
	@PostMapping("/getUserDetailWare")
	public NexacroResult getUserDetailWare(@ParamDataSet(name = "dsSearch") SystUserAuthVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<SystUserAuthVO> list =  systUserService.getUserDetailWare(input);
		result.addDataSet("dsCode", list);
		
		return result;
	}	
	
	/**
	 * 사용자 리스트 상세정보 - 창고목록 저장
	 */
	@PostMapping("/saveUserDetailWare")
	public NexacroResult saveUserDetailWare(@ParamDataSet(name = "dsCode") List<SystUserAuthVO> data) throws Exception {

		NexacroResult result = new NexacroResult();
		int res = systUserService.updateUserDetailWare(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}			
		
		return result;
	}	
	
	/**
	 * 사용자 리스트 상세정보 - 권한목록 조회
	 */
	@PostMapping("/getUserDetailAuth")
	public NexacroResult getUserDetailAuth(@ParamDataSet(name = "dsSearchDtl") SystUserVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<SystUserAuthVO> list =  systUserService.getUserDetailAuth(input);
		result.addDataSet("dsList_auth", list);		
		
		return result;
	}	
	
	/**
	 * 사용자 권한 목록 조회 팝업
	 */
	@PostMapping("/selectUserAuthPopup")
	public NexacroResult selectUserAuthPopup(@ParamDataSet(name = "dsSearch") SystUserVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<SystUserAuthVO> list =  systUserService.selectUserAuthPopup(input);
		result.addDataSet("dsList", list);		
		
		return result;
	}	
	
	/**
	 * 사용자 리스트 상세정보 - 권한목록 저장
	 */
	@PostMapping("/saveUserDetailAuth")
	public NexacroResult saveUserDetailAuth(@ParamDataSet(name = "dsCode") List<SystUserAuthVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		int res = systUserService.updateUserDetailAuth(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}		
	
	/**
	 * 사용자 리스트 상세정보 - 고객목록 조회
	 */
	@PostMapping("/getUserDetailCust")
	public NexacroResult getUserDetailCust(@ParamDataSet(name = "dsSearch") SystUserAuthVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<SystUserAuthVO> list =  systUserService.getUserDetailCust(input);
		result.addDataSet("dsCode", list);				
		
		return result;
	}	
	
	/**
	 * 사용자 리스트 상세정보 - 고객목록 저장
	 */
	@PostMapping("/saveUserDetailCust")
	public NexacroResult saveUserDetailCust(@ParamDataSet(name = "dsCode") List<SystUserAuthVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		int res = systUserService.updateUserDetailCust(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}				
		
		return result;
	}	
	
	/*********************************************************************************/
	/**
	 * 사용자접속 조회
	 */
	@PostMapping("/getConnetInfo")
	public NexacroResult getConnetInfo(@ParamDataSet(name = "dsSearch") SysUserConnHVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<SysUserConnHVO> list =  systUserService.getConnetInfo(input);
		result.addDataSet("dsCode", list);	
		
		return result;
	}		
	
	
	/**
	 * 사용자접속 저장
	 */
	@PostMapping("/saveConnetInfo")
	public NexacroResult saveConnetInfo(@ParamDataSet(name = "dsCode") List<SysUserConnHVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		int res = systUserService.saveConnetInfo(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}		
	
	//유저 정보 세팅
	private void setUserId(List<SystUserVO> vo) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		
		for(SystUserVO row : vo) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}	

	
}

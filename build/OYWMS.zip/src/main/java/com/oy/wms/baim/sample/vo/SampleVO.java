package com.oy.wms.baim.sample.vo;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SampleVO implements DataSetRowTypeAccessor{
	private String id;
	private long cnt;
	private String txt;
	private String regDt;
	private String modiDt;
	private String regUserId;
	private String modiUserId;
	
	private int rowType;
}

package com.oy.wms.syst.hist;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.syst.hist.vo.PrgmErrHistVO;
import com.oy.wms.syst.hist.vo.PrgmUseHistVO;

@Controller
@RequestMapping("/syst/hist")
public class SystHistController {
	
	@Resource(name = "systHistService")
	private SystHistService systHistService;
	
	@PostMapping("/getPrgmUseHist")
	public NexacroResult getPrgmUseHist(@ParamDataSet(name = "dsSearch") PrgmUseHistVO dsIn) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<PrgmUseHistVO> list =  systHistService.getPrgmUseHist(dsIn);
		result.addDataSet("dsList", list);			
		
		return result;
	}

	@PostMapping("/getPrgmErrHist")
	public NexacroResult getPrgmErrHist(@ParamDataSet(name = "dsSearch") PrgmErrHistVO dsIn) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<PrgmErrHistVO> list =  systHistService.getPrgmErrHist(dsIn);
		result.addDataSet("dsList", list);
		
		return result;
	}
}

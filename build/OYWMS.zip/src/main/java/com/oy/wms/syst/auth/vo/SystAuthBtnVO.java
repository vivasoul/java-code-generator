package com.oy.wms.syst.auth.vo;

import java.io.Serializable;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SystAuthBtnVO implements Serializable ,DataSetRowTypeAccessor {

	private static final long serialVersionUID = -8247041400940661737L;

	private String chk;
	
	private String authCd;
	private String menuCd;
	private String menuNm;
	private String upperMenuCd;
	private String upperMenuNm;
	private String mainMenuSortOrdr;
	private String subMenuSortOrdr;	
	private String srchBtnYn;
	private String newBtnYn;
	private String saveBtnYn;
	private String delBtnYn;
	private String printBtnYn;
	private String xlsDownBtnYn;
	private String allChkYn;
	private String menuYn;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	
	private int lv;
	private int rowType;
}
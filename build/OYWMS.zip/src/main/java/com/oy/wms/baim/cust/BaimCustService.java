package com.oy.wms.baim.cust;

import java.util.List;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service("baimCustService")
@RequiredArgsConstructor
public class BaimCustService {
	
	private final BaimCustMapper baimCustMapper;

	/**
	 * 고객사 조회
	 */
	public List<BaimCustVO> selectCustList(BaimCustVO vo) {
		return baimCustMapper.selectCustList(vo);
	}
}

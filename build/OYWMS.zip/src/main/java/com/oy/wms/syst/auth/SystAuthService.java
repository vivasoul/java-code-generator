package com.oy.wms.syst.auth;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.wms.syst.auth.vo.SystAuthMenuVO;
import com.oy.wms.syst.auth.vo.SystAuthVO;
import com.oy.wms.syst.auth.vo.SystAuthBtnVO;
import com.oy.config.exception.NexacroErrorCode;
import lombok.RequiredArgsConstructor;

@Service("systAuthService")
@RequiredArgsConstructor

public class SystAuthService {

	private final SystAuthMapper systAuthMapper;
	
	
	
	/**
	 * 권한관리 - 조회
	 **/
	List<SystAuthVO> selectAuth(SystAuthVO vo) {	

		return systAuthMapper.selectAuth(vo);
	}
	
	/**
	 * 권한관리 - I/U 저장
	 **/	
	int saveAuth(List<SystAuthVO> data) throws NexacroBizException {
		
		int res = 0;
		for(SystAuthVO row: data) {			
			
			int rowType = row.getRowType();
			
			switch(rowType) {
			case DataSet.ROW_TYPE_INSERTED:
				if(systAuthMapper.checkDupAuthCd(row)) {
					throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
				} else {
					res += systAuthMapper.insertAuth(row);
				}
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += systAuthMapper.updateAuth(row);
					break;
			}
		}
		
		return res;
	}
		
	/**
	 * 권한관리 - 삭제
	 **/	
	int deleteAuth(List<SystAuthVO> data) throws NexacroBizException {
			
		int res = 0;
		for(SystAuthVO row: data) {					
			res += systAuthMapper.deleteAuth(row);
		}
				
		return res;
	}

	/**
	 * 권한관리 - 메뉴리스트 - 좌측 전체메뉴중 권한을 갖는 메뉴를 뺀 항목
	 */
	public List<SystAuthMenuVO> selectMenu(SystAuthMenuVO input) throws NexacroBizException {
		
		return systAuthMapper.selectMenu(input.getAuthCd());
	}	
	
	/**
	 * 권한관리 - 메뉴리스트 - 우측 권한을 갖는 메뉴
	 */
	public List<SystAuthMenuVO> selectMenuByAuth(SystAuthMenuVO input) throws NexacroBizException {
		
		return systAuthMapper.selectMenuByAuth(input.getAuthCd());
	}		
	
	/**
	 * 권한관리 - 메뉴리스트 권한 추가
	 */
	public int saveAuthMenu(List<SystAuthMenuVO> data) throws NexacroBizException {
		
		int res = 0;		
		for(SystAuthMenuVO row: data) {			
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					res += systAuthMapper.mergeAuthMenuList(row);
					break;
			}		
		}		
		
		return res;	
	}	
	

	/**
	 * 권한관리 - 메뉴리스트 권한 삭제
	 */
	int deleteAuthMenu(List<SystAuthMenuVO> data) {
		
		int res = 0;		
		for(SystAuthMenuVO row: data) {			
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					res += systAuthMapper.deleteAuthMenuList(row);
					break;
			}		
		}
		
		return res;
	}	
	
	//메뉴별 버튼 권한 조회
	public List<SystAuthBtnVO> selectAuthBtn(SystAuthBtnVO input) throws Exception {
		
		return systAuthMapper.selectAuthBtn(input);
	}	
	
	//메뉴별 버튼 권한 저장
	public int saveAuthBtn(List<SystAuthBtnVO> data) throws Exception {
		
		int res = 0;
		for(SystAuthBtnVO row : data) {
			res += systAuthMapper.updateAuthBtn(row);
		}		
		
		return res;
	}

}
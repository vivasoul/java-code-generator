package com.oy.wms.baim.strt.set;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service("baimStrtService")
@RequiredArgsConstructor
@Slf4j
public class BaimStrtService {
	
	private final BaimStrtMapper baimStrtMapper;
	
	/**
	 * 	전략세트 조회
	 */
	public List<BaimStrtVO> getStrtSet(BaimStrtVO vo) {
		
		return baimStrtMapper.selectStrtSet(vo);
	};

	/**
	 * 	전략세트 저장
	 */	
	@Transactional	
	public int saveStrtSet(List<BaimStrtVO> data) throws Exception {
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimStrtVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					if(baimStrtMapper.checkDupStrtSet(row)) {
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
					} else {
						res += baimStrtMapper.insertStrtSet(row);
					}
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += baimStrtMapper.updateStrtSet(row);
					break;
			}
		}
		
		return res;
	}
	
	/**
	 * 	전략세트 삭제
	 * @throws Exception 
	 */	
	@Transactional	
	public int deleteStrtSet(List<BaimStrtVO> data) throws Exception {

		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "삭제할 데이터가 존재하지 않습니다.");
		}		
		
		int res = 0;
		for(BaimStrtVO row : data) {
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED:
					res += baimStrtMapper.deleteStrtSet(row);
					break;
			}
		}
		
		return res;		
	}
	
	/**
	 * 	전략세트 중복 조회
	 */			
	public String getStrtSetDup(BaimStrtVO vo) {
		
		return baimStrtMapper.checkDupStrtSet(vo) ? "Y" : "N";
	}
}

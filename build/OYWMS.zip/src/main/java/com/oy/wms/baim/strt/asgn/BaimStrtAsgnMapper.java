package com.oy.wms.baim.strt.asgn;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BaimStrtAsgnMapper {
	
	//창고-전략설정 조회
	List<BaimStrtAsgnVO> selectStrtWareAsgn(BaimStrtAsgnVO vo);

	//창고-전략설정 저장
	int mergeStrtWareAsgn(BaimStrtAsgnVO vo);

	//창고-전략설정 삭제
	int deleteStrtWareAsgn(BaimStrtAsgnVO vo);

	//창고-전략설정 중복조회
	boolean checkDupStrtWareAsgn(BaimStrtAsgnVO vo);	
	
	
	//고객-전략설정 조회
	List<BaimStrtAsgnVO> selectStrtCustAsgn(BaimStrtAsgnVO vo);
	
	//고객-전략설정 저장
	int mergeStrtCustAsgn(BaimStrtAsgnVO vo);
	
	//고객-전략설정 삭제
	int deleteStrtCustAsgn(BaimStrtAsgnVO vo);
	
	//고객-전략설정 중복조회
	boolean checkDupStrtCustAsgn(BaimStrtAsgnVO vo);	
	
	
	//상품그룹-전략설정 조회
	List<BaimStrtAsgnVO> selectStrtItemGrpAsgn(BaimStrtAsgnVO vo);
	
	//상품그룹-전략설정 저장
	int mergeStrtItemGrpAsgn(BaimStrtAsgnVO vo);
	
	//상품그룹-전략설정 삭제
	int deleteStrtItemGrpAsgn(BaimStrtAsgnVO vo);
	
	//상품그룹-전략설정 중복조회
	boolean checkDupStrtItemGrpAsgn(BaimStrtAsgnVO vo);
	
	
	//상품-전략설정 조회
	List<BaimStrtAsgnVO> selectStrtItemAsgn(BaimStrtAsgnVO vo);
	
	//상품-전략설정 저장
	int mergeStrtItemAsgn(BaimStrtAsgnVO vo);
	
	//상품-전략설정 삭제
	int deleteStrtItemAsgn(BaimStrtAsgnVO vo);
	
	//상품-전략설정 중복조회
	boolean checkDupStrtItemAsgn(BaimStrtAsgnVO vo);
}

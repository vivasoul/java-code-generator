package com.oy.wms.syst.menu;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;

import lombok.RequiredArgsConstructor;

@Service("systMenuService")
@RequiredArgsConstructor
public class SystMenuService {
	
	private final SystMenuMapper systMenuMapper;
	
	/**
	 * 메뉴설정 - 메뉴 조회
	 */
	public List<SystMenuVO> getMenu(SystMenuVO input) throws Exception {
		//dsIn = dsSearch
		
		return systMenuMapper.selectMenu(input);
	}
	
		
	/**
	 * 메뉴설정 - 메뉴 저장
	 */
	public int saveMenu(List<SystMenuVO> data) throws Exception {
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(SystMenuVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					if(systMenuMapper.checkDupMenu(row)) {
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
					} else {
						res += systMenuMapper.insertMenu(row);
					}
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += systMenuMapper.updateMenu(row);
					break;
			}
		}		
		
		return res;
		
	}
	
	
	/**
	 * 메뉴설정 - 메뉴 삭제
	 */
	public int deleteMenu(List<SystMenuVO> data) throws Exception {
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "삭제할 데이터가 존재하지 않습니다.");
		}		
		
		int res = 0;
		for(SystMenuVO row : data) {
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED : 
					res += systMenuMapper.deleteMenu(row);
					break;
			}
		}
		
		return res;
	}

}

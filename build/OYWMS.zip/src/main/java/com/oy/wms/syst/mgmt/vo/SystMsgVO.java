package com.oy.wms.syst.mgmt.vo;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;
import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SystMsgVO implements Serializable ,DataSetRowTypeAccessor {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2335220201668545899L;
	
	private String msgCd;
	private String cntryLangCd;
	private String msgTypeCd;
	private String msgCont;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	
	private String chk;
	private int rowType;
	
}
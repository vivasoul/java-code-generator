package com.oy.wms.syst.hist.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PrgmErrHistVO {
	private String errHistSeq;
	private String errCont;
	private String occurDtime;
	private String connIpAddr;
	private String srvrIpAddr;
	private String rqstUrl;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	
	private String startOccurDtime;
	private String endOccurDtime;
}

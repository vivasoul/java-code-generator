package com.oy.wms.baim.strt.set.lotefc;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;

import lombok.RequiredArgsConstructor;

@Service("baimLotEfctService")
@RequiredArgsConstructor
public class BaimLotEfctService {
	
	private final BaimLotEfctMapper baimLotEfctMapper;

	/**
	 * 로트유효성전략 목록 조회
	 */
	List<BaimLotEfctVO> selectEftcStrtList(BaimLotEfctVO vo) {
		return baimLotEfctMapper.selectEftcStrtList(vo);
	}
	
	/**
	 * 로트유효성전략 저장
	 */
	@Transactional
	int saveEftcStrtList(List<BaimLotEfctVO> data) throws NexacroBizException {
		
		if(data.isEmpty()){
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimLotEfctVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
			case DataSet.ROW_TYPE_INSERTED :
				if(baimLotEfctMapper.checkDupDistStrt(row)) {
					throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
				} else {
					res += baimLotEfctMapper.insertEftcStrtList(row);
				}
				break;
			case DataSet.ROW_TYPE_UPDATED :
				res += baimLotEfctMapper.updateEftcStrtList(row);
				break;
			}
		}
		return res;
	}
	
	/**
	 * 로트유효성전략 삭제
	 */
	@Transactional
	int deleteEftcStrtList(List<BaimLotEfctVO> data) throws Exception{
		
		if(data.isEmpty()){
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "삭제할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimLotEfctVO row : data) {
			int rowType = row.getRowType();
			
			switch(rowType) {
			case DataSet.ROW_TYPE_DELETED :
				res += baimLotEfctMapper.deleteEftcStrtList(row);
				break;
			}
		}
		return res;
	}
	
	
}

package com.oy.wms.baim.item;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.oy.wms.baim.item.vo.BaimAltnCodeVO;
import com.oy.wms.baim.item.vo.BaimItemGrpVO;
import com.oy.wms.baim.item.vo.BaimItemHistVO;
import com.oy.wms.baim.item.vo.BaimItemVO;
import com.oy.wms.baim.item.vo.BaimItemUnitVO;

@Mapper
public interface BaimItemMapper {
	
	/**
	 * 상품그룹 조회
	 **/
	List<BaimItemGrpVO> selectItemGrpList(BaimItemGrpVO vo);

	//상품그룹 중복 조회
	boolean checkDupItemGrp(BaimItemGrpVO vo);	
	
	/**
	 * 상품그룹 추가
	 **/
	int insertItemGrp(BaimItemGrpVO vo);
	
	/**
	 * 상품그룹 수정
	 **/
	int updateItemGrp(BaimItemGrpVO vo);
	
	/**
	 * 상품그룹 삭제
	 **/
	int deleteItemGrp(BaimItemGrpVO vo);
	
	/* --------------------- */
	
	/* --------------------- */
	
	/**
	 * 상품이력 조회
	 **/
	List<BaimItemHistVO> selectItemHistList(BaimItemHistVO vo);
	
	/**
	 * 상품 저장 이력 추가
	 **/
	int insertItemHist(BaimItemVO vo);  

	/**
	 * 상품 삭제 이력 추가
	 **/	
	
	int deleteItemHist(BaimItemVO vo);  
	
	/**
	 * 상품 상세 저장 이력
	 **/
	int insertItemDtlHist(BaimItemUnitVO vo); 

	/**
	 * 상품 상세 삭제 이력 
	 **/	
	int deleteItemDtlHist(BaimItemUnitVO vo); 
	
	/**
	 * 상품이력 수정
	 **/
	int updateItemHist(BaimItemHistVO vo);
	
	/**
	 * 상품이력 삭제
	 **/	
	int deleteItemHist(BaimItemHistVO vo);
	
	/* --------------------- */
	
	/**
	 * 상품대체코드 조회
	 **/
	List<BaimAltnCodeVO> selectAltnCodeList(BaimAltnCodeVO vo);
	
	/**
	 * 상품대체코드 추가
	 **/
	int insertAltnCode(BaimAltnCodeVO vo);
	
	/**
	 * 상품대체코드 수정
	 **/
	int updateAltnCode(BaimAltnCodeVO vo);
	
	/**
	 * 상품대체코드 삭제
	 **/		
	int deleteAltnCode(BaimAltnCodeVO vo);
	
	/**
	 * 상품마스터 조회
	 **/
	List<BaimItemVO> selectItemList(BaimItemVO vo);
	
	//상품관리 마스터 아이템 중복 조회
	boolean checkDupItem(BaimItemVO vo);
	
	//상품관리 메인
	int mergeItem(BaimItemVO vo); 
	
	/**
	 * 상품마스터 수정 팝업
	 **/
	int updateItem(BaimItemVO vo);
	
	/**
	 * 상품마스터 삭제
	 **/	
	int deleteItem(BaimItemVO vo);
	
	//상품 한건의 하위 단위 리스트 값 리턴 리스트
	List<BaimItemUnitVO> selectItemDRtn(BaimItemVO vo);
	
	//상품 단위 리스트 조회
	List<BaimItemUnitVO> selectItemDList(BaimItemUnitVO vo);
	
	//상품 단위 저장
	int mergeItemDtl(BaimItemUnitVO vo);
	
	//상품 단위 수정
	int updateItemDtl(BaimItemUnitVO vo);

	//상품 단위 삭제
	int deleteItemDtl(BaimItemUnitVO vo);	

}

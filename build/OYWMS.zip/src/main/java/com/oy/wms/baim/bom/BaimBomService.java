package com.oy.wms.baim.bom;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.wms.baim.bom.vo.BaimBomMainVO;
import com.oy.wms.baim.bom.vo.BaimBomDtlVO;

import lombok.RequiredArgsConstructor;


@Service("baimBomService")
@RequiredArgsConstructor
public class BaimBomService {

	private final BaimBomMapper baimBomMapper;
	
	/**
	 * BOM 조회
	 */		
	public List<BaimBomMainVO> selectBomMList(BaimBomMainVO vo) {
		
		return baimBomMapper.selectBomMList(vo);
	}

	/**
	 * BOM 저장
	 */		
	public int saveBomMList(List<BaimBomMainVO> data) throws NexacroBizException{
		
		int res = 0;
		for(BaimBomMainVO row: data) {			
						
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					res += baimBomMapper.insertBomMain(row);
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += baimBomMapper.updateBomMain(row);
					break;
			}
		}
		
		return res;
	}	
	
	/**
	 * BOM 삭제
	 */		
	public int deleteBomMList(List<BaimBomMainVO> data) {
		int res = 0;
		String modiUserId =  data.get(0).getModiUserId();
		for(BaimBomMainVO row : data) {
			int rowType = row.getRowType();
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED:
					res += baimBomMapper.deleteBomMain(row);					
					List<BaimBomDtlVO> rtn = selectBomDRtn(row);										
					for(int i =0; i < rtn.size(); i++) {
						rtn.get(i).setModiUserId(modiUserId);
						baimBomMapper.deleteBomDtl(rtn.get(i));
						baimBomMapper.deleteBomDHist(rtn.get(i));
					}					
					break;
			}			
		}
		
		return res;
	}

	/**
	 * BOM 메인 하위에 있는 디테일 로우 리스트
	 */		
	private List<BaimBomDtlVO> selectBomDRtn(BaimBomMainVO vo) {
		return baimBomMapper.selectBomDRtn(vo);
	}

	/**
	 * BOM 상세 조회
	 */		
	public List<BaimBomDtlVO> selectBomDList(BaimBomDtlVO vo) {
		
		return baimBomMapper.selectBomDList(vo);
	}

	/**
	 * BOM 상세 저장
	 */		
	public int saveBomDList(List<BaimBomDtlVO> data) throws NexacroBizException{
		
		int res = 0;
		for(BaimBomDtlVO row: data) {			
						
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					res += baimBomMapper.insertBomDtl(row);
					String bom_dtl_no = baimBomMapper.selectBomDtlLastNo(row);
						   row.setBomDtlNo(bom_dtl_no);
					       baimBomMapper.insertBomDHist(row);
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += baimBomMapper.updateBomDtl(row);
					       baimBomMapper.insertBomDHist(row);
					break;
				case DataSet.ROW_TYPE_DELETED:
					res += baimBomMapper.deleteBomDtl(row);
						   baimBomMapper.deleteBomDHist(row);
					break;		
			}
		}
		
		return res;
	}

}

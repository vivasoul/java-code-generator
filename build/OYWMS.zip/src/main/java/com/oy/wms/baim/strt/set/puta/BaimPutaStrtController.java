package com.oy.wms.baim.strt.set.puta;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.baim.strt.set.puta.vo.BaimPutaStrtDVO;
import com.oy.wms.baim.strt.set.puta.vo.BaimPutaStrtMVO;
import com.oy.wms.login.vo.LoginVO;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/baim/strt/puta")
public class BaimPutaStrtController {
	
	private final BaimPutaStrtService baimPutaService ;
	
	/**
	 * 적치전략설정 조회
	 */
	@PostMapping("/getPutaStrtList")
	public NexacroResult getPutaStrtList(@ParamDataSet(name = "dsSearch") BaimPutaStrtMVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimPutaStrtMVO> list =  baimPutaService.selectPutaStrtList(input);
		result.addDataSet("dsList", list);
		
		return result;
	}
	
	/**
	 * 적치전략설정 추가,수정
	 */
	@PostMapping("/savePutaStrtList")
	public NexacroResult savePutaStrtList(@ParamDataSet(name = "dsList") List<BaimPutaStrtMVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserIdMVO(data);
		int res = baimPutaService.savePutaStrtList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}
		return result;
	}
	
	/**
	 * 적치전략설정 삭제
	 */
	@PostMapping("/deletePutaStrtList")
	public NexacroResult deletePutaStrtList(@ParamDataSet(name = "dsList") List<BaimPutaStrtMVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserIdMVO(data);
		int res = baimPutaService.deletePutaStrtList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}
		return result;
	}
	
	/**
	 * 상세적치전략설정 조회
	 */
	@PostMapping("/getPutaStrtListDetail")
	public NexacroResult getPutaStrtListDetail(@ParamDataSet(name = "dsSearchDt") BaimPutaStrtDVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimPutaStrtDVO> list =  baimPutaService.selectPutaStrtListDetail(input);
		result.addDataSet("dsListDt", list);
		
		return result;
	}
	
	/**
	 * 상세적치전략설정 추가,수정
	 */
	@PostMapping("/savePutaStrtListDetail")
	public NexacroResult savePutaStrtListDetail(@ParamDataSet(name = "dsListDt") List<BaimPutaStrtDVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserIdDVO(data);
		int res = baimPutaService.savePutaStrtListDetail(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}
		return result;
	}
	
	/**
	 * 상세적치전략설정 삭제
	 */
	@PostMapping("/deletePutaStrtListDetail")
	public NexacroResult deletePutaStrtListDetail(@ParamDataSet(name = "dsListDt") List<BaimPutaStrtDVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserIdDVO(data);
		int res = baimPutaService.deletePutaStrtListDetail(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}
		return result;
	}
	
	private void setUserIdMVO(List<BaimPutaStrtMVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(BaimPutaStrtMVO vo : data) {
			vo.setRegUserId(userId);
			vo.setModiUserId(userId);
		}
	}
	
	private void setUserIdDVO(List<BaimPutaStrtDVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(BaimPutaStrtDVO vo : data) {
			vo.setRegUserId(userId);
			vo.setModiUserId(userId);
		}
	}
}

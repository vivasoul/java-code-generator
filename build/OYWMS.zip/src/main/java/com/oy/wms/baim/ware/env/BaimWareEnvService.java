package com.oy.wms.baim.ware.env;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nexacro.java.xapi.data.DataSet;

@Service("baimWareEnvService")
public class BaimWareEnvService {

	@Autowired
	private BaimWareEnvMapper baimWareEnvMapper;
	
	/**
	 * 창고환경정보관리 목록 조회
	 */
	public List<BaimWareEnvVO> getBaimWareEnvList(String cond1) {
		return baimWareEnvMapper.getBaimWareEnvList(cond1);
	}

	/**
	 * 창고환경정보관리 저장
	 */
	public int saveBaimWareEnvList(List<BaimWareEnvVO> data) throws Exception {
		
		int res = 0;
		for(BaimWareEnvVO row : data) {
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					res += baimWareEnvMapper.insertBaimWareEnvList(row);
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += baimWareEnvMapper.updateBaimWareEnvList(row);
					break;		
			}
		}
		return res;
		
	}
	
	/**
	 * 창고환경정보관리 삭제
	 */
	public int deleteBaimWareEnvList(List<BaimWareEnvVO> data) {
		int res = 0;
		for(BaimWareEnvVO row : data) {
			res += baimWareEnvMapper.deleteBaimWareEnvList(row);
		}
		return res;
	}

}

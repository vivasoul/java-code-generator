package com.oy.wms.baim.cust.bp;

import java.io.Serializable;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimCustBpVO implements Serializable ,DataSetRowTypeAccessor {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5666818151831689918L;
	
	private String vndrId;
	private String custId;
	private String indirBpTypeCd;
	private String relCorpTypeCd;
	private String telNo1;
	private String telNo2;
	private String telNo3;
	private String indirBpFaxNo1;
	private String indirBpFaxNo2;
	private String indirBpFaxNo3;
	private String cntryCd;
	private String sido;
	private String skk;
	private String custBpDscr;
	private String sysUseDivCd;
	private String exstSysCd;
	private String sameBpDivCd;
	private String oldrBpCd;
	private String srcBpCd;
	private String vndrGrpCd;
	private String vndrDivCd;
	private String mngrNm;
	private String bspsCd;
	private String repreNm;
	private String txpyAddr;
	private String txpyDtlAddr;
	private String taxBilPrintDivCd;
	private String txpyBzcnNm;
	private String txpyBznm;
	private String txpyCtgryNm;
	private String txpyNo;
	private String txpyRepreNm;
	private String newBzcnDivCd;
	private String saleUserNm;
	private String saleUserTelNo1;
	private String saleUserTelNo2;
	private String saleUserTelNo3;
	private String mainWhobCntrCd;
	private String whDivCd;
	private String pnltyYn;
	private String salesDeptEntrNo;
	private String salesDeptSapCd;
	private String cntrGlsUseYn;
	private String dvntPrintDivCd;
	private String adaptWkDivCd;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private String chk;
	private int rowType;
}
package com.oy.wms.syst.user;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.oy.wms.syst.user.vo.SysUserConnHVO;
import com.oy.wms.syst.user.vo.SystUserAuthVO;
import com.oy.wms.syst.user.vo.SystUserVO;

@Mapper
public interface SystUserMapper {

	// 사용자리스트 조회
	List<SystUserVO> selectUser(SystUserVO param);
	
	// 사용자 중복 여부
	int chkDupUser(SystUserVO param);
	
	// 사용자 저장
	int mergeUser(SystUserVO row);	
	
	// 사용자 수정
	int updateUser(SystUserVO row);
	
	// 사용자 삭제
	int deleteUser(SystUserVO row);		

	// 사용자 비밀번호 초기화
	int updateUserPwReset(SystUserVO row);	
	
	// 사용자 리스트 권한 추가시 권한유저에 정보 저장
	int mergeAuthUser(SystUserVO row);	
	
	// 사용자 리스트 - 비밀번호 초기화 시 기록 입력
	int insertPwResetHist(SystUserVO row);
	
	// 사용자 리스트 상세정보 - 창고목록 조회
	List<SystUserAuthVO> selectUserDetailWare(SystUserAuthVO param);
	
	// 사용자 리스트 상세정보 - 창고목록 저장
	int updateUserDetailWare(SystUserAuthVO row);		
	
	// 사용자 리스트 상세정보 - 권한목록 조회
	List<SystUserAuthVO> selectUserDetailAuth(SystUserVO param);	
	
	// 사용자 권한조회 팝업 조회
	List<SystUserAuthVO> selectUserAuthPopup(SystUserVO param);	
	
	// 사용자 리스트 상세정보 - 권한목록 저장
	int updateUserDetailAuth(SystUserAuthVO row);	
	
	// 사용자 리스트 상세정보 - 고객목록 조회
	List<SystUserAuthVO> selectUserDetailCust(SystUserAuthVO param);	
	
	// 사용자 리스트 상세정보 - 고객목록 저장
	int updateUserDetailCust(SystUserAuthVO row);	
	
	// 사용자접속 조회
	List<SysUserConnHVO> selectConnetInfo(SysUserConnHVO param);

	// 사용자접속 저장 - 로그인시
	int updateConnetInfo(SysUserConnHVO row);
	
}

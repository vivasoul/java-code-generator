package com.oy.wms.syst.hist.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PrgmUseHistVO {
	private String prgmUseHistSeq;
	private String userId;
	private String userNm;
	private String connIp;
	private String connTypeCd;
	private String cntrCd;
	private String whCd;
	private String menuCd;
	private String srvcNm;
	private String mthdNm;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
}

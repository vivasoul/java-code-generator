package com.oy.wms.baim.sample;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nexacro.java.xapi.data.DataSet;
import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;
import com.oy.config.annotation.ValidateMembers;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.mvc.Parameters;
import com.oy.wms.baim.sample.vo.SampleVO;

@Service("sampleService")
public class SampleService {
	
	//@Resource(name = "SampleMapper")
	@Autowired
	private SampleMapper sampleMapper;
	
	public String getData() {
		return "TEST";
	}
	
	public List<SampleVO> selectSome(String cond1) {
		return sampleMapper.selectSome(cond1);
	}
	
	public int insertRow(SampleVO data) {
		return sampleMapper.insertSome(data);
	}
	
	public int updateRow(SampleVO data) {
		return sampleMapper.updateSome(data);
	}
	
	public int deleteRow(SampleVO data) { 
		return sampleMapper.deleteSome(data);
	}	
	
	public int mergeRows(List<SampleVO> data) throws Exception {
		
		int res = 0;
		for(SampleVO row : data) {
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					res += insertRow(row);
					break;
				case DataSet.ROW_TYPE_UPDATED:
					res += updateRow(row);
					break;
				case DataSet.ROW_TYPE_DELETED:
					res += deleteRow(row);
					break;					
			}
		}
		return res;
	}
	
	@ValidateMembers( dsName="dsList", members= {"CNT", "TXT"} )
	public void aopTest(Parameters parameters) {
		System.out.println("parameters has been called..");
	}
}

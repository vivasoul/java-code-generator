package com.oy.wms.baim.strt.set;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BaimStrtMapper {
		
	// 전략세트 조회
	List<BaimStrtVO> selectStrtSet(BaimStrtVO vo);
	
	// 전략세트 추가
	int insertStrtSet(BaimStrtVO vo);
	
	// 전략세트 수정
	int updateStrtSet(BaimStrtVO vo);
	
	// 전략세트 삭제
	int deleteStrtSet(BaimStrtVO vo);
	
	// 전략세트 중복 조회	
	boolean checkDupStrtSet(BaimStrtVO vo);
}

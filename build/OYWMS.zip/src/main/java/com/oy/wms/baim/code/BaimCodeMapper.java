package com.oy.wms.baim.code;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.oy.wms.baim.code.vo.BaimCodeDVO;
import com.oy.wms.baim.code.vo.BaimCodeMVO;

@Mapper
public interface BaimCodeMapper {
	
	// 기준코드 존재여부
	int isExistCode(BaimCodeDVO param);
	
	// 기준코드 조회
	List<BaimCodeMVO> selectCode(BaimCodeMVO param);

	// 기준코드 등록
	int insertCode(BaimCodeMVO row);
	
	// 기준코드 수정
	int updateCode(BaimCodeMVO row);
	
	// 기준코드 삭제
	int deleteCode(BaimCodeMVO row);
	
	// 기준코드 중복 체크
	boolean checkDupCode(BaimCodeMVO row);
	
	// 기준코드상세 조회
	List<BaimCodeDVO> selectCodeDetail(BaimCodeDVO param);
	
	// 기준코드상세 추가
	int insertCodeDetail(BaimCodeDVO row);
	
	// 기준코드상세 수정
	int updateCodeDetail(BaimCodeDVO row);
	
	// 기준코드상세 삭제
	int deleteCodeDetail(BaimCodeDVO row);
	
	// 기준코드상세 중복 체크
	boolean checkDupCodeDetail(BaimCodeDVO row);
	
}

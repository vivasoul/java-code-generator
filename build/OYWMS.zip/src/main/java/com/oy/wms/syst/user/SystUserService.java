package com.oy.wms.syst.user;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;
import com.oy.wms.syst.user.vo.SysUserConnHVO;
import com.oy.wms.syst.user.vo.SystUserAuthVO;
import com.oy.wms.syst.user.vo.SystUserVO;

import lombok.RequiredArgsConstructor;

@Service("systMgmtService")
@RequiredArgsConstructor
public class SystUserService {

	private final SystUserMapper systMgmtMapper;
	
	/**
	 * 사용자리스트 조회
	 */
	public List<SystUserVO> getUser(SystUserVO input) throws Exception {
		
		return systMgmtMapper.selectUser(input);
	}	

	/**
	 * 사용자리스트 조회
	 */
	public List<SystUserAuthVO> selectUserDetailAuth(SystUserVO input) throws Exception {
		
		return systMgmtMapper.selectUserDetailAuth(input);
	}	
	
	/**
	 * 사용자 저장
	 */
	@Transactional
	public int saveUser(List<SystUserVO> data) throws NexacroBizException {
		
		int res = 0;
		for(SystUserVO row : data) {
			
			int rowType = row.getRowType();			
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					if(systMgmtMapper.chkDupUser(row) < 1) {//사용가능 id 여부
						res += systMgmtMapper.mergeUser(row);						
					}else {
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_ID.getCode(), "사용할 수 없는 ID 입니다.");
					}
					break;
				case DataSet.ROW_TYPE_UPDATED:
						res += systMgmtMapper.updateUser(row);
					break;
			}
		}
		
		return res;
	}	
	
	/**
	 * 사용자 삭제
	 */
	@Transactional
	public int deleteUser(List<SystUserVO> data) throws Exception {
		
		int res = 0;
		for(SystUserVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED:
					res += systMgmtMapper.deleteUser(row);
					break;
			}
		}
		
		return res;	
	}		
	
	/**
	 * 사용자 비밀번호 초기화
	 */
	public int saveUserPwReset(List<SystUserVO> data) throws Exception {
		
		int res = 0;
		for(SystUserVO row : data) { //CHG_BF_PWD
			var chgBfPwd =  row.getPwd(); //변경전 비밀번호
			row.setChgBfPwd(chgBfPwd);
			//비밀번호 변경 시 기록 추가
			res += systMgmtMapper.insertPwResetHist(row);
		    
			//초기화를 눌렀을 때 비밀번호 세팅값
			res += systMgmtMapper.updateUserPwReset(row);
		}
		return res;	
	}	
	
	/**
	 * 사용자 리스트 상세정보 - 창고목록 조회
	 */
	public List<SystUserAuthVO> getUserDetailWare(SystUserAuthVO input) throws Exception {
		
		return systMgmtMapper.selectUserDetailWare(input);
	}
		
	/**
	 * 사용자 리스트 상세정보 - 창고목록 저장
	 */
	public int updateUserDetailWare(List<SystUserAuthVO> data) throws Exception {
		
		if(data.isEmpty()) {
			// TODO (2022.12.29) 다국어 조회 처리 필요
//			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), CommonLang.select({CntryLangCd}, {MsgCd}, "저장할 데이터가 존재하지 않습니다."));
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(SystUserAuthVO row : data) {		
			
			res += systMgmtMapper.updateUserDetailWare(row);
		}		
		
		return res;
	}
	
	/**
	 * 사용자 리스트 상세정보 - 권한목록 조회
	 */
	public List<SystUserAuthVO> getUserDetailAuth(SystUserVO input) throws Exception {
		
		return systMgmtMapper.selectUserDetailAuth(input);
	}
	
	/**
	 * 사용자 리스트 상세정보 - 권한목록 조회
	 */
	public List<SystUserAuthVO> selectUserAuthPopup(SystUserVO input) throws Exception {
		
		return systMgmtMapper.selectUserAuthPopup(input);
	}
		
	/**
	 * 사용자 리스트 상세정보 - 권한목록 저장
	 */
	public int updateUserDetailAuth(List<SystUserAuthVO> data) throws Exception {

		if(data.isEmpty()) {
			// TODO (2022.12.29) 다국어 조회 처리 필요
//			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), CommonLang.select({CntryLangCd}, {MsgCd}, "저장할 데이터가 존재하지 않습니다."));
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(SystUserAuthVO row : data) {		
			
			res += systMgmtMapper.updateUserDetailAuth(row);
		}		
		
		return res;	
	}	
	
	/**
	 * 사용자 리스트 상세정보 - 고객목록 조회
	 */
	public List<SystUserAuthVO> getUserDetailCust(SystUserAuthVO input) throws Exception {	
		
		return systMgmtMapper.selectUserDetailCust(input);
	}
		
	/**
	 * 사용자 리스트 상세정보 - 고객목록 저장
	 */
	public int updateUserDetailCust(List<SystUserAuthVO> data) throws Exception {
		//dsIn = dsCode
		if(data.isEmpty()) {
			// TODO (2022.12.29) 다국어 조회 처리 필요
//			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), CommonLang.select({CntryLangCd}, {MsgCd}, "저장할 데이터가 존재하지 않습니다."));
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(SystUserAuthVO row : data) {
			
			res += systMgmtMapper.updateUserDetailCust(row);
		}		
		
		return res;	
	}		
	
	/**
	 * 사용자접속 조회
	 */
	public List<SysUserConnHVO> getConnetInfo(SysUserConnHVO input) throws Exception {
		//dsIn = dsSearch
		//dsOut = dsCode			
		
		return systMgmtMapper.selectConnetInfo(input);
	}
		
	/**
	 * 사용자접속 저장
	 */
	public int saveConnetInfo(List<SysUserConnHVO> data) throws Exception {
		//dsIn = dsCode
		if(data.isEmpty()) {
			// TODO (2022.12.29) 다국어 조회 처리 필요
//			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), CommonLang.select({CntryLangCd}, {MsgCd}, "저장할 데이터가 존재하지 않습니다."));
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(SysUserConnHVO row : data) {
						
			res += systMgmtMapper.updateConnetInfo(row);
		}				
		return res;
		
	}


}

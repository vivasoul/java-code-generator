package com.oy.wms.baim.strt.asgn;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;

import lombok.RequiredArgsConstructor;

@Service("baimStrtAsgnService")
@RequiredArgsConstructor
public class BaimStrtAsgnService {
	
	private final BaimStrtAsgnMapper baimStrtAsgnMapper;
	
	/**
	 *  창고-전략설정 조회
	 */
	public List<BaimStrtAsgnVO> getStrtWareAsgn(BaimStrtAsgnVO vo) {
		
		return baimStrtAsgnMapper.selectStrtWareAsgn(vo);
	}	
	
	/**
	 *  창고-전략설정 저장
	 */
	@Transactional
	public int saveStrtWareAsgn(List<BaimStrtAsgnVO> data) throws NexacroBizException{
		
		if(data.isEmpty()) {
			// TODO (2022.12.29) 다국어 조회 처리 필요
//			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), CommonLang.select({CntryLangCd}, {MsgCd}, "저장할 데이터가 존재하지 않습니다."));
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimStrtAsgnVO row: data) {			
						
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					if(baimStrtAsgnMapper.checkDupStrtWareAsgn(row)) 
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
				case DataSet.ROW_TYPE_UPDATED:
					res += baimStrtAsgnMapper.mergeStrtWareAsgn(row);
					break;
			}
		}
		
		return res;
	}	
	
	/**
	 *  창고-전략설정 삭제
	 */
	@Transactional
	public int deleteStrtWareAsgn(List<BaimStrtAsgnVO> data) throws Exception{
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "삭제할 데이터가 존재하지 않습니다.");
		}		
		
		int res = 0;
		for(BaimStrtAsgnVO row : data) {
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED:				
					res += baimStrtAsgnMapper.deleteStrtWareAsgn(row);
					break;
			}	
		}
		
		return res;
	}	
	
	/**
	 *  고객-전략설정 조회
	 */
	public List<BaimStrtAsgnVO> getStrtCustAsgn(BaimStrtAsgnVO vo) {
		
		return baimStrtAsgnMapper.selectStrtCustAsgn(vo);
	}		
	
	/**
	 *  고객-전략설정 저장
	 */
	@Transactional
	public int saveStrtCustAsgn(List<BaimStrtAsgnVO> data) throws NexacroBizException{
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimStrtAsgnVO row: data) {			
						
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					if(baimStrtAsgnMapper.checkDupStrtCustAsgn(row)) 
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode()); 
				case DataSet.ROW_TYPE_UPDATED:
					res += baimStrtAsgnMapper.mergeStrtCustAsgn(row);
					break;
			}
		}
		
		return res;
	}	
	
	/**
	 *  고객-전략설정 삭제
	 */
	@Transactional
	public int deleteStrtCustAsgn(List<BaimStrtAsgnVO> data) throws Exception{
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "삭제할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimStrtAsgnVO row : data) {
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED:			
					res += baimStrtAsgnMapper.deleteStrtCustAsgn(row);
				break;
			}
		}
		
		return res;
	}		
	
	/**
	 *  상품그룹-전략설정 조회
	 */
	public List<BaimStrtAsgnVO> getStrtItemGrpAsgn(BaimStrtAsgnVO vo) {
		
		return baimStrtAsgnMapper.selectStrtItemGrpAsgn(vo);
	}	
	
	/**
	 *  상품그룹-전략설정 저장
	 */
	@Transactional
	public int saveStrtItemGrpAsgn(List<BaimStrtAsgnVO> data) throws NexacroBizException{
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimStrtAsgnVO row: data) {			
						
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					if(baimStrtAsgnMapper.checkDupStrtItemGrpAsgn(row))
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
				case DataSet.ROW_TYPE_UPDATED:
					res += baimStrtAsgnMapper.mergeStrtItemGrpAsgn(row);
					break;
			}
		}
		
		return res;
	}	
	
	/**
	 *  상품그룹-전략설정 삭제
	 */
	@Transactional
	public int deleteStrtItemGrpAsgn(List<BaimStrtAsgnVO> data) throws Exception{
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "삭제할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimStrtAsgnVO row : data) {
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED:					
					res += baimStrtAsgnMapper.deleteStrtItemGrpAsgn(row);
					break;
			}
		}
		
		return res;
	}	
	
	/**
	 *  상품-전략설정 조회
	 */
	public List<BaimStrtAsgnVO> getStrtItemAsgn(BaimStrtAsgnVO vo) {
		
		return baimStrtAsgnMapper.selectStrtItemAsgn(vo);
	}	
	
	/**
	 *  상품-전략설정 저장
	 */
	@Transactional
	public int saveStrtItemAsgn(List<BaimStrtAsgnVO> data) throws NexacroBizException{
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimStrtAsgnVO row: data) {			
						
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED:
					if(baimStrtAsgnMapper.checkDupStrtItemAsgn(row))
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
				case DataSet.ROW_TYPE_UPDATED:
					res += baimStrtAsgnMapper.mergeStrtItemAsgn(row);
					break;
			}
		}
		
		return res;
	}	
	
	/**
	 *  상품-전략설정 삭제
	 */
	@Transactional
	public int deleteStrtItemAsgn(List<BaimStrtAsgnVO> data) throws Exception{
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "삭제할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimStrtAsgnVO row : data) {
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED:				
					res += baimStrtAsgnMapper.deleteStrtItemAsgn(row);
					break;
			}
		}
		
		return res;
	}	
}

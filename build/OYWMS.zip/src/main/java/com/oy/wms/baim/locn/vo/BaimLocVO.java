package com.oy.wms.baim.locn.vo;

import java.io.Serializable;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimLocVO implements Serializable, DataSetRowTypeAccessor {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8603140091144501569L;
	private String cntrCd;
	private String whCd;
	private String locCd;
	private String cntrNm;
	private String whNm;
	private String locNm;
	private String zoneCd;
	private String posTypeCd;
	private int prtyRank;
	private String dtlNo;
	private String hldSttsCd;
	private String chnlCd;
	private String locDscr;
	private String logicLocDscr;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private String chk;
	private int rowType;
}

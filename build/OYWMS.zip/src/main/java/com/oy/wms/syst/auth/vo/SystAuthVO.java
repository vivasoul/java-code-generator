package com.oy.wms.syst.auth.vo;

import java.io.Serializable;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SystAuthVO implements Serializable ,DataSetRowTypeAccessor {

	private static final long serialVersionUID = 5435299472439189433L;
	private String authCd;
	private String authNm;
	private String authDscr;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
		
	private int rowType;
}
package com.oy.wms.syst.hist;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.oy.wms.syst.hist.vo.PrgmErrHistVO;
import com.oy.wms.syst.hist.vo.PrgmUseHistVO;

@Mapper
public interface SystHistMapper {
	
	/* 프로그램사용이력 조회 */
	List<PrgmUseHistVO> selectPrgmUseHist(PrgmUseHistVO params);
	
	/* 프로그램사용이력 추가 */
	int insertPrgmUseHist(PrgmUseHistVO vo);
	
	/* 프로그램오류이력 조회 */
	List<PrgmErrHistVO> selectPrgmErrHist(PrgmErrHistVO params);
	
	/* 프로그램오류이력 추가 */
	int insertPrgmErrHist(PrgmErrHistVO vo);
}

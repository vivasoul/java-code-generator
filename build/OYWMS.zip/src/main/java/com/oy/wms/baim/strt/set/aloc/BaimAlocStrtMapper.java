package com.oy.wms.baim.strt.set.aloc;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BaimAlocStrtMapper {
	
	// 할당전략 조회
	List<BaimAlocStrtVO> selectAllocationStrategySettings(BaimAlocStrtVO param);

	// 할당전략 등록
	int insertAllocationStrategySettings(BaimAlocStrtVO row);
	
	// 할당전략 수정
	int updateAllocationStrategySettings(BaimAlocStrtVO row);
	
	// 할당전략 삭제
	int deleteAllocationStrategySettings(BaimAlocStrtVO row);
	
}

package com.oy.wms.baim.locn;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.oy.wms.baim.locn.vo.BaimCellVO;
import com.oy.wms.baim.locn.vo.BaimLocVO;
import com.oy.wms.baim.locn.vo.BaimZoneVO;
import com.oy.wms.baim.strt.set.dist.BaimDistStrtVO;

@Mapper
public interface BaimLocnMapper {
	
	// ZONE 조회
	List<BaimZoneVO> selectZone(BaimZoneVO param);
	
	// ZONE 등록
	int insertZone(BaimZoneVO row);
	
	// ZONE 수정
	int updateZone(BaimZoneVO row);
	
	// ZONE 삭제
	int deleteZone(BaimZoneVO row);
	
	// ZONE 중복 조회
	boolean checkDupZone(BaimZoneVO vo);	
	
	// 로케이션 조회
	List<BaimLocVO> selectLocation(BaimLocVO param);
	
	// 로케이션 등록
	int insertLocation(BaimLocVO row);
	
	// 로케이션 수정
	int updateLocation(BaimLocVO row);
	
	// 로케이션 삭제
	int deleteLocation(BaimLocVO row);
	
	// 로케이션 중복 조회	
	boolean checkDupLocation(BaimLocVO vo);
	
	// 셀 조회
	List<BaimCellVO> selectCell(BaimCellVO param);
	
	// 셀 등록
	int insertCell(BaimCellVO row);
	
	// 셀 수정
	int updateCell(BaimCellVO row);
	
	// 셀 삭제
	int deleteCell(BaimCellVO row);
	
	// 셀 중복 조회	
	boolean checkDupCell(BaimCellVO vo);	
}

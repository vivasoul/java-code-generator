package com.oy.wms.login.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginVO {
	private String userId;
	private String userNm;
	private String pwd;
	private String cmpnyTelNo1;
	private String cmpnyTelNo2;
	private String cmpnyTelNo3;
	private String hpNo1;
	private String hpNo2;
	private String hpNo3;
	private String homeTelNo1;
	private String homeTelNo2;
	private String homeTelNo3;
	private String emailAddr1;
	private String emailAddr2;
	private String langDivCd;
	private String cntryCd;
	private String empyYmd;
	private String rtrmYmd;
	private String rqstYmd;
	private String aprvYmd;
	private String rjctYmd;
	private String expryYmd;
	private String userTypeCd;
	private String blngDivCd;
	private String custId;
	private String vndrId;
	private String deptCd;
	private String cocnYn;
	private String drmAdaptYn;
	private String tzCd;
	private String rqstRsn;
	private String useYn;
	private String delYn;
	private String tempPwdModiYn;
	private String connDivCd;
	private int pwdErrCnt;
	private String pwdFinalModiDtime;
	private String zipNo;
	private String addr;
	private String dtlAddr;
	private String skk;
	private String sido;
	private String userWorkDivCd;
	private String sysDivCd;
	private String eqmDivCd;
}

package com.oy.wms.baim.strt.set.repl;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimReplStrtVO implements DataSetRowTypeAccessor {
	private String cntrCd;
	private String cntrNm;
	private String whCd;
	private String whNm;
	private String stockReplStrtCd;
	private String leftQtyAllocYn;
	private String allocTypeCd;
	private String rotTypeCd;
	private String replCellTypeCd;
	private String stockReplStrtDscr;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	
	private String chk;
	private int rowType;
}
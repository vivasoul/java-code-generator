package com.oy.wms.baim.ware;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;
import com.oy.wms.baim.ware.vo.BaimCntrVO;
import com.oy.wms.baim.ware.vo.BaimWareVO;

@Service("baimWareService")
//@RequiredArgsConstructor
public class BaimWareService {
	
	private final BaimWareMapper baimWareMapper;
	
	public BaimWareService(BaimWareMapper baimWareMapper) {
		this.baimWareMapper = baimWareMapper;
	}
	
	/**
	 * 센터 조회
	 */
	public List<BaimCntrVO> getCntr(BaimCntrVO input) {
		return baimWareMapper.selectCntr(input);
	}	
	
	/**
	 * 센터 저장
	 */
	@Transactional
	public int saveCntr(List<BaimCntrVO> data) throws Exception{
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimCntrVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED : 
					if(baimWareMapper.checkDupCntr(row)) {
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
					} else {
						res += baimWareMapper.insertCntr(row);
					}
					break;
				case DataSet.ROW_TYPE_UPDATED : 
					res += baimWareMapper.updateCntr(row);
					break;
			}
		}
		return res;
	}

	/**
	 * 센터 삭제
	 */
	@Transactional
	public int deleteCntr(List<BaimCntrVO> data) {
		int res = 0;
		
		for(BaimCntrVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED : 
					res += baimWareMapper.deleteCntr(row);
					break;

			}
		}
		
		return res;
	}	
	
	/**
	 * 창고 조회
	 */
	public List<BaimWareVO> getWare(BaimWareVO input) {
		return baimWareMapper.selectWare(input);
	}
	
	/**
	 * 창고 저장
	 */
	@Transactional
	public int saveWare(List<BaimWareVO> data) throws Exception{
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimWareVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_INSERTED : 
					if(baimWareMapper.checkDupWare(row)) {
						throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
					} else {
						res += baimWareMapper.insertWare(row);
					}
					break;
				case DataSet.ROW_TYPE_UPDATED : 
					res += baimWareMapper.updateWare(row);
					break;
			}
		}
		return res;
	}

	/**
	 * 창고 삭제
	 */
	@Transactional
	public int deleteWare(List<BaimWareVO> data) {
		int res = 0;
		
		for(BaimWareVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
				case DataSet.ROW_TYPE_DELETED : 
					res += baimWareMapper.deleteWare(row);
					break;

			}
		}
		
		return res;
	}
}

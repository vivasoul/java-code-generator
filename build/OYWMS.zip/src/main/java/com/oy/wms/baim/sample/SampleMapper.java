package com.oy.wms.baim.sample;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.oy.wms.baim.sample.vo.SampleVO;

@Mapper 
public interface SampleMapper {
	
	List<SampleVO> selectSome(String cond1);
	
	int insertSome(SampleVO row);
	
	int updateSome(SampleVO row);
	
	int deleteSome(SampleVO row);
}

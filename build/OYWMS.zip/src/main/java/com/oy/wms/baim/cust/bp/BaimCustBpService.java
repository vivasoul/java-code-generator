package com.oy.wms.baim.cust.bp;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;

import lombok.RequiredArgsConstructor;

@Service("baimCustBpService")
@RequiredArgsConstructor
public class BaimCustBpService {
	
	private final BaimCustBpMapper baimCustBpMapper;

	/**
	 * 고객사별 거래처관리 목록 조회
	 */
	public List<BaimCustBpVO> selectCustBpList(BaimCustBpVO vo) {
		return baimCustBpMapper.selectCustBpList(vo);
	}

	/**
	 * 고객사별 거래처관리 추가,수정
	 */
	public int saveCustBpList(List<BaimCustBpVO> data) throws NexacroBizException {
		
		if(data.isEmpty()) {
			throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		}
		
		int res = 0;
		for(BaimCustBpVO row : data) {
			
			int rowType = row.getRowType();
			
			switch(rowType) {
			case DataSet.ROW_TYPE_INSERTED : 
				if(baimCustBpMapper.checkDupCustBp(row)) {
					throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
				} else {
					res += baimCustBpMapper.insertCustBpList(row);
				}
				break;
			case DataSet.ROW_TYPE_UPDATED :
				res += baimCustBpMapper.updateCustBpList(row);
				break;
			}
		}
		return res;
	}

	/**
	 * 고객사별 거래처관리 삭제
	 */
	public int deleteCustBpList(List<BaimCustBpVO> data) {
		int res = 0;
		for(BaimCustBpVO row : data) {
			res += baimCustBpMapper.deleteCustBpList(row); 
		}
		return res;
	}
}

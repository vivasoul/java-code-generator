package com.oy.wms.baim.strt.set.aloc;

import java.io.Serializable;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimAlocStrtVO implements Serializable ,DataSetRowTypeAccessor {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4233898505571364353L;
	
	private String chk;
	private String cntrCd;
	private String whCd;
	private String whNm;
	private String allocStrtCd;
	private String leftQtyAllocYn;
	private String allocTypeCd;
	private String rotTypeCd;
	private String allocYmdTypeCd;
	private String qtyAllocTypeCd;
	private String allocCellTypeCd;
	private String allocUnitTypeCd;
	private String pickTypeCd;
	private String delYn;
	private String allocStrtDscr;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	
	private int rowType;
}

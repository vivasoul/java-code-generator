package com.oy.wms.baim.cust;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/baim/cust")
public class BaimCustController {
	
	private final BaimCustService baimCustService;
	
	/**
	 * 고객사 검색
	 */
	@PostMapping("/getCust")
	public NexacroResult getCustBList(@ParamDataSet(name = "dsSearch") BaimCustVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimCustVO> list =  baimCustService.selectCustList(input);
		result.addDataSet("dsList", list);
		
		return result;
	}
}

package com.oy.wms.sample.crud.mybatis;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface SampleMybatisMapper {
    public List<Vo> getList(Vo searchVo);

    public Vo get(int sampleSn);

    public int put(Vo vo);

    public int set(Vo vo);

    public int del(int sampleSn);
}
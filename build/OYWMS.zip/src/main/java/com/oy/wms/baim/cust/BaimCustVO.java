package com.oy.wms.baim.cust;

import java.io.Serializable;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimCustVO implements Serializable ,DataSetRowTypeAccessor {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7316911350968183010L;
	
	private String custId;
	private String custTypeCd;
	private String custNm;
	private String custAbbrNm;
	private String cmpnyDivCd;
	private String repreNm;
	private String bzno;
	private String zipNo;
	private String addr;
	private String dtlAddr;
	private String cityNm;
	private String stateNm;
	private String telNo1;
	private String telNo2;
	private String telNo3;
	private String faxNo1;
	private String faxNo2;
	private String faxNo3;
	private String emailAddr;
	private String cntryCd;
	private String sido;
	private String skk;
	private String useYn;
	private String shipDivCd;
	private String mdmCd;
	private String mdmUseYn;
	private String mngrNm;
	private String mngrHpNo1;
	private String mngrHpNo2;
	private String mngrHpNo3;
	private String mmExpcSalesAmt;
	private String dscr;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private String chk;
	private int rowType;
}
package com.oy.wms.baim.ware.env;


import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimWareEnvVO implements DataSetRowTypeAccessor{
	private String cntrCd;
	private String whCd;
	private String whEnvStngCd;
	private String envStngDmnVal;
	private String baseVal;
	private String realVal;
	private String dscr;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	
	private int rowType;
}
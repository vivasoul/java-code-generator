package com.oy.wms.baim.strt.set;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimStrtVO implements DataSetRowTypeAccessor {
	private String cntrCd;
	private String cntrNm;
	private String whCd;
	private String whNm;
	private String strtSetCd;
	private String bfAllocStrtCd;
	private String bfAllocStrtDscr;
	private String allocStrtCd;
	private String allocStrtDscr;
	private String stockReplStrtCd;
	private String stockReplStrtDscr;
	private String putaStrtCd;
	private String putaStrtDscr;
	private String lotGenStrtCd;
	private String lotGenStrtDscr;
	private String lotAttrChgStrtCd;
	private String lotAttrChgStrtDscr;
	private String lotEfctChkCd;
	private String lotEfctChkDscr;
	private String agvStockReplYn;
	private String delYn;
	private String strtSetDscr;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	
	private String chk;
	private int rowType;
}
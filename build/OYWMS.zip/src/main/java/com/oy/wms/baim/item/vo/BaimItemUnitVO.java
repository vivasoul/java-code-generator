package com.oy.wms.baim.item.vo;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;
import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimItemUnitVO implements Serializable ,DataSetRowTypeAccessor {
	
	private static final long serialVersionUID = 3712955138728235650L;
	
	private String custId;
	private String itemCd;
	private String itemSaveCd;
	private String reprUnitYn;
	private String msreCd;
	private String qty;
	private String dispItemSaveCd;
	private String reprConvUnitYn;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private String chk;
	private int rowType;
}
package com.oy.wms.syst.mgmt;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.annotation.ParamVariable;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.login.vo.LoginVO;
import com.oy.wms.syst.mgmt.vo.SystLangVO;
import com.oy.wms.syst.mgmt.vo.SystMsgVO;
import com.oy.wms.syst.mgmt.vo.SystTermVO;

@Controller
@RequestMapping("/systMgmt")
public class SystMgmtController {
	
	@Resource(name = "systLangService")
	private SystLangService systLangService;
	
	/**
	 * 다국어용어 저장
	 */
	@PostMapping("/saveLangTerm")
	public NexacroResult saveLangTerm(@ParamDataSet(name = "dsUpdateList") List<SystTermVO> input) throws Exception{

		NexacroResult result = new NexacroResult();
		setUserIdLT(input);
		int res = systLangService.saveLangTerm(input);
		if(res < 1) {
			result.setErrorCode(-1);
		}
				
		return result;
	}
	
	/**
	 * 다국어용어 조회
	 */
	@PostMapping("/getLangTerm")
	public NexacroResult getLangTerm(@ParamDataSet(name = "dsSearch") SystTermVO input) throws Exception{
				
		NexacroResult result = new NexacroResult();
		List<SystTermVO> list =  systLangService.getLangTerm(input);
		result.addDataSet("dsOutput", list);
		
		return result;
	}
	
	/**
	 * 다국어용어 삭제
	 */
	@PostMapping("/deleteLangTerm")
	public NexacroResult deleteLangTerm(@ParamDataSet(name = "dsDelete") List<SystTermVO> input) throws Exception{
		
		NexacroResult result = new NexacroResult();
		setUserIdLT(input);
		int res = systLangService.deleteLangTerm(input);
		if(res < 1) {
			result.setErrorCode(-1);
		}
		
		return result;
	}
	
	/**
	 * 다국어메세지 저장
	 */
	@PostMapping("/saveLangMsg")
	public NexacroResult saveLangMsg(@ParamDataSet(name = "dsUpdateList") List<SystMsgVO> input) throws Exception{
		
		NexacroResult result = new NexacroResult();
		setUserIdLM(input);
		int res = systLangService.saveLangMsg(input);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
	/**
	 * 다국어메세지 조회
	 */
	@PostMapping("/getLangMsg")
	public NexacroResult getLangMsg(@ParamDataSet(name = "dsSearch") SystMsgVO input) throws Exception{
		
		NexacroResult result = new NexacroResult();
		List<SystMsgVO> list =  systLangService.getLangMsg(input);
		result.addDataSet("dsOutput", list);		
		
		return result;
	}
	
	/**
	 * 다국어메세지 삭제
	 */
	@PostMapping("/deleteLangMsg")
	public NexacroResult deleteLangMsg(@ParamDataSet(name = "dsDeleteList") List<SystMsgVO> input) throws Exception{
				
		NexacroResult result = new NexacroResult();
		setUserIdLM(input);
		int res = systLangService.deleteLangMsg(input);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;		
	}
	
	
	/**
	 * 언어코드 조회
	 */
	@PostMapping("/getLangCode")
	public NexacroResult getLangCode(@ParamDataSet(name = "dsSearch", required=false) SystLangVO input, @ParamVariable(name="strSearch", required=false) String search) throws Exception{
				
		NexacroResult result = new NexacroResult();
		SystLangVO searchVO = new SystLangVO();
		searchVO.setDelYn(search);
		String outDs = "dsLangList";
		
		if(input != null) {
			searchVO = input;
			outDs = "dsList";
		}
		
		List<SystLangVO> list =  systLangService.getLangCode(searchVO);
		result.addDataSet(outDs, list);
		
		return result;
	}
	
	/**
	 * 언어코드 삭제
	 */
	@PostMapping("/deleteLangCode")
	public NexacroResult deleteLangCode(@ParamDataSet(name = "dsList") List<SystLangVO> input) throws Exception{
		
		NexacroResult result = new NexacroResult();
		setUserIdLC(input);
		int res = systLangService.deleteLangCode(input);
		if(res < 1) {
			result.setErrorCode(-1);
		}
		
		return result;
	}
	
	/**
	 * 언어코드 저장
	 */
	@PostMapping("/saveLangCode")
	public NexacroResult saveLangCode(@ParamDataSet(name = "dsList") List<SystLangVO> input) throws Exception{
		
		NexacroResult result = new NexacroResult();
		setUserIdLC(input);
		int res = systLangService.saveLangCode(input);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
	private void setUserIdLC(List<SystLangVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(SystLangVO row : data) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}
	
	private void setUserIdLT(List<SystTermVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(SystTermVO row : data) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}
	
	private void setUserIdLM(List<SystMsgVO> data) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		for(SystMsgVO row : data) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}
}

package com.oy.wms.syst.noti;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SystNotiMapper {
	
	// 공지사항 조회
	List<SystNotiVO> selectNoti(SystNotiVO param);

	// 공지사항 등록
	int insertNoti(SystNotiVO row);
	
	// 공지사항 수정
	int updateNoti(SystNotiVO row);
	
	// 공지사항 삭제
	int deleteNoti(SystNotiVO row);
	
}

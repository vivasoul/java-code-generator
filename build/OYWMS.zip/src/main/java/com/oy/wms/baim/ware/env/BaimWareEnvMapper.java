package com.oy.wms.baim.ware.env;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BaimWareEnvMapper {
	
	List<BaimWareEnvVO> getBaimWareEnvList(String cond1);

	int insertBaimWareEnvList(BaimWareEnvVO row);

	int updateBaimWareEnvList(BaimWareEnvVO data);

	int deleteBaimWareEnvList(BaimWareEnvVO data);
}

package com.oy.wms.syst.mgmt.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SystTermVO {
	private String chk;
	
	private String termCd;
	private String dtlTermCd;		//기준코드용 컬럼(그외 용어유형타입[용어/메뉴]에서는 무조건 01로 고정)
	private String termTypeCd;
	private String cntryLangCd;
	private String shortNm;
	private String totNm;
	private String aprvYn;
	private String pdaYn;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	
	private int rowType;
}

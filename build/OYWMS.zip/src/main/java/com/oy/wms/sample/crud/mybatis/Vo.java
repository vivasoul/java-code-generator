package com.oy.wms.sample.crud.mybatis;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Schema(description = "Sample 등록/조회/수정/삭제하기 위한 객체")
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility=JsonAutoDetect.Visibility.ANY, getterVisibility=JsonAutoDetect.Visibility.NONE,
        setterVisibility=JsonAutoDetect.Visibility.NONE, creatorVisibility= JsonAutoDetect.Visibility.NONE)
public class Vo extends DefaultVo implements java.io.Serializable {

    private static final long serialVersionUID = 5036836064217608611L;

    @Schema(description = "고유번호", example = "1", required = true)
    private int userId;

    @Schema(description = "이름", example = "길동", required = true)
    private String userName;

}

package com.oy.wms.baim.strt.set.lotatr;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimLotAttrChgStrtVO implements DataSetRowTypeAccessor {
	private String chk;
	
	private String cntrCd;
	private String whCd;
	private String whNm;
	private String lotAttrChgStrtCd;
	private String whWhibYmdUseYn;
	private String prodYmdUseYn;
	private String validDtimeUseYn;
	private String prodLotNoUseYn;
	private String markDscrUseYn;
	private String lotAttr1UseYn;
	private String lotAttr2UseYn;
	private String lotAttr3UseYn;
	private String lotAttr4UseYn;
	private String lotAttr5UseYn;
	private String lotAttr6UseYn;
	private String lotAttr7UseYn;
	private String lotAttr8UseYn;
	private String lotAttr9UseYn;
	private String lotAttr10UseYn;
	private String lotAttrChgStrtDscr;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	
	private int rowType;
}

package com.oy.wms.baim.cust;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BaimCustMapper {

	/**
	 * 고객사 조회
	 */
	List<BaimCustVO> selectCustList(BaimCustVO vo);

}

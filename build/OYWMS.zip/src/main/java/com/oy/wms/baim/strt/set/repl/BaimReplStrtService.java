package com.oy.wms.baim.strt.set.repl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nexacro.java.xapi.data.DataSet;
import com.oy.config.exception.NexacroBizException;
import com.oy.config.exception.NexacroErrorCode;

import lombok.RequiredArgsConstructor;

@Service("baimReplStrtService")
@RequiredArgsConstructor
public class BaimReplStrtService {
	
	private final BaimReplStrtMapper baimReplStrtMapper;

	/**
	 * 재고보충전전략 목록 조회
	 */
	public List<BaimReplStrtVO> selectBaimReplStrt(BaimReplStrtVO vo) {
		return baimReplStrtMapper.selectBaimReplStrt(vo);
	}

	/**
	 * 재고보충전전략 저장
	 */
	@Transactional
	public int saveBaimReplStrtList(List<BaimReplStrtVO> data) throws NexacroBizException {
		if(data.isEmpty()) throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "저장할 데이터가 존재하지 않습니다.");
		
		int res = 0;
		
		for(BaimReplStrtVO row : data) {
			
			int rowType = row.getRowType();
			switch(rowType) {
			case DataSet.ROW_TYPE_INSERTED : 
				if(baimReplStrtMapper.checkDupReplStrt(row)) {
					throw new NexacroBizException(NexacroErrorCode.DUPLICATED_KEYS.getCode());
				} else {
					res += baimReplStrtMapper.insertBaimReplStrt(row);
				}
				break;
			case DataSet.ROW_TYPE_UPDATED : 
				res+= baimReplStrtMapper.updateBaimReplStrt(row);
				break;
			}
			
		}
		return res;
	}
	
	/**
	 * 재고보충전전략 삭제
	 */
	@Transactional
	public int deleteBaimReplStrtList(List<BaimReplStrtVO> data) throws Exception {
		
		if(data.isEmpty()) throw new NexacroBizException(NexacroErrorCode.BIZ_ERROR.getCode(), "삭제할 데이터가 존재하지 않습니다.");
		
		int res = 0;
		for(BaimReplStrtVO row : data) {
			int rowType = row.getRowType();
			
			switch(rowType) {
			case DataSet.ROW_TYPE_DELETED : 
				res += baimReplStrtMapper.deleteBaimReplStrt(row);
			}
			
		}
		return res;
	}
}

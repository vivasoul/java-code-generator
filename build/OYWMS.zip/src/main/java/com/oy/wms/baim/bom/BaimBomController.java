package com.oy.wms.baim.bom;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.baim.bom.vo.BaimBomMainVO;
import com.oy.wms.login.vo.LoginVO;
import com.oy.wms.baim.bom.vo.BaimBomDtlVO;

import lombok.RequiredArgsConstructor;



@Controller 
@RequiredArgsConstructor
@RequestMapping("/baim/bom")
public class BaimBomController {
	
	private final BaimBomService baimBomService;
	
	/**
	 * BOM 조회
	 */
	@PostMapping("/getBomMList")
	public NexacroResult getBomMList(@ParamDataSet(name = "dsSearch") BaimBomMainVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimBomMainVO> list =  baimBomService.selectBomMList(input);
		result.addDataSet("dsList", list);
		
		return result;
	}
	
	/**
	 * BOM 저장
	 */
	@PostMapping("/saveBomMList")
	public NexacroResult saveBomMList(@ParamDataSet(name = "dsList") List<BaimBomMainVO> data,
			@ParamDataSet(name = "dsListDtl") List<BaimBomDtlVO> dataDtl) throws Exception {

		NexacroResult result = new NexacroResult();
		
		setUserId(data);
		int res = baimBomService.saveBomMList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}
		setUserId_dtl(dataDtl);
		int resDtl = baimBomService.saveBomDList(dataDtl);
		if(resDtl < 1) {
			result.setErrorCode(-1);
		}
		
		return result;
	}	
	
	/**
	 * BOM 삭제
	 */
	@PostMapping("/deleteBomMList")
	public NexacroResult deleteBomMList(@ParamDataSet(name = "dsList") List<BaimBomMainVO> data) throws Exception {

		NexacroResult result = new NexacroResult();
		setUserId(data);
		int res = baimBomService.deleteBomMList(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
	/**
	 * BOM 상세 조회
	 */	
	@PostMapping("/getBomDList")
	public NexacroResult getBomDList(@ParamDataSet(name = "dsSearchDtl") BaimBomDtlVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<BaimBomDtlVO> list =  baimBomService.selectBomDList(input);
		result.addDataSet("dsListDtl", list);
		
		return result;
	}
	
	private void setUserId(List<BaimBomMainVO> vo) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		
		for(BaimBomMainVO row : vo) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}
	
	private void setUserId_dtl(List<BaimBomDtlVO> vo) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		
		for(BaimBomDtlVO row : vo) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}	
		
}

package com.oy.wms.baim.ware;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.oy.wms.baim.strt.set.dist.BaimDistStrtVO;
import com.oy.wms.baim.ware.vo.BaimCntrVO;
import com.oy.wms.baim.ware.vo.BaimWareVO;

@Mapper
public interface BaimWareMapper {
	
	// 센터 조회
	List<BaimCntrVO> selectCntr(BaimCntrVO input);

	// 센터 등록
	int insertCntr(BaimCntrVO row);

	// 센터 수정
	int updateCntr(BaimCntrVO row);

	// 센터 삭제
	int deleteCntr(BaimCntrVO row);	
	
	// 센터 중복 조회
	boolean checkDupCntr(BaimCntrVO vo);
	
	// 창고 조회
	List<BaimWareVO> selectWare(BaimWareVO input);

	// 창고 등록
	int insertWare(BaimWareVO row);

	// 창고 수정
	int updateWare(BaimWareVO row);

	// 창고 삭제
	int deleteWare(BaimWareVO row);

	// 창고 중복 조회
	boolean checkDupWare(BaimWareVO vo);
}

package com.oy.wms.login;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.oy.wms.login.vo.CodeVO;
import com.oy.wms.login.vo.LoginVO;
import com.oy.wms.login.vo.MenuVO;

@Mapper
public interface LoginMapper {
	
	/**
	 * 사용자정보 조회
	 * */
	LoginVO selectUser(String userId);

	/**
	 * 패스워드 에러 횟수 업데이트
	 * */	
	int upadtePwdErrCnt(String userId);
	
	/**
	 * 메뉴정보 조회
	 * */
	List<MenuVO> selectMenu(String userId);
		
	/**
	 * 코드정보 조회
	 * */
	List<CodeVO> selectCode();
}

package com.oy.wms.baim.item.vo;

import java.io.Serializable;

import com.nexacro.uiadapter.spring.core.data.DataSetRowTypeAccessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaimAltnCodeVO implements Serializable ,DataSetRowTypeAccessor {

	private static final long serialVersionUID = -7194229967672089979L;
	private String custId;
	private String itemCd;
	private String altnItemCd;
	private String vndrId;
	private String unitCd;
	private String qty;
	private String dscr;
	private String delYn;
	private String regUserId;
	private String regDtime;
	private String modiUserId;
	private String modiDtime;
	private int rowType;
}
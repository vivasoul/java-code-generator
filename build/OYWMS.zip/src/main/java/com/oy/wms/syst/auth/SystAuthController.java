package com.oy.wms.syst.auth;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;
import com.oy.wms.login.vo.LoginVO;
import com.oy.wms.syst.auth.vo.SystAuthBtnVO;
import com.oy.wms.syst.auth.vo.SystAuthVO;
import com.oy.wms.syst.auth.vo.SystAuthMenuVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequiredArgsConstructor
@Slf4j
@RequestMapping("/syst/auth")
public class SystAuthController {

	private final SystAuthService systAuthService;
	


	/**
	 * 권한 조회
	 */
	@PostMapping("/getAuthList")
	public NexacroResult getAuthList(@ParamDataSet(name = "dsSearch") SystAuthVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<SystAuthVO> list =  systAuthService.selectAuth(input);
		log.debug("getAuthList : "+ input);
		
		result.addDataSet("dsList", list);
		
		return result;
	}	
	
	/**
	 * 권한 저장
	 */
	@PostMapping("/saveAuth")
	public NexacroResult saveAuthList(@ParamDataSet(name = "dsList") List<SystAuthVO> data) throws Exception {

		NexacroResult result = new NexacroResult();
		
		setUserId_Auth(data);
		
		int res = systAuthService.saveAuth(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
	/**
	 * 권한 삭제
	 */
	@PostMapping("/deleteAuth")
	public NexacroResult deleteAuthList(@ParamDataSet(name = "dsList") List<SystAuthVO> data) throws Exception {

		NexacroResult result = new NexacroResult();
		
		setUserId_Auth(data);
		
		int res = systAuthService.deleteAuth(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}		
	
	/**
     * 권한별 갖는 메뉴 항목 조회
	 */
	@PostMapping("/getMenuAuth")
	public NexacroResult getMenuAuth(@ParamDataSet(name = "dsSearchMenu") SystAuthMenuVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		List<SystAuthMenuVO> list_menu =  systAuthService.selectMenu(input);		
		List<SystAuthMenuVO> list_authMenu =  systAuthService.selectMenuByAuth(input);
		
		result.addDataSet("dsMenuList", list_menu);		
		result.addDataSet("dsAuthMenuList", list_authMenu);
		
		return result;
	}
	
	/**
	 * 권한별 갖는 메뉴 항목 I/U 
	 */
	@PostMapping("/saveAuthMenuR")
	public NexacroResult saveAuthMenuR(@ParamDataSet(name = "dsAuthMenuList") List<SystAuthMenuVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserId_Menu(data);
		
		int res = systAuthService.saveAuthMenu(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}
			
		return result;		
	}

	/**
	 * 권한별 갖는 메뉴 항목 I/U 
	 */
	@PostMapping("/saveAuthMenuL")
	public NexacroResult saveAuthMenuL(@ParamDataSet(name = "dsMenuList") List<SystAuthMenuVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserId_Menu(data);
		
		int res = systAuthService.deleteAuthMenu(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}
			
		return result;		
	}	
	
	/**
	 * 권한별메뉴 - 메뉴별 버튼 권한 조회
	 */
	@PostMapping("/getAuthBtn")
	public NexacroResult getAuthBtn(@ParamDataSet(name = "dsSearchBtnAuth") SystAuthBtnVO input) throws Exception {
		
		NexacroResult result = new NexacroResult();
		List<SystAuthBtnVO> list =  systAuthService.selectAuthBtn(input);
		result.addDataSet("dsCode", list);		
		
		return result;
	}
	
	/**
	 * 메뉴별 버튼 권한 I/U
	 */
	@PostMapping("/saveAuthBtn")
	public NexacroResult saveAuthBtn(@ParamDataSet(name = "dsBtnAuthList") List<SystAuthBtnVO> data) throws Exception {
		
		NexacroResult result = new NexacroResult();
		
		setUserId_Btn(data);
		
		int res = systAuthService.saveAuthBtn(data);
		if(res < 1) {
			result.setErrorCode(-1);
		}		
		
		return result;
	}
	
	//권한용 유저 정보
	private void setUserId_Auth(List<SystAuthVO> vo) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		
		for(SystAuthVO row : vo) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}	
	
	//권한 메뉴용 유저 정보
	private void setUserId_Menu(List<SystAuthMenuVO> vo) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		
		for(SystAuthMenuVO row : vo) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}	
	
	//권한 버튼용 유저 정보
	private void setUserId_Btn(List<SystAuthBtnVO> vo) {
		LoginVO userObj  = (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
		String userId = userObj.getUserId();
		
		for(SystAuthBtnVO row : vo) {
			row.setRegUserId(userId);
			row.setModiUserId(userId);
		}
	}	
}
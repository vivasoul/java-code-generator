package com.oy.config.mvc;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.util.StopWatch;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.servlet.View;

import com.nexacro.java.xapi.data.DataSet;
import com.nexacro.java.xapi.data.DataSetList;
import com.nexacro.java.xapi.data.PlatformData;
import com.nexacro.java.xapi.data.Variable;
import com.nexacro.java.xapi.data.VariableList;
import com.nexacro.uiadapter.spring.core.data.convert.ConvertDefinition;
import com.nexacro.uiadapter.spring.core.data.convert.NexacroConvertException;
import com.nexacro.uiadapter.spring.core.data.convert.NexacroConverter;
import com.nexacro.uiadapter.spring.core.data.convert.NexacroConverterFactory;
import com.nexacro.uiadapter.spring.core.resolve.NexacroHandlerMethodReturnValueHandler;

public class ParametersMethodReturnValueHandler extends NexacroHandlerMethodReturnValueHandler {
	  private Logger logger = LoggerFactory.getLogger(NexacroHandlerMethodReturnValueHandler.class);
	  
	  private Logger performanceLogger = LoggerFactory.getLogger("com.nexacro.performance");	
	
	
	@Override
	public boolean supportsReturnType(MethodParameter returnType) {
	    Class<?> parameterType = returnType.getParameterType();
	    if (Parameters.class.isAssignableFrom(parameterType)) {
	    	return true; 
	    } else {
	    	return super.supportsReturnType(returnType);
	    }
	}

	@Override
	public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest) throws Exception {
		Class<?> parameterType = returnType.getParameterType();
		
		if (Parameters.class.isAssignableFrom(parameterType)) {
			handleParametersReturnValue(returnValue, returnType, mavContainer, webRequest);
		} else {
			super.handleReturnValue(returnValue, returnType, mavContainer, webRequest);
		}
	}
	
	private void handleParametersReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest) throws Exception {
	    Class<?> parameterType = returnType.getParameterType();
	    if (returnValue == null) {
	      mavContainer.setView(getView());
	      return;
	    } 
	    View responseView = null;
	    StopWatch sw = new StopWatch(getClass().getSimpleName());
	    sw.start("resolve return value");
	    try {
			Parameters parameters = (Parameters) returnValue;
			PlatformData platformData = new PlatformData();
			
			addDataSetsIntoPlatformData(platformData, parameters);
			addVariablesIntoPlatformData(platformData, parameters);
			addErrorInformationIntoPlatformData(platformData, parameters);
			
			mavContainer.addAttribute("NexacroPlatformData", platformData);
			responseView = getView();
	    } catch (Exception e) {
	      this.logger.error("Error handling return value. value" + returnValue + ", e=" + e + ", message=" + e.getMessage(), e);
	      throw e;
	    } finally {
	      sw.stop();
	      if (this.performanceLogger.isTraceEnabled())
	        this.performanceLogger.trace(sw.prettyPrint()); 
	    } 
	    mavContainer.setView(responseView);		
	}
	
	@SuppressWarnings("unchecked")
	private void addDataSetsIntoPlatformData(PlatformData platformData, Parameters parameters) throws NexacroConvertException {
		Map<String, List<Map<String,Object>>> dataSetList = parameters.getOutDatasetList();
		
		Set<String> keys = dataSetList.keySet();
		
		for (String name: keys) {
			List<Map<String,Object>> mapList = dataSetList.get(name);
			
			if (mapList == null) {
				platformData.addDataSet(new DataSet(name));
				continue;
			} 
			
			NexacroConverter dataSetConverter = getDataSetConverter(mapList.getClass());
			if (dataSetConverter == null) {
				this.logger.debug("not found converter {} to List to DataSet({})", name);
				continue;
			} 
			this.logger.debug("found a converter({}) for converting the List to DataSet({})", dataSetConverter.getClass().getName(), name);
			
			ConvertDefinition definition = new ConvertDefinition();
			definition.setName(name);
			Object convert = dataSetConverter.convert(mapList, definition);
			
			if (convert != null && convert instanceof DataSet) platformData.addDataSet((DataSet)convert); 
		} 
	}
	
	private void addVariablesIntoPlatformData(PlatformData platformData, Parameters parameters) throws NexacroConvertException {
		VariableList variableList = parameters.getOutVariableList();
				
		int size = variableList.size();
		for (int i=0; i<size; i++) {
			Variable val = variableList.get(i);
			String name = val.getName(); 
			
			NexacroConverter variableConverter = getVariableConverter(val.getClass());
			if (variableConverter == null) {
				this.logger.debug("not found converter {} to Variable({})", val.getClass(), name);
				continue;
			} 
			this.logger.debug("found a converter({}) for converting the {} to Variable({})", 
					new Object[] { variableConverter.getClass().getName(), val.getClass(), name });
			
			ConvertDefinition definition = new ConvertDefinition();
			definition.setName(name);
			Object convert = variableConverter.convert(val, definition);
			
			if (convert != null && convert instanceof Variable) platformData.addVariable((Variable)convert); 
		} 
	}
	
	private void addErrorInformationIntoPlatformData(PlatformData platformData, Parameters parameters) {
		int errCode = parameters.getErrCode();
		if (parameters.getErrCode() != 0) {
			platformData.addVariable(Variable.createVariable("ErrorMsg", parameters.getErrMessage()));
		}
		
		platformData.addVariable(Variable.createVariable("ErrorCode", errCode));
	}
	
	private NexacroConverter getDataSetConverter(Class source) {
		return getConverter(source, DataSet.class);
	}
	
	private NexacroConverter getVariableConverter(Class source) {
		return getConverter(source, Variable.class);
	}
	
	private NexacroConverter getConverter(Class source, Class target) {
		return NexacroConverterFactory.getConverter(source, target);
	}
}

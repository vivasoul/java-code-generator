package com.oy.config.exception;

import com.nexacro.uiadapter.spring.core.NexacroException;

public class NexacroBizException extends NexacroException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5237334485464934055L;

	public NexacroBizException() {
		this(-1);
	}
	
	public NexacroBizException(int errCode) {
		super(Integer.toString(errCode), errCode, null);
	}
	
	public NexacroBizException(int errCode, String errMessage) {
		super(Integer.toString(errCode), errCode, errMessage);
	}
}

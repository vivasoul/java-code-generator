package com.oy.config.mvc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nexacro.java.xapi.data.DataSet;
import com.nexacro.java.xapi.data.DataSetList;
import com.nexacro.java.xapi.data.PlatformData;
import com.nexacro.java.xapi.data.Variable;
import com.nexacro.java.xapi.data.VariableList;
import com.oy.config.exception.NoSuchDataSetException;

public class Parameters {

	private final Map<String, List<Map<String, Object>>> mapListCache = new HashMap<>();
	
    private PlatformData platformData;
    private DataSetList datasetList;
    private VariableList variableList;
    //private DataSetList outDatasetList;
    private Map<String, List<Map<String,Object>>> outDatasetList;
    private VariableList outVariableList;

    private int errCode;
    private String errMessage;

    public Parameters() {
        this.platformData = new PlatformData();
        this.datasetList = new DataSetList();
        this.variableList = new VariableList();
        this.outDatasetList = new HashMap<>();
        this.outVariableList = new VariableList();
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> getFirstRow(String dataSetName) throws NoSuchDataSetException {
    	
    	return getMapList(dataSetName).get(0);
    }
    
    //DataSet -> List<Map<String, Object>>
    @SuppressWarnings("unchecked")
	public List<Map<String, Object>> getMapList(String dataSetName) throws NoSuchDataSetException {
    	List<Map<String, Object>> mapList = null;
    	PlatformData platformData = getPlatformData();

		if(platformData.getDataSet(dataSetName) == null) {
			throw new NoSuchDataSetException(dataSetName);
		} else {
    		mapList = platformData.getMapList(dataSetName);
		}
    	
        return mapList;
    }    
  
    public Map<String, List<Map<String,Object>>> getOutDatasetList() {
        return outDatasetList;
    }

    public void setOutDatasetList(Map<String, List<Map<String,Object>>> outDatasetList) {
        this.outDatasetList = outDatasetList;
    }

    public void addOutDataset(String dsName, List<Map<String,Object>> mapList) {
        this.outDatasetList.put(dsName, mapList);
    }

    public VariableList getOutVariableList() {
        return outVariableList;
    }

    public void setOutVariableList(VariableList outVariableList) {
        this.outVariableList = outVariableList;
    }

    public void addOutVariable(String valName, Object paramVal) {
        this.outVariableList.add(valName, paramVal);
    }

    public PlatformData getPlatformData() {
        return platformData;
    }

    public void setPlatformData(PlatformData platformData) {
        this.platformData = platformData;
    }

    public DataSetList getDatasetList() {
        return datasetList;
    }

    public void setDatasetList(DataSetList datasetList) {
        this.datasetList = datasetList;
    }

    public VariableList getVariableList() {
        return variableList;
    }

    public void setVariableList(VariableList variableList) {
        this.variableList = variableList;
    }

    public DataSet getDataSet(int idx) {
        return datasetList.get(idx);
    }

    public DataSet getDataSet(String name) {
        return datasetList.get(name);
    }

    public Variable getVariable(String name) {
        return this.variableList.get(name);
    }

    public Variable getVariable(int index) {
        return this.variableList.get(index);
    }

	public int getErrCode() {
		return errCode;
	}

	public void setErrCode(int errCode) {
		this.errCode = errCode;
	}

	public String getErrMessage() {
		return errMessage;
	}

	public void setErrMessage(String errMessage) {
		this.errMessage = errMessage;
	}
	
	public void setErrCodeMessage(int errCode, String errMessage) {
		this.errCode = errCode;
		this.errMessage = errMessage;
	}
}

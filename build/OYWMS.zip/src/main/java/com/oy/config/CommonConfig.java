package com.oy.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Lazy;

import com.nexacro.uiadapter.spring.core.context.ApplicationContextProvider;
import com.nexacro.uiadapter.spring.dao.DbVendorsProvider;
import com.nexacro.uiadapter.spring.dao.Dbms;
import com.nexacro.uiadapter.spring.dao.dbms.Mysql;
import com.nexacro.uiadapter.spring.dao.dbms.Oracle;

@Configuration
public class CommonConfig {
	/* nexacro 연동용 스프링 설정 START */
	
	@Bean
	public ApplicationContextProvider applicationContextProviderBean(ApplicationContext applicationContext) {
		ApplicationContextProvider provider = new ApplicationContextProvider();
		provider.setApplicationContext(applicationContext);
		
		return provider;
	}
	
	@Bean(name = "dbmsProvider")
	@DependsOn({"applicationContextProviderBean"})
	public DbVendorsProvider dbmsProviderBean() {
		DbVendorsProvider dbmsProvider = new DbVendorsProvider();
		
		Map<String, Dbms> vendorMap = new HashMap<>();
		vendorMap.put("MariaDB", new Mysql());
		vendorMap.put("Oracle", new Oracle());
		dbmsProvider.setDbvendors(vendorMap);
		
		return dbmsProvider;
	}

	/* nexacro 연동용 스프링 설정 END */
}
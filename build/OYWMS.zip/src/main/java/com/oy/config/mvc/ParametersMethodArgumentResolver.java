package com.oy.config.mvc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.nexacro.java.xapi.data.PlatformData;
import com.nexacro.java.xapi.tx.PlatformException;
import com.nexacro.uiadapter.spring.core.context.NexacroContext;
import com.nexacro.uiadapter.spring.core.context.NexacroContextHolder;

public class ParametersMethodArgumentResolver implements HandlerMethodArgumentResolver {
	
	private boolean isCached = false;
	
	public ParametersMethodArgumentResolver() {
		this(false);
	}
	
	public ParametersMethodArgumentResolver(boolean isCached) {
		this.isCached = isCached;
	}
	
	@Override
	@SuppressWarnings("rawtypes")
	public boolean supportsParameter(MethodParameter parameter) {
		// TODO Auto-generated method stub
		Class paramClass = parameter.getParameterType();
		
		return paramClass.equals(Parameters.class);
	}

	@Override
	public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer,
			NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {
		// TODO Auto-generated method stub
		NexacroContext nexacroCachedData = prepareResolveArguments(webRequest);
		
		PlatformData platformData = nexacroCachedData.getPlatformData();
		Parameters parameters = null;
		
		if(isCached) {
			parameters = new CachedParameters();
		} else {
			parameters = new Parameters();
		}
		
		bindParametersArgument(parameters, platformData);
		
		return parameters;
	}

	private void bindParametersArgument(Parameters parameters, PlatformData platformData) {
		parameters.setDatasetList(platformData.getDataSetList());
		parameters.setVariableList(platformData.getVariableList());
		parameters.setPlatformData(platformData);
	}
	
	private NexacroContext prepareResolveArguments(NativeWebRequest nativeWebRequest) throws PlatformException {
		NexacroContext cache = parsePlatformRequestOrGetAttribute(nativeWebRequest);
		return cache;
	}
	
	private NexacroContext parsePlatformRequestOrGetAttribute(NativeWebRequest nativeWebRequest) throws PlatformException {
		NexacroContext cache = NexacroContextHolder.getNexacroContext();
		if (cache != null)
			return cache; 
		
		HttpServletRequest servletRequest = (HttpServletRequest)nativeWebRequest.getNativeRequest();
		HttpServletResponse servletResponse = (HttpServletResponse)nativeWebRequest.getNativeResponse();
		cache = NexacroContextHolder.getNexacroContext(servletRequest, servletResponse);
		
		return cache;
	}
}
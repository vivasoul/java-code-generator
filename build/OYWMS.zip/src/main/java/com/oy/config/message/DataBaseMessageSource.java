package com.oy.config.message;

import java.text.MessageFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.support.AbstractMessageSource;
import org.springframework.util.StringUtils;

import com.oy.wms.syst.mgmt.vo.SystMsgVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DataBaseMessageSource extends AbstractMessageSource{
	
	private final ConcurrentMap<String, Map<Locale, MessageFormat>> cachedMessageFormats = new ConcurrentHashMap<>();
	
	private SqlSessionFactory sqlSessionFactory;
	
	public void init() throws Exception {
		log.debug("Initializing DataBaseMessageSource...");
		
		loadMessages();
	}
	
	public void destroy() {
		log.debug("Destroying DataBaseMessageSource...");
		
		this.cachedMessageFormats.clear();
	}
	
	synchronized public void refresh() throws Exception {
		log.debug("Refreshing DataBaseMessageSource...");
		
		this.cachedMessageFormats.clear();
		loadMessages();
	}
	
	public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) { 
		this.sqlSessionFactory = sqlSessionFactory;
	}
		
	@Override
	protected MessageFormat resolveCode(String code, Locale locale) {
		Map<Locale, MessageFormat> localeMap = this.cachedMessageFormats.get(code);
		
		if(localeMap == null) {
			return createMessageFormat(code, locale);	
		} else {
			return localeMap.get(locale);
		}
	}
	
	private void loadMessages() throws Exception {
		/* 1. read data from database */
		List<SystMsgVO> messageList = readData();
		
		if(messageList == null || messageList.isEmpty()) {
			log.warn("messageList is empty..");
		} else {
			/* 2. bind the data to memory */
			for(SystMsgVO message: messageList) {
				String localeCd = message.getCntryLangCd();
				Locale locale = StringUtils.parseLocale(localeCd);
				
				String msgCd = message.getMsgCd();
				String msgNm = message.getMsgCont();
				
				Map<Locale, MessageFormat> localeMap = new ConcurrentHashMap<>();
				Map<Locale, MessageFormat> existing = this.cachedMessageFormats.putIfAbsent(msgCd, localeMap);
				if (existing != null) {
					localeMap = existing;
				}			
				MessageFormat result = createMessageFormat(msgNm, locale);
				localeMap.put(locale, result);
			}			
		}
		
	}
	
	private List<SystMsgVO> readData() throws Exception {
		if(sqlSessionFactory == null) {
			throw new Exception("sqlSessionFactory cannot be null.");
		}
		
		SqlSession sqlSession  = sqlSessionFactory.openSession();
		List<SystMsgVO> data = null;
		try {
			sqlSession  = sqlSessionFactory.openSession();
			
			SystMsgVO condition = new SystMsgVO();
			condition.setMsgTypeCd("X");
			condition.setDelYn("N");
			
			data = sqlSession.selectList("com.oy.wms.syst.mgmt.SystLangMapper.selectLangMsg", condition);
		} catch (Exception ex) {
			log.error(ex.getMessage());
		} finally {
			if(sqlSession != null) sqlSession.close();
		}
		
		return data;
	}
}

package com.oy.config.message;

import java.nio.charset.StandardCharsets;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

@Configuration
public class MessageSourceConfig {
	@Bean
    public MessageSource messageSource() {
        ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource = new ReloadableResourceBundleMessageSource();
        reloadableResourceBundleMessageSource
                .addBasenames("classpath:/messages/message");
        reloadableResourceBundleMessageSource
                .setDefaultEncoding(StandardCharsets.UTF_8.displayName());
        reloadableResourceBundleMessageSource.setUseCodeAsDefaultMessage(true);
        return reloadableResourceBundleMessageSource;
    }
	
	
	
	@Bean(name="nexaMessageSource", initMethod = "init", destroyMethod = "destroy")
	public DataBaseMessageSource dataBaseMessageSource(@Qualifier("masterSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
		
		DataBaseMessageSource messageSource = new DataBaseMessageSource();
		messageSource.setSqlSessionFactory(sqlSessionFactory);		
		
		return messageSource;
	}
}

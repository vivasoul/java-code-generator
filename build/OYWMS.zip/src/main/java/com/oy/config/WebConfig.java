package com.oy.config;

import java.util.List;
import javax.annotation.Resource;
import com.oy.config.mvc.NexacroBizExceptionResolver;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;
import org.springframework.web.servlet.view.AbstractView;

import com.nexacro.java.xapi.tx.PlatformType;
import com.nexacro.uiadapter.spring.core.resolve.NexacroHandlerMethodReturnValueHandler;
import com.nexacro.uiadapter.spring.core.resolve.NexacroMethodArgumentResolver;
//import com.nexacro.uiadapter.spring.core.resolve.NexacroMappingExceptionResolver;
import com.nexacro.uiadapter.spring.core.view.NexacroFileView;
import com.nexacro.uiadapter.spring.core.view.NexacroView;
import com.oy.common.view.FixedUrlBasedView;

@Configuration
@EnableWebMvc
public class WebConfig implements WebMvcConfigurer {

    @Value("${nexacro.main.path}")
    private String mainUri;

    @Resource(name = "nexaMessageSource")
    private MessageSource messageSource;

    @Value("${nexacro.exception.default.message}")
    private String nexacroExceptionDefaultMessage;

    @Bean(name = "nexaMain")
    public AbstractView getNexaMainView() {

        AbstractView nexaView = new FixedUrlBasedView(mainUri);

        return nexaView;
    }

    @Bean
    @ConditionalOnMissingBean
    public LocaleResolver localeResolver() {
        AcceptHeaderLocaleResolver localeResolver = new AcceptHeaderLocaleResolver();
        localeResolver.setDefaultLocale(LocaleContextHolder.getLocale());
        return localeResolver;
    }


    @Override
    public void configureDefaultServletHandling(
            DefaultServletHandlerConfigurer configurer) {
        configurer.enable();
    }

    @Override
    public void configureViewResolvers(ViewResolverRegistry registry) {
        registry.jsp("/WEB-INF/jsp/", ".jsp");
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        //@Todo. move to spring-security configuration
        registry.addResourceHandler("/static/nexa_web/**")
                .addResourceLocations("/nowhere");

        registry.addResourceHandler("/nexa/**")
                .addResourceLocations("classpath:/static/nexa_web/");

        registry.addResourceHandler("/static/**")
                .addResourceLocations("classpath:/static/");

    }

    @Override
    public void addArgumentResolvers(
            List<HandlerMethodArgumentResolver> resolvers) {
        NexacroMethodArgumentResolver nexacroResolver = new NexacroMethodArgumentResolver();
        resolvers.add(nexacroResolver);
    }

    @Override
    public void addReturnValueHandlers(
            List<HandlerMethodReturnValueHandler> handlers) {
        NexacroHandlerMethodReturnValueHandler returnValueHandler = new NexacroHandlerMethodReturnValueHandler();
        //NexacroHandlerMethodReturnValueHandler returnValueHandler = new ParametersMethodReturnValueHandler();

        //NexacroFileView nexacroFileView = new NexacroFileView();
        NexacroView nexacroView = new NexacroView();
        nexacroView.setDefaultContentType(PlatformType.CONTENT_TYPE_XML);
        returnValueHandler.setView(nexacroView);
        //returnValueHandler.setFileView(nexacroFileView);
        handlers.add(returnValueHandler);
    }

    /**
     * Nexacro ExceptionResolver
     */
    @Override
    public void configureHandlerExceptionResolvers(
            List<HandlerExceptionResolver> resolvers) {
        NexacroView nexacroView = new NexacroView();
        nexacroView.setDefaultContentType(PlatformType.CONTENT_TYPE_XML);

        NexacroBizExceptionResolver exceptionResolver = new NexacroBizExceptionResolver();
        exceptionResolver.setView(nexacroView);
        exceptionResolver.setShouldLogStackTrace(true);
        exceptionResolver.setShouldSendStackTrace(false);
        exceptionResolver.setLocaleResolver(localeResolver());
        //nexacroException.setDefaultErrorMsg(nexacroExceptionDefaultMessage);
        exceptionResolver.setMessageSource(messageSource);
        exceptionResolver.setOrder(1);
        resolvers.add(exceptionResolver);
    }
}




package com.oy.config.mvc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nexacro.java.xapi.data.PlatformData;
import com.oy.config.exception.NoSuchDataSetException;

public class CachedParameters extends Parameters{
	
	private final Map<String, List<Map<String, Object>>> mapListCache = new HashMap<>();
	
	@Override
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> getMapList(String dataSetName) throws NoSuchDataSetException {
    	List<Map<String, Object>> mapList = null;
    	PlatformData platformData = getPlatformData();
    	
    	if(mapListCache.containsKey(dataSetName)) {
    		mapList = mapListCache.get(dataSetName);
    	} else {
    		
    		if(platformData.getDataSet(dataSetName) == null) {
    			throw new NoSuchDataSetException(dataSetName);
    		} else {
        		mapList = platformData.getMapList(dataSetName);
        		mapListCache.put(dataSetName, mapList);    			
    		}
    	}
    	
        return mapList;
    }   
}

package com.oy.config.mvc;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;

import com.nexacro.uiadapter.spring.core.NexacroException;
import com.nexacro.uiadapter.spring.core.util.NexacroUtil;
import com.nexacro.uiadapter.spring.core.view.NexacroModelAndView;
import com.nexacro.uiadapter.spring.core.view.NexacroView;

public class NexacroBizExceptionResolver extends AbstractHandlerExceptionResolver {
	  private final Logger logger = LoggerFactory.getLogger(NexacroBizExceptionResolver.class);
	  
	  private MessageSource messageSource;
	  
	  private int defaultErrorCode = -1;
	  
	  private boolean shouldSendStackTrace = false;
	  
	  private boolean shouldLogStackTrace = false;
	  
	  private View view;
	  
	  private LocaleResolver localeResolver;
	  
	  public View getView() {
	    if (this.view == null)
	      return (View)new NexacroView(); 
	    return this.view;
	  }
	  
	  public void setView(View view) {
	    this.view = view;
	  }
	  
	  public void setDefaultErrorCode(int defaultErrorCode) {
	    this.defaultErrorCode = defaultErrorCode;
	  }
	  
	  public void setShouldSendStackTrace(boolean shouldSendStackTrace) {
	    this.shouldSendStackTrace = shouldSendStackTrace;
	  }
	  
	  public void setShouldLogStackTrace(boolean shouldLogStackTrace) {
	    this.shouldLogStackTrace = shouldLogStackTrace;
	  }
	  
	  public void setMessageSource(MessageSource messageSource) {
	    this.messageSource = messageSource;
	  }
	  
	  public void setLocaleResolver(LocaleResolver localeResolver) {
		  this.localeResolver = localeResolver;
	  }
	 
	  protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
	    prepareResolveException(request, response, handler, ex);
	    if (NexacroUtil.isNexacroRequest(request)) {
	      NexacroModelAndView mav = new NexacroModelAndView(getView());
	      
	      Locale locale = localeResolver == null ? getDefaultLocale() : localeResolver.resolveLocale(request);
	      
	      if (ex instanceof NexacroException) {
	        NexacroException nexaExp = (NexacroException)ex;
	        mav.setErrorCode(nexaExp.getErrorCode());
	      } else {
	        mav.setErrorCode(defaultErrorCode);
	        
	      } 
	      mav.setErrorMsg(getExceptionSendMessage(ex, locale));
	      
	      return (ModelAndView)mav;
	    }
	    
	    return null;
	  }
	  
	  private void prepareResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
	    if (this.shouldLogStackTrace) {
	      String exceptionMessage = getExceptionLogMessage(ex);
	      this.logger.error(exceptionMessage, ex);
	    } 
	  }
	  
	  private String getExceptionLogMessage(Exception e) {
	    String exceptionMessage = getLocalizedMessage(e.getMessage());
	    if (e instanceof NexacroException) {
	      String userErrorMsg = getLocalizedMessage(((NexacroException)e).getErrorMsg());
	      exceptionMessage = "errorMsg=" + userErrorMsg + ", stackMessage=" + exceptionMessage;
	    } 
	    return exceptionMessage;
	  }
	  
	  private String getExceptionSendMessage(Exception e, Locale locale) {
		String errMsg = null;
		  
	    if (e instanceof NexacroException) {
	    	errMsg = getLocalizedMessage(((NexacroException)e).getErrorCode(), locale); 
	    	logger.debug("A-1. exceptionMessage {} ",errMsg);
	    } else {
	    	errMsg = getLocalizedMessage(this.defaultErrorCode, locale);
	    	logger.debug("A-2. exceptionMessage {} ",errMsg);
	    }
	    
	    if (this.shouldSendStackTrace) {
	      String stackMessage = e.getLocalizedMessage();
	      if(e.getCause() != null) {
	    	  stackMessage = stackMessage +" ☆ "+ e.getCause().getMessage();
	      }
	      
	      errMsg = "errorMsg=" + errMsg + ", stackMessage=" + stackMessage;
	      logger.debug("B. exceptionMessage {} ",errMsg);
	    } 
	    
	    return errMsg;
	  }
	  
	  private String getLocalizedMessage(String reason) {
		  return getLocalizedMessage(reason, getDefaultLocale());
	  }	  
	  
	  private String getLocalizedMessage(int reason, Locale locale) {
		  return getLocalizedMessage(Integer.toString(reason), locale);
	  }
	  
	  private String getLocalizedMessage(String reason, Locale locale) {
	    if (reason == null)
	      return null; 
	    if (this.messageSource != null)
	      reason = this.messageSource.getMessage(reason, null, reason, locale); 
	    return reason;
	  }
	  
	  private Locale getDefaultLocale() {
		  return LocaleContextHolder.getLocale();
	  }
}


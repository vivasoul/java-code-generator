package com.oy.config.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum NexacroErrorCode {
	
	/** NexacroException ErrorCode
	 *  -1 : RuntimeException, NexacroBizException 
	 *  
	 */
	BIZ_ERROR(-1),
	DUPLICATED_KEYS(-2),
	DUPLICATED_ID(-3);
	
	
	private final int code;

}


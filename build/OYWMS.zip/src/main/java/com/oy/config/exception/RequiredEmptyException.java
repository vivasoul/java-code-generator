package com.oy.config.exception;

public class RequiredEmptyException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8669015653045121796L;

	public RequiredEmptyException( ) {
		this(null, null);
	}	
	
	public RequiredEmptyException(String columnName) {
		this(columnName, null);
	}	
	
	public RequiredEmptyException(String columnName, String signatureName) {
		super(columnName+" is required, but empty on "+signatureName);
	}
}

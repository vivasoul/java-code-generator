package com.oy.config.exception;

public class NoSuchDataSetException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4141914411039395950L;

	public NoSuchDataSetException() {
		this(null);
	}
	
	public NoSuchDataSetException(String dataSetName) {
		super("Can not find the dataset named: "+dataSetName);
	}
}	

package com.oy.config.aop;

import javax.annotation.Resource;
import javax.sound.midi.SysexMessage;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.oy.wms.login.vo.LoginVO;
import com.oy.wms.syst.hist.SystHistService;
import com.oy.wms.syst.hist.vo.PrgmErrHistVO;
import com.oy.wms.syst.hist.vo.PrgmUseHistVO;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Aspect
@Slf4j
public class AccessLogAOP {
	
	@Resource(name = "systHistService")
	private SystHistService systHistService;
	
	@Pointcut("within(com.oy..*Controller) && execution(public * *(..))")
	public void accessLogPointCut() {};	

	@Pointcut("accessLogPointCut() && @annotation(requestMapping)")
	public void accessLogRequestPointCut(RequestMapping requestMapping) {};		

	@Pointcut("accessLogPointCut() && @annotation(requestMapping)")
	public void accessLogPostPointCut(PostMapping requestMapping) {};	
	
	@AfterReturning(value="accessLogRequestPointCut(requestMapping)")
	public void saveRequestMappingLog(JoinPoint jpoint, RequestMapping requestMapping) {
		String method = getMethod(requestMapping);
		
		saveNormalLog(jpoint, method);
	}
	
	@AfterReturning(value="accessLogPostPointCut(requestMapping)")
	public void savePostMappingLog(JoinPoint jpoint, PostMapping requestMapping) {
		
		saveNormalLog(jpoint, RequestMethod.POST.name());
	}
	
	@AfterThrowing(value="accessLogRequestPointCut(requestMapping)", throwing = "ex")
	public void saveRequestMappingExLog(JoinPoint jpoint, RequestMapping requestMapping, Exception ex) {
		String url = getUrl(requestMapping);
		String method = getMethod(requestMapping);
		
		saveErrorLog(jpoint, url, method, ex);		
	}
	
	@AfterThrowing(value="accessLogPostPointCut(requestMapping)", throwing = "ex")
	public void savePostMappingExLog(JoinPoint jpoint, PostMapping requestMapping, Exception ex) {
		String url = getUrl(requestMapping);
		
		saveErrorLog(jpoint, url, RequestMethod.POST.name(), ex);
	}
	
	
	private void saveNormalLog(JoinPoint jpoint, String method) {
		String serviceName = jpoint.getSignature().getDeclaringTypeName();
		String methodName = jpoint.getSignature().getName();
		LoginVO user = getUser();
		String userId = user.getUserId();
		String userNm = user.getUserNm();
		
		log.debug("Save an access log for the call: "+serviceName+"."+methodName+" with method - "+method);
		
		PrgmUseHistVO histVO = new PrgmUseHistBuilder().setConnIp("127.0.0.1")
													   .setSrvcNm(serviceName)
													   .setMthdNm(methodName)
													   .setUserId(userId)
													   .setUserNm(userNm)
													   .setRegUserId(userId)
													   .build();
		
		//systHistService.insertPrgmUseHist(histVO);
	}
	
	private void saveErrorLog(JoinPoint jpoint, String url, String method, Exception ex) {
		String serviceName = jpoint.getSignature().getDeclaringTypeName();
		String methodName = jpoint.getSignature().getName();
		LoginVO user = getUser();
		String userId = user.getUserId();
		String exMessage = ex.getMessage();
		
		log.debug("Save an error log for the call: "+serviceName+"."+methodName+" with method - "+method);
		log.error(exMessage);
		
		PrgmErrHistVO histVO = new PrgmErrHistBuilder().setErrCont(exMessage.length() > 1000 ? exMessage.substring(0,1000) : exMessage)
													   .setRqstUrl(url)
													   .setConnIpAddr("127.0.0.1")
													   .setSrvrIpAddr("127.0.0.1")
													   .setRegUserId(userId)
													   .build();
		
		//systHistService.insertPrgmErrHist(histVO);
	}
	
	private String getMethod(RequestMapping requestMapping) {
		RequestMethod[] methodList = requestMapping.method();
		String method = null;
		
		if(methodList.length > 0) {
			method = methodList[0].name();
		}
		
		return method;
	}
	
	private String getUrl(RequestMapping requestMapping) {
		return getUrl(requestMapping.value());			
	}
	
	private String getUrl(PostMapping requestMapping) {
		return getUrl(requestMapping.value());		
	}	
	
	private String getUrl(String[] urlList) {
		return urlList.length > 0 ? urlList[0] : null;	
	}
	
	private LoginVO getUser() {
		return (LoginVO)(RequestContextHolder.getRequestAttributes().getAttribute("user", RequestAttributes.SCOPE_SESSION));
	}
	
	class PrgmUseHistBuilder {
		private String userId;
		private String userNm;
		private String connIp;
		private String connTypeCd;
		private String whCd;
		private String menuCd;
		private String srvcNm;
		private String mthdNm;
		private String regUserId;
		
		public PrgmUseHistBuilder setUserId(String userId) {
			this.userId = userId;
			return this;
		}

		public PrgmUseHistBuilder setUserNm(String userNm) {
			this.userNm = userNm;
			return this;
		}

		public PrgmUseHistBuilder setConnIp(String connIp) {
			this.connIp = connIp;
			return this;
		}

		public PrgmUseHistBuilder setConnTypeCd(String connTypeCd) {
			this.connTypeCd = connTypeCd;
			return this;
		}

		public PrgmUseHistBuilder setWhCd(String whCd) {
			this.whCd = whCd;
			return this;
		}

		public PrgmUseHistBuilder setMenuCd(String menuCd) {
			this.menuCd = menuCd;
			return this;
		}

		public PrgmUseHistBuilder setSrvcNm(String srvcNm) {
			this.srvcNm = srvcNm;
			return this;
		}

		public PrgmUseHistBuilder setMthdNm(String mthdNm) {
			this.mthdNm = mthdNm;
			return this;
		}

		public PrgmUseHistBuilder setRegUserId(String regUserId) {
			this.regUserId = regUserId;
			return this;
		}

		public PrgmUseHistVO build() {
			PrgmUseHistVO vo = new PrgmUseHistVO();
			vo.setUserId(userId);
			vo.setUserNm(userNm);
			vo.setConnIp(connIp);
			vo.setConnTypeCd(connTypeCd);
			vo.setWhCd(whCd);
			vo.setMenuCd(menuCd);
			vo.setSrvcNm(srvcNm);
			vo.setMthdNm(mthdNm);
			vo.setRegUserId(regUserId);
			
			return vo;
		}
	}
	
	class PrgmErrHistBuilder {
		private String errCont;
		private String occurDtime;
		private String connIpAddr;
		private String srvrIpAddr;
		private String rqstUrl;
		private String regUserId;
		
		public PrgmErrHistBuilder setErrCont(String errCont) {
			this.errCont = errCont;
			return this;
		}

		public PrgmErrHistBuilder setOccurDtime(String occurDtime) {
			this.occurDtime = occurDtime;
			return this;
		}

		public PrgmErrHistBuilder setConnIpAddr(String connIpAddr) {
			this.connIpAddr = connIpAddr;
			return this;
		}

		public PrgmErrHistBuilder setSrvrIpAddr(String srvrIpAddr) {
			this.srvrIpAddr = srvrIpAddr;
			return this;
		}

		public PrgmErrHistBuilder setRqstUrl(String rqstUrl) {
			this.rqstUrl = rqstUrl;
			return this;
		}

		public PrgmErrHistBuilder setRegUserId(String regUserId) {
			this.regUserId = regUserId;
			return this;
		}

		public PrgmErrHistVO build() {
			PrgmErrHistVO vo = new PrgmErrHistVO();
			vo.setErrCont(errCont);
			vo.setOccurDtime(occurDtime);
			vo.setConnIpAddr(connIpAddr);
			vo.setSrvrIpAddr(srvrIpAddr);
			vo.setRqstUrl(rqstUrl);
			vo.setRegUserId(regUserId);
			
			return vo;
		}
	}
}

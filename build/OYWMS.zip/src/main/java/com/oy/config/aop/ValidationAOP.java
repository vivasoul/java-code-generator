package com.oy.config.aop;

import java.util.Map;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.Configuration;

import com.oy.config.annotation.ValidateMembers;
import com.oy.config.exception.NoSuchDataSetException;
import com.oy.config.exception.RequiredEmptyException;
import com.oy.config.mvc.Parameters;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Aspect
@Slf4j
public class ValidationAOP {
	
	@Pointcut("within(com.oy..service.*Service) && execution(public * *(..)) && args(parameters)")
	public void fieldValidationPointCut(Parameters parameters){};
	
	
	@Before( value = "fieldValidationPointCut(parameters) && @annotation(validateMems)")
	public void doVaidate(JoinPoint jpoint, Parameters parameters, ValidateMembers validateMems) 
			throws NoSuchDataSetException, RequiredEmptyException{
		
		String methodName = jpoint.getSignature().toShortString();
		log.info("Start validation for the call: "+methodName);
		
		String dsName = validateMems.dsName();
		if(dsName != null && !dsName.isEmpty()) {
			Map<String, Object> row = parameters.getFirstRow(dsName);
			log.debug("Checking validation for the row : "+row);
			String[] members = validateMems.members();
			for(String mem: members) {
				
				if(isEmpty(row, mem)) {
					throw new RequiredEmptyException(mem, methodName);
				}
			}
		} else {
			log.warn("A dataset name is empty for the validation at call of ["+methodName+"]");
		}
	}
	
    private boolean isEmpty(Map<String, Object> parameter, String columnName) {
        if (parameter == null || !parameter.containsKey(columnName)) {
            log.error("invalid parameter : {}", parameter);
            return true;
        } else {
            Object value = parameter.get(columnName);
            if (value == null) {
                log.error("invalid parameter[{}] : {}", columnName, value);
                return true;
            } else if (value instanceof String) {
                if (value.toString().isEmpty()) {
                    log.error("invalid parameter[{}] : {}", columnName, value);
                    return true;
                }
            }

            return false;
        }
    }
}

package com.oy.common.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.oy.wms.syst.mgmt.SystLangMapper;

@Component
public class CommonLang {

	@Autowired
	private SystLangMapper systLangMapper;
	private static SystLangMapper postSystLangMapper;
	
	
	@PostConstruct
    private void initialize() {
		// static 사용을 위해 PostConstruct로 매퍼 주입
        this.postSystLangMapper = systLangMapper;
    }
	
	/*
	 * 언어 코드 / 메세지 코드에 맞는 메세지를 반환한다.
	 */
	public static String select(String cntry_lang_cd, String msg_cd, String default_msg) {
		Map<String, Object> msgMapper = new HashMap<String, Object>();
		msgMapper.put("CNTRY_LANG_CD", cntry_lang_cd);
		msgMapper.put("MSG_CD", msg_cd);		
		//String msg = Optional.ofNullable(postSystLangMapper.selectCommonMsg(msgMapper)).orElse(default_msg);
		return "";
    }    
}

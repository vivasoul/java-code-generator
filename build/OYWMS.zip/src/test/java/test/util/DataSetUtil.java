package test.util;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.springframework.core.io.ClassPathResource;

import com.nexacro.java.xapi.data.DataSet;
import com.nexacro.java.xapi.data.PlatformData;
import com.nexacro.java.xapi.tx.PlatformRequest;
import com.nexacro.java.xapi.tx.PlatformType;
import com.nexacro.uiadapter.spring.core.data.convert.ConvertDefinition;
import com.nexacro.uiadapter.spring.core.data.convert.NexacroConvertException;
import com.nexacro.uiadapter.spring.core.data.support.DataSetToListConverter;
import com.nexacro.uiadapter.spring.core.data.support.DataSetToObjectConverter;
import com.nexacro.uiadapter.spring.core.data.support.ListToDataSetConverter;
import com.oy.config.mvc.Parameters;

public class DataSetUtil {
	private static final DataSetToListConverter ds2ListConverter = new DataSetToListConverter();
	private static final ListToDataSetConverter list2DsConverter = new ListToDataSetConverter();
	private static final DataSetToObjectConverter ds2ObjConverter = new DataSetToObjectConverter();
	
	
	public static DataSet readXMLData(String path) throws Exception{
		return readXMLData(path, null);
	}
	
	public static DataSet readXMLData(String path, String dataSetName) throws Exception{
		
		InputStream is = null;
		DataSet ds = null;
		try {
				
			is = new ClassPathResource(path).getInputStream();
			// 파일로부터 데이터 읽기
			PlatformRequest req = new PlatformRequest(is, PlatformType.CONTENT_TYPE_XML);
			req.receiveData();
			
			PlatformData data = req.getData();
			
			if(dataSetName == null || dataSetName.isEmpty()) {
				ds = data.getDataSet(0);
			} else {
				ds = data.getDataSet(dataSetName);
			}
			
			if(ds == null) {
				throw new Exception("Can not read the dataset with name: "+dataSetName);
			} else {
				return ds;
			}
			
		} catch(Exception ex) {
			ex.printStackTrace();
			throw ex;
		} finally {
			if(is != null) try { is.close(); } catch(Exception e) { }	
		}
	}
	
	public static List<Map<String,Object>> readXMLDataInList(String path) throws Exception {
		return readXMLDataInList(path, null);
	}
	
	public static List<Map<String,Object>> readXMLDataInList(String path, String dataSetName) throws Exception {
		DataSet dataSet = readXMLData(path, dataSetName);
		List<Map<String,Object>>  list = dataSet2List(dataSet);
		
		return list;
	}	
	

	
	public static DataSet extractOutDataSetFromParameters(Parameters paraemters, String dataSetName) throws NexacroConvertException {
		
		if(dataSetName == null) {
			return null;
		} else {
			Map<String, List<Map<String, Object>>> outDataSetList = paraemters.getOutDatasetList();
			if(outDataSetList.containsKey(dataSetName)) {
				List<Map<String, Object>> list = outDataSetList.get(dataSetName);
				return list2DataSet(list, dataSetName);
			} else {
				return null;
			}
		}
	}
	
	public static List<Map<String,Object>> dataSet2List(DataSet ds) throws NexacroConvertException {
	    ConvertDefinition definition = new ConvertDefinition();
	    definition.setName(ds.getName());
	    definition.setGenericType(Map.class);
		return ds2ListConverter.convert(ds, definition);
	}
	
	public static DataSet list2DataSet(List<Map<String,Object>> list, String dataSetName) throws NexacroConvertException {
	    ConvertDefinition definition = new ConvertDefinition();
	    definition.setName(dataSetName);
		return list2DsConverter.convert(list, definition);
	}
	
	public static <T>T dataSet2Object(DataSet ds, Class<T> clazz) throws NexacroConvertException {
	    ConvertDefinition definition = new ConvertDefinition();
	    definition.setName(ds.getName());
	    definition.setGenericType(clazz);
		return (T) ds2ObjConverter.convert(ds, definition);
	}	

}

package test.util;

import java.lang.reflect.Method;
import java.util.List;

import org.springframework.context.ApplicationContext;

import com.oy.config.mvc.Parameters;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BulkTest {
	
    public static void runTest(ApplicationContext applicationContext, Parameters parameters, String serviceName, List<String> methods) {
    	Object obj = applicationContext.getBean(serviceName);
    	log.info("Test Begins");
    	log.info("ServiceName : " + serviceName);
    	methods.forEach((methodName) -> {
			try {
				log.info("Testing Method : " + methodName);
				Method method = obj.getClass().getMethod(methodName, Parameters.class);
				Parameters result = (Parameters)method.invoke(obj, parameters);
				log.info("Test Result : " + result.getErrCode());
			} catch (Exception e) {
				log.error("Error Method Name : " + methodName);
				log.error("error msg : " + e.getMessage());
			} 
    	});
    }    
}

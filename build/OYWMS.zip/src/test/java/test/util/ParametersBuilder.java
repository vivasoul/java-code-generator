package test.util;

import com.nexacro.java.xapi.data.DataSet;
import com.nexacro.java.xapi.data.DataSetList;
import com.nexacro.java.xapi.data.PlatformData;
import com.nexacro.java.xapi.data.Variable;
import com.nexacro.java.xapi.data.VariableList;
import com.oy.config.mvc.Parameters;

public class ParametersBuilder {
	
    private PlatformData platformData = new PlatformData();
    private DataSetList datasetList = new DataSetList();
    private VariableList variableList = new VariableList();
    
    public ParametersBuilder() {
	  	platformData = new PlatformData();
	    datasetList = new DataSetList();
	    variableList = new VariableList();
	}
    
    public ParametersBuilder addDataSet(DataSet ds) {
    	
    	return addDataSet(null, ds);
    }
    
    public ParametersBuilder addDataSet(String dataSetName, DataSet ds) {
    	
    	if(dataSetName != null && !dataSetName.isEmpty()) ds.setName(dataSetName);
    	datasetList.add(ds);
    	return this;
    }
    
    public ParametersBuilder addVariable(Variable variable) {
    	
    	variableList.add(variable);
    	return this;
    }

    public ParametersBuilder addVariable(String key, Object value) {
    	Variable variable = new Variable(key);
    	variable.set(value);
    	
    	return addVariable(variable);
    }
    
    public Parameters build() {
    	Parameters parameters =  new Parameters();
    	
    	platformData.setDataSetList(datasetList);
    	platformData.setVariableList(variableList);
    	
    	parameters.setPlatformData(platformData);
    	parameters.setDatasetList(datasetList);
    	parameters.setVariableList(variableList);
    	
    	return parameters;
    }
}

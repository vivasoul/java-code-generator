package test.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.nexacro.java.xapi.data.DataSet;
import com.nexacro.java.xapi.data.DataTypes;

import lombok.Setter;

public class DataSetBuilder {
    
    
    public static DataSet makeDataSet(String name, Map<String, ?> row) {
        List<Map<String, ?>> rows = new ArrayList<>();
        rows.add(row);
        
        return makeDataSet(name, rows);
    }
    
    public static DataSet makeDataSet(String name, List<Map<String, ?>> rows) {
        DatasetBuilder builder = new DatasetBuilder();
        builder.setName(name);
        builder.setRows(rows);
        
        return builder.getDataSet();
    }    
    
    static class DatasetBuilder {
        
        @Setter
        String name;

        @Setter
        List<Map<String, ?>> rows;
        
        DataSet getDataSet() {
            DataSet dataset = new DataSet(name);
            
            for(String columnName : rows.get(0).keySet()) {
            	dataset.addColumn(columnName, DataTypes.STRING);
            }

            int row = dataset.newRow();
            for(String columnName : rows.get(0).keySet()) {
            	dataset.set(row, columnName, rows.get(0).get(columnName));
            }
            return dataset;
        }
    }
}
